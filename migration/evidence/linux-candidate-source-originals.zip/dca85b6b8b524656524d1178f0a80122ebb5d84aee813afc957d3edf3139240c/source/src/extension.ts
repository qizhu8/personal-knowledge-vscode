import { PanelRegistry, clonePanelSnapshot as panelsSnapshot } from "./ui/panel-registry";
import { withCrossProcessLock } from "./runtime/cross-process-lock";
import { assertPkmWatchRootAllowed, createBoundedFileWatcher, isPkmWatchDirectory } from "./runtime/bounded-file-watcher";
import { stableUserPort } from "./runtime/user-service-ports";
import { KnowledgeInventoryManager, notesFromInventoryOrFallback } from "./knowledge/knowledge-inventory";
import { BackgroundProcessInventory } from "./runtime/background-processes";
import { panelSearchTarget } from "./retrieval/panel-search";
import { performanceSummary, recordPerformanceMetric, recordPerformanceMetrics } from "./runtime/performance-telemetry";
import { PKM_ENTRY_POINTS, projectExecution } from "./runtime/pkm-projection";
import { baselineReport, recordBaselineEvent } from "./runtime/pkm-baseline";
import { mcpUsageSummary, recipeNodeUsageSummary, todoUsageSummary } from "./mcp/mcp-usage";
import { agentSnapshotIsEncrypted, createAgentSnapshot, deleteAgentSnapshot, listAgentSnapshots, renameAgentSnapshot, readAgentSnapshotContents } from "./agent-sessions/agent-snapshots";
import { agentSessionArchiveKeepLatestK, agentSessionLiveness, pkmOwnedAgentSession, retireNonPkmAgentSessions, emptyAgentSessionTrash, enforceAgentSessionArchiveRetention, moveAgentSessionToTrash, permanentlyDeleteTrashedAgentSession, projectedAgentSessionStatus, recipeNodeObservability, reconcileAgentSessionActiveMappings, restoreAgentSessionFromTrash, stopAgentSession } from "./agent-sessions/agent-session-lifecycle";
import { JsonFileCache } from "./runtime/json-file-cache";
import { agentSessionGroup } from "./agent-sessions/agent-session-lifecycle";
import { deleteAgentSessionGroup } from "./agent-sessions/agent-session-lifecycle";
import { DiagnosticLog } from "./runtime/diagnostic-log";
import { RetainedJsonlLog } from "./runtime/retained-jsonl-log";
import { createChatKnowledgeRetriever } from "./chat/chat-knowledge-retriever";
import { ExtensionHostRegistry, loadedExtensionBuild, readInstalledExtensionBuild } from "./runtime/extension-host-runtime";
import * as vscode from "vscode";
import * as path from "path";
import * as os from "os";
import * as http from "http";
import * as net from "net";
import * as fs from "fs";
import { syncServer, attachMarkdownAssetsToSyncBundle } from "./sync/sync-server";
import { MAX_SUBSCRIPTION_CACHE_BYTES, SharedContentType, SharedMarketManager, SHARED_CONTENT_TYPES } from "./subscriptions/subscriptions";
import { brokerShareMarkers, sharedContentIdentity } from "./subscriptions/broker-share-markers";
import { isContentItemPrivate, isContentPathPrivate, isTopLevelPrivate, privateTopLevels, PrivacyContentType, renameTopLevelPrivacy, setPrivacyStoreRoot, setTopLevelPrivacy } from "./knowledge/content-privacy";
import { knowledgeGroupAssign, knowledgeGroupCreate, knowledgeGroupDelete, knowledgeGroupFolderRenamed, knowledgeGroupRename, knowledgeGroupSetColor, knowledgeGroupSnapshot, KnowledgeGroupArea, setKnowledgeGroupStoreRoot } from "./knowledge/knowledge-groups";
import { forkSubscriptionContent } from "./subscriptions/subscription-fork";
import {
  skillList, skillSearch, skillGet, skillUpsert, skillDelete, skillMoveCategory, skillMove, skillSetPinned,
  skillMoveToTrash, skillFolderMoveToTrash, skillTrashList, skillTrashRestore, skillTrashEmpty, skillTrashDelete,
  knowledgeMoveToTrash, knowledgeTrashList, knowledgeTrashRestore, knowledgeTrashDelete, knowledgeTrashEmpty, KnowledgeTrashArea,
  noteList, noteSearch, noteGet, noteUpsert, noteDelete, slugExists, noteMove, noteMoveFolder, noteSetPinned, noteFolderPins, noteSetFolderPinned,
  noteExport, noteImport, saveNoteAsset,
  noteWorkItemsRead, noteWorkItemCommand, noteWorkItemNotes, todoBoardCreate, todoBoardGrantWorker,
  paperList, paperSearch, paperGet, paperUpsert, paperDelete, paperMoveAllToTrash,
  migrateLegacyMyIdeasFolder,
  paperFacets, paperGraph, savePaperFile,
  paperGroups, paperSetGroup, paperGroupRename, paperGroupDelete, paperSetPinned, paperSetTopic,
  setStorePath as fsSetStorePath, getStorePath,
  folderCreate, folderList, folderRename, folderDeletePromote, storeEntryMove, storeSafeName, knowledgeFilePath,
  SkillPriority,
} from "./knowledge/filestore";
import { checkedMarkdownPath, importMarkdownAssetBundle, isMarkdownAssetDirectory, MarkdownAssetArea, markdownAssetDirectory, markdownBundleDocuments, listedMarkdownAssets } from "./knowledge/markdown-assets";
import { manageMarkdownAssets } from "./ui/markdown-assets";
import { reviewAssetClassification, reviewAssetClassificationRollback } from "./ui/asset-classification";
import { importGitPackage, updateGitPackage } from "./knowledge/git-package";
import { migrateDbToFiles } from "./knowledge/migrate";
import {
  initServers, disposeServers, serverList, serverImport, serverImportGit, serverUpdateGit, serverCreate,
  serverUpdate, serverGroupList, serverCreateGroup, serverMoveGroup, serverPortOwner, serverNetworkAddresses, forceStopExternalServer, serverDelete, startServer, stopServer, restartServer, setServerPort, serverLog, serverDir,
} from "./servers/servers";
import { ChatHub, ChatClient, ChatMessage, Member, FileMeta, AgentRuntimeState, ChatMode, ReplyPolicy, MAX_FILE_BYTES } from "./chatroom/chatroom";
import { PeerSession } from "./chatroom/peer-session";
import { executePortalCommand, parsePortalCommand, portalCommandCapabilities } from "./chatroom/portal-command";
import { selectPortalRoute } from "./chatroom/portal-routing";
import { cleanupLegacyPortals } from "./chatroom/portal-cleanup";
import { boundPortalToolOutputs } from "./chatroom/portal-observation";
import { assertPeerEndpoint, PORTAL_TRANSPORT_PATH } from "./chatroom/peer-protocol";
import { createPortalLink, parsePortalLink, preflightPortalEndpoint } from "./chatroom/portal-link";
import { configurePortalRuntime, onPortalChanged, portalChanged, PortalObserver, PortalSource, PortalReview } from "./chatroom/portal-runtime";
import { endpointScope, portalConnectionAccess, PortalConnectionJournal, PortalConnectionLive, PortalConnectionSnapshot, type PortalHubPortStatus } from "./chatroom/portal-connections";
import { PortalEndpointStore, portalEndpointAllowsExternalAccess, type PortalEndpointRecord } from "./chatroom/portal-endpoint-store";
import { PortalPermissions, PORTAL_PERMISSION_DIMENSIONS } from "./chatroom/portal-permissions";
import { toolPermissionScope } from "./chat/permissions";
import { PortalFiles, PortalTransferStatus } from "./chatroom/portal-files";
import { chatroomImageMime, decodeChatroomImages, MAX_CHATROOM_IMAGE_BYTES } from "./chatroom/chatroom-images";
import { MeetingStateStore, MeetingRoomSnapshot } from "./chatroom/meeting-state";
import { ChatMeetingLifecycle, isFinalLeadSummary } from "./chatroom/chat-meeting-lifecycle";
import { messageAddressesManagedAgent } from "./chatroom/chat-managed-agent-routing";
import { BOT_NAME } from "./chatroom/chat-commands";
import { StoredChatRoom } from "./chatroom/chat-room-lifecycle";
import { chatRoomIdentity, joinedRoomRecents } from "./chatroom/chat-room-identity";
import { probeChatRoomActive } from "./chatroom/chat-hub-health";
import {
  initPyenvs, pyenvList, pyenvAdd, pyenvUpdate, pyenvDelete,
  condaEnvs, detectFolderEnv, pyenvPackages, pyenvCompare,
  pyenvSize, pyenvActivateScript, pyenvActivateCommands, pyenvCreate, pyenvSimilarity, pyenvPyVersion, pyenvMigrate, pyenvDeleteScript, pyenvMergeScript,
} from "./servers/pyenvs";
import {
  promptList, promptGetFile, promptGetAllVersionsOfFile, promptFilePath, promptSaveVersionNote,
  packageList, packageGet, packageFileGet, packageDelete,
  scriptList, scriptSearch, scriptGet, scriptMove, scriptMoveFolder,
  promptImport, scriptImport, packageImport,
  setStorePath as storageSetStorePath,
} from "./knowledge/storage";

// ── Git helper ─────────────────────────────────────────────────────────────
import { execFile, execSync } from "child_process";
import { createHash, randomBytes, randomUUID } from "crypto";
import { createSyncMagicCode, parseSyncMagicCode } from "./sync/sync-magic-code";
import { createChatMagicLink, chatInviteMessage } from "./chatroom/chat-magic-link";
import { startLiveMarkdownServer } from "./knowledge/live-note-server";
import { manageBrowserTodo } from "./ui/note-todo-management";
import { browserFaviconTag, browserIconBuffer, ensureBrowserFavicon } from "./ui/browser-branding";
import { browserNoteTodo } from "./ui/note-todo-browser";
import { managedEnvironmentsRoot } from "./runtime/environment-paths";
import { defaultKnowledgeGitignore } from "./runtime/root-storage-policy";
import { NavigationStatus, summarizeChatNavigation, summarizeServerNavigation } from "./ui/navigation-status";
import { navigationItemPath } from "./ui/navigation-path";
import { parsePkmLocator, PkmLocatorError, resolvePkmLocator, ResolvedPkmLocator } from "./knowledge/knowledge-locator";
import { subscriptionNavigationRoot, SubscriptionNavigationNode } from "./ui/navigation-subscriptions";
import { createRetrievalSnapshot } from "./retrieval/retrieval-snapshot";
import { RetrievalWorkerManager, type RetrievalWorkerStatus } from "./retrieval/retrieval-worker";
import { cloudSynchronizedPath, extensionHostDescription, isAbsoluteForPlatform, isForeignAbsolutePath, resolveMachineStorePath } from "./knowledge/store-path";
import { loadLocaleCatalogs, loadLocaleManifest, localizedText, normalizeUiLanguage, resolveUiLanguage, UiLanguageSetting, uiLanguageSetting } from "./ui/localization";
import { readHelpGuide } from "./ui/help-guide";
import { decideInitialExperience, FEATURE_TOUR_MODULES, minorRelease } from "./ui/onboarding-experience";
import { AiBackend, aiSummarizeScript, listAiBackends, runAiPrompt, scriptCacheDir } from "./ai/ai";
import { registerApiChatShell, setChatStartupTrace } from "./chat/api-chat-shell";
import { configureCopilotSdk, disposeCopilotSdk } from "./chat/api-chat-copilot-sdk";
import { PersonaProfileStore, type PersonaSnapshot } from "./chat/persona-profiles";
import { configureUserProfile } from "./chat/persona-profile-ui";
import { requestNativePortalInteraction } from "./chat/portal-native-interaction";
import { authorizeGitHubSyncProfiles } from "./sync/github-sync-profiles";
import { actionRequest, initializeActionCommands, openActionLibrary, openActionWorkbench, openActionWorkbenchInBrowser, renderEmbeddedActionWorkbench, renderEmbeddedActionLibrary, handleActionWorkbenchMessage, handleActionLibraryMessage } from "./ui/action-browser";
import { createNativeHarnessServer } from "./runtime/native-harness-server";
import { readHarnessActions } from "./runtime/native-harness-actions";
import { projectCockpits } from "./workflows/project-cockpit";
import { inspectWorkItem, projectWorkItemProgress, WorkItemReference } from "./knowledge/work-item-progress";
import { handleProjectCockpitRequest, promoteChatProject, actionRunProject } from "./workflows/project-cockpit-host";
import { agentSessionOrigin, apiChatGroupSnapshots, apiChatSessionHarnessSnapshot, verifyHarnessArtifacts } from "./chat/api-chat-store";
import {
  cancelMcpPythonScan, combinedMcpRegistry,
  configuredMcpFeatureDomains, detectMcpPython, ensureMcpRuntime as ensureMcpRuntimeWithProgress, McpRuntimeProgress, generateMcpServer, MCP_FEATURE_DOMAINS, McpFeatureDomain,
  managedMcpRuntimePath, managedMcpServerDirectory, mcpProcessStatus, mcpRuntimeManualCommands, mcpRuntimeStatus, mcpRuntimeStatusAsync, warmMcpPythonProbes, mcpServerDefinitionData, mcpStatus, streamMcpPythonCandidates,
  resolveMcpPython, validateMcpPython, writeMcpFeatureDomainConfig, writeActionWorkspaceConfig, trashKnowledgeFileViaMcp,
} from "./mcp/mcp";
import { nativeMcpCwdUri } from "./mcp/mcp-native-location";
import { configureManagedMcpAttribution } from "./mcp/mcp-attribution";
import { readAccountMcpBinding, writeAccountMcpBinding, accountKnowledgeSecurity } from "./mcp/mcp-account-binding";
import { assertNoManualPkm, copilotMcpConfigPath, copilotMcpDefinition, inspectCopilotMcpRegistration, parseNativeMcpConfiguration, registerCopilotMcp, inspectVscodeMcpRegistration, registerVscodeMcp } from "./mcp/mcp-client-registration";
import { scheduleRestoredWebviewRecovery } from "./ui/webview-restoration";
import {
  disconnectPkmSkill, retirePkmSkillProjections,
} from "./skills/pkm-skill-projection";
import { cachedPromptAnalysis, inspectPromptCached, renderPrompt } from "./ui/prompt-manager";
import { canonicalJson, compileWorkflowDefinitionV1, WorkflowDefinitionV1 } from "./workflows/workflow-contracts";
import { ProjectStore, ProjectStoreCommand } from "./workflows/project-store";
import { GanttTaskInput, ProjectModelError, RecipeKnowledgeBinding, RecipeMetadata, RecipeRecord } from "./workflows/project-model";
import { CollaborationMessageMetadata, CollaborationTransition } from "./chatroom/collaboration-model";
import { BundledKnowledgeContent, exportProjectRecipeBundle } from "./workflows/project-recipe-bundle";
import { recipeBrowserEditorDocument } from "./ui/recipe-browser";
import { availableSkillRouterSources, normalizeSkillRouterSourcePriority, SkillRouterSource } from "./skills/skill-router-config";
import {
  GITHUB_SYNC_CONTENT_TYPES, GitHubPublicationMigration, GitHubPublicationMigrationSource, GitHubSyncCatalog, GitHubSyncConflictError, GitHubSyncContentType, GitHubSyncCredentials, GitHubSyncExtensionCompatibilityError, GitHubSyncFolderFingerprints, GitHubSyncRecipePull, GitHubSyncRecipeDelete, GitHubSyncTarget, githubSyncMigrationCanonicalFiles,
  completeGitHubSyncTransaction, validateGitHubSyncTransaction, createGitHubSyncIdentity, discoverGitHubCredentialManagerAccounts, discoverGitHubSshIdentities, fetchGitHubRemoteSnapshot, githubSyncAuthenticationSessionOptions, githubSyncEntryShields, githubSyncExcludedPaths, githubSyncFolderShields, githubSyncIgnoredPath, githubSyncIsTextContent, githubSyncManagedContent, githubSyncManifestFileFingerprints, githubSyncManifestFolderFingerprints, githubSyncResultIsNoChange, githubSyncSafeRelativePath, githubSyncShield, githubSyncShieldReasons, normalizeGitHubSyncTarget, previewGitHubSyncTarget,
  applyGitHubRemoteAuthority, completeGitHubRemoteAuthorityBackup, githubSyncLocalFingerprints, previewGitHubRemoteAuthority, probeGitHubSyncAuthentication, probeGitHubSyncHttpsAuthentication, probeGitHubSyncVscodeAuthentication, readGitHubCachedManifest, readGitHubRemoteFile, readGitHubRemoteFilesForSubscription, readGitHubRemoteManifest, replaceGitHubSyncFilesAtomically, restoreGitHubRemoteFiles, testGitHubSyncAuthentication,
  inspectGitHubSyncLocalContent,
} from "./sync/github-sync";
import { githubSyncCatalogInWorker } from "./sync/github-sync-catalog-worker";
import { githubSyncFingerprintInWorker } from "./sync/github-sync-fingerprint-worker";
import {
  clearGitHubSyncConflict, GitHubSyncAgentReview, gitHubSyncConflictVariantPath, listGitHubSyncConflicts, readGitHubSyncConflict,
  readGitHubSyncConflictCandidate, refreshGitHubSyncConflictLocalCandidate, selectAllGitHubSyncConflictCandidates, selectAllGitHubSyncConflictDeletions,
  selectAllGitHubSyncConflictLocalDeletions, selectGitHubSyncConflictCandidate, selectGitHubSyncConflictDeletion,
  selectGitHubSyncConflictLocalDeletion, storeGitHubSyncConflict, updateGitHubSyncAgentCandidate,
  validateGitHubSyncConflictLocalState, validateGitHubSyncManualCandidate, validateGitHubSyncConflictVersion, validateGitHubSyncConflictScriptIdentity,
  saveGitHubSyncManualCandidate, markGitHubSyncConflictApplied, markGitHubSyncConflictApplying,
} from "./sync/github-sync-conflicts";
import { GitHubSyncWorkbenchRequest, GitHubSyncWorkbenchState, openGitHubSyncConflictWorkbench } from "./sync/github-sync-workbench";
import { GitHubSyncDeferredError, GitHubSyncReason, GitHubSyncRuntimeState, githubSyncFailureDetails, isGitHubSyncAuthenticationFailure } from "./sync/github-sync-scheduler";
import { GitHubSyncCredentialError, readStoredGitHubSyncCredentials } from "./sync/github-sync-credentials";
import type { GitHubSyncResult } from "./sync/github-sync";
import { archiveSupersededGitHubSyncResult } from "./sync/github-sync-recovery";
import { githubSyncCoordinatorDirectory, sameKnowledgeRoot } from "./sync/github-sync-coordinator";
import {
  GitHubSyncContentRepairError, applyGitHubSyncEmptyMarkerCandidate, clearGitHubSyncContentRepair,
  contentRepairDigest, contentRepairSource, inspectConflictMarkers, readGitHubSyncContentRepair, storeGitHubSyncContentRepair,
} from "./sync/github-sync-content-repair";
import { PkmServiceClient, PkmServiceRecoveryPersistenceError } from "./runtime/pkm-service";
import { BackgroundTaskProducer, BackgroundTaskRegistry } from "./runtime/background-task-registry";
import { ActionBackgroundTasks } from "./runtime/action-background-tasks";
import { StatusDashboard, dashboardSyncTargets, indexBuildPercent } from "./ui/status-dashboard";

let projectStoreBinding: { root: string; store: ProjectStore } | undefined;

function currentProjectStore(): ProjectStore {
  const root = path.resolve(getStorePath());
  if (!projectStoreBinding || projectStoreBinding.root !== root) {
    projectStoreBinding = { root, store: new ProjectStore(path.join(root, ".pkm", "state")) };
  }

  return projectStoreBinding.store;
}

function projectCommand(store: ProjectStore, operation: string, input: object): ProjectStoreCommand {
  return {
    commandId: randomUUID(),
    fingerprint: createHash("sha256").update(canonicalJson({ operation, input }), "utf8").digest("hex"),
    expectedStoreVersion: store.list().storeVersion
  };
}

function knowledgeTags(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  try { const parsed = JSON.parse(String(value || "[]")); return Array.isArray(parsed) ? parsed.map(String) : []; }
  catch { return []; }
}

function projectRecipeKnowledge(kind: "skill" | "note", knowledgeId: string): BundledKnowledgeContent {
  const parts = knowledgeId.split("/").filter(Boolean);
  if (!parts.length || parts.some(part => part === "." || part === "..")) throw new Error(`Knowledge binding has an invalid identity: ${knowledgeId}`);
  let document: Record<string, unknown>;
  if (kind === "skill") {
    const item = skillGet(parts[parts.length - 1]);
    if (!item || [item.category, item.name].filter(Boolean).join("/") !== knowledgeId) throw new Error(`Bound Skill was not found: ${knowledgeId}`);
    document = { name: item.name, description: item.description || "", category: item.category || "", tags: knowledgeTags(item.tags), content: item.content || "" };
  } else {
    const item = noteGet(knowledgeId);
    if (!item) throw new Error(`Bound Note was not found: ${knowledgeId}`);
    document = { title: item.title, type: item.type || "general", category: item.category || "", tags: knowledgeTags(item.tags), content: item.content || "" };
  }
  const contentHash = createHash("sha256").update(canonicalJson(document), "utf8").digest("hex");
  return { knowledgeId, kind, contentHash, document };
}

function recipeReferenceCatalog(): Record<"skills" | "notes", any[]> {
  return {
    skills: (skillList() as any[]).map(row => ({
      id: [row.category, row.name].filter(Boolean).join("/"),
      label: row.name,
      cat: row.category || "",
      treePath: row.category || "(uncategorized)",
      meta: compactTags(row.tags)
    })),
    notes: (noteList(undefined, 500) as any[]).map(row => ({
      id: row.slug,
      label: row.title,
      cat: row.category || "",
      treePath: row.category || "(uncategorized)",
      meta: row.type || "note"
    }))
  };
}

const agentSessionJsonCache = new JsonFileCache(512);

function agentSessionSnapshots(recipes: any[], directory = path.join(getStorePath(), ".pkm", "state", "agent-sessions"), selectedSessionId?: string, includeExternal = false): any[] {
  const storeRoot = getStorePath();
  const runsDirectory = path.join(storeRoot, ".pkm", "state", "recipe-runs");
  if (!fs.existsSync(directory)) return [];
  const recipeNames = new Map(recipes.map(recipe => [String(recipe.recipeId || ""), String(recipe.name || recipe.recipeId || "Recipe")]));
  const runErrors = new Map<string, string>();
  const readRun = (runId: string): any | undefined => {
    try {
      if (!/^recipe_run_[A-Za-z0-9_-]+$/.test(runId)) throw new Error("Invalid Recipe Run identity.");
      const run = agentSessionJsonCache.read<any>(path.join(runsDirectory, `${runId}.json`));
      if (run?.schema !== "pkm.recipe.run/v1" || run?.runId !== runId) throw new Error("Recipe Run identity mismatch.");
      const definitions = Array.isArray(run?.definition?.spec?.nodes) ? run.definition.spec.nodes : [];
      return {
        runId,
        recipeId: String(run.recipeId || ""),
        recipeName: String(run.recipeName || recipeNames.get(String(run.recipeId || "")) || run.recipeId || "Task plan"),
        origin: run.origin && typeof run.origin === "object" ? { kind: String(run.origin.kind || "library") } : { kind: "library" },
        recipeRevision: Number(run.recipeRevision || 0),
        executableDigest: String(run.executableDigest || ""),
        definition: run.definition,
        status: String(run.status || "unknown"),
        projection: projectExecution("recipe-runtime", String(run.status || "unknown"), {
          waiting: Object.values(run.nodes || {}).some((record: any) => !!record.progress?.waitingOn),
        }),
        traversalStrategy: String(run.definition?.spec?.traversalStrategy || ""),
        parent: run.parent && typeof run.parent === "object"
          ? { runId: String(run.parent.runId || ""), nodeId: String(run.parent.nodeId || "") } : undefined,
        createdAt: String(run.createdAt || ""),
        updatedAt: String(run.updatedAt || ""),
        usage: run.usage && typeof run.usage === "object" ? run.usage : undefined,
        nodes: definitions.map((node: any) => {
          const record = run.nodes?.[node.nodeId] || {};
          return {
            nodeId: String(node.nodeId || ""),
            kind: String(node.kind || ""),
            instruction: String(node.generalInstruction || ""),
            dependsOn: (Array.isArray(node.dependsOn) ? node.dependsOn : []).map((dependency: any) => ({
              from: String(dependency.from || ""),
              accept: Array.isArray(dependency.accept) ? dependency.accept.map(String) : [],
              loop: !!dependency.loop,
            })),
            control: node.control && typeof node.control === "object" ? node.control : { mode: "single" },
            state: String(record.state || "pending"),
            projection: projectExecution("recipe-runtime", String(record.state || "pending"), {
              waiting: node.kind === "pkm.gate.human/v1" && record.state === "running" || !!record.progress?.waitingOn,
              interrupted: recipeNodeObservability(record).state === "intervention-required" && record.state === "running",
              ...(node.kind === "pkm.gate.human/v1" ? { nextOwner: "user" as const } : {}),
            }),
            outcome: String(record.outcome || ""),
            error: String(record.error || ""),
            attempt: record.attempt,
            result: record.result,
            config: node.config,
            childRunId: String(record.childRunId || ""),
            startedAt: String(record.startedAt || ""),
            lastHeartbeatAt: String(record.lastHeartbeatAt || ""),
            lastProgressAt: String(record.lastProgressAt || ""),
            progress: record.progress && typeof record.progress === "object" ? record.progress : undefined,
            usage: recipeNodeUsageSummary(runId, String(node.nodeId || ""), run.usage),
            observability: recipeNodeObservability(record),
            background: record.background && typeof record.background === "object" ? {
              state: String(record.background.state || ""),
              launcherPid: Number(record.background.launcherPid || 0),
              startedAt: String(record.background.startedAt || ""),
            } : undefined,
          };
        }),
        loops: Object.values(run.loops && typeof run.loops === "object" ? run.loops : {}).map((loop: any) => ({
          source: String(loop.source || ""), target: String(loop.target || ""), state: String(loop.state || ""),
          iteration: Number(loop.iteration || 0), maxIterations: Number(loop.maxIterations || 0),
          condition: String(loop.condition || ""),
          history: Array.isArray(loop.history) ? loop.history : [],
        })),
      };
    } catch (error) { runErrors.set(runId, error instanceof Error ? error.message : String(error)); return undefined; }
  };
  const snapshots: any[] = [];
  for (const name of fs.readdirSync(directory)) {
    if (!name.endsWith(".json")) continue;
    if (selectedSessionId && name !== `${selectedSessionId}.json`) continue;
    try {
      const session = agentSessionJsonCache.read<any>(path.join(directory, name));
      if (session?.schema !== "pkm.agent.session/v1" || !String(session.sessionId || "").startsWith("agent_session_")) continue;
      if (!includeExternal && !pkmOwnedAgentSession(session)) continue;
      const checkpoints = Array.isArray(session.checkpoints) ? session.checkpoints : [];
      const latest = checkpoints.at(-1);
      const state = latest?.state && typeof latest.state === "object" ? latest.state : {};
      runErrors.clear();
      const rawRuns: any[] = (Array.isArray(session.recipeRunIds) ? session.recipeRunIds : [])
        .map(String).map(readRun).filter(Boolean);
      if (agentSessionOrigin(session).origin === "pkm-native") {
        const visited = new Set(rawRuns.map(run => run.runId));
        const readChild = (id: string) => {
          if (!id || visited.has(id)) return;
          visited.add(id);
          const child = readRun(id);
          if (child) rawRuns.push(child);
        };
        for (const edge of Array.isArray(session.recipeTreeEdges) ? session.recipeTreeEdges : []) readChild(String(edge.toRunId || ""));
        for (let index = 0; index < rawRuns.length; index++) for (const node of rawRuns[index].nodes) readChild(node.childRunId);
      }
      const runsById = new Map<string, any>(rawRuns.map((run: any) => [run.runId, run]));
      const todoUsages = new Map<string, ReturnType<typeof todoUsageSummary>>((Array.isArray(session.todos) ? session.todos : []).map((todo: any) => {
        const runIds = [...new Set<string>((Array.isArray(todo.recipeRunIds) ? todo.recipeRunIds : [todo.recipeRunId]).filter(Boolean).map(String))];
        return [String(todo.todoId || ""), todoUsageSummary(storeRoot, String(session.sessionId), String(todo.todoId || ""), runIds.map(runId => runsById.get(runId)).filter(Boolean))];
      }));
      const moduleProtocols = new Map<string, ReturnType<typeof todoUsageSummary>["protocol"]>();
      for (const usage of todoUsages.values()) for (const [key, protocol] of Object.entries(usage.modules || {})) {
        const previous = moduleProtocols.get(key);
        if (!previous) moduleProtocols.set(key, { ...protocol });
        else {
          for (const field of ["calls", "successes", "failures", "inputBytes", "outputBytes", "durationMs", "estimatedTokens"] as const) previous[field] += protocol[field];
          previous.observed ||= protocol.observed;
          previous.quality = previous.observed ? "estimated" : "unknown";
        }
      }
      const runs = rawRuns.map((run: any) => {
        const { usage: _usage, ...projection } = run;
        return { ...projection, nodes: projection.nodes.map((node: any) => ({
          ...node, usage: { ...node.usage, protocol: moduleProtocols.get(`${run.runId}:${node.nodeId}`) || node.usage.protocol },
        })) };
      });
      const waiting = session.nativeChat?.progress?.status === "running" && session.nativeChat?.progress?.steps?.slice(-1)[0]?.status === "waiting"
        || runs.some((run: any) => run.nodes.some((node: any) =>
        node.state === "running"
        && (node.kind === "pkm.gate.human/v1" || node.observability?.state === "waiting")));
      let harness: ReturnType<typeof apiChatSessionHarnessSnapshot> | undefined;
      if (session.origin === "pkm-native" && session.nativeChat) {
        try { harness = apiChatSessionHarnessSnapshot(session, String(session.sessionId), path.join(storeRoot, ".pkm", "state")); }
        catch (error) {
          harness = {
            schema: "pkm.agent.harness/v1", chatId: String(session.hostSessionId || ""), sessionId: String(session.sessionId),
            state: "failed", currentPhase: { kind: "failed", label: "Harness snapshot unavailable", status: "failed" },
            currentProblem: "", currentProblemSource: "unavailable",
            queuedInputs: [], attempts: [],
            waiting: { kind: "dependency", detail: error instanceof Error ? error.message : "Harness snapshot unavailable" },
          };
        }
      }
      snapshots.push({
        sessionId: String(session.sessionId), status: projectedAgentSessionStatus(session),
        projection: projectExecution("agent-session", session.nativeChat?.progress?.status === "failed"
          || projectedAgentSessionStatus(session) === "completed" && (session.todos || []).some((todo: any) => todo.status === "failed")
          ? "failed" : projectedAgentSessionStatus(session), {
          waiting, interrupted: agentSessionLiveness(session, waiting).state === "suspected-interrupted",
        }),
        task: String(session.task || "Managed task"), projectId: String(session.projectId || ""),
        ...agentSessionGroup(session),
        ...agentSessionOrigin(session),
        nativeAgent: session.origin === "pkm-native" && session.nativeChat ? {
          requestStatus: session.nativeChat.progress?.status,
          waitingForInput: session.nativeChat.progress?.status === "running" && session.nativeChat.progress?.steps?.slice(-1)[0]?.status === "waiting",
          model: session.nativeChat.modelProvider === "vscode" ? session.nativeChat.vscodeModelLabel || session.nativeChat.vscodeModelId || "VS Code · not connected" : session.nativeChat.modelProfileId || vscode.workspace.getConfiguration("personalKnowledge").get("aiModel", "gpt-4o-mini"),
          contextWindow: session.nativeChat.contextWindow, maxOutputTokens: session.nativeChat.maxOutputTokens,
          includeHistory: session.nativeChat.includeHistory,
          memory: (session.nativeChat.memoryTasks || []).map((item: any) => String(item.title)),
          pkmSkills: ["Automatic"],
          externalSkills: (session.nativeChat.agentContext?.externalSkills || []).map((item: any) => String(item.label)),
          context: (session.nativeChat.context || []).map((item: any) => String(item.label)),
          builtinTools: session.nativeChat.builtinTools, platform: process.platform,
          mcpServers: (session.nativeChat.mcpServers || []).map((server: any) => ({ label: server.label, enabled: server.enabled, tools: server.tools })),
        } : undefined,
        harness,
        harnessWarnings: [...runErrors].map(([id, error]) => `${id}: ${error}`),
        traversalStrategy: String(session.traversalStrategy || ""),
        recipeTreeEdges: (Array.isArray(session.recipeTreeEdges) ? session.recipeTreeEdges : []).map((edge: any) => ({
          fromRunId: String(edge.fromRunId || ""), fromNodeId: String(edge.fromNodeId || ""),
          toRunId: String(edge.toRunId || ""), toNodeId: String(edge.toNodeId || ""),
        })).filter((edge: any) => edge.fromRunId && edge.fromNodeId && edge.toRunId && edge.toNodeId),
        agent: { name: String(session.agent?.name || "Agent"), product: String(session.agent?.product || "") },
        createdAt: String(session.createdAt || ""), updatedAt: String(session.updatedAt || ""),
        trashedAt: session.trashedAt ? String(session.trashedAt) : undefined,
        liveness: agentSessionLiveness(session, waiting),
        lastActivity: session.lastActivity && typeof session.lastActivity === "object" ? {
          tool: String(session.lastActivity.tool || ""), ok: session.lastActivity.ok !== false, at: String(session.lastActivity.at || ""),
        } : undefined,
        todos: (Array.isArray(session.todos) ? session.todos : []).map((todo: any) => {
          const recipeRunIds = [...new Set<string>((Array.isArray(todo.recipeRunIds) ? todo.recipeRunIds : [todo.recipeRunId])
            .filter(Boolean).map((value: unknown) => String(value)))];
          const todoId = String(todo.todoId || "");
          const { modules: _modules, ...usage } = todoUsages.get(todoId)!;
          return {
            todoId, title: String(todo.title || ""), details: String(todo.details || ""),
            status: String(todo.status || "pending"), summary: String(todo.summary || ""),
            recipeRunId: String(todo.recipeRunId || ""), createdAt: String(todo.createdAt || ""),
            recipeRunIds,
            updatedAt: String(todo.updatedAt || ""),
            usage,
          };
        }),
        checkpoint: latest ? {
          checkpointId: String(latest.checkpointId || ""), sequence: Number(latest.sequence || checkpoints.length),
          createdAt: String(latest.createdAt || ""), reason: String(latest.reason || ""),
          summary: typeof state.summary === "string" ? state.summary : "",
          nextActionCount: Array.isArray(state.next_actions) ? state.next_actions.length : Array.isArray(state.nextActions) ? state.nextActions.length : 0,
        } : undefined,
        runs,
      });
    } catch { /* A corrupt record must not hide healthy Agent Sessions. */ }
  }
  return snapshots.sort((left, right) => right.updatedAt.localeCompare(left.updatedAt));
}

function agentSessionTrashSnapshots(): any[] {
  const directory = path.join(getStorePath(), ".pkm", "state", "agent-sessions-trash");
  return agentSessionSnapshots([], directory, undefined, true).map(session => ({ ...session, restorable: session.origin === "pkm-native" && session.hostKind === "pkm" })).sort((left, right) => String(right.trashedAt || "").localeCompare(String(left.trashedAt || "")));
}

function configuredAgentSessionArchiveKeepLatestK(): number {
  return agentSessionArchiveKeepLatestK(
    vscode.workspace.getConfiguration("personalKnowledge").get<number>("agentSessionArchiveKeepLatestK")
  );
}

let agentSessionRetentionPending: Promise<void> = Promise.resolve();
function applyAgentSessionArchiveRetention(): Promise<void> {
  if (!_storeReady) return Promise.resolve();
  const stateDirectory = path.join(getStorePath(), ".pkm", "state");
  const run = async () => {
    const result = await enforceAgentSessionArchiveRetention(stateDirectory, configuredAgentSessionArchiveKeepLatestK());
    if (result.moved.length || result.deleted.length) log.info(`Agent Session Trash retention: moved ${result.moved.length}, permanently deleted ${result.deleted.length} overflow Session(s).`);
    for (const error of result.errors) log.warn(`Agent Session archive retention: ${error}`);
  };
  agentSessionRetentionPending = agentSessionRetentionPending.then(run, run);
  return agentSessionRetentionPending;
}

const nativeHarnessServers = new Map<string, {
  root: string;
  promise: ReturnType<typeof createNativeHarnessServer>;
  server?: Awaited<ReturnType<typeof createNativeHarnessServer>>;
}>();

function nativeHarnessAccess(sessionId: string, root = getStorePath()): void {
  if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before inspecting native execution records.");
  if (!root || getStorePath() !== root) throw new Error("Knowledge Root changed. Reopen the Session from VS Code.");
  if (!/^agent_session_[a-f0-9]{32}$/.test(sessionId)) throw new Error("Invalid native Session identity.");
  const record = agentSessionJsonCache.read<Record<string, unknown>>(path.join(root, ".pkm", "state", "agent-sessions", `${sessionId}.json`));
  if (record?.schema !== "pkm.agent.session/v1" || record.sessionId !== sessionId || agentSessionOrigin(record).origin !== "pkm-native" || record.hostKind !== "pkm") {
    throw new Error("The native Session is unavailable or no longer belongs to this host.");
  }
}

async function nativeHarnessRequest(method: string, params: Record<string, unknown>): Promise<unknown> {
  const sessionId = String(params.sessionId || "");
  nativeHarnessAccess(sessionId);
  if (method === "snapshot") {
    const directory = path.join(getStorePath(), ".pkm", "state");
    const snapshot = agentSessionSnapshots(currentProjectStore().list().recipes, path.join(directory, "agent-sessions"), sessionId)[0];
    if (!snapshot) throw new Error("The native Session could not be read.");
    if (snapshot.harness) snapshot.harness = await verifyHarnessArtifacts(snapshot.harness,
      vscode.workspace.isTrusted === false ? [] : (vscode.workspace.workspaceFolders || []).map(folder => folder.uri.fsPath), undefined, directory);
    const references = (snapshot.harness as ReturnType<typeof apiChatSessionHarnessSnapshot> | undefined)?.attempts
      .flatMap(attempt => attempt.toolCalls.flatMap(call => call.actionRunIds)) || [];
    return { ...snapshot, memoryStoreReader:true, profileReader:true, ...readHarnessActions(directory, references, filename => agentSessionJsonCache.read<unknown>(filename)) };
  }
  if (method === "memoryOverview" || method === "memoryPiece" || method === "profiles") {
    const filename = path.join(getStorePath(), ".pkm", "state", "agent-sessions", `${sessionId}.json`);
    const record = agentSessionJsonCache.read<Record<string, unknown>>(filename), chat = record?.nativeChat;
    if (!chat || typeof chat !== "object" || !("id" in chat) || typeof chat.id !== "string"
      || !("sessionId" in chat) || chat.sessionId !== sessionId) throw new Error("The owning Chat for scoped inspection is unavailable.");
    const result = await vscode.commands.executeCommand("personalKnowledge.readChatHarness",chat.id,method,
      method === "memoryPiece" ? {piece:params.piece,after:params.after} : {});
    if (result === undefined) throw new Error("The scoped Chat reader is unavailable.");
    return result;
  }
  if (method === "result") {
    const directory = path.join(getStorePath(), ".pkm", "state");
    const record = agentSessionJsonCache.read<Record<string, unknown>>(path.join(directory, "agent-sessions", `${sessionId}.json`));
    const snapshot = apiChatSessionHarnessSnapshot(record, sessionId, directory, true);
    const call = snapshot.attempts.find(attempt => attempt.messageId === params.messageId)?.toolCalls.find(item => item.id === params.callId);
    if (!call) throw new Error("The recorded tool result is unavailable.");
    return call.resultPreview;
  }
  throw new Error("Unsupported read-only Harness operation.");
}

async function openNativeHarnessBrowser(context: vscode.ExtensionContext, sessionId: string): Promise<void> {
  const root = getStorePath();
  nativeHarnessAccess(sessionId, root);
  let entry = nativeHarnessServers.get(sessionId);
  if (entry && entry.root !== root) {
    void entry.promise.then(server => server.dispose(), error => log.warn(`Harness host cleanup: ${String(error)}`));
    nativeHarnessServers.delete(sessionId); entry = undefined;
  }
  if (!entry) {
    entry = { root, promise:createNativeHarnessServer({ extensionPath:context.extensionPath, sessionId,
      access:() => nativeHarnessAccess(sessionId, root), request:nativeHarnessRequest }) };
    nativeHarnessServers.set(sessionId, entry);
    const created = entry;
    context.subscriptions.push({ dispose() {
      void created.promise.then(server => server.dispose(), error => log.warn(`Harness host cleanup: ${String(error)}`));
      if (nativeHarnessServers.get(sessionId) === created) nativeHarnessServers.delete(sessionId);
    } });
  }
  let server: Awaited<ReturnType<typeof createNativeHarnessServer>>;
  try { server = await entry.promise; entry.server = server; }
  catch (error) { if (nativeHarnessServers.get(sessionId) === entry) nativeHarnessServers.delete(sessionId); throw error; }
  nativeHarnessAccess(sessionId, root);
  const local = new URL(server.url);
  const external = new URL((await vscode.env.asExternalUri(vscode.Uri.parse(`${local.origin}/`))).toString());
  server.allowOrigin(external.origin);
  external.hash = local.hash;
  if (!await vscode.env.openExternal(vscode.Uri.parse(external.toString()))) throw new Error("The browser could not open the native Session.");
}

let nonPkmAgentSessionsRetired: Promise<void> | undefined;
let nonPkmAgentSessionsRoot = "";
function retireExternalAgentSessions(): Promise<void> {
  const root = getStorePath();
  if (!nonPkmAgentSessionsRetired || nonPkmAgentSessionsRoot !== root) {
    nonPkmAgentSessionsRoot = root;
    nonPkmAgentSessionsRetired = retireNonPkmAgentSessions(path.join(root, ".pkm", "state")).then(result => {
      if (result.moved.length) log.info(`Agent Sessions are PKM Chat only: moved ${result.moved.length} external Session(s) to Trash.`);
      for (const error of result.errors) log.warn(`Agent Session retirement: ${error}`);
    }, error => { nonPkmAgentSessionsRetired = undefined; log.warn(`Agent Session retirement: ${String(error)}`); });
  }
  return nonPkmAgentSessionsRetired;
}

async function agentSessionProjectStateData(): Promise<any> {
  await retireExternalAgentSessions();
  await applyAgentSessionArchiveRetention();
  const mappingResult = reconcileAgentSessionActiveMappings(path.join(getStorePath(), ".pkm", "state"));
  for (const error of mappingResult.errors) log.warn(`Agent Session active mapping reconciliation: ${error}`);
  const snapshot = currentProjectStore().list();
  const groupsDirectory = path.join(getStorePath(), ".pkm", "state", "agent-groups");
  const storedGroups = (fs.existsSync(groupsDirectory) ? fs.readdirSync(groupsDirectory) : []).flatMap(name => {
    if (!/^agent_group_[a-f0-9]{64}\.json$/.test(name)) return [];
    try {
      const group = agentSessionJsonCache.read<any>(path.join(groupsDirectory, name));
      if (group?.schema !== "pkm.agent.group/v1" || `${group.groupId}.json` !== name || typeof group.hostSessionId !== "string" || group.hostKind !== "pkm") return [];
      return [{ groupId: group.groupId, hostSessionId: group.hostSessionId, hostKind: String(group.hostKind || "unknown"), title: typeof group.title === "string" ? group.title : "", deletedAt: group.deletedAt }];
    } catch { return []; }
  });
  const agentSessionGroups = [...new Map([...storedGroups, ...apiChatGroupSnapshots(path.join(getStorePath(), ".pkm", "state"))].map(group => [group.groupId, group])).values()]
    .map(group => {
      const portal = getChatMgr().portalStateForChat(group.hostSessionId);
      return { ...group, portal: portal && { connected: portal.connected, binding: portal.binding } };
    });
  return {
    ...snapshot,
    projects: snapshot.projects.map(project => ({ ...project, objectKind: "Project" })),
    cockpits: projectCockpits(getStorePath(), snapshot.projects, snapshot.collaborationTasks),
    threads: snapshot.threads.map(thread => ({ ...thread, objectKind: "Project" })),
    recipes: snapshot.recipes.map(recipe => ({ ...recipe, objectKind: "Recipe" })),
    ganttTasks: snapshot.ganttTasks.map(task => ({ ...task, projection: projectExecution("project", task.status) })),
    collaborationTasks: snapshot.collaborationTasks.map(task => ({ ...task, projection: projectExecution("collaboration", task.convergenceState || task.status) })),
    agentSessionGroups,
    agentSessions: agentSessionSnapshots(snapshot.recipes),
    agentSessionTrash: agentSessionTrashSnapshots(),
    agentSessionArchiveKeepLatestK: configuredAgentSessionArchiveKeepLatestK(),
    agentSnapshots: listAgentSnapshots(getStorePath()),
    privateTopLevels: privateTopLevels("recipes"),
    referenceCatalog: recipeReferenceCatalog(),
  };
}

async function mutateAgentSessionTrash(action: "move" | "restore" | "delete" | "empty", sessionId: string): Promise<void> {
  const stateDirectory = path.join(getStorePath(), ".pkm", "state");
  if (action === "empty") {
    emptyAgentSessionTrash(stateDirectory);
    return;
  }
  if (!/^agent_session_[a-zA-Z0-9_-]+$/.test(sessionId)) throw new Error("Agent Session identity is invalid.");
  if (action === "move") {
    await moveAgentSessionToTrash(stateDirectory, sessionId, { requireCompleted: true });
    return;
  }
  if (action === "delete") {
    permanentlyDeleteTrashedAgentSession(stateDirectory, sessionId);
    return;
  }
  restoreAgentSessionFromTrash(stateDirectory, sessionId);
}

function hydrateRecipeNodeBindings(value: unknown): RecipeRecord["nodeBindings"] {
  if (!Array.isArray(value)) return [];
  return value.map((node: any) => ({
    nodeId: String(node?.nodeId || ""),
    bindings: (Array.isArray(node?.bindings) ? node.bindings : []).map((binding: any) => {
      const kind = binding?.kind === "skill" ? "skill" as const : binding?.kind === "note" ? "note" as const : undefined;
      if (!kind) throw new ProjectModelError("recipe-binding-kind-invalid", "Recipe references currently support Skills and Notes.");
      const knowledgeId = String(binding.knowledgeId || "");
      const content = projectRecipeKnowledge(kind, knowledgeId);
      const usage = ["required", "recommended", "reference"].includes(String(binding.usage)) ? binding.usage as RecipeKnowledgeBinding["usage"] : "reference";
      const bindingId = String(binding.bindingId || `binding_${createHash("sha256").update(`${node?.nodeId}\0${kind}\0${knowledgeId}`).digest("hex").slice(0, 20)}`);
      return { bindingId, kind, knowledgeId, contentHash: content.contentHash, usage };
    })
  }));
}

async function exportProjectRecipes(projectId: string): Promise<string | undefined> {
  const snapshot = currentProjectStore().list();
  const project = snapshot.projects.find(candidate => candidate.projectId === projectId);
  if (!project) throw new Error("Project was not found.");
  const recipes = snapshot.recipes.filter(recipe => recipe.scope === "project" && recipe.projectId === projectId);
  if (!recipes.length) throw new Error("This Project has no Recipes to export.");
  const knowledge = new Map<string, BundledKnowledgeContent>();
  for (const recipe of recipes) for (const node of recipe.nodeBindings || []) for (const binding of node.bindings) {
    const item = projectRecipeKnowledge(binding.kind, binding.knowledgeId);
    if (item.contentHash !== binding.contentHash) throw new Error(`Bound ${binding.kind} changed since Recipe revision ${recipe.revision}: ${binding.knowledgeId}`);
    knowledge.set(`${binding.kind}:${binding.knowledgeId}`, item);
  }
  const bundle = exportProjectRecipeBundle({ project, recipes, knowledge: [...knowledge.values()] });
  const filename = `${safeFilePart(project.name).toLowerCase().replace(/\s+/g, "-") || "project"}.pkm-recipes.json`;
  const target = await vscode.window.showSaveDialog({
    saveLabel: "Export Project Recipes",
    defaultUri: vscode.Uri.file(path.join(os.homedir(), filename)),
    filters: { "PKM Project Recipe Bundle": ["json"] }
  });
  if (!target) return undefined;
  fs.writeFileSync(target.fsPath, JSON.stringify(bundle, null, 2) + "\n", "utf8");
  return target.fsPath;
}

// Background one-shot sweep to compute on-disk sizes for envs missing a cached
// value, then refresh the panel so sizes show up "by default".
let _sizeSweeping = false;
async function sweepEnvSizes(respond: (m: any) => void): Promise<void> {
  if (_sizeSweeping) return;
  const missing = pyenvList().filter(e => typeof e.sizeBytes !== "number");
  if (!missing.length) return;
  _sizeSweeping = true;
  try {
    for (const e of missing) await refreshEnvironmentSize(e.id);
    respond({ command: "envList", data: envListForUi() });
  } finally { _sizeSweeping = false; }
}

// Fast background sweep to detect Python versions for envs missing one.
let _verSweeping = false;
const environmentProbeErrors = new Map<string, string>();
const environmentSizeProbeErrors = new Map<string, string>();
async function refreshEnvironmentSize(id: string): Promise<Awaited<ReturnType<typeof pyenvSize>>> {
  try {
    const result = await pyenvSize(id, true);
    if (result.error) {
      environmentSizeProbeErrors.set(id, result.error);
      log.warn(`Environment ${id} disk size probe failed: ${result.error}`);
    } else environmentSizeProbeErrors.delete(id);
    return result;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    environmentSizeProbeErrors.set(id, message);
    log.warn(`Environment ${id} disk size probe failed: ${message}`);
    return { bytes: 0, human: "", at: "", cached: false, error: message };
  }
}
async function refreshEnvironmentVersion(id: string): Promise<Awaited<ReturnType<typeof pyenvPyVersion>>> {
  try {
    const result = await pyenvPyVersion(id, true);
    if (result.error) {
      environmentProbeErrors.set(id, result.error);
      log.warn(`Environment ${id} Python probe failed: ${result.error}`);
    } else environmentProbeErrors.delete(id);
    return result;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    environmentProbeErrors.set(id, message);
    log.warn(`Environment ${id} Python probe failed: ${message}`);
    return { version: "", cached: false, error: message };
  }
}
async function sweepEnvVersions(respond: (m: any) => void): Promise<void> {
  if (_verSweeping) return;
  const missing = pyenvList().filter(e => !e.pyVersion);
  if (!missing.length) return;
  _verSweeping = true;
  try {
    for (const e of missing) await refreshEnvironmentVersion(e.id);
    respond({ command: "envList", data: envListForUi() });
  } finally { _verSweeping = false; }
}

// Resolve the extension-managed environments root (for the Migrate action).
function pyenvsRoot(): string {
  return managedEnvironmentsRoot();
}

// Env list enriched with a `managed` flag (already inside the managed root).
function envListForUi(): any[] {
  const rp = path.resolve(pyenvsRoot());
  return pyenvList().map(e => {
    const pathExists = !!e.path && fs.existsSync(e.path);
    const pythonExists = !!e.python && fs.existsSync(e.python);
    return {
      ...e,
      managed: !!e.path && path.resolve(e.path).startsWith(rp + path.sep),
      missing: (!!e.path && !pathExists) || (!!e.python && !pythonExists),
      pathExists,
      pythonExists,
      probeError: [environmentProbeErrors.get(e.id), environmentSizeProbeErrors.get(e.id)].filter(Boolean).join("\n") || undefined,
      pythonProbeError: environmentProbeErrors.get(e.id),
      sizeProbeError: environmentSizeProbeErrors.get(e.id),
      isMcpRuntime: !!e.path && path.resolve(e.path) === path.resolve(managedMcpRuntimePath()),
    };
  });
}

let mcpRuntimeStatusCache: { at: number; value: ReturnType<typeof mcpRuntimeStatus> } | undefined;

function cachedMcpRuntimeStatus(): ReturnType<typeof mcpRuntimeStatus> {
  const now = Date.now();
  if (mcpRuntimeStatusCache && now - mcpRuntimeStatusCache.at < 60_000) return mcpRuntimeStatusCache.value;
  const value = mcpRuntimeStatus();
  mcpRuntimeStatusCache = { at: now, value };
  return value;
}

function mcpPanelStatusData(traceId = ""): object {
  const trace = { traceId, surface: "mcp" };
  const info = loadProfiler.measure("host.mcp.status", trace, () => mcpStatus());
  const python = loadProfiler.measure("host.mcp.python", trace, () => detectMcpPython());
  const runtime = loadProfiler.measure("host.mcp.runtime", trace, () => cachedMcpRuntimeStatus());
  const activeStorePath = _storeReady ? getStorePath() : "";
  const storePathValid = !!activeStorePath && directoryExists(activeStorePath);
  const cloudStore = activeStorePath ? cloudSynchronizedPath(activeStorePath) : undefined;
  const storeHost = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const accountBinding = readAccountMcpBinding();
  const accountSecurity = activeStorePath ? accountKnowledgeSecurity(activeStorePath) : { private: false, detail: "No account Knowledge Root is configured." };
  const guideDismissed = !!chatCtx?.globalState.get<boolean>("pkm.integrationGuideDismissed.v1", false);
  // Config is resumable from actual state, independently of the dismissible invitation.
  const guideStep = !python.valid ? "python" : integrationMaintenanceState === "ready" ? ""
    : !runtime.healthy ? "runtime" : !info.current ? "server" : "";
  return {
    ...info,
    extensionVersion: String(chatCtx?.extension?.packageJSON?.version || "unknown"),
    combinedRegistry: runtime.healthy ? combinedMcpRegistry() : "",
    nativeMcpProvider: _nativeMcpProvider,
    clientRegistration: mcpClientRegistrationStatus(),
    accountBinding: accountBinding || null,
    accountSecurity,
    mcpProcess: mcpProcessStatus(),
    store: {
      path: activeStorePath,
      configured: !!activeStorePath,
      valid: storePathValid,
      host: storeHost,
      cloudSynchronized: cloudStore ? { provider: cloudStore.provider } : null,
    },
    paths: {
      store: activeStorePath,
      environments: managedEnvironmentsRoot(),
      runtime: runtime.path,
      python: python.path,
      serverDirectory: info.serverPath ? path.dirname(info.serverPath) : "",
    },
    mcpPython: python,
    mcpRuntime: runtime,
    featureDomains: mcpFeatureDomainState(),
    usage: { sessions: [], deferred: true, measurementNote: "Usage evidence is loaded only when requested." },
    skillRouters: [
      { id: "exact", name: "Exact", kind: "Deterministic", version: "1", status: "active", description: "Hard exact constraints and identifier matches." },
      { id: "bm25", name: "BM25", kind: "Lexical", version: "academic-k1=0.9-b=0.4", status: "active", description: "Frozen relevance ranking across the typed Subscriber index." },
    ],
    firstRunGuide: { visible: !!guideStep, step: guideStep, dismissed: guideDismissed },
    automaticSetup: { state: integrationMaintenanceState, error: integrationMaintenanceError, progress: integrationSetupProgress },
    performance: performanceStateDir ? performanceSummary(performanceStateDir) : {},
    baseline: baselineReport(performanceStateDir, loadProfiler.enabled()),
    objectTaxonomy: PKM_ENTRY_POINTS,
    loadProfiling: { enabled: loadProfiler.enabled(), logFile: loadProfiler.logPath() },
    externalLink: { ...externalLinkHostOptions(), contentPort: publicContentActivePort || publicContentPort() },
  };
}

function enabledMcpFeatureDomains(): McpFeatureDomain[] {
  return configuredMcpFeatureDomains();
}

function mcpFeatureDomainState(): object {
  const enabled = new Set(enabledMcpFeatureDomains());
  return {
    domains: [
      { id: "knowledge", name: "Knowledge + Tools", enabled: enabled.has("knowledge"), description: "Search, read, and maintain PKM content and configuration." },
      { id: "automation", name: "Automation", enabled: enabled.has("automation"), description: "Recipes, Agent Sessions, Chatrooms, and operational workflows." },
      { id: "skillRouter", name: "Router", enabled: enabled.has("skillRouter"), description: "Retrieve and apply relevant Skills before substantial work." },
    ],
    note: "These switches control Agent/MCP exposure only. They do not disable the extension UI.",
  };
}

const mcpPathSizeCache = new Map<string, { bytes: number; at: number; error?: string }>();
let mcpPathSizeGeneration = 0;
async function calculatePathBytes(target: string): Promise<{ bytes: number; error?: string }> {
  if (!target) return { bytes: 0, error: "Not configured" };
  let bytes = 0;
  const pending = [target];
  try {
    while (pending.length) {
      const current = pending.pop()!;
      let stat: fs.Stats;
      try { stat = await fs.promises.lstat(current); } catch (error: any) {
        if (current === target) throw error;
        continue;
      }
      const allocatedBytes = typeof stat.blocks === "number" && stat.blocks > 0 ? stat.blocks * 512 : stat.size;
      bytes += allocatedBytes;
      if (stat.isSymbolicLink()) continue;
      if (!stat.isDirectory()) continue;
      let entries: fs.Dirent[];
      try { entries = await fs.promises.readdir(current, { withFileTypes: true }); }
      catch { continue; }
      for (const entry of entries) pending.push(path.join(current, entry.name));
      if (pending.length % 500 === 0) await new Promise<void>(resolve => setImmediate(resolve));
    }
    return { bytes };
  } catch (error: any) {
    return { bytes: 0, error: error?.code === "ENOENT" ? "Not found" : error?.message || String(error) };
  }
}

async function sendMcpPathSizes(respond: (m: object) => void, generation = mcpPathSizeGeneration): Promise<void> {
  const info = mcpStatus();
  const python = detectMcpPython();
  const runtime = mcpRuntimeStatus();
  const paths: Record<string, string> = {
    store: _storeReady ? getStorePath() : "",
    environments: managedEnvironmentsRoot(),
    runtime: runtime.path,
    python: python.path,
    serverDirectory: info.serverPath ? path.dirname(info.serverPath) : "",
  };
  for (const [key, target] of Object.entries(paths)) {
    if (generation !== mcpPathSizeGeneration) return;
    const cached = mcpPathSizeCache.get(target);
    const result = cached || { ...await calculatePathBytes(target), at: Date.now() };
    if (generation !== mcpPathSizeGeneration) return;
    if (target) mcpPathSizeCache.set(target, result);
    respond({ command: "mcpPathSize", data: { key, path: target, ...result } });
  }
}

// ── Logging ────────────────────────────────────────────────────────────────
type LogLevel = "debug" | "info" | "warn" | "error";
const LEVEL_ORDER: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 };

class Logger {
  private channel: vscode.OutputChannel;
  private fileLog: DiagnosticLog | undefined;
  private heartbeat: NodeJS.Timeout | undefined;
  private minLevel: LogLevel = "info";

  constructor() {
    this.channel = vscode.window.createOutputChannel("Personal Knowledge Manager");
  }

  init(context: vscode.ExtensionContext): void {
    try {
      const dir = path.join(context.globalStorageUri.fsPath, "diagnostics", "extension");
      this.fileLog = new DiagnosticLog(dir, 100_000, 1_000, error => {
        this.channel.appendLine(`[ERROR] ${error.message}`);
        console.error(error.message);
        void vscode.window.showWarningMessage(error.message, "Open diagnostic log").then(choice => {
          if (choice === "Open diagnostic log") this.show();
        }, notificationError => console.error("PKM diagnostic warning failed:", notificationError));
      });
      this.fileLog.record("host.started", { parentPid: process.ppid, platform: process.platform, extensionVersion: context.extension?.packageJSON?.version ?? "unknown", buildId: loadedExtensionBuild?.buildId ?? "unknown", vscodeVersion: vscode.version ?? "unknown", nodeVersion: process.version });
      this.channel.appendLine(`Diagnostic log: ${dir} writer=${this.fileLog.writerId} latest=100000`);
    } catch (error) {
      this.channel.appendLine(`Diagnostic logging initialization failed: ${error instanceof Error ? error.message : String(error)}`);
      void vscode.window.showErrorMessage("PKM diagnostic logging could not initialize. Open Output > Personal Knowledge Manager.")
        .then(undefined, notificationError => console.error("PKM diagnostic initialization warning failed:", notificationError));
    }
    this.refreshLevel();
    if (this.heartbeat) clearInterval(this.heartbeat);
    let previous = performance.now();
    this.heartbeat = setInterval(() => {
      const now = performance.now();
      const delayMs = Math.max(0, Math.round(now - previous - 60_000));
      previous = now;
      this.fileLog?.record("host.heartbeat", { delayMs });
      if (delayMs >= 5_000) this.warn(`extension host heartbeat delayed by ${delayMs}ms`);
    }, 60_000);
    this.heartbeat.unref();
    context.subscriptions.push({ dispose: () => {
      if (this.heartbeat) clearInterval(this.heartbeat);
      this.fileLog?.record("host.stopped");
    } });
  }

  refreshLevel(): void {
    const cfg = vscode.workspace.getConfiguration("personalKnowledge");
    this.minLevel = (cfg.get<LogLevel>("logLevel") ?? "info");
  }

  private write(level: LogLevel, msg: string): void {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[this.minLevel]) return;
    const line = `[${new Date().toISOString()}] [${level.toUpperCase()}] ${msg}`;
    this.channel.appendLine(line);
    this.fileLog?.record("extension.log", { level, message: msg });
  }

  debug(msg: string): void { this.write("debug", msg); }
  info(msg: string):  void { this.write("info", msg); }
  warn(msg: string):  void { this.write("warn", msg); }
  error(msg: string): void { this.write("error", msg); }

  startup(msg: string): void {
    this.channel.appendLine(`[${new Date().toISOString()}] [STARTUP] ${msg}`);
    this.fileLog?.record("chat.startup", { message: msg });
  }

  /** Log a user action (always at info level for auditability). */
  action(name: string, detail?: object): void {
    this.write("info", `action: ${name}${detail ? " " + JSON.stringify(detail) : ""}`);
  }

  show(): void {
    const recent = this.fileLog?.latest() || [];
    if (this.fileLog?.persistenceError || recent.some(entry => entry.persisted === false)) {
      this.channel.appendLine(this.fileLog?.persistenceError || "Some recent diagnostics were not persisted and remain only in memory.");
      for (const entry of recent) this.channel.appendLine(`[memory diagnostic] ${JSON.stringify(entry)}`);
    }
    this.channel.show();
  }
}

const log = new Logger();

// Recent Portal lifecycle events for PKM: Portal Diagnostics; never contains link secrets or pairing codes.
const portalEvents: string[] = [];
function recordPortalEvent(level: "info" | "warn", message: string): void {
  portalEvents.push(`${new Date().toISOString()} ${level.toUpperCase()} ${message}`);
  if (portalEvents.length > 300) portalEvents.splice(0, portalEvents.length - 300);
}
function portalLog(level: "info" | "warn", message: string): void {
  recordPortalEvent(level, message);
  log[level](`Portal: ${message}`);
}
function hubLog(message: string): void {
  if (message.startsWith("portal relay:")) recordPortalEvent("info", message);
  log.info(message);
}
/** How long a paired Portal keeps its pairing while either endpoint reconnects. */
const PORTAL_GRACE_MS = 120_000;

type LoadProfileFields = Record<string, string | number | boolean | undefined>;

class GitHubSyncDiagnostics {
  private filePath = "";
  private retainedLog?: RetainedJsonlLog;

  init(context: vscode.ExtensionContext): void {
    this.filePath = path.join(context.globalStorageUri.fsPath, "github-sync-diagnostic.jsonl");
    this.retainedLog = new RetainedJsonlLog(this.filePath, error => {
      log.warn(`GitHub Sync diagnostic write/retention failed: ${error instanceof Error ? error.message : String(error)}`);
    });
    void this.flush().catch(error => log.warn(`GitHub Sync diagnostic retention failed: ${error instanceof Error ? error.message : String(error)}`));
  }

  logPath(): string { return this.filePath; }
  async flush(): Promise<void> { await this.retainedLog?.flush(); }

  record(event: string, fields: Record<string, string | number | boolean | undefined> = {}): void {
    if (!this.filePath || !/^[a-z][a-z0-9_.-]{1,79}$/.test(event)) return;
    const entry = {
      at: new Date().toISOString(),
      event,
      ...Object.fromEntries(Object.entries(fields).filter(([, value]) =>
        typeof value === "string" || typeof value === "number" || typeof value === "boolean")),
      platform: process.platform,
      remote: vscode.env.remoteName || "local",
    };
    try {
      this.retainedLog!.append(entry);
    } catch (error) {
      log.warn(`GitHub Sync diagnostic write failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async open(): Promise<void> {
    if (!this.filePath) return;
    await this.flush();
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    if (!fs.existsSync(this.filePath)) fs.writeFileSync(this.filePath, "", { mode: 0o600 });
    await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(this.filePath), { preview: false });
  }
}

const githubSyncDiagnostics = new GitHubSyncDiagnostics();

class LoadProfiler {
  private channel = vscode.window.createOutputChannel("PKM Load Profiling");
  private context: vscode.ExtensionContext | undefined;
  private active = false;
  private filePath = "";

  init(context: vscode.ExtensionContext): void {
    this.context = context;
    this.filePath = path.join(context.globalStorageUri.fsPath, "load-profile.jsonl");
    this.refresh();
  }

  refresh(): void {
    this.active = vscode.workspace.getConfiguration("personalKnowledge").get<boolean>("loadProfilingEnabled", false);
  }

  enabled(): boolean { return this.active; }
  logPath(): string { return this.filePath; }

  record(event: string, fields: LoadProfileFields = {}): void {
    if (!this.active || !/^[a-z][a-z0-9_.-]{1,79}$/.test(event)) return;
    const detail = Object.fromEntries(Object.entries(fields).filter(([, value]) =>
      typeof value === "string" || typeof value === "number" || typeof value === "boolean"));
    const entry = {
      at: new Date().toISOString(),
      event,
      ...detail,
      platform: process.platform,
      remote: vscode.env.remoteName || "local",
      extensionVersion: String(this.context?.extension?.packageJSON?.version || "unknown"),
    };
    const line = JSON.stringify(entry);
    this.channel.appendLine(line);
    if (!this.filePath) return;
    try {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
      if (fs.existsSync(this.filePath) && fs.statSync(this.filePath).size > 4 * 1024 * 1024) {
        const previous = `${this.filePath}.previous`;
        fs.rmSync(previous, { force: true });
        fs.renameSync(this.filePath, previous);
      }
      fs.appendFileSync(this.filePath, `${line}\n`, { encoding: "utf8", mode: 0o600 });
    } catch (error) {
      log.warn(`load profiling write failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  measure<T>(event: string, fields: LoadProfileFields, work: () => T): T {
    if (!this.active) return work();
    const startedAt = performance.now();
    try { return work(); }
    finally { this.record(event, { ...fields, durationMs: Math.round(performance.now() - startedAt) }); }
  }

  show(): void { this.channel.show(); }

  async open(): Promise<void> {
    if (!this.filePath) return;
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    if (!fs.existsSync(this.filePath)) fs.writeFileSync(this.filePath, "", { mode: 0o600 });
    await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(this.filePath), { preview: false });
  }

  clear(): void {
    if (this.filePath) {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
      fs.writeFileSync(this.filePath, "", { mode: 0o600 });
    }
    this.channel.clear();
  }
}

const loadProfiler = new LoadProfiler();
let sharedMarket: SharedMarketManager | undefined;
const RETRIEVAL_ENGINE_VERSION = "0.3.0.dev2026100504";
const RETRIEVAL_CONFIGURATION_HASH = createHash("sha256").update("retrieval-boundary-v2|exact-match-v1|bm25-academic-k1=0.9-b=0.4|typed-prior-v1|derived-link-graph-v1|dual-path-rrf60-fuzzy08-v1").digest("hex");
let retrievalWorker: RetrievalWorkerManager | undefined;
let retrievalRefreshTimer: NodeJS.Timeout | undefined;
let retrievalRefreshRunning: Promise<void> | undefined;
let skillRouterRuntimeCache: Record<string, unknown> | undefined;
let skillRouterRuntimeRefresh: Promise<Record<string, unknown>> | undefined;
let publishedShareRefreshTimer: NodeJS.Timeout | undefined;
let publishedShareRefreshRunning: Promise<void> | undefined;
let githubSyncStartupTimer: NodeJS.Timeout | undefined;
let knowledgeInventory: KnowledgeInventoryManager | undefined;
const backgroundProcessInventory = new BackgroundProcessInventory();
const backgroundTaskRegistry = new BackgroundTaskRegistry(() => new Date(), (task, previous) => {
  if (task.kind !== "action-validation") return;
  const enabled = vscode.workspace.getConfiguration("personalKnowledge").get<boolean>("loadProfilingEnabled", false);
  if (!previous) recordBaselineEvent(performanceStateDir, enabled, { kind: "start-request", source: "action-validation", evidence: "observed" });
  if (task.status === "running") recordBaselineEvent(performanceStateDir, enabled, { kind: "start-success", source: "action-validation", evidence: "observed" });
});
const inventoryTask = backgroundTaskRegistry.producer({ id: "inventory:refresh", kind: "inventory", label: "Refresh knowledge inventory" });
const retrievalQueuedTask = backgroundTaskRegistry.producer({ id: "retrieval:queued", kind: "retrieval", label: "Refresh search index" });
const retrievalRunningTask = backgroundTaskRegistry.producer({ id: "retrieval:running", kind: "retrieval", label: "Refresh search index" });
const retrievalSolutionTask = backgroundTaskRegistry.producer({ id: "retrieval:solution", kind: "retrieval", label: "Prepare model retrieval" });
let retrievalSolutionTimer: NodeJS.Timeout | undefined;
let retrievalSolutionDisposed = false;
const brokerRefreshQueuedTask = backgroundTaskRegistry.producer({ id: "broker-refresh:queued", kind: "broker-refresh", label: "Refresh published Brokers" });
const brokerRefreshRunningTask = backgroundTaskRegistry.producer({ id: "broker-refresh:running", kind: "broker-refresh", label: "Refresh published Brokers" });
const contentCheckTask = backgroundTaskRegistry.producer({ id: "content-check:periodic", kind: "content-check", label: "Check Knowledge Root for changes" });
const githubSyncTasks = new Map<string, BackgroundTaskProducer>();
let performanceStateDir = "";
let activationStartedAt = 0;
let firstContentRecorded = false;
let knowledgeListRequestSequence = 0;

function invalidatePendingSubscriptionGroupLists(): void {
  knowledgeListRequestSequence += 1;
  for (const session of [panels.staging, ...panels.instances.values()]) session.listRequests.clear();
}

function refreshKnowledgeInventory(context: vscode.ExtensionContext, afterMutation = false): Promise<void> {
  if (!knowledgeInventory) return Promise.resolve();
  const startedAt = Date.now();
  inventoryTask.running({ detail: "Scanning files" });
  return knowledgeInventory.refresh(progress => {
    inventoryTask.running({
      detail: progress.parsed ? `Scanning files · ${progress.parsed} changed` : "Scanning files",
      progress: { current: progress.scanned, unit: "files" },
    });
    if (progress.batchCount) {
      postToPanel({ command: "inventoryBatch", data: { count: progress.batchCount, scanned: progress.scanned } });
    }
  }, afterMutation).then(snapshot => {
    if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "inventory.refresh_ms", Date.now() - startedAt, snapshot.stats.scanned);
    log.info(`knowledge inventory ready revision=${snapshot.revision.slice(0, 12)} scanned=${snapshot.stats.scanned} reused=${snapshot.stats.reused} parsed=${snapshot.stats.parsed} removed=${snapshot.stats.removed}`);
    _treeProvider?.refresh();
    postToPanel({ command: "inventoryReady", data: { revision: snapshot.revision, stats: snapshot.stats } });
  }).catch(error => {
    log.warn(`knowledge inventory refresh failed: ${(error as Error).message}`);
    if (afterMutation) throw error;
  })
    .finally(() => inventoryTask.idle());
}

function getSharedMarket(): SharedMarketManager {
  if (!sharedMarket) throw new Error("Subscription service is not initialized.");
  return sharedMarket;
}

function retrievalStateDirectory(context: vscode.ExtensionContext): string {
  const identity = createHash("sha256").update(path.resolve(getStorePath())).digest("hex").slice(0, 16);
  return path.join(context.globalStorageUri.fsPath, "retrieval", identity);
}

function currentRetrievalSnapshot() {
  const skills = skillList().flatMap(row => {
    const detail = skillGet(row.name);
    return detail ? [{ ...row, ...detail }] : [];
  });
  const notes = noteList(undefined, Number.MAX_SAFE_INTEGER, true);
  const papers = paperList().flatMap(row => {
    const detail = paperGet(row.slug);
    return detail ? [{ ...row, ...detail }] : [];
  });
  const scripts = scriptList().flatMap(row => {
    const detail = scriptGet(row.path);
    return detail ? [{ ...row, ...detail, extension: path.extname(row.path) }] : [];
  });
  const subscriptionGroups = sharedMarket
    ? SHARED_CONTENT_TYPES.flatMap(type => sharedMarket!.cachedGroups(type, "", Number.MAX_SAFE_INTEGER))
    : [];
  return createRetrievalSnapshot({
    skills, notes, papers, scripts,
    recipes: currentProjectStore().list().recipes,
    subscriptionGroups,
    readSubscription: key => getSharedMarket().cachedDetail(key),
  });
}

const MATURE_SKILL_ROUTER_SOLUTIONS = ["copilot_default", "l1_online"] as const;
type MatureSkillRouterSolution = typeof MATURE_SKILL_ROUTER_SOLUTIONS[number];

function enabledSkillRouterSolutions(): MatureSkillRouterSolution[] {
  const configured = vscode.workspace.getConfiguration("personalKnowledge")
    .get<string[]>("skillRouterEnabledSolutions", [...MATURE_SKILL_ROUTER_SOLUTIONS]);
  const enabled = MATURE_SKILL_ROUTER_SOLUTIONS.filter(solution => configured.includes(solution));
  if (!enabled.includes("copilot_default")) enabled.unshift("copilot_default");
  return enabled;
}

function skillRouterSources(): SkillRouterSource[] {
  const snapshot = getSharedMarket().snapshot as {
    subscriptions?: Array<{ id: string; alias?: string; brokerName?: string; shareId?: string; publisher?: string }>;
  };
  return availableSkillRouterSources(snapshot.subscriptions || []);
}

function skillRouterSourcePriority(sources = skillRouterSources()): string[] {
  const configured = vscode.workspace.getConfiguration("personalKnowledge")
    .get<string[]>("skillRouterSourcePriority", []);
  return normalizeSkillRouterSourcePriority(configured, sources);
}

function writeSkillRouterRuntimeConfig(context: vscode.ExtensionContext): MatureSkillRouterSolution[] {
  const enabledSolutions = enabledSkillRouterSolutions();
  const sources = skillRouterSources();
  const sourcePriority = skillRouterSourcePriority(sources);
  const stateDirectory = retrievalStateDirectory(context);
  fs.mkdirSync(stateDirectory, { recursive: true });
  const target = path.join(stateDirectory, "router-config.json");
  const temporary = `${target}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify({ schema: 2, enabledSolutions, sourcePriority, sources }, null, 2), { mode: 0o600 });
  fs.renameSync(temporary, target);
  return enabledSolutions;
}

let skillRouterBenchmarkRunning = false;
let skillRouterBenchmarkError = "";

function readSkillRouterBenchmarkReport(target: string) {
  try {
    const report = JSON.parse(fs.readFileSync(target, "utf8"));
    const measured = report.measured?.find((tier: any) => tier.tier === 1000 && tier.status === "measured");
    const pathMetrics = measured?.routingPath;
    if (report.schema === "pkm.retrieval.benchmark/v1" && report.engineVersion === RETRIEVAL_ENGINE_VERSION
        && pathMetrics?.profile === "l1_online" && pathMetrics.corpus === "synthetic"
        && pathMetrics.judgedQueries === 5 && pathMetrics.samples >= 5
        && [pathMetrics.successRate, pathMetrics.precisionAt5, pathMetrics.ndcgAt5, pathMetrics.latencyMs?.p50, pathMetrics.latencyMs?.p95]
          .every(value => typeof value === "number" && Number.isFinite(value) && value >= 0)) {
      return { generatedAt: report.generatedAt, metrics: pathMetrics };
    }
  } catch { /* no compatible report yet */ }
  return undefined;
}

function skillRouterBenchmarkState(context: vscode.ExtensionContext) {
  const target = path.join(retrievalStateDirectory(context), "router-benchmark.json");
  const measured = readSkillRouterBenchmarkReport(target);
  if (measured) return { running: skillRouterBenchmarkRunning, error: skillRouterBenchmarkError, ...measured };
  return { running: skillRouterBenchmarkRunning, error: skillRouterBenchmarkError };
}

async function skillRouterStatusData(context: vscode.ExtensionContext): Promise<object> {
  const enabledSolutions = writeSkillRouterRuntimeConfig(context);
  const sources = skillRouterSources();
  const sourcePriority = skillRouterSourcePriority(sources);
  const activeProfile = enabledSolutions.includes("l1_online") ? "l1_online" : "copilot_default";
  const inventory = knowledgeInventory?.snapshot;
  const documentCount = inventory ? Object.keys(inventory.entries).length : Number(skillRouterRuntimeCache?.documentCount || 0);
  const revision = inventory?.revision || String(skillRouterRuntimeCache?.corpusRevision || "");
  let runtime: Record<string, unknown> = skillRouterRuntimeCache || { ready: false };
  if (retrievalWorker) {
    const refresh = skillRouterRuntimeRefresh ||= retrievalWorker.status()
      .then(status => {
        skillRouterRuntimeCache = {
          ready: status.ready,
          documentCount: status.document_count,
          edgeCount: status.edge_count,
          corpusRevision: status.corpus_revision,
          readyGeneration: status.ready_generation,
          buildingGeneration: status.building_generation,
          engineVersion: status.engine_version,
          engine: status.engine,
          configurationHash: status.configuration_hash,
          schema: status.schema,
          supportedRoutes: status.supported_routes,
          unsupportedRoutes: status.unsupported_routes,
          tokenizers: status.tokenizers,
          facets: status.facets,
          updateMode: status.update_mode,
          limitations: status.limitations,
          error: status.error,
          semanticStatus: status.semantic_status,
          solution: status.solution,
          skillServing: status.skill_serving,
        };
        return skillRouterRuntimeCache;
      })
      .finally(() => { skillRouterRuntimeRefresh = undefined; });
    try {
      const refreshed = await Promise.race([
        refresh,
        new Promise<undefined>(resolve => setTimeout(() => resolve(undefined), 1_000)),
      ]);
      runtime = refreshed || { ...runtime, refreshing: true };
    } catch (error: any) {
      runtime = { ...runtime, ready: false, error: error?.message || String(error) };
    }
  }
  return {
    activeProfile,
    fallbackProfile: "copilot_default",
    enabledSolutions,
    sources,
    sourcePriority,
    solutions: {
      copilot_default: { available: true, mature: true, enabled: enabledSolutions.includes("copilot_default"), externallyServed: true },
      l1_exact: { available: false, mature: false, enabled: false },
      l1_online: { available: true, mature: true, enabled: enabledSolutions.includes("l1_online") },
      l1_weighted: { available: false, mature: false, enabled: false, systemDisabled: true },
    },
    modelBasedRoutingEnabled: runtime.semanticStatus === "ready",
    learnedCoordinationEnabled: false,
    collector: {
      eventType: "search_invocation",
      collectedTools: [
        "pkm.skill_context", "pkm.search_knowledge", "pkm.search_skills",
        "pkm.search_notes", "pkm.search_papers", "pkm.search_subscribed_content",
      ],
      unavailableTools: ["vscode.tool_search", "vscode.grep_search"],
      queryTextCollected: false,
    },
    corpus: { documentCount, revision },
    benchmark: skillRouterBenchmarkState(context),
    runtime,
  };
}

async function refreshRetrievalIndex(context: vscode.ExtensionContext): Promise<void> {
  if (!getStorePath() || !(await mcpRuntimeStatusAsync()).healthy) return;
  retrievalWorker ||= new RetrievalWorkerManager(
    retrievalStateDirectory(context),
    path.join(context.extensionPath, "resources", "retrieval_worker.py"),
    resolveMcpPython(),
    RETRIEVAL_ENGINE_VERSION,
    RETRIEVAL_CONFIGURATION_HASH,
    path.join(managedEnvironmentsRoot(), "pkm-retrieval"),
  );
  const startedAt = Date.now();
  const snapshot = currentRetrievalSnapshot();
  const sync = await retrievalWorker.sync(snapshot);
  scheduleRetrievalSolutionStatus(context);
  if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "retrieval.sync_ms", Date.now() - startedAt, sync.upserts + sync.deletes);
  log.info(`retrieval ${sync.mode} submitted revision=${snapshot.corpus_revision.slice(0, 12)} documents=${snapshot.documents.length} upserts=${sync.upserts} deletes=${sync.deletes}`);
}

async function requireRetrievalWorker(context: vscode.ExtensionContext): Promise<RetrievalWorkerManager> {
  if (!retrievalWorker) await refreshRetrievalIndex(context);
  if (!retrievalWorker) throw new Error("The retrieval worker is unavailable. Check the managed runtime in Settings.");
  return retrievalWorker;
}

function scheduleRetrievalSolutionStatus(context: vscode.ExtensionContext): void {
  if (retrievalSolutionDisposed) return;
  if (retrievalSolutionTimer) clearTimeout(retrievalSolutionTimer);
  retrievalSolutionTimer = setTimeout(async () => {
    retrievalSolutionTimer = undefined;
    if (retrievalSolutionDisposed) return;
    try {
      const worker = await requireRetrievalWorker(context);
      if (retrievalSolutionDisposed) return;
      const catalog = await worker.solutions();
      if (retrievalSolutionDisposed) return;
      const status = await worker.status();
      if (retrievalSolutionDisposed) return;
      if (panels.instances.size) void postToPanel({ command: "retrievalSolutions",
        data: { ...catalog, setup:worker.setupStatus(), modelRuntime: worker.modelRuntime(), runtimeStatus: {
          semanticStatus: status.semantic_status, solution: status.solution, skillServing: status.skill_serving,
        } } });
      if (catalog.state === "building" || catalog.state === "queued" || !!status.building_revision) {
        const progress = catalog.progress;
        retrievalSolutionTask.running({ detail: progress?.phase || catalog.state,
          progress: progress && progress.total !== null
            ? { current: progress.current, total: progress.total, unit: "units" } : undefined });
        scheduleRetrievalSolutionStatus(context);
      } else {
        retrievalSolutionTask.idle();
      }
    } catch (error) {
      if (retrievalSolutionDisposed) return;
      retrievalSolutionTask.idle();
      log.warn(`Model retrieval status failed: ${(error as Error).message}`);
      if (panels.instances.size) void postToPanel({ command: "retrievalSolutions", data: { error: (error as Error).message } });
    }
  }, 1000);
  retrievalSolutionTimer.unref();
}

function scheduleRetrievalRefresh(context: vscode.ExtensionContext, delay = 5_000): void {
  if (retrievalRefreshTimer) clearTimeout(retrievalRefreshTimer);
  retrievalQueuedTask.queued({
    detail: "Waiting for content changes to settle",
    nextRunAt: new Date(Date.now() + delay).toISOString(),
  });
  retrievalRefreshTimer = setTimeout(() => {
    retrievalRefreshTimer = undefined;
    retrievalQueuedTask.idle();
    const previous = retrievalRefreshRunning || Promise.resolve();
    retrievalRefreshRunning = previous.catch(() => {}).then(() => {
      retrievalRunningTask.running({ detail: "Updating the local search corpus" });
      return vscode.window.withProgress({
        location: vscode.ProgressLocation.Window,
        title: "PKM: Updating search index",
      }, () => refreshRetrievalIndex(context));
    })
      .catch(error => log.warn(`retrieval refresh failed: ${(error as Error).message}`))
      .finally(() => {
        retrievalRefreshRunning = undefined;
        retrievalRunningTask.idle();
      });
  }, delay);
  retrievalRefreshTimer.unref?.();
}

function schedulePublishedShareRefresh(context: vscode.ExtensionContext, delay = 5_000): void {
  if (!sharedMarket) return;
  brokerRefreshQueuedTask.queued({
    detail: "Waiting for content changes to settle",
    nextRunAt: new Date(Date.now() + delay).toISOString(),
  });
  if (publishedShareRefreshTimer) clearTimeout(publishedShareRefreshTimer);
  publishedShareRefreshTimer = setTimeout(() => {
    publishedShareRefreshTimer = undefined;
    brokerRefreshQueuedTask.idle();
    const previous = publishedShareRefreshRunning || Promise.resolve();
    publishedShareRefreshRunning = previous.catch(() => {}).then(() => {
      brokerRefreshRunningTask.running({ detail: "Checking published share revisions" });
      return vscode.window.withProgress({
        location: vscode.ProgressLocation.Window,
        title: "PKM: Refreshing published Brokers",
      }, async () => {
        const changed = await sharedMarket?.refreshPublishedShares() || 0;
        if (changed && activePanel()) void handleMessage({ command: "subscriptionState", refresh: false }, message => postToPanel(message), context);
      });
    }).catch(error => {
      log.warn(`background Broker refresh failed: ${(error as Error).message}`);
    }).finally(() => {
      publishedShareRefreshRunning = undefined;
      brokerRefreshRunningTask.idle();
    });
  }, delay);
  publishedShareRefreshTimer.unref?.();
}

/** Package list enriched with git-tracking info (tracked in the store, or its own repo). */
function packagesWithGit(): any[] {
  const store = getStorePath();
  const tracked = new Set<string>();
  try {
    const out = execSync("git ls-files -- packages/", { cwd: store, encoding: "utf-8", maxBuffer: 1 << 24, windowsHide: process.platform === "win32" });
    for (const line of out.split("\n")) { const m = line.match(/^packages\/([^/]+)\//); if (m) tracked.add(m[1]); }
  } catch { /* not a git repo */ }
  return (packageList() as any[]).map(p => ({
    ...p,
    gitRepo: fs.existsSync(path.join(store, "packages", p.name, ".git")),
    gitTracked: tracked.has(p.name),
  }));
}

/** Human summary of what a sync session shares, across ALL content types. */
function syncSummary(s: { contentTypes: string[]; selected: Record<string, string[]> }): string {
  const types = s.contentTypes || [];
  if (!types.length) return "nothing";
  return types.map(t => {
    const arr = (s.selected as any)?.[t] || [];
    return arr.length ? `${arr.length} ${t}` : `all ${t}`;
  }).join(", ");
}

function compactTags(value: unknown): string {
  if (Array.isArray(value)) return value.map(String).join(", ");
  if (typeof value !== "string") return "";
  try { return compactTags(JSON.parse(value)); } catch { return value; }
}

function preserveTopLevelPrivacy(type: PrivacyContentType, oldPath: string, newPath: string): void {
  if (!oldPath.includes("/") && newPath && !newPath.includes("/")) renameTopLevelPrivacy(type, oldPath, newPath);
}

function privateTopLevelPromotionBlocked(type: PrivacyContentType, oldPath: string, newPath: string): boolean {
  return !oldPath.includes("/") && !newPath && isTopLevelPrivate(type, oldPath);
}

let sharedCatalogRevision = 0;
let sharedCatalogCache: { revision: number; value: Record<string, any[]> } | undefined;
let sharedCatalogBuild: { revision: number; promise: Promise<Record<string, any[]>> } | undefined;
let githubSyncCatalogCache: { revision: number; value: GitHubSyncCatalog } | undefined;
let githubSyncCatalogBuild: { revision: number; promise: Promise<GitHubSyncCatalog> } | undefined;

function invalidateSharedContentCatalog(): void {
  sharedCatalogRevision += 1;
  sharedCatalogCache = undefined;
  githubSyncCatalogCache = undefined;
}

function memorySample(): { heapUsed: number; external: number; arrayBuffers: number } {
  const usage = process.memoryUsage();
  return { heapUsed: usage.heapUsed, external: usage.external, arrayBuffers: usage.arrayBuffers };
}

async function sharedContentCatalog(): Promise<Record<string, any[]>> {
  const revision = sharedCatalogRevision;
  if (sharedCatalogCache?.revision === revision) return sharedCatalogCache.value;
  if (sharedCatalogBuild?.revision === revision) return sharedCatalogBuild.promise;
  const startedAt = Date.now(), before = memorySample();
  const promise = (async () => ({
    skills: (skillList() as any[]).filter(row => !isContentItemPrivate("skills", row)).map(row => ({ id: row.name, label: row.name, cat: row.category ?? "", treePath: row.category || "(uncategorized)", meta: compactTags(row.tags) })),
    notes: (noteList(undefined, 500) as any[]).filter(row => !isContentItemPrivate("notes", row)).map(row => ({ id: row.slug, label: row.title, cat: row.category ?? "", treePath: row.category || "(uncategorized)", meta: row.type })),
    papers: (paperList() as any[]).filter(row => !isContentItemPrivate("papers", row)).map(row => ({ id: row.slug, label: row.title, cat: row.category || row.topic || "", treePath: row.category || "(uncategorized)", meta: [row.topic, row.year].filter(Boolean).join(" · ") })),
    prompts: promptList().filter(row => !isContentItemPrivate("prompts", row)).map(row => ({ id: `${row.project}/${row.task}`, label: row.task, cat: row.project, treePath: row.project, meta: row.latest })),
    scripts: (scriptList() as any[]).filter(row => !isContentItemPrivate("scripts", row)).map(row => ({ id: row.path, label: row.file, cat: row.category === "(root)" ? "" : row.category ?? "", treePath: row.category === "(root)" ? "" : row.category ?? "", meta: row.lang })),
    packages: packageList().filter((row: any) => !isContentItemPrivate("packages", row)).map((row: any) => ({ id: row.name, label: row.name, cat: "", treePath: "", meta: row.lang })),
    servers: (await serverList()).filter(row => !isContentItemPrivate("servers", row)).map(row => ({ id: row.slug, label: row.name, cat: row.category ?? "", treePath: row.category || "Ungrouped", meta: (row.tags || []).join(", ") })),
    recipes: currentProjectStore().list().recipes.filter(row => !isContentItemPrivate("recipes", row)).map(row => ({ id: row.recipeId, label: row.name, cat: row.category ?? "", treePath: row.category || "Uncategorized", meta: row.scope === "project" ? "Project Recipe" : "Global Recipe" })),
  }))();
  sharedCatalogBuild = { revision, promise };
  try {
    const value = await promise;
    if (sharedCatalogRevision === revision) sharedCatalogCache = { revision, value };
    const after = memorySample();
    log.info(`subscription catalog build revision=${revision} durationMs=${Date.now() - startedAt} items=${Object.values(value).reduce((sum, items) => sum + items.length, 0)} heapDelta=${after.heapUsed - before.heapUsed} externalDelta=${after.external - before.external} arrayBufferDelta=${after.arrayBuffers - before.arrayBuffers}`);
    return value;
  } finally {
    if (sharedCatalogBuild?.promise === promise) sharedCatalogBuild = undefined;
  }
}

const GITHUB_SYNC_TARGETS_SCHEMA = 1;
const GITHUB_SYNC_SECRET_PREFIX = "personalKnowledge.githubSync.vscode.";
let githubSyncScheduler: PkmServiceClient | undefined;
let githubSyncCoordinatorStatePath: string | undefined;
const githubSyncForceUpdateAudit = new Map<string, { actor: string; comment: string }>();

function githubSyncStateDirectory(context: vscode.ExtensionContext): string {
  return path.join(context.globalStorageUri.fsPath, "github-sync");
}

function githubSyncCoordinatorStateDirectory(context: vscode.ExtensionContext): string {
  return githubSyncCoordinatorDirectory(context.globalStorageUri.fsPath, getStorePath());
}

function withGitHubSyncTargetLock<T>(context: vscode.ExtensionContext, targetId: string, action: () => Promise<T>): Promise<T> {
  return withCrossProcessLock(
    path.join(githubSyncStateDirectory(context), "locks", `${targetId}.lock`),
    `GitHub Sync target ${targetId}`,
    10 * 60_000,
    action,
    4 * 60 * 60_000,
  );
}

function withGitHubSyncApplyLock<T>(context: vscode.ExtensionContext, action: () => Promise<T>): Promise<T> {
  return withCrossProcessLock(
    path.join(githubSyncCoordinatorStateDirectory(context), "apply.lock"),
    "GitHub Sync Knowledge Root apply",
    10 * 60_000,
    action,
    4 * 60 * 60_000,
  );
}

function cleanupDeletedGitHubSyncTarget(context: vscode.ExtensionContext, targetId: string): void {
  void withGitHubSyncTargetLock(context, targetId, async () => {
    fs.rmSync(path.join(githubSyncStateDirectory(context), "checkouts", targetId), {
      recursive: true,
      force: true,
      maxRetries: 8,
      retryDelay: 150,
    });
    fs.rmSync(path.join(githubSyncStateDirectory(context), "checkouts", "remote-authority-cache", targetId), {
      recursive: true, force: true, maxRetries: 8, retryDelay: 150,
    });
    clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
  }).catch(error => {
    log.warn(`GitHub Sync target ${targetId} was deleted, but background checkout cleanup will need a later retry: ${error instanceof Error ? error.message : String(error)}`);
  });
}

function githubSyncTargetsPath(context: vscode.ExtensionContext): string {
  return path.join(githubSyncStateDirectory(context), "targets.json");
}

function githubPublicationMigration(context: vscode.ExtensionContext, targetId: string): GitHubPublicationMigration {
  return new GitHubPublicationMigration(githubSyncStateDirectory(context), targetId);
}

async function githubPublicationMigrationSource(
  context: vscode.ExtensionContext,
  target: GitHubSyncTarget,
  includeRepositoryDigests = false,
): Promise<GitHubPublicationMigrationSource> {
  const checkoutRoot = path.join(githubSyncStateDirectory(context), "checkouts");
  const credentials = await readGitHubSyncCredentials(context, target);
  const snapshot = await fetchGitHubRemoteSnapshot(target, checkoutRoot, false, credentials);
  const manifest = await readGitHubRemoteManifest(target, checkoutRoot, snapshot.commit);
  let repositoryDigests: Record<string, string> | undefined;
  if (includeRepositoryDigests) {
    repositoryDigests = {};
    const maximumBatchBytes = 64 * 1024 * 1024;
    let batch: typeof snapshot.files = [];
    let batchBytes = 0;
    const digestBatch = async () => {
      if (!batch.length) return;
      const contents = await readGitHubRemoteFilesForSubscription(
        target,
        checkoutRoot,
        snapshot.commit,
        batch,
        maximumBatchBytes,
      );
      for (const file of batch) {
        const content = contents.get(file.path);
        if (!content) throw new Error(`Remote file could not be read for migration: ${file.path}.`);
        repositoryDigests![file.path] = createHash("sha256").update(content).digest("hex");
      }
      batch = [];
      batchBytes = 0;
    };
    for (const file of snapshot.files) {
      if (file.size > maximumBatchBytes) {
        throw new Error(`Remote file is too large to migrate: ${file.path}.`);
      }
      if (batch.length && batchBytes + file.size > maximumBatchBytes) await digestBatch();
      batch.push(file);
      batchBytes += file.size;
    }
    await digestBatch();
  }
  const catalog = await githubSyncCatalog();
  const folderCount = new Set(snapshot.files.map(file => path.posix.dirname(file.path)).filter(folder => folder !== ".")).size;
  const idCount = new Set(GITHUB_SYNC_CONTENT_TYPES.flatMap(type => catalog[type].map(item => `${type}\0${item.id}`))).size;
  return {
    target,
    remoteCommit: snapshot.commit,
    manifest,
    repositoryFiles: snapshot.files.map(file => file.path),
    repositoryDigests,
    canonicalFiles: githubSyncMigrationCanonicalFiles(catalog, target),
    activeCount: snapshot.files.length,
    trashCount: snapshot.files.filter(file => file.path.split("/").includes(".trash")).length,
    folderCount,
    idCount,
  };
}

function optionalConflictText(filePath: string): string {
  try { return fs.readFileSync(filePath, "utf8"); }
  catch (error: any) {
    if (error?.code === "ENOENT") return "(file does not exist in this version)";
    throw error;
  }
}

function parseAgentMergeResponse(raw: string, type: GitHubSyncContentType): {
  mergedContent: string;
  rationale: string;
  safeToApply: boolean;
  review: GitHubSyncAgentReview;
} {
  const cleaned = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  let parsed: any;
  try { parsed = JSON.parse(cleaned); }
  catch { throw new Error("The Agent did not return a valid merge candidate."); }
  const mergedContent = type === "recipes" && parsed?.mergedContent && typeof parsed.mergedContent === "object"
    ? JSON.stringify(parsed.mergedContent, null, 2) + "\n"
    : parsed?.mergedContent;
  const decisions = Array.isArray(parsed?.decisions) ? parsed.decisions : [];
  const evidence = Array.isArray(parsed?.evidence) ? parsed.evidence : [];
  const unresolvedConflicts = Array.isArray(parsed?.unresolvedConflicts) ? parsed.unresolvedConflicts : [];
  const introducedContent = Array.isArray(parsed?.introducedContent) ? parsed.introducedContent : [];
  const choices = new Set(["base", "local", "remote", "combined", "removed"]);
  if (typeof mergedContent !== "string" || typeof parsed?.rationale !== "string" || typeof parsed?.safeToApply !== "boolean"
    || !Array.isArray(parsed?.decisions) || !Array.isArray(parsed?.evidence)
    || !Array.isArray(parsed?.unresolvedConflicts) || !Array.isArray(parsed?.introducedContent)
    || typeof parsed?.confidence !== "number" || parsed.confidence < 0 || parsed.confidence > 1
    || !decisions.every((decision: any) => decision && typeof decision.subject === "string"
      && choices.has(decision.choice) && typeof decision.reason === "string")
    || !evidence.every((item: unknown) => typeof item === "string")
    || !unresolvedConflicts.every((item: unknown) => typeof item === "string")
    || !introducedContent.every((item: unknown) => typeof item === "string")) {
    throw new Error("The Agent merge response is missing required fields.");
  }
  return {
    mergedContent,
    rationale: parsed.rationale,
    safeToApply: parsed.safeToApply,
    review: {
      decisions,
      evidence,
      unresolvedConflicts,
      introducedContent,
      confidence: parsed.confidence,
      accuracyRisk: unresolvedConflicts.length > 0 || introducedContent.length > 0 || parsed.confidence < 0.85,
      humanFinalReviewRequired: true,
    },
  };
}

interface GitHubSyncAgentBatchResult {
  prepared: number;
  unsupported: number;
  failed: Array<{ path: string; error: string }>;
}

async function prepareGitHubSyncAgentCandidates(
  context: vscode.ExtensionContext,
  targetId: string,
  relative = "",
  reportProgress?: (message: string, increment?: number) => void,
): Promise<GitHubSyncAgentBatchResult> {
  const stateDirectory = githubSyncStateDirectory(context);
  const record = readGitHubSyncConflict(stateDirectory, targetId);
  if (!record) throw new Error("GitHub Sync conflict was not found.");
  if (record.purpose === "initial-preview" && record.remoteSchema !== 3) {
    throw new Error(`Complete the GitHub publication migration from schema ${record.remoteSchema || "unknown"} to schema 3 before applying the initial comparison.`);
  }
  const backends = await listAiBackends(context);
  const backend = backends.find(candidate => candidate.kind === "copilot") || backends[0];
  if (!backend || backend.id.endsWith(":needkey")) throw new Error("No available Agent model can prepare this conflict. Keep manual review or configure an AI backend.");
  const files = record.files.filter(file => file.candidateSource === "unresolved" && (!relative || file.path === relative));
  if (!files.length) throw new Error("No unresolved GitHub Sync conflict files are available for Agent merging.");
  const result: GitHubSyncAgentBatchResult = { prepared: 0, unsupported: 0, failed: [] };
  for (const file of files) {
    if (file.type !== "skills" && file.type !== "recipes") {
      if (relative) throw new Error(`Agent-assisted merge supports Skills and Recipes. Choose this machine, choose GitHub, or edit ${file.path} manually.`);
      result.unsupported += 1;
      continue;
    }
    reportProgress?.(file.path, 100 / Math.max(1, files.length));
    try {
      const variants = {
        base: optionalConflictText(path.join(stateDirectory, "conflicts", targetId, "base", ...file.path.split("/"))),
        local: optionalConflictText(path.join(stateDirectory, "conflicts", targetId, "local", ...file.path.split("/"))),
        remote: optionalConflictText(path.join(stateDirectory, "conflicts", targetId, "remote", ...file.path.split("/"))),
      };
      if (Object.values(variants).some(value => Buffer.byteLength(value, "utf8") > 512 * 1024)) {
        throw new Error(`Agent-assisted merge is limited to 512 KiB per version: ${file.path}`);
      }
      const recipe = file.type === "recipes";
      const response = parseAgentMergeResponse(await runAiPrompt(context, backend, [
        recipe
          ? "Merge this PKM Recipe conflict structurally and semantically, not by line concatenation."
          : "Merge this PKM Skill conflict by meaning, not by line concatenation.",
        recipe
          ? "Preserve the Recipe schema, node IDs, dependency graph, required completion nodes, configuration, and compatible changes from both sides. Do not invent unsupported node kinds."
          : "Preserve correct and compatible instructions from both sides, remove stale contradictions, and do not invent unverified facts.",
        recipe
          ? "Return JSON only with: mergedContent (the complete Recipe JSON object or a complete JSON string), rationale, safeToApply, decisions, evidence, unresolvedConflicts, introducedContent, confidence."
          : "Return JSON only with: mergedContent (complete Skill Markdown), rationale, safeToApply, decisions, evidence, unresolvedConflicts, introducedContent, confidence.",
        "decisions must be an array of {subject, choice, reason}; choice must be base, local, remote, combined, or removed.",
        "evidence, unresolvedConflicts, and introducedContent must be string arrays. confidence must be between 0 and 1.",
        "Treat numbers, dates, citations, factual claims, conclusions, privacy, deletion-vs-modification, executable logic, and ambiguous intent as accuracy-sensitive. List every unresolved accuracy risk. Do not silently invent content.",
        "Set safeToApply=false when intent is ambiguous, an accuracy-sensitive conflict remains unresolved, or the result could create an incorrect PKM item.",
        "A human will always perform Final Review before Accept & Push.",
        `Path: ${file.path}`,
        `BASE:\n${variants.base}`,
        `LOCAL:\n${variants.local}`,
        `REMOTE:\n${variants.remote}`,
      ].join("\n\n")), file.type);
      if (!response.safeToApply) throw new Error(`The Agent declined to produce a safe merge for ${file.path}: ${response.rationale}`);
      if (recipe) {
        const mergedRecipe = JSON.parse(response.mergedContent) as Record<string, unknown>;
        const compiled = compileWorkflowDefinitionV1(mergedRecipe.definition);
        if (!compiled.ok) throw new Error(`The Agent produced an invalid Recipe definition: ${file.path}`);
        mergedRecipe.executableDigest = compiled.executableDigest;
        response.mergedContent = `${JSON.stringify(mergedRecipe, null, 2)}\n`;
      }
      updateGitHubSyncAgentCandidate(stateDirectory, targetId, file.path, response.mergedContent, response.rationale, response.review);
      result.prepared += 1;
    } catch (error: any) {
      if (relative) throw error;
      result.failed.push({ path: file.path, error: error?.message || String(error) });
    }
  }
  return result;
}

function githubSyncCandidateDestination(root: string, relative: string): string {
  const safe = githubSyncSafeRelativePath(relative);
  let current = path.resolve(root);
  for (const segment of safe.split("/")) {
    current = path.join(current, segment);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) {
      throw new Error(`GitHub Sync candidate crosses a symbolic link: ${relative}`);
    }
  }
  return current;
}

function requireSavedGitHubSyncConflictDocuments(context: vscode.ExtensionContext, targetId: string): void {
  const stateDirectory = githubSyncStateDirectory(context);
  const record = readGitHubSyncConflict(stateDirectory, targetId);
  if (!record) throw new Error("GitHub Sync conflict was not found.");
  const paths = new Set<string>();
  for (const file of record.files) {
    paths.add(path.resolve(gitHubSyncConflictVariantPath(stateDirectory, targetId, "merged", file.path)));
    for (const relative of [file.path, file.localPath, file.resultPath]) {
      if (!relative) continue;
      paths.add(path.resolve(relative.startsWith("agentSnapshots/")
        ? githubSyncCandidateDestination(path.join(getStorePath(), ".pkm", "state"), `agent-snapshots/${relative.slice("agentSnapshots/".length)}`)
        : githubSyncCandidateDestination(getStorePath(), relative)));
    }
  }
  const dirty = vscode.workspace.textDocuments.filter(document =>
    document.isDirty && document.uri.scheme === "file" && paths.has(path.resolve(document.uri.fsPath)));
  if (dirty.length) {
    throw new Error(`Save or discard unsaved editor changes before changing conflict choices or applying: ${dirty.map(document => path.basename(document.uri.fsPath)).join(", ")}`);
  }
}

async function withGitHubSyncConflictEdit<T>(
  context: vscode.ExtensionContext,
  message: { targetId: string; conflictId?: string; revision?: number },
  action: () => Promise<T>,
  allowApplied = false,
): Promise<T> {
  return withGitHubSyncTargetLock(context, message.targetId, async () => {
    const record = validateGitHubSyncConflictVersion(githubSyncStateDirectory(context), message.targetId, {
      conflictId: message.conflictId || "",
      revision: message.revision ?? -1,
    });
    requireSavedGitHubSyncConflictDocuments(context, message.targetId);
    if (record.appliedAt && !allowApplied) {
      throw new Error("These resolutions have already been applied locally. Retry Sync or refresh its status before editing them.");
    }
    return action();
  });
}

async function openGitHubSyncResolutionWorkbench(context: vscode.ExtensionContext, targetId: string, initialPath?: string): Promise<void> {
  const stateDirectory = githubSyncStateDirectory(context);
  await openGitHubSyncConflictWorkbench(context, targetId, {
    initialPath,
    getState: () => withGitHubSyncTargetLock(context, targetId, async (): Promise<GitHubSyncWorkbenchState | undefined> => {
      const record = readGitHubSyncConflict(stateDirectory, targetId);
      if (!record) return undefined;
      return {
        record,
        files: record.files.map(file => {
          const variants: Partial<Record<"base" | "local" | "remote" | "merged", string>> = {};
          const previews: Partial<Record<"base" | "local" | "remote" | "merged", string>> = {};
          const extension = path.extname(file.path).toLowerCase();
          const mime = ({ ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp" } as Record<string, string>)[extension];
          let binary = false;
          for (const variant of ["base", "local", "remote", "merged"] as const) {
            if (variant === "base" && !file.hasBase || variant === "local" && !file.hasLocal || variant === "remote" && !file.hasRemote) continue;
            const content = fs.readFileSync(gitHubSyncConflictVariantPath(stateDirectory, targetId, variant, file.path));
            const text = content.toString("utf8");
            if (!githubSyncIsTextContent(file.path, content)) binary = true;
            variants[variant] = text;
            if (mime) previews[variant] = `data:${mime};base64,${content.toString("base64")}`;
          }
          return { path: file.path, binary, mime, previews, ...(binary ? {} : variants) };
        }),
      };
    }),
    perform: (request: GitHubSyncWorkbenchRequest) => withGitHubSyncConflictEdit(context, { targetId, ...request }, async () => {
      const relative = request.path || "";
      switch (request.command) {
        case "choose":
          if (!request.source) throw new Error("Choose a source version.");
          selectGitHubSyncConflictCandidate(stateDirectory, targetId, relative, request.source);
          break;
        case "delete-remote": selectGitHubSyncConflictDeletion(stateDirectory, targetId, relative); break;
        case "delete-local": selectGitHubSyncConflictLocalDeletion(stateDirectory, targetId, relative); break;
        case "save":
          if (typeof request.content === "string") saveGitHubSyncManualCandidate(stateDirectory, targetId, relative, request.content);
          else validateGitHubSyncManualCandidate(stateDirectory, targetId, relative);
          break;
        case "agent":
          await prepareGitHubSyncAgentCandidates(context, targetId, relative);
          break;
        case "apply": {
          const result = await withGitHubSyncApplyLock(context, () => acceptGitHubSyncConflict(context, targetId));
          if (result.refreshed.length) throw new Error("Local files changed. Review the refreshed choices before applying again.");
          break;
        }
        case "compare": {
          const file = readGitHubSyncConflict(stateDirectory, targetId)?.files.find(file => file.path === relative);
          if (!file) throw new Error("GitHub Sync conflict file was not found.");
          const variant = file.hasRemote ? "remote" : file.hasBase ? "base" : "local";
          await vscode.commands.executeCommand("vscode.diff",
            vscode.Uri.file(gitHubSyncConflictVariantPath(stateDirectory, targetId, variant, relative)),
            vscode.Uri.file(gitHubSyncConflictVariantPath(stateDirectory, targetId, "merged", relative)),
            `GitHub Sync source | Result: ${relative}`);
          break;
        }
        case "refresh": break;
        default: throw new Error("Unsupported conflict workbench action.");
      }
    }, request.command === "apply" || request.command === "refresh" || request.command === "compare"),
  });
}

async function acceptGitHubSyncConflict(
  context: vscode.ExtensionContext,
  targetId: string,
  reportProgress?: (text: string) => void,
): Promise<{ accepted: number; refreshed: string[] }> {
  const stateDirectory = githubSyncStateDirectory(context);
  const record = readGitHubSyncConflict(stateDirectory, targetId);
  if (!record) throw new Error("GitHub Sync conflict was not found.");
  if (!githubSyncScheduler) throw new Error("GitHub Sync coordinator is not ready. Refresh GitHub Sync before applying resolutions.");
  requireSavedGitHubSyncConflictDocuments(context, targetId);
  if (record.appliedAt) {
    reportProgress?.("Retrying synchronization of the already-applied local resolutions…");
    await githubSyncScheduler.request(targetId, "manual");
    return { accepted: record.files.length, refreshed: [] };
  }
  if (record.purpose === "initial-preview" && record.remoteSchema !== 3) {
    throw new Error(`Complete the GitHub publication migration from schema ${record.remoteSchema || "unknown"} to schema 3 before applying the initial comparison.`);
  }
  const unresolved = record.files.filter(file => file.candidateSource === "unresolved");
  if (unresolved.length) {
    throw new Error(`Choose a resolution for every conflicting file before syncing: ${unresolved.map(file => file.path).join(", ")}`);
  }
  for (const file of record.files.filter(member => member.reason === "unrecorded-local-absence")) {
    const members = record.files.filter(member => member.type === file.type && member.itemId === file.itemId);
    if (members.some(member => member.candidateSource === "delete")
      && !members.every(member => member.candidateSource === "delete")) {
      throw new Error(`Review the whole missing entity before applying: ${file.type}/${file.itemId}. Body, sidecars and dependencies cannot mix deletion and restoration.`);
    }
  }
  reportProgress?.("Verifying the Remote commit…");
  const target = githubSyncTargetById(context, targetId);
  const credentials = await readGitHubSyncCredentials(context, target);
  const snapshot = await fetchGitHubRemoteSnapshot(target, path.join(stateDirectory, "checkouts"), false, credentials);
  if (snapshot.commit !== record.remoteCommit) throw new Error("The remote branch changed after this conflict was prepared. Sync again before accepting a merge.");
  reportProgress?.("Checking machine-local files…");
  const recipeSnapshot = currentProjectStore().list();
  const recipeSyncContent = new Map(currentProjectStore().recipeSyncEntries()
    .map(entry => [entry.recipe.recipeId, githubSyncManagedContent("recipes", Buffer.from(entry.content, "utf8"))]));
  const candidates = record.files.map(file => {
    const deleteRemote = file.candidateSource === "delete";
    const deleteLocal = file.candidateSource === "delete-local";
    const content = deleteRemote || deleteLocal ? undefined : readGitHubSyncConflictCandidate(stateDirectory, targetId, file.path, true);
    const sourcePath = file.localPath || file.path;
    const resultPath = file.resultPath || file.path;
    return {
      file,
      content,
      deleteRemote,
      deleteLocal,
      originalLocal: file.hasLocal
        ? fs.readFileSync(gitHubSyncConflictVariantPath(stateDirectory, targetId, "local", file.path))
        : undefined,
      currentLocal: file.type === "recipes"
        ? (() => {
          const recipe = recipeSnapshot.recipes.find(candidate => candidate.recipeId === file.itemId);
          return recipe ? recipeSyncContent.get(recipe.recipeId) || githubSyncRecipeContent(recipe) : undefined;
        })()
        : undefined,
      source: file.type === "recipes" ? undefined
        : sourcePath.startsWith("agentSnapshots/")
          ? githubSyncCandidateDestination(path.join(getStorePath(), ".pkm", "state"), `agent-snapshots/${sourcePath.slice("agentSnapshots/".length)}`)
          : githubSyncCandidateDestination(getStorePath(), sourcePath),
      destination: file.type === "recipes"
        ? undefined
        : resultPath.startsWith("agentSnapshots/")
          ? githubSyncCandidateDestination(path.join(getStorePath(), ".pkm", "state"), `agent-snapshots/${resultPath.slice("agentSnapshots/".length)}`)
          : githubSyncCandidateDestination(getStorePath(), resultPath),
    };
  });
  if (candidates.some(candidate => candidate.file.type === "scripts")) {
    validateGitHubSyncConflictScriptIdentity(getStorePath(), record, candidates);
  }
  const refreshed: string[] = [];
  for (const { file, content, deleteRemote, deleteLocal, originalLocal, currentLocal, source, destination } of candidates) {
    const current = file.type === "recipes"
      ? currentLocal
      : source && fs.existsSync(source) ? fs.readFileSync(source) : undefined;
    if (!deleteRemote && !deleteLocal && destination && source !== destination && fs.existsSync(destination)
      && !fs.readFileSync(destination).equals(content!)) {
      throw new Error(`The selected destination already contains different local content: ${file.resultPath || file.path}`);
    }
    if (deleteRemote) {
      if (current) refreshed.push(file.path);
    } else if (deleteLocal) {
      if (current && (!originalLocal || !current.equals(originalLocal))) refreshed.push(file.path);
    } else {
      try { validateGitHubSyncConflictLocalState(file.path, originalLocal, content!, current); }
      catch { refreshed.push(file.path); }
    }
    if (refreshed.includes(file.path)) {
      refreshGitHubSyncConflictLocalCandidate(stateDirectory, targetId, file.path, current);
    }
  }
  if (refreshed.length) {
    return { accepted: 0, refreshed };
  }
  reportProgress?.(`Applying ${record.files.length} choices locally…`);
  const recipeCandidates = candidates.filter(candidate =>
    candidate.file.type === "recipes" && !candidate.deleteRemote && !candidate.deleteLocal
  ).map(candidate => {
    const recipe = JSON.parse(candidate.content!.toString("utf8")) as RecipeRecord;
    if (recipe.recipeId !== candidate.file.itemId) {
      throw new Error(`Recipe identity does not match the conflict record: ${candidate.file.path}`);
    }
    return recipe;
  });
  // Write durable intent first. If a later Recipe/target/marker write fails,
  // retry rechecks Remote, digests and raw snapshots; already-written bytes are idempotent.
  markGitHubSyncConflictApplying(stateDirectory, targetId);
  replaceGitHubSyncFilesAtomically(
    candidates
      .filter(candidate => !candidate.deleteRemote && !!candidate.destination)
      .flatMap(({ source, destination, content, originalLocal }) => [
        { destination: destination!, content, guard: { original: source === destination ? originalLocal : undefined } },
        ...(source && source !== destination ? [{ destination: source, content: undefined, guard: { original: originalLocal } }] : []),
      ]),
    "GitHub Sync conflict acceptance",
    getStorePath(),
  );
  if (recipeCandidates.length) {
    const store = currentProjectStore();
    store.replaceRecipesFromSync(projectCommand(store, "recipe-github-sync", {
      targetId,
      conflictId: record.id,
      recipes: recipeCandidates.map(recipe => ({ recipeId: recipe.recipeId, revision: recipe.revision }))
    }), recipeCandidates);
  }
  applyGitHubSyncRecipeDeletes(candidates
    .filter(candidate => candidate.deleteLocal && candidate.file.type === "recipes")
    .map(candidate => candidate.file.itemId));
  for (const { file } of candidates) {
    if (file.privacy === "private" && file.type !== "agentSnapshots" && file.type !== "profiles") {
      const topLevel = file.type === "actions" ? file.itemId : (file.resultPath || file.path).split("/").slice(1, -1)[0];
      if (topLevel) setTopLevelPrivacy(file.type as PrivacyContentType, topLevel, true);
    }
  }
  await mutateGitHubSyncTargets(context, `accept ${targetId}`, targets => {
    const current = targets.find(candidate => candidate.id === targetId);
    if (!current) throw new Error("GitHub Sync target was not found.");
    current.lastSync = {
      at: new Date().toISOString(),
      commit: record.remoteCommit,
      fingerprints: current.lastSync?.fingerprints || {},
      repository: current.repository,
      branch: current.branch,
      storeRoot: path.resolve(getStorePath()),
    };
    current.lastResolutionReport = record.resolutionReport;
    current.automation.enabled = false;
    const deletions = candidates.filter(candidate => candidate.deleteRemote
      && candidate.file.entityDeletion !== false
      && candidates.filter(other => other.file.type === candidate.file.type && other.file.itemId === candidate.file.itemId)
        .every(other => other.deleteRemote)).map(({ file }) => ({
      type: file.type,
      itemId: file.itemId,
      deletedAt: new Date().toISOString(),
      category: file.category,
      privacy: file.privacy,
    }));
    current.pendingDeletions = record.purpose === "initial-preview"
      ? []
      : [
        ...(current.pendingDeletions || []).filter(existing =>
          !deletions.some(deletion => deletion.type === existing.type && deletion.itemId === existing.itemId)),
        ...deletions,
      ];
    delete current.lastFailure;
    return { targets, result: undefined };
  });
  markGitHubSyncConflictApplied(stateDirectory, targetId);
  invalidateSharedContentCatalog();
  reportProgress?.("Queueing Fetch, Commit, and Push…");
  await githubSyncScheduler.request(targetId, "manual");
  reportProgress?.("Refreshing the Knowledge inventory…");
  await refreshKnowledgeInventory(context);
  _treeProvider?.refresh();
  return { accepted: record.files.length, refreshed: [] };
}

function githubSyncTargetById(context: vscode.ExtensionContext, targetId: string): GitHubSyncTarget {
  const target = readGitHubSyncTargets(context).find(candidate => candidate.id === targetId);
  if (!target) throw new Error("GitHub Sync target was not found.");
  return target;
}

function requireGitHubSyncManualMode(target: GitHubSyncTarget, action: string): void {
  if (target.automation.enabled) {
    throw new Error(`Turn off Auto Sync for ${target.name} before ${action}.`);
  }
}

async function revalidateGitHubSyncLocalContent(context: vscode.ExtensionContext, targetId: string): Promise<void> {
  invalidateSharedContentCatalog();
  const target = githubSyncTargetById(context, targetId);
  const { issues, materialized } = await inspectGitHubSyncLocalContent(target, await githubSyncCatalog(), getStorePath());
  if (materialized.deferredEntities.size) {
    throw new Error("Selected files changed while validation was reading them. Revalidate again; no Sync was started.");
  }
  clearGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
  if (issues.length) {
    storeGitHubSyncContentRepair(githubSyncStateDirectory(context), new GitHubSyncContentRepairError(targetId, issues));
  } else {
    void vscode.window.showInformationMessage("Local content validation passed. No Sync was started. Use Sync when you are ready.");
  }
}

function readGitHubSyncTargets(context: vscode.ExtensionContext): GitHubSyncTarget[] {
  try {
    const parsed = JSON.parse(fs.readFileSync(githubSyncTargetsPath(context), "utf8"));
    if (parsed?.schema !== GITHUB_SYNC_TARGETS_SCHEMA || !Array.isArray(parsed.targets)) throw new Error("unsupported target file");
    return parsed.targets.map((target: unknown) => normalizeGitHubSyncTarget(target));
  } catch (error: any) {
    if (error?.code === "ENOENT") return [];
    throw new Error(`Cannot read GitHub Sync targets: ${error?.message || String(error)}`);
  }
}

function writeGitHubSyncTargets(context: vscode.ExtensionContext, targets: GitHubSyncTarget[]): void {
  const targetPath = githubSyncTargetsPath(context);
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  const temporary = `${targetPath}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify({ schema: GITHUB_SYNC_TARGETS_SCHEMA, targets }, null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
  fs.renameSync(temporary, targetPath);
}

async function mutateGitHubSyncTargets<T>(
  context: vscode.ExtensionContext,
  owner: string,
  mutation: (targets: GitHubSyncTarget[]) => { targets: GitHubSyncTarget[]; result: T },
): Promise<T> {
  return withCrossProcessLock(
    path.join(githubSyncStateDirectory(context), "targets-state.lock"),
    `GitHub Sync target state (${owner})`,
    10 * 60_000,
    async () => {
      const { targets, result } = mutation(readGitHubSyncTargets(context));
      writeGitHubSyncTargets(context, targets);
      return result;
    },
  );
}

interface StoredGitHubSyncCredentials {
  accountId: string;
  accountLabel: string;
  accessToken: string;
}

function githubSyncSecretKey(targetId: string): string {
  return `${GITHUB_SYNC_SECRET_PREFIX}${targetId}`;
}

async function readGitHubSyncCredentials(context: vscode.ExtensionContext, target: GitHubSyncTarget): Promise<GitHubSyncCredentials | undefined> {
  return readStoredGitHubSyncCredentials(() => context.secrets.get(githubSyncSecretKey(target.id)), target);
}

async function connectGitHubSyncVscodeAccount(context: vscode.ExtensionContext, target: GitHubSyncTarget, persist = true): Promise<GitHubSyncCredentials> {
  if (target.authentication?.method !== "vscode") throw new Error("Choose VS Code GitHub Authentication first.");
  let session = await vscode.authentication.getSession("github", ["repo"], githubSyncAuthenticationSessionOptions());
  if (session.account.label.toLowerCase() !== target.authentication.expectedLogin.toLowerCase()) {
    session = await vscode.authentication.getSession("github", ["repo"], githubSyncAuthenticationSessionOptions(true));
  }
  if (session.account.label.toLowerCase() !== target.authentication.expectedLogin.toLowerCase()) {
    throw new Error(`Selected VS Code GitHub account is ${session.account.label}, not ${target.authentication.expectedLogin}. Choose the expected account when prompted.`);
  }
  const credentials = { accessToken: session.accessToken };
  await probeGitHubSyncVscodeAuthentication(target.repository, target.authentication.expectedLogin, credentials);
  if (persist) {
    await context.secrets.store(githubSyncSecretKey(target.id), JSON.stringify({
      accountId: session.account.id,
      accountLabel: session.account.label,
      accessToken: session.accessToken,
    } satisfies StoredGitHubSyncCredentials));
  }
  target.authentication.accountId = session.account.id;
  return credentials;
}

async function authorizeGitHubSyncTarget(context: vscode.ExtensionContext, target: GitHubSyncTarget): Promise<void> {
  if (target.authentication?.method !== "vscode") return;
  try {
    const credentials = await readGitHubSyncCredentials(context, target);
    await probeGitHubSyncVscodeAuthentication(target.repository, target.authentication.expectedLogin, credentials!);
  } catch (error) {
    if (error instanceof GitHubSyncCredentialError && ["CREDENTIAL_READ_TIMEOUT", "CREDENTIAL_READ_CANCELED", "CREDENTIAL_READ_FAILED"].includes(error.code)) throw error;
    await connectGitHubSyncVscodeAccount(context, target);
  }
}

function updateGitHubSyncBackgroundTask(context: vscode.ExtensionContext, targetId: string, state: GitHubSyncRuntimeState): void {
  const target = readGitHubSyncTargets(context).find(candidate => candidate.id === targetId);
  if (!target) {
    githubSyncTasks.get(targetId)?.idle();
    githubSyncTasks.delete(targetId);
    return;
  }
  let producer = githubSyncTasks.get(targetId);
  if (!producer) {
    producer = backgroundTaskRegistry.producer({ id: `github-sync:${targetId}`, kind: "github-sync", label: `GitHub sync · ${target.name}` });
    githubSyncTasks.set(targetId, producer);
  }
  const label = `GitHub sync · ${target.name}`;
  if (state.status === "syncing") {
    producer.running({ label, detail: state.detail || state.phase || "Waiting for Git" });
  } else if (state.status === "blocked" || state.status === "needs-attention") {
    producer.queued({ label, detail: state.detail || "Waiting for extension upgrade" });
  } else if (state.status === "queued" || state.status === "scheduled" || state.nextSyncAt) {
    producer.queued({
      label,
      detail: state.status === "error"
        ? `${state.phase || "Git operation"} failed · retry scheduled`
        : state.detail || (state.status === "queued" ? "Queued for shared coordinator" : "Scheduled"),
      nextRunAt: state.nextSyncAt,
    });
  } else {
    producer.idle();
  }
}

async function finalizeGitHubSyncServiceResult(
  context: vscode.ExtensionContext, targetId: string, reason: GitHubSyncReason,
  result: GitHubSyncResult, reportRefresh?: () => void, localChangeFingerprint?: string,
): Promise<void> {
  const target = githubSyncTargetById(context, targetId);
  // In particular, a recovered partial result can outlive the checkout's latest transaction.
  // Validate before changing Recipes, privacy, lastSync or conflict records, not only when acknowledging.
  validateGitHubSyncTransaction(path.join(githubSyncStateDirectory(context), "checkouts"), targetId, result.transactionId, {
    repository: target.repository, branch: target.branch, commit: result.commit,
  });
  applyGitHubSyncRecipePulls(result.recipePulls);
  applyGitHubSyncRecipeDeletes(result.recipeDeletes);
  const changedLocalContent = result.pulled.length > 0 || result.deletedLocal.length > 0
    || result.recipePulls.length > 0 || result.recipeDeletes.length > 0;
  for (const [type, topLevels] of Object.entries(result.privateTopLevels)) {
    for (const topLevel of topLevels || []) setTopLevelPrivacy(type as PrivacyContentType, topLevel, true);
  }
  if (result.pulled.length || result.deletedLocal.length || result.recipeDeletes.length) {
    invalidateSharedContentCatalog();
    _treeProvider?.refresh();
  }
  const updated = await mutateGitHubSyncTargets(context, `sync ${targetId}`, currentTargets => {
    const current = currentTargets.find(candidate => candidate.id === targetId);
    if (!current) return { targets: currentTargets, result: false };
    const wasInitialSyncCompleted = current.automation.initialSyncCompleted;
    const migration = githubPublicationMigration(context, targetId).status();
    current.lastSync = {
      at: new Date().toISOString(), commit: result.commit, fingerprints: result.fingerprints,
      repository: current.repository, branch: current.branch, storeRoot: path.resolve(getStorePath()),
      entityBases: result.entityBases || {},
    };
    current.lastResolutionReport = result.resolutionReport;
    const acknowledged = new Set(result.acknowledgedDeletions.map(item => `${item.type}\0${item.itemId}`));
    current.pendingDeletions = (current.pendingDeletions || []).filter(item => !acknowledged.has(`${item.type}\0${item.itemId}`));
    if (localChangeFingerprint && !Object.keys(result.entityBases || {}).length) {
      current.lastSync.localChangeFingerprint = githubSyncLocalChangeFingerprint(current, localChangeFingerprint);
    }
    if (reason === "manual" || reason === "force-local-authority") {
      current.automation.initialSyncCompleted = true;
      if (migration?.phase === "cutover") {
        current.publication = {
          requiredCapability: "stable-entity-identity", sourceCommit: migration.remoteCommit,
          sourceDigest: migration.sourceDigest, manualVerificationCompleted: true,
        };
      } else if (reason === "force-local-authority" || (!wasInitialSyncCompleted && !current.publication)) {
        // A local-authority publish always writes the current manifest schema, so it completes the publication upgrade.
        current.publication = {
          requiredCapability: "stable-entity-identity", sourceCommit: result.commit,
          sourceDigest: createHash("sha256").update(JSON.stringify(result.fingerprints)).digest("hex"),
          manualVerificationCompleted: true,
        };
      } else if (current.publication) current.publication.manualVerificationCompleted = true;
    }
    delete current.lastFailure;
    return { targets: currentTargets, result: true };
  });
  if (!updated) return;
  completeGitHubSyncTransaction(path.join(githubSyncStateDirectory(context), "checkouts"), targetId, result.transactionId);
  clearGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
  if (!Object.keys(result.entityBases || {}).length) clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
  if (!githubSyncResultIsNoChange(result)) {
    reportRefresh?.();
    try {
      await refreshKnowledgeInventory(context);
      await refreshRetrievalIndex(context);
    } catch (error) {
      log.warn(`GitHub Sync target=${target.name} committed=${result.commit}; inventory/retrieval post-processing will retry: ${error instanceof Error ? error.message : String(error)}`);
      scheduleRetrievalRefresh(context, 0);
    }
  }
  if (changedLocalContent) githubSyncScheduler?.notifyContentChanged(targetId);
}

function githubSyncLocalChangeFingerprint(target: GitHubSyncTarget, contentFingerprint: string): string {
  const deletions = (target.pendingDeletions || []).map(item => `${item.type}\0${item.itemId}`).sort();
  return createHash("sha256").update(JSON.stringify([contentFingerprint, deletions])).digest("hex");
}

async function recoverGitHubSyncServiceResults(context: vscode.ExtensionContext, service: PkmServiceClient): Promise<void> {
  for (const receipt of await service.listRecoverableResults()) {
    await withGitHubSyncTargetLock(context, receipt.targetId, () => withGitHubSyncApplyLock(context, async () => {
      if (!(await service.listRecoverableResults()).some(current => current.operationId === receipt.operationId)) {
        log.info(`PKM service receipt ${receipt.operationId} was already recovered by another window.`);
        return;
      }
      if (!readGitHubSyncTargets(context).some(target => target.id === receipt.targetId)) {
        throw new Error(`PKM service has an unapplied result for deleted target ${receipt.targetId}. Preserve receipt ${receipt.operationId} for review.`);
      }
      const currentTarget = githubSyncTargetById(context, receipt.targetId);
      const reason = receipt.reason;
      if (!reason || receipt.repository !== currentTarget.repository || receipt.branch !== currentTarget.branch) {
        throw new Error(`PKM service result ${receipt.operationId} has missing or mismatched target metadata. Preserve it for review; no recovery was applied.`);
      }
      let result: GitHubSyncResult;
      try {
        result = await service.recoverSyncResult(receipt.operationId);
      } catch (error) {
        if (error instanceof GitHubSyncDeferredError) {
          await service.acknowledgeRecoveredResult(receipt.operationId);
          log.warn(`Recovered deferred GitHub Sync target=${receipt.targetId}; no Git operation repeated: ${error.message}`);
          return;
        }
        if (error instanceof GitHubSyncContentRepairError) {
          storeGitHubSyncContentRepair(githubSyncStateDirectory(context), error);
          await service.acknowledgeRecoveredResult(receipt.operationId);
          log.warn(`Recovered local content repair target=${receipt.targetId}; no Remote/Base was fetched.`);
          return;
        }
        if (error instanceof Error && /^GitHub Sync content still contains merge conflict markers: /.test(error.message)) {
          await mutateGitHubSyncTargets(context, `failure ${receipt.targetId}`, targets => {
            const target = targets.find(target => target.id === receipt.targetId);
            if (target) target.lastFailure = { at: new Date().toISOString(), error: error.message, reason, attempts: 1 };
            return { targets, result: undefined };
          });
          await service.acknowledgeRecoveredResult(receipt.operationId);
          log.warn(`Recovered preflight validation failure target=${receipt.targetId}: ${error.message}`);
          return;
        }
        if (!(error instanceof GitHubSyncConflictError)) throw error;
        if (error.partialResult) {
          const archived = archiveSupersededGitHubSyncResult(githubSyncStateDirectory(context), receipt, currentTarget, error.partialResult);
          if (archived) {
            await service.acknowledgeRecoveredResult(receipt.operationId);
            log.warn(`Superseded GitHub Sync conflict preserved at ${archived}; current content, baseline and conflict choices were not changed.`);
            return;
          }
          await finalizeGitHubSyncServiceResult(context, receipt.targetId, reason, error.partialResult);
        }
        applyGitHubSyncRecipePulls(error.recipePulls);
        applyGitHubSyncRecipeDeletes(error.recipeDeletes);
        for (const [type, topLevels] of Object.entries(error.privateTopLevels)) {
          for (const topLevel of topLevels || []) setTopLevelPrivacy(type as PrivacyContentType, topLevel, true);
        }
        storeGitHubSyncConflict(githubSyncStateDirectory(context), receipt.targetId, error);
        await mutateGitHubSyncTargets(context, `failure ${receipt.targetId}`, targets => {
          const target = targets.find(target => target.id === receipt.targetId);
          if (target && !error.partialResult) target.lastFailure = { at: new Date().toISOString(), error: error.message, reason, attempts: 3 };
          return { targets, result: undefined };
        });
        invalidateSharedContentCatalog();
        await refreshKnowledgeInventory(context);
        scheduleRetrievalRefresh(context, 0);
        await service.acknowledgeRecoveredResult(receipt.operationId);
        log.warn(`Recovered GitHub Sync conflict from PKM service target=${receipt.targetId}; review the stored choices.`);
        return;
      }
      const archived = archiveSupersededGitHubSyncResult(githubSyncStateDirectory(context), receipt, currentTarget, result);
      if (archived) {
        await service.acknowledgeRecoveredResult(receipt.operationId);
        log.warn(`Superseded GitHub Sync result preserved at ${archived}; current content and baseline were not changed.`);
        return;
      }
      await finalizeGitHubSyncServiceResult(context, receipt.targetId, reason, result);
      await service.acknowledgeRecoveredResult(receipt.operationId);
      log.info(`Recovered completed GitHub Sync from PKM service target=${receipt.targetId} commit=${result.commit}; no Git operation was repeated.`);
    }));
  }
}

function configureGitHubSyncScheduler(context: vscode.ExtensionContext): void {
  let createdCoordinator = false;
  const coordinatorStatePath = githubSyncCoordinatorStateDirectory(context);
  if (githubSyncScheduler && githubSyncCoordinatorStatePath !== coordinatorStatePath) {
    githubSyncScheduler.dispose();
    githubSyncScheduler = undefined;
    githubSyncCoordinatorStatePath = undefined;
  }
  if (!githubSyncScheduler) {
    createdCoordinator = true;
    githubSyncCoordinatorStatePath = coordinatorStatePath;
    githubSyncScheduler = new PkmServiceClient({
      globalStoragePath: context.globalStorageUri.fsPath,
      shouldRetryFailure: error => !(error instanceof GitHubSyncConflictError) && !(error instanceof GitHubSyncContentRepairError) && !(error instanceof PkmServiceRecoveryPersistenceError),
      onAutoPaused: targetId => {
        void mutateGitHubSyncTargets(context, `automatic failure pause ${targetId}`, currentTargets => {
          const current = currentTargets.find(candidate => candidate.id === targetId);
          if (current) current.automation.enabled = false;
          return { targets: currentTargets, result: undefined };
        }).then(async () => {
          log.warn(`GitHub Sync target=${targetId}: Auto Sync disabled after exhausting automatic retries`);
          if (panels.instances.size) postToPanel({ command: "githubSyncState", data: await githubSyncStateData(context) });
        }).catch(error => log.error(`GitHub Sync auto-pause persistence failed: ${error instanceof Error ? error.message : String(error)}`));
      },
      stateDirectory: coordinatorStatePath,
      knowledgeRoot: getStorePath(),
      extensionVersion: String(context.extension.packageJSON.version),
      serviceEntryPath: path.join(context.extensionPath, "dist", "runtime", "pkm-service-entry.js"),
      onCompatibilityWarning: message => {
        log.warn(`PKM singleton service: ${message}`);
        void vscode.window.showWarningMessage(message);
      },
      onError: error => {
        log.error(`PKM singleton service: ${error instanceof Error ? error.stack || error.message : String(error)}`);
        void vscode.window.showErrorMessage(`PKM background service: ${error instanceof Error ? error.message : String(error)}`);
      },
      compatibilityBlock: error => error instanceof GitHubSyncExtensionCompatibilityError
        ? { requiredVersion: error.requiredVersion, installedVersion: error.installedVersion }
        : undefined,
      shouldExecute: (targetId, reason) => withGitHubSyncTargetLock(context, targetId, async () => {
        if (reason !== "force-local-authority" && reason !== "manual" && readGitHubSyncConflict(githubSyncStateDirectory(context), targetId)?.purpose === "initial-preview"
          && !clearEquivalentGitHubSyncConflict(context, targetId)) {
          log.info(`automatic GitHub Sync target=${targetId} reason=${reason} skipped=conflict-awaiting-approval`);
          return false;
        }
        const migration = githubPublicationMigration(context, targetId).status();
        if (migration && migration.phase !== "cutover" && migration.phase !== "rolled-back") {
          log.info(`automatic GitHub Sync target=${targetId} reason=${reason} skipped=migration-${migration.phase}`);
          return false;
        }
        if (reason === "change") {
          const target = githubSyncTargetById(context, targetId);
          if (target.lastSync?.localChangeFingerprint && target.lastSync.repository === target.repository
            && target.lastSync.branch === target.branch && target.lastSync.storeRoot
            && sameKnowledgeRoot(target.lastSync.storeRoot, getStorePath())) {
            invalidateSharedContentCatalog();
            const current = await githubSyncFingerprintInWorker(target, await githubSyncCatalog(), getStorePath());
            if (githubSyncLocalChangeFingerprint(target, current.localChangeFingerprint) === target.lastSync.localChangeFingerprint) {
              githubSyncDiagnostics.record("github_sync.change_skipped", { targetId, reason: "selected-content-unchanged" });
              return false;
            }
          }
        }
        return true;
      }),
      execute: (targetId, reason) => {
        githubSyncScheduler?.report(targetId, "waiting-for-lock", "Waiting for Git lock");
        return withGitHubSyncTargetLock(context, targetId, () => withGitHubSyncApplyLock(context, async () => {
          const target = githubSyncTargetById(context, targetId);
          const forceAudit = githubSyncForceUpdateAudit.get(targetId);
          const attemptedAt = new Date().toISOString();
          const traceId = randomUUID();
          let diagnosticPhase = "waiting-for-lock";
          const report = (phase: "fetch" | "resolve-conflicts" | "commit" | "push", detail: string): void => {
            diagnosticPhase = phase;
            githubSyncScheduler?.report(targetId, phase, detail);
            githubSyncDiagnostics.record("github_sync.phase", { traceId, targetId, reason, phase, detail });
          };
          githubSyncDiagnostics.record("github_sync.started", {
            traceId,
            targetId,
            reason,
            branch: target.branch,
            hasBase: !!target.lastSync?.commit,
            baseCommit: target.lastSync?.commit || "",
            pendingDeletions: target.pendingDeletions?.length || 0,
            servicePid: githubSyncScheduler?.snapshot()[targetId]?.service?.pid,
            serviceVersion: githubSyncScheduler?.snapshot()[targetId]?.service?.version,
          });
          try {
            githubSyncScheduler?.report(targetId, "authenticating", "Authenticating GitHub credentials");
            diagnosticPhase = "authenticating";
            githubSyncDiagnostics.record("github_sync.phase", { traceId, targetId, reason, phase: diagnosticPhase });
            const credentials = await readGitHubSyncCredentials(context, target);
            report("fetch", "Preparing Local files for Fetch / Pull");
            invalidateSharedContentCatalog();
            const catalog = await githubSyncCatalog();
            const localState = await githubSyncFingerprintInWorker(target, catalog, getStorePath());
            githubSyncDiagnostics.record("github_sync.catalog", {
              traceId,
              targetId,
              counts: GITHUB_SYNC_CONTENT_TYPES.map(type => `${type}:${catalog[type].length}`).join(","),
              total: GITHUB_SYNC_CONTENT_TYPES.reduce((sum, type) => sum + catalog[type].length, 0),
            });
            if (!githubSyncScheduler) throw new Error("PKM singleton service disconnected before synchronization.");
            const syncGitHubTarget = githubSyncScheduler.sync.bind(githubSyncScheduler);
            const result = await syncGitHubTarget(
              target,
              catalog,
              path.join(githubSyncStateDirectory(context), "checkouts"),
              credentials,
              getStorePath(),
              report,
              {
                mode: reason === "force-local-authority" ? "force-local-authority" : "normal",
                ...(reason === "force-local-authority"
                  ? {
                    actor: forceAudit?.actor || target.authentication?.expectedLogin || os.userInfo().username,
                    comment: forceAudit?.comment,
                  }
                  : {}),
              },
            );
            await finalizeGitHubSyncServiceResult(context, targetId, reason, result, () =>
              githubSyncScheduler?.report(targetId, "refresh-index", "Refreshing the PKM inventory and retrieval index"), localState.localChangeFingerprint);
            githubSyncScheduler?.report(targetId, githubSyncResultIsNoChange(result) ? "no-change" : "scheduled",
              githubSyncResultIsNoChange(result) ? "No changes on this machine or GitHub" : "Next fetch scheduled");
            githubSyncDiagnostics.record("github_sync.completed", {
              traceId,
              targetId,
              reason,
              commit: result.commit,
              changed: result.changed,
              pulled: result.pulled.length,
              deletedLocal: result.deletedLocal.length,
              recipePulls: result.recipePulls.length,
              recipeDeletes: result.recipeDeletes.length,
            });
            log.info(`automatic GitHub Sync target=${target.name} reason=${reason} changed=${result.changed} commit=${result.commit}`);
          } catch (error) {
            let message = error instanceof Error ? error.message : String(error);
            const failure = {
              ...githubSyncFailureDetails(error, diagnosticPhase),
              ...(error instanceof GitHubSyncConflictError || error instanceof PkmServiceRecoveryPersistenceError ? { retryable: false } : {}),
            };
            if (error instanceof GitHubSyncContentRepairError) {
              const previous = readGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
              storeGitHubSyncContentRepair(githubSyncStateDirectory(context), error);
              if (!previous || JSON.stringify(previous.issues.map(issue => [issue.path, issue.digest]))
                !== JSON.stringify(error.issues.map(issue => [issue.path, issue.digest]))) {
                void vscode.window.showWarningMessage(`GitHub Sync "${target.name}" needs local content repair. Remote has not been fetched.`,
                  "Review local repairs").then(choice => {
                    if (choice === "Review local repairs") openPanelTab(context, "githubSync");
                  });
              }
            }
            if (error instanceof GitHubSyncExtensionCompatibilityError) {
              message = localizedText(context.extensionPath, "githubSync.extensionUpgradeRequired", {
                required: error.requiredVersion,
                installed: error.installedVersion,
              });
            }
            if (error instanceof GitHubSyncConflictError) {
              if (error.partialResult) {
                await finalizeGitHubSyncServiceResult(context, targetId, reason, error.partialResult);
              } else {
                applyGitHubSyncRecipePulls(error.recipePulls);
                applyGitHubSyncRecipeDeletes(error.recipeDeletes);
                for (const [type, topLevels] of Object.entries(error.privateTopLevels)) {
                  for (const topLevel of topLevels || []) setTopLevelPrivacy(type as PrivacyContentType, topLevel, true);
                }
                if (error.pulled.length || error.deletedLocal.length || error.recipeDeletes.length) {
                  invalidateSharedContentCatalog();
                  await refreshKnowledgeInventory(context);
                  scheduleRetrievalRefresh(context, 0);
                  _treeProvider?.refresh();
                }
              }
              const previousWorkspace = readGitHubSyncConflict(githubSyncStateDirectory(context), target.id);
              const workspace = storeGitHubSyncConflict(githubSyncStateDirectory(context), target.id, error);
              const choiceRequired = workspace.files.filter(file => file.candidateSource === "unresolved").length;
              githubSyncScheduler?.report(targetId, "resolve-conflicts", `${workspace.files.length} workspace members: ${choiceRequired} choice required; ${workspace.files.length - choiceRequired} candidates awaiting approval`);
              if (workspace.id !== previousWorkspace?.id && target.conflictResolution === "agent" && error.conflicts.some(conflict => conflict.type === "skills" || conflict.type === "recipes")) {
                try {
                  const batch = await prepareGitHubSyncAgentCandidates(context, target.id);
                  message += ` Agent prepared ${batch.prepared} candidates; ${batch.unsupported} unsupported and ${batch.failed.length} failed. Review the remaining choices in GitHub Sync.`;
                  for (const failure of batch.failed) log.warn(`GitHub Sync Agent merge ${failure.path}: ${failure.error}`);
                } catch (agentError) {
                  message += ` Agent preparation stopped: ${agentError instanceof Error ? agentError.message : String(agentError)}. Review the conflicts manually in GitHub Sync.`;
                }
              } else {
                message += " Open GitHub Sync, choose This Machine or GitHub for each file, then Apply resolutions & Sync.";
              }
              if (workspace.id !== previousWorkspace?.id) void vscode.window.showWarningMessage(
                `GitHub Sync "${target.name}": ${choiceRequired} members need a choice; independent content continues syncing. Missing entities require intent review.`,
                "Review conflicts",
              ).then(choice => {
                if (choice === "Review conflicts") openPanelTab(context, "githubSync");
              });
            }
            if (!(error instanceof GitHubSyncDeferredError) && !(error instanceof GitHubSyncExtensionCompatibilityError) && !(error instanceof GitHubSyncContentRepairError)
              && !(error instanceof GitHubSyncConflictError && error.partialResult)) {
              try {
                await mutateGitHubSyncTargets(context, `failure ${targetId}`, currentTargets => {
                  const current = currentTargets.find(candidate => candidate.id === targetId);
                  if (current) {
                    const authenticationFailure = isGitHubSyncAuthenticationFailure({ at: attemptedAt, error: message, reason, ...failure });
                    current.lastFailure = {
                      at: authenticationFailure ? new Date().toISOString() : attemptedAt, error: message, reason, ...failure,
                      attempts: error instanceof GitHubSyncConflictError || error instanceof PkmServiceRecoveryPersistenceError ? 3
                        : Math.min(3, (isGitHubSyncAuthenticationFailure(current.lastFailure) && !authenticationFailure ? 0 : current.lastFailure?.attempts || 0) + 1),
                    };
                  }
                  return { targets: currentTargets, result: undefined };
                });
              } catch (persistenceError) {
                message += ` Failure status could not be persisted: ${persistenceError instanceof Error ? persistenceError.message : String(persistenceError)}.`;
                log.error(message);
              }
            }
            const diagnostic = error instanceof Error ? error.stack || error.message : String(error);
            if (githubSyncScheduler) await githubSyncScheduler.acknowledgeExecutionErrors(targetId);
            githubSyncDiagnostics.record(error instanceof GitHubSyncDeferredError ? "github_sync.deferred" : error instanceof GitHubSyncConflictError && error.partialResult ? "github_sync.partial" : error instanceof GitHubSyncContentRepairError ? "github_sync.content_attention" : error instanceof GitHubSyncExtensionCompatibilityError ? "github_sync.blocked" : "github_sync.failed", {
              traceId,
              targetId,
              reason,
              phase: diagnosticPhase,
              errorCode: failure.errorCode,
              errorName: error instanceof Error ? error.name : typeof error,
              error: message,
              stack: diagnostic,
              ...(error instanceof GitHubSyncContentRepairError ? {
                attemptId: error.attemptId, issues: JSON.stringify(error.issues.map(issue => ({
                  path: issue.path, source: issue.source, reason: issue.reason, lines: issue.lines, digest: issue.digest,
                  error: issue.error, diagnostics: issue.diagnostics, sourceLocator: issue.sourceLocator,
                }))),
              } : {}),
              ...(error instanceof PkmServiceRecoveryPersistenceError ? {
                operationId: error.operationId, recoveryAvailable: error.recoveryAvailable,
                persistenceStage: error.persistenceStage, transactionId: error.transactionId,
                primaryError: error.primaryError?.message, primaryStack: error.primaryError?.stack,
                primaryCode: error.primaryError && "code" in error.primaryError && typeof error.primaryError.code === "string" ? error.primaryError.code : undefined,
                persistenceError: error.persistenceError.message, persistenceStack: error.persistenceError.stack,
                persistenceCode: "code" in error.persistenceError && typeof error.persistenceError.code === "string" ? error.persistenceError.code : undefined,
              } : {}),
            });
            if (error instanceof GitHubSyncDeferredError) {
              log.warn(`GitHub Sync target=${target.name} reason=${reason} deferred; Auto Sync setting retained: ${message}`);
            } else if (error instanceof GitHubSyncExtensionCompatibilityError) {
              log.info(`automatic GitHub Sync target=${target.name} reason=${reason} blocked=extension-upgrade required=${error.requiredVersion} installed=${error.installedVersion}`);
            } else if (error instanceof GitHubSyncConflictError && error.partialResult) {
              log.info(`GitHub Sync target=${target.name} partial commit=${error.partialResult.commit}: ${error.message}`);
            } else {
              log.error(`automatic GitHub Sync target=${target.name} reason=${reason}: ${diagnostic}`);
            }
            throw error;
          } finally {
            if (reason === "force-local-authority") githubSyncForceUpdateAudit.delete(targetId);
            if (panels.instances.size) void githubSyncStateData(context).then(data => postToPanel({ command: "githubSyncState", data })).catch(error => log.warn(`GitHub Sync state refresh failed: ${(error as Error).message}`));
          }
        }));
      },
      onState: (targetId, state) => {
        updateGitHubSyncBackgroundTask(context, targetId, state);
        postToPanel({ command: "githubSyncRuntimeState", data: { targetId, state } });
      },
    });
  }
  const targets = readGitHubSyncTargets(context);
  const activeTargetIds = new Set(targets.map(target => target.id));
  for (const [targetId, producer] of githubSyncTasks) {
    if (activeTargetIds.has(targetId)) continue;
    producer.idle();
    githubSyncTasks.delete(targetId);
  }
  const service = githubSyncScheduler;
  void (async () => {
    if (createdCoordinator) await recoverGitHubSyncServiceResults(context, service);
    await service.configure(readGitHubSyncTargets(context).map(target => ({
    id: target.id,
    enabled: target.automation.enabled && target.automation.initialSyncCompleted,
    intervalMinutes: target.automation.intervalMinutes,
    syncOnChange: target.automation.syncOnChange,
    lastSuccessAt: target.lastSync?.at,
    lastFailure: target.lastFailure,
    needsAttention: !!readGitHubSyncContentRepair(githubSyncStateDirectory(context), target.id),
    })));
    if (createdCoordinator) {
      for (const record of listGitHubSyncConflicts(githubSyncStateDirectory(context))) {
        const target = targets.find(target => target.id === record.targetId);
        if (record.appliedAt && target && !target.lastFailure) {
          await service.request(target.id, "manual");
          log.info(`recovered applied GitHub Sync resolutions target=${target.id}; queued manual synchronization`);
        }
      }
    }
  })().catch(error => {
    log.error(`PKM singleton service configuration failed: ${error instanceof Error ? error.message : String(error)}`);
    void vscode.window.showErrorMessage(`PKM background service: ${error instanceof Error ? error.message : String(error)}`);
  });
}

async function subscriptionStateData(context: vscode.ExtensionContext): Promise<object> {
  const githubConnections = readGitHubSyncTargets(context).map(target => ({ id: target.id, name: target.name, repository: target.repository, branch: target.branch, method: target.authentication?.method, account: target.authentication?.expectedLogin }));
  return { ...getSharedMarket().snapshot, catalog: await sharedContentCatalog(), networkAddresses: serverNetworkAddresses(), githubConnections };
}

interface GitHubSubscriptionRequest {
  targetId?: string;
  credentialTargetId?: string;
  repository?: string;
  branch?: string;
  expectedCommit?: string;
  selectedPaths?: string[];
  selectedFolders?: string[];
}

interface TestedGitHubSubscription {
  testedAt: number;
  target: GitHubSyncTarget;
  credentialTargetId?: string;
  checkoutRoot: string;
  snapshot: Awaited<ReturnType<typeof fetchGitHubRemoteSnapshot>>;
}

const testedGitHubSubscriptions = new Map<string, TestedGitHubSubscription>();
const GITHUB_SUBSCRIPTION_TEST_TTL_MS = 10 * 60_000;

function githubSubscriptionTestKey(context: vscode.ExtensionContext, input: GitHubSubscriptionRequest): string {
  const { target, credentialTargetId } = githubSubscriptionTarget(context, input);
  return `${target.repository}\0${target.branch}\0${credentialTargetId || "public"}`;
}

function githubSubscriptionTarget(context: vscode.ExtensionContext, input: GitHubSubscriptionRequest): { target: GitHubSyncTarget; credentialTargetId?: string } {
  const credentialTargetId = String(input.credentialTargetId || input.targetId || "").trim() || undefined;
  const credentialTarget = credentialTargetId ? githubSyncTargetById(context, credentialTargetId) : undefined;
  const repository = String(input.repository || credentialTarget?.repository || "").trim();
  const branch = String(input.branch || credentialTarget?.branch || "main").trim();
  const id = `subscription-${createHash("sha256").update(`${repository}\0${branch}\0${credentialTargetId || "public"}`).digest("hex").slice(0, 24)}`;
  return { target: normalizeGitHubSyncTarget({ id, name: repository.split(/[/:]/).pop()?.replace(/\.git$/i, "") || "GitHub Branch", repository, branch, authentication: credentialTarget?.authentication }), credentialTargetId };
}

async function githubSubscriptionSnapshot(context: vscode.ExtensionContext, input: GitHubSubscriptionRequest, onProgress?: (stage: string) => void) {
  const resolved = githubSubscriptionTarget(context, input);
  const checkoutRoot = path.join(githubSyncStateDirectory(context), "checkouts");
  const credentialTarget = resolved.credentialTargetId ? githubSyncTargetById(context, resolved.credentialTargetId) : resolved.target;
  onProgress?.("credentials");
  const credentials = await readGitHubSyncCredentials(context, credentialTarget);
  const fetched = await fetchGitHubRemoteSnapshot(resolved.target, checkoutRoot, true, credentials, onProgress);
  const files = fetched.files.filter(file => file.type !== "agentSnapshots");
  const snapshot = {
    ...fetched,
    files,
    validation: {
      ...fetched.validation,
      importableFiles: files.length,
      ignoredFiles: fetched.validation.repositoryFiles - files.length - fetched.validation.invalidFiles,
      importableBytes: files.reduce((sum, file) => sum + file.size, 0),
      largestFileBytes: files.reduce((largest, file) => Math.max(largest, file.size), 0),
      filesOverPreviewLimit: files.filter(file => file.size > 1024 * 1024).length,
    },
  };
  return {
    ...resolved,
    checkoutRoot,
    snapshot,
    authentication: {
      profileName: resolved.credentialTargetId ? credentialTarget.name : "Default Git credentials",
      method: resolved.target.authentication?.method || "default",
      account: resolved.target.authentication?.expectedLogin || "",
    },
  };
}

function githubSubscriptionContentReaders(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
  selected: { path: string; size: number }[]
): { path: string; size: number; content: () => Promise<Buffer> }[] {
  const batches: { path: string; size: number }[][] = [];
  const maximumBatchFiles = 128;
  const maximumBatchBytes = 16 * 1024 * 1024;
  for (const file of selected) {
    const current = batches[batches.length - 1];
    const currentBytes = current?.reduce((sum, item) => sum + item.size, 0) || 0;
    if (!current || current.length >= maximumBatchFiles || currentBytes + file.size > maximumBatchBytes) batches.push([file]);
    else current.push(file);
  }
  return batches.flatMap(batch => {
    let pending: Promise<Map<string, Buffer>> | undefined;
    const load = () => pending ||= readGitHubRemoteFilesForSubscription(target, checkoutRoot, commit, batch, MAX_SUBSCRIPTION_CACHE_BYTES);
    return batch.map(file => ({
      ...file,
      content: async () => {
        const contents = await load();
        const content = contents.get(file.path);
        if (!content) throw new Error(`GitHub batch did not return ${file.path}.`);
        contents.delete(file.path);
        return content;
      },
    }));
  });
}

async function mountGitHubBranchSubscription(context: vscode.ExtensionContext, input: GitHubSubscriptionRequest, alias = "", onProgress?: (progress: any) => void) {
  const testKey = githubSubscriptionTestKey(context, input);
  let tested = testedGitHubSubscriptions.get(testKey);
  if (tested && Date.now() - tested.testedAt > GITHUB_SUBSCRIPTION_TEST_TTL_MS) {
    testedGitHubSubscriptions.delete(testKey);
    tested = undefined;
  }
  if (!input.expectedCommit || !tested || tested.snapshot.commit !== input.expectedCommit) {
    throw new Error("Test this GitHub repository again before subscribing. The tested result is missing, expired, or changed.");
  }
  const { target, credentialTargetId, checkoutRoot, snapshot } = tested;
  const selectedPaths = [...new Set((input.selectedPaths || []).map(githubSyncSafeRelativePath))];
  const selectedFolders = [...new Set((input.selectedFolders || []).map(value => githubSyncSafeRelativePath(`${String(value).replace(/\/$/, "")}/_folder_rule_`).replace(/\/_folder_rule_$/, "")))];
  const hasRules = input.selectedPaths !== undefined || input.selectedFolders !== undefined;
  const selected = hasRules ? snapshot.files.filter(file => selectedPaths.includes(file.path) || selectedFolders.some(folder => file.path.startsWith(`${folder}/`))) : snapshot.files;
  if (!selected.length) throw new Error("Select at least one GitHub file or folder to subscribe.");
  const selectedBytes = selected.reduce((sum, file) => sum + file.size, 0);
  if (selectedBytes > MAX_SUBSCRIPTION_CACHE_BYTES) throw new Error(`Selected GitHub content exceeds the ${MAX_SUBSCRIPTION_CACHE_BYTES / 1024 / 1024} MB subscription cache limit.`);
  const files = githubSubscriptionContentReaders(target, checkoutRoot, snapshot.commit, selected);
  const mounted = await getSharedMarket().mountGitHubBranch({
    credentialTargetId, name: target.name, repository: target.repository, branch: target.branch,
    commit: snapshot.commit, account: target.authentication?.expectedLogin, selectedPaths, selectedFolders, files,
  }, alias, onProgress);
  testedGitHubSubscriptions.delete(testKey);
  return mounted;
}

function githubSyncRecipeContent(recipe: RecipeRecord): Buffer {
  return githubSyncManagedContent("recipes", Buffer.from(canonicalJson(recipe) + "\n", "utf8"));
}

function applyGitHubSyncRecipePulls(pulls: GitHubSyncRecipePull[]): void {
  if (!pulls.length) return;
  const store = currentProjectStore();
  const snapshot = store.list();
  const syncContent = new Map(store.recipeSyncEntries()
    .map(entry => [entry.recipe.recipeId, githubSyncManagedContent("recipes", Buffer.from(entry.content, "utf8"))]));
  const recipes = pulls.map(pull => {
    const current = snapshot.recipes.find(recipe => recipe.recipeId === pull.itemId);
    validateGitHubSyncConflictLocalState(
      pull.path,
      pull.expectedLocal,
      pull.content,
      current ? syncContent.get(current.recipeId) || githubSyncRecipeContent(current) : undefined,
    );
    const recipe = JSON.parse(pull.content.toString("utf8")) as RecipeRecord;
    if (recipe.recipeId !== pull.itemId) throw new Error(`Recipe identity does not match the remote manifest: ${pull.path}`);
    if (current?.editorLayout) recipe.editorLayout = current.editorLayout;
    return recipe;
  });
  store.replaceRecipesFromSync(projectCommand(store, "recipe-github-pull", {
    recipes: pulls.map(pull => ({ path: pull.path, recipeId: pull.itemId }))
  }), recipes);
}

function applyGitHubSyncRecipeDeletes(deletions: Array<GitHubSyncRecipeDelete | string>): void {
  if (!deletions.length) return;
  const store = currentProjectStore();
  const syncContent = new Map(store.recipeSyncEntries()
    .map(entry => [entry.recipe.recipeId, githubSyncManagedContent("recipes", Buffer.from(entry.content, "utf8"))]));
  for (const deletion of deletions) {
    const recipeId = typeof deletion === "string" ? deletion : deletion.itemId;
    const current = store.list().recipes.find(recipe => recipe.recipeId === recipeId);
    if (!current) continue;
    if (typeof deletion === "string" || !Buffer.isBuffer(deletion.expectedLocal)) {
      throw new Error(`Recipe deletion has no local version evidence: ${recipeId}. Preserve the recovery record and reconcile again before deleting.`);
    }
    validateGitHubSyncConflictLocalState(
      deletion.path, deletion.expectedLocal, deletion.expectedLocal,
      syncContent.get(recipeId) || githubSyncRecipeContent(current),
    );
  }
  for (const deletion of deletions) {
    const recipeId = typeof deletion === "string" ? deletion : deletion.itemId;
    if (store.list().recipes.some(recipe => recipe.recipeId === recipeId)) {
      store.moveRecipeToTrash(projectCommand(store, "recipe-github-delete", { recipeId }), recipeId);
    }
  }
}

async function buildGitHubSyncCatalog(): Promise<GitHubSyncCatalog> {
  const root = path.resolve(getStorePath());
  const recipes = currentProjectStore().recipeSyncEntries().map(({ recipe, destination, content, sourceLocator }) => ({
    id: recipe.recipeId,
    label: recipe.name,
    cat: recipe.category || "",
    meta: recipe.scope === "project" ? "Project Recipe" : "Global Recipe",
    isPrivate: isContentItemPrivate("recipes", recipe),
    destination,
    content,
    sourceLocator,
  }));
  const servers = (await serverList()).map(({ slug, name, category, tags }) => ({ slug, name, category, tags }));
  return githubSyncCatalogInWorker({ root, servers, recipes });
}

async function githubSyncCatalog(): Promise<GitHubSyncCatalog> {
  const revision = sharedCatalogRevision;
  if (githubSyncCatalogCache?.revision === revision) return githubSyncCatalogCache.value;
  if (githubSyncCatalogBuild?.revision === revision) return githubSyncCatalogBuild.promise;
  const startedAt = Date.now();
  const previousBuild = githubSyncCatalogBuild?.promise;
  const promise = previousBuild
    ? previousBuild.catch(() => undefined).then(buildGitHubSyncCatalog)
    : buildGitHubSyncCatalog();
  githubSyncCatalogBuild = { revision, promise };
  try {
    const value = await promise;
    if (sharedCatalogRevision === revision) githubSyncCatalogCache = { revision, value };
    log.info(`GitHub Sync catalog build revision=${revision} durationMs=${Date.now() - startedAt} items=${GITHUB_SYNC_CONTENT_TYPES.reduce((sum, type) => sum + value[type].length, 0)}`);
    return value;
  } finally {
    if (githubSyncCatalogBuild?.promise === promise) githubSyncCatalogBuild = undefined;
  }
}

function refreshStaleGitHubSyncConflicts(context: vscode.ExtensionContext, targetId?: string): number {
  const stateDirectory = githubSyncStateDirectory(context);
  const recipeContent = new Map(currentProjectStore().recipeSyncEntries()
    .map(entry => [entry.recipe.recipeId, githubSyncManagedContent("recipes", Buffer.from(entry.content, "utf8"))]));
  let refreshed = 0;
  for (const record of listGitHubSyncConflicts(stateDirectory)) {
    if (targetId && record.targetId !== targetId || record.appliedAt) continue;
    for (const file of record.files) {
      const mergedPath = gitHubSyncConflictVariantPath(stateDirectory, record.targetId, "merged", file.path);
      if (vscode.workspace.textDocuments.some(document => document.isDirty && document.uri.scheme === "file"
        && path.resolve(document.uri.fsPath) === path.resolve(mergedPath))) continue;
      const current = file.type === "recipes"
        ? recipeContent.get(file.itemId)
        : (() => {
          const relative = file.localPath || file.path;
          const destination = relative.startsWith("agentSnapshots/")
            ? githubSyncCandidateDestination(path.join(getStorePath(), ".pkm", "state"), `agent-snapshots/${relative.slice("agentSnapshots/".length)}`)
            : githubSyncCandidateDestination(getStorePath(), relative);
          return fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
        })();
      const selected = file.candidateSource !== "unresolved"
        && file.candidateSource !== "delete"
        && file.candidateSource !== "delete-local"
        ? readGitHubSyncConflictCandidate(stateDirectory, record.targetId, file.path)
        : undefined;
      if (file.candidateSource === "delete-local" && current === undefined) continue;
      if (selected && current?.equals(selected)) continue;
      const original = file.hasLocal
        ? fs.readFileSync(gitHubSyncConflictVariantPath(stateDirectory, record.targetId, "local", file.path))
        : undefined;
      if (original ? current?.equals(original) : current === undefined) continue;
      refreshGitHubSyncConflictLocalCandidate(stateDirectory, record.targetId, file.path, current);
      refreshed++;
    }
  }
  return refreshed;
}

function clearEquivalentGitHubSyncConflict(context: vscode.ExtensionContext, targetId: string): boolean {
  const stateDirectory = githubSyncStateDirectory(context);
  const record = readGitHubSyncConflict(stateDirectory, targetId);
  if (!record?.files.length || record.appliedAt || record.files.some(file => file.plannedOperation || !file.hasRemote
    || file.candidateSource !== "unresolved" || (file.localPath || file.path) !== (file.remotePath || file.path))) return false;
  const recipeContent = new Map(currentProjectStore().recipeSyncEntries()
    .map(entry => [entry.recipe.recipeId, githubSyncManagedContent("recipes", Buffer.from(entry.content, "utf8"))]));
  const equivalent = record.files.every(file => {
    const current = file.type === "recipes"
      ? recipeContent.get(file.itemId)
      : (() => {
        const destination = file.path.startsWith("agentSnapshots/")
          ? githubSyncCandidateDestination(path.join(getStorePath(), ".pkm", "state"), `agent-snapshots/${file.path.slice("agentSnapshots/".length)}`)
          : githubSyncCandidateDestination(getStorePath(), file.path);
        return fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
      })();
    if (!current) return false;
    const remote = fs.readFileSync(gitHubSyncConflictVariantPath(stateDirectory, targetId, "remote", file.path));
    return current.equals(remote);
  });
  if (!equivalent) return false;
  clearGitHubSyncConflict(stateDirectory, targetId);
  log.info(`cleared identity-only GitHub Sync conflict target=${targetId} files=${record.files.length}`);
  return true;
}

let githubAuthenticationOptionsCache: { accounts: string[]; identities: string[] } | undefined;

function emptyGitHubSyncCatalog(): GitHubSyncCatalog {
  return Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, []])) as unknown as GitHubSyncCatalog;
}

let githubSyncStateSequence = 0;
async function githubSyncStateData(context: vscode.ExtensionContext, waitForExpensive = true): Promise<object> {
  let targets = readGitHubSyncTargets(context);
  const fingerprintTargets = JSON.stringify(targets);
  const accounts = new Set(githubAuthenticationOptionsCache?.accounts || []);
  const identities = new Set(githubAuthenticationOptionsCache?.identities || []);
  for (const target of targets) {
    if (target.authentication?.expectedLogin) accounts.add(target.authentication.expectedLogin);
    if (target.authentication?.method === "ssh" && target.authentication.identityFile) identities.add(target.authentication.identityFile);
  }
  let catalog = githubSyncCatalogCache?.value || emptyGitHubSyncCatalog();
  if (waitForExpensive) {
    const [freshCatalog, discoveredAccounts, discoveredIdentities] = await Promise.all([
      githubSyncCatalog(),
      discoverGitHubCredentialManagerAccounts(),
      new Promise<string[]>(resolve => setImmediate(() => resolve(discoverGitHubSshIdentities()))),
    ]);
    catalog = freshCatalog;
    for (const account of discoveredAccounts) accounts.add(account);
    for (const identity of discoveredIdentities) identities.add(identity);
    githubAuthenticationOptionsCache = { accounts: [...accounts], identities: [...identities] };
  }
  let refreshedConflicts = 0;
  for (const record of listGitHubSyncConflicts(githubSyncStateDirectory(context))) {
    refreshedConflicts += await withGitHubSyncTargetLock(context, record.targetId, async () => {
      clearEquivalentGitHubSyncConflict(context, record.targetId);
      return refreshStaleGitHubSyncConflicts(context, record.targetId);
    });
  }
  if (refreshedConflicts) log.info(`refreshed ${refreshedConflicts} stale GitHub Sync conflict candidate${refreshedConflicts === 1 ? "" : "s"}`);
  const currentFingerprints: Record<string, Partial<Record<GitHubSyncContentType, string>>> = {};
  const currentFolderFingerprints: Record<string, Partial<GitHubSyncFolderFingerprints>> = {};
  const baseFolderFingerprints: Record<string, Partial<GitHubSyncFolderFingerprints>> = {};
  const currentFileFingerprints: Record<string, Partial<GitHubSyncFolderFingerprints>> = {};
  const baseFileFingerprints: Record<string, Partial<GitHubSyncFolderFingerprints>> = {};
  if (waitForExpensive) {
    const builtInRecipeIds = new Set(currentProjectStore().list().recipes
      .filter(recipe => recipe.systemKind === "built-in").map(recipe => recipe.recipeId));
    await Promise.all(targets.map(async target => {
      const current = await githubSyncFingerprintInWorker(target, catalog, getStorePath());
      currentFingerprints[target.id] = current.fingerprints;
      currentFolderFingerprints[target.id] = current.folders;
      currentFileFingerprints[target.id] = current.files;
      if (!target.lastSync?.commit) return;
      const rawManifest = await readGitHubCachedManifest(
        target,
        path.join(githubSyncStateDirectory(context), "checkouts"),
        target.lastSync.commit,
      );
      if (rawManifest) {
        const baseFiles = githubSyncManifestFileFingerprints(target, rawManifest);
        const excluded = await githubSyncExcludedPaths(getStorePath(), Object.values(baseFiles).flatMap(files => Object.keys(files)));
        baseFolderFingerprints[target.id] = githubSyncManifestFolderFingerprints(target, rawManifest, excluded, builtInRecipeIds);
        baseFileFingerprints[target.id] = githubSyncManifestFileFingerprints(target, rawManifest, excluded, builtInRecipeIds);
      }
    }));
  }
  const shields = waitForExpensive
    ? Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, githubSyncShield(targets, type, currentFingerprints, baseFileFingerprints)]))
    : undefined;
  const folderShields = waitForExpensive
    ? githubSyncFolderShields(targets, currentFingerprints, currentFolderFingerprints, baseFolderFingerprints)
    : undefined;
  const fileShields = waitForExpensive
    ? githubSyncEntryShields(targets, currentFingerprints, currentFileFingerprints, baseFileFingerprints)
    : undefined;
  const uiCatalog = Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, catalog[type].map(({ source, content, destination, ...item }) => ({ ...item, syncPath: destination }))]));
  const connected: Record<string, boolean> = {};
  const credentialErrors: Record<string, { error: string; errorCode: string; phase?: string }> = {};
  await Promise.all(targets.map(async target => {
    try {
      connected[target.id] = target.authentication?.method !== "vscode" || !!(await readGitHubSyncCredentials(context, target));
    } catch (error) {
      credentialErrors[target.id] = { error: error instanceof Error ? error.message : String(error), ...githubSyncFailureDetails(error) };
      log.warn(`GitHub Sync account check target=${target.id} code=${credentialErrors[target.id].errorCode}: ${credentialErrors[target.id].error}`);
    }
  }));
  targets = readGitHubSyncTargets(context);
  // Sequence by read time, not start time: a slow snapshot that started earlier may carry newer state.
  const snapshotSequence = ++githubSyncStateSequence;
  const fingerprintsCurrent = waitForExpensive && fingerprintTargets === JSON.stringify(targets);
  return {
    snapshotSequence,
    targets,
    contentRepairs: Object.fromEntries(targets.flatMap(target => {
      const repair = readGitHubSyncContentRepair(githubSyncStateDirectory(context), target.id);
      return repair ? [[target.id, { ...repair, issues: repair.issues.map(({ content, candidate, sourcePath, ...issue }) => ({
        ...issue, hasCandidate: candidate !== undefined && sourcePath !== undefined, canOpen: sourcePath !== undefined || !!issue.recipeId,
        canTrash: sourcePath !== undefined && /^[a-f0-9]{64}$/.test(issue.digest)
          && ["skills", "notes", "papers", "prompts", "scripts"].includes(issue.type),
      })) }]] : [];
    })),
    catalog: uiCatalog,
    ...(fingerprintsCurrent && shields ? { shields } : {}),
    ...(fingerprintsCurrent ? { shieldReasons: Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type =>
      [type, githubSyncShieldReasons(targets, type, currentFileFingerprints, baseFileFingerprints, catalog)])) } : {}),
    ...(fingerprintsCurrent && folderShields ? { folderShields } : {}),
    ...(fingerprintsCurrent && fileShields ? { fileShields } : {}),
    fingerprintsDeferred: !fingerprintsCurrent,
    runtime: githubSyncScheduler?.snapshot() || {},
    migrations: Object.fromEntries(targets.flatMap(target => {
      const status = githubPublicationMigration(context, target.id).status();
      return status ? [[target.id, status]] : [];
    })),
    conflicts: Object.fromEntries(listGitHubSyncConflicts(githubSyncStateDirectory(context)).map(record => [record.targetId, {
      id: record.id,
      revision: record.revision || 0,
      remoteCommit: record.remoteCommit,
      createdAt: record.createdAt,
      purpose: record.purpose,
      remoteSchema: record.remoteSchema,
      resolutionReport: record.resolutionReport,
      appliedAt: record.appliedAt,
      applyState: record.applyState,
      files: record.files.map(file => ({
        path: file.path,
        type: file.type,
        itemId: file.itemId,
        member: file.member,
        basePath: file.basePath,
        localPath: file.localPath,
        remotePath: file.remotePath,
        reason: file.reason,
        plannedOperation: file.plannedOperation,
        deletionEvidence: file.deletionEvidence,
        absenceEvidence: file.absenceEvidence,
        hasBase: file.hasBase,
        hasLocal: file.hasLocal,
        hasRemote: file.hasRemote,
        candidateSource: file.candidateSource,
        rationale: file.rationale,
        agentReview: file.agentReview,
      })),
    }])),
    connected,
    credentialErrors,
    authenticationOptions: { accounts: [...accounts].sort(), identities: [...identities].sort() }
  };
}

/** Ensure the knowledge store is a git repository (init on first use). */
function ensureGitRepo(): void {
  try {
    const store = getStorePath();
    if (!store || !fs.existsSync(store)) return;
    if (fs.existsSync(path.join(store, ".git"))) return;
    execSync(`git -C "${store}" init`, { stdio: "pipe", windowsHide: process.platform === "win32" });
    // Keep generated and machine-local state out of the portable Knowledge Root repository.
    const gitignore = path.join(store, ".gitignore");
    if (!fs.existsSync(gitignore)) {
      fs.writeFileSync(gitignore, defaultKnowledgeGitignore());
    }
    execSync(`git -C "${store}" add -A && git -C "${store}" commit -m "init: personal knowledge store" --allow-empty`, { stdio: "pipe", windowsHide: process.platform === "win32" });
    log.info(`initialized git repo in ${store}`);
  } catch (e: any) {
    log.warn(`ensureGitRepo failed: ${e?.message}`);
  }
}

let gitCommitQueue = Promise.resolve();

function runGit(args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    execFile("git", args, { stdio: "pipe", windowsHide: process.platform === "win32" } as any, error => error ? reject(error) : resolve());
  });
}

function gitCommit(msg: string): void {
  invalidateSharedContentCatalog();
  const store = getStorePath();
  gitCommitQueue = gitCommitQueue
    .then(() => runGit(["-C", store, "add", "-A"]))
    .then(() => runGit(["-C", store, "commit", "-m", msg]))
    .catch(() => { /* nothing to commit, or the next operation will retry */ });
}

// (Notes & skills are persisted directly as files by filestore.ts — no separate mirror needed.)

// ── Slug from title ────────────────────────────────────────────────────────
function toSlug(title: string): string {
  return title.toLowerCase().replace(/[^a-z0-9\s-]/g, "").trim()
    .replace(/\s+/g, "-").slice(0, 40) || `note-${Date.now()}`;
}
function uniqueSlug(title: string): string {
  let slug = toSlug(title), n = 2;
  while (slugExists(slug)) slug = `${toSlug(title)}-${n++}`;
  return slug;
}

// Paper identity is its folder path + title (title preserved). paperUpsert
// writes to the sanitized path; this just builds the category/title key.
function uniquePaperSlug(title: string, category: string): string {
  const cat = (category || "").replace(/^\/+|\/+$/g, "");
  return (cat ? cat + "/" : "") + ((title || "paper").trim() || "paper");
}

// ── Standalone note HTML export ──────────────────────────────────────────────
/** Filesystem-safe filename part (no path separators or reserved chars). */
function safeFilePart(s: string): string {
  return (s || "").replace(/[/\\:*?"<>|\u0000-\u001f]/g, "").trim().slice(0, 120);
}

function authorizeEphemeralBrowserRequest(req: http.IncomingMessage, res: http.ServerResponse, accessToken: string): boolean {
  const requestUrl = new URL(String(req.url || "/"), "http://localhost");
  const cookieName = `pkm_ephemeral_preview_${accessToken.slice(0, 12)}`;
  const cookieToken = String(req.headers.cookie || "")
    .split(";")
    .map(value => value.trim())
    .find(value => value.startsWith(`${cookieName}=`))
    ?.slice(cookieName.length + 1);
  if (requestUrl.searchParams.get("_pkm_token") === accessToken) {
    res.setHeader("Set-Cookie", `${cookieName}=${accessToken}; HttpOnly; SameSite=Strict; Path=/`);
    return true;
  }
  if (cookieToken === accessToken) return true;
  res.writeHead(403, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" });
  res.end("Forbidden");
  return false;
}

/**
 * Open a self-contained HTML document in the user's real browser — works both
 * locally and over Remote-SSH. We serve the doc from an ephemeral loopback HTTP
 * server and route the URL through `asExternalUri`, which tunnels the port to
 * the local machine on remote setups (and is a no-op locally). This avoids the
 * `vscode-remote:`/`file:` "select an app" prompt you get from opening a file URI.
 */
async function openHtmlInBrowser(doc: string): Promise<boolean> {
  return await new Promise<boolean>((resolve) => {
    let settled = false;
    const brandedDocument = ensureBrowserFavicon(doc);
    const accessToken = randomBytes(24).toString("base64url");
    const finish = (v: boolean) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const server = http.createServer((req, res) => {
        if (!authorizeEphemeralBrowserRequest(req, res, accessToken)) return;
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
        res.end(brandedDocument);
      });
      server.on("error", () => finish(false));
      // Auto-close after a grace period; a self-contained page needs one GET.
      const closeTimer = setTimeout(() => { try { server.close(); } catch { /* ignore */ } }, 120_000);
      closeTimer.unref?.();
      server.listen(0, "0.0.0.0", async () => {
        try {
          const port = (server.address() as any).port;
          const opened = await vscode.env.openExternal(vscode.Uri.parse(`http://${externalUrlHost()}:${port}/?_pkm_token=${accessToken}`));
          finish(!!opened);
        } catch {
          try { server.close(); } catch { /* ignore */ }
          finish(false);
        }
      });
    } catch {
      finish(false);
    }
  });
}

function readBrowserJson(req: http.IncomingMessage, maximumBytes = 2_000_000): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on("data", chunk => {
      size += chunk.length;
      if (size > maximumBytes) {
        reject(new Error("Request body is too large."));
        req.destroy();
        return;
      }
      chunks.push(Buffer.from(chunk));
    });
    req.on("end", () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}")); }
      catch { reject(new Error("Request body must be valid JSON.")); }
    });
    req.on("error", reject);
  });
}

function browserJson(res: http.ServerResponse, status: number, value: unknown): void {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(value));
}

async function openRecipeEditorInBrowser(recipeId: string): Promise<boolean> {
  return await new Promise<boolean>((resolve) => {
    let settled = false;
    const accessToken = randomBytes(24).toString("base64url");
    const finish = (value: boolean) => { if (!settled) { settled = true; resolve(value); } };
    const findRecipe = () => currentProjectStore().list().recipes.find(candidate => candidate.recipeId === recipeId);
    try {
      const server = http.createServer(async (req, res) => {
        if (!authorizeEphemeralBrowserRequest(req, res, accessToken)) return;
        const requestUrl = new URL(String(req.url || "/"), "http://localhost");
        try {
          if (req.method === "GET" && requestUrl.pathname === "/") {
            const recipe = findRecipe();
            if (!recipe) { res.writeHead(404); res.end("Recipe not found"); return; }
            res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
            res.end(ensureBrowserFavicon(recipeBrowserEditorDocument(recipe, pyenvList())));
            return;
          }
          if (req.method === "GET" && requestUrl.pathname === "/api/recipe") {
            const recipe = findRecipe();
            browserJson(res, recipe ? 200 : 404, recipe ? { recipe } : { error: "Recipe not found." });
            return;
          }
          if (req.method === "POST" && requestUrl.pathname === "/api/validate") {
            const body = await readBrowserJson(req) as { definition?: unknown };
            const compiled = compileWorkflowDefinitionV1(body.definition);
            if (!compiled.ok) throw new ProjectModelError("recipe-definition-invalid", "Recipe definition is invalid.", { diagnostics: compiled.diagnostics });
            browserJson(res, 200, { definition: compiled.model, executableDigest: compiled.executableDigest, nodeCount: compiled.model.spec.nodes.length });
            return;
          }
          if (req.method === "PUT" && requestUrl.pathname === "/api/recipe") {
            const body = await readBrowserJson(req) as RecipeRecord;
            const current = findRecipe();
            if (!current) { browserJson(res, 404, { error: "Recipe not found." }); return; }
            if (Number(body.revision) !== current.revision) {
              browserJson(res, 409, { error: `Recipe changed since this page opened (current revision ${current.revision}). Reload before saving.` });
              return;
            }
            const input = {
              name: String(body.name || ""), category: String(body.category || ""), description: String(body.description || ""),
              methodology: body.methodology,
              metadata: body.metadata as RecipeMetadata | undefined,
              editorLayout: body.editorLayout as RecipeRecord["editorLayout"],
              definition: body.definition as WorkflowDefinitionV1,
              nodeBindings: hydrateRecipeNodeBindings(body.nodeBindings)
            };
            const store = currentProjectStore();
            store.updateRecipe(projectCommand(store, "recipe-browser-update", { recipeId, ...input }), recipeId, input);
            const recipe = findRecipe();
            browserJson(res, 200, { recipe });
            return;
          }
          browserJson(res, 404, { error: "Not found." });
        } catch (error: any) {
          browserJson(res, 400, { error: String(error?.message || error || "Request failed.") });
        }
      });
      server.on("error", () => finish(false));
      const closeTimer = setTimeout(() => { try { server.close(); } catch { /* ignore */ } }, 1_800_000);
      closeTimer.unref?.();
      server.listen(0, "0.0.0.0", async () => {
        try {
          const port = (server.address() as any).port;
          const opened = await vscode.env.openExternal(vscode.Uri.parse(`http://${externalUrlHost()}:${port}/?_pkm_token=${accessToken}`));
          finish(!!opened);
        } catch {
          try { server.close(); } catch { /* ignore */ }
          finish(false);
        }
      });
    } catch { finish(false); }
  });
}

function recipeBrowserDocument(recipe: RecipeRecord): string {
  const escape = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
  const nodes = recipe.definition.spec.nodes;
  const dependentIds = new Set(nodes.flatMap(node => node.dependsOn.filter(dependency => !dependency.loop).map(dependency => dependency.from)));
  const roots = nodes.filter(node => !node.dependsOn.some(dependency => !dependency.loop));
  const terminals = nodes.filter(node => !dependentIds.has(node.nodeId));
  const bindings = new Map((recipe.nodeBindings || []).map(item => [item.nodeId, item.bindings]));
  const portList = (ports: Record<string, unknown>) => Object.keys(ports).length
    ? Object.keys(ports).map(port => `<code>${escape(port)}</code>`).join("")
    : '<span class="empty">None</span>';
  const cards = nodes.map(node => {
    const incoming = node.dependsOn.map(dependency => {
      const route = [dependency.fromOutput, dependency.toInput].filter(Boolean).map(escape).join(" → ");
      const loop = dependency.loop ? ` · loop until ${escape(dependency.loop.termination.condition)} · max ${dependency.loop.termination.maxIterations}` : "";
      return `<li><strong>${escape(dependency.from)}</strong>${route ? ` · ${route}` : ""}${loop}</li>`;
    }).join("");
    const references = (bindings.get(node.nodeId) || []).map(binding => `<li><span class="kind">${escape(binding.kind)}</span><strong>${escape(binding.knowledgeId)}</strong><small>${escape(binding.usage)}</small></li>`).join("");
    const control = node.control ? JSON.stringify(node.control) : "single";
    const config = node.kind === "pkm.subflow/v1" ? `<div class="facts"><span>Recipe ${escape(node.config.recipeId)}</span><span>Revision ${node.config.revision}</span></div>` : "";
    return `<article class="node"><header><span>${escape(node.kind)}</span><h2>${escape(node.nodeId)}</h2></header>${config}<dl><div><dt>Control</dt><dd>${escape(control)}</dd></div><div><dt>Inputs</dt><dd>${(node.ports?.inputs || []).map(port => `<code>${escape(port)}</code>`).join("") || '<span class="empty">None</span>'}</dd></div><div><dt>Outputs</dt><dd>${(node.ports?.outputs || []).map(port => `<code>${escape(port)}</code>`).join("") || '<span class="empty">None</span>'}</dd></div></dl><section><h3>Intent &amp; Guidance</h3><p>${escape(node.generalInstruction || "No guidance provided.")}</p></section><section><h3>Incoming routes</h3>${incoming ? `<ul>${incoming}</ul>` : '<p class="empty">Source</p>'}</section><section><h3>References</h3>${references ? `<ul class="references">${references}</ul>` : '<p class="empty">None</p>'}</section></article>`;
  }).join('<div class="arrow" aria-hidden="true">↓</div>');
  const trigger = recipe.definition.spec.trigger ? `<span class="pill">${escape(recipe.definition.spec.trigger.expression)} · ${escape(recipe.definition.spec.trigger.timezone)}</span>` : '<span class="empty">Manual</span>';
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(recipe.name)} · Recipe</title><style>:root{color-scheme:light dark;--bg:#111315;--panel:#1b1e21;--line:#3c4248;--text:#f3f4f6;--muted:#9da5ad;--accent:#e25555}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 ui-sans-serif,system-ui,sans-serif}main{width:min(920px,calc(100% - 28px));margin:0 auto;padding:34px 0 70px}.eyebrow,.node header span{color:var(--accent);font-size:11px;font-weight:700;text-transform:uppercase}h1{margin:3px 0 5px;font-size:clamp(25px,5vw,42px)}.subtitle{color:var(--muted)}.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:28px 0;border-block:1px solid var(--line)}.summary>div{padding:13px;border-right:1px solid var(--line)}.summary>div:last-child{border:0}.summary small,dt{display:block;color:var(--muted);font-size:10px;text-transform:uppercase}.io{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}.band{padding:15px;border-left:3px solid var(--accent);background:var(--panel)}.band h2{margin:0 0 8px;font-size:14px}.flow{display:flex;align-items:center;flex-direction:column}.boundary{min-width:180px;padding:9px 16px;border:1px solid var(--accent);text-align:center;font-weight:700}.node{width:100%;padding:18px;border:1px solid var(--line);border-top:3px solid var(--accent);background:var(--panel)}.node header h2{margin:2px 0 12px;font-size:19px}.node dl{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:0}.node dl>div,.node section{min-width:0;padding-top:11px;border-top:1px solid var(--line)}dd{margin:4px 0;overflow-wrap:anywhere}.node section{margin-top:12px}.node h3{margin:0 0 5px;font-size:11px;text-transform:uppercase}.node p{margin:0;white-space:pre-wrap}.arrow{height:40px;color:var(--accent);font-size:25px}.facts{display:flex;gap:8px;margin-bottom:12px;color:var(--muted)}code,.pill,.kind{display:inline-block;margin:2px 4px 2px 0;padding:2px 6px;border:1px solid var(--line);background:#0002;font:12px ui-monospace,monospace}.empty{color:var(--muted)}ul{margin:4px 0;padding-left:19px}.references{padding:0;list-style:none}.references li{display:flex;align-items:center;gap:7px}.references small{color:var(--muted)}@media(max-width:620px){main{padding-top:20px}.summary{grid-template-columns:1fr 1fr}.summary>div:nth-child(2){border-right:0}.io,.node dl{grid-template-columns:1fr}.summary>div{border-bottom:1px solid var(--line)}}</style></head><body><main><header><div class="eyebrow">Automation Recipe</div><h1>${escape(recipe.name)}</h1><div class="subtitle">${escape(recipe.description || "No description provided.")}</div></header><section class="summary"><div><small>Revision</small><strong>${recipe.revision}</strong></div><div><small>Nodes</small><strong>${nodes.length}</strong></div><div><small>Trigger</small>${trigger}</div><div><small>Digest</small><strong title="${escape(recipe.executableDigest)}">${escape(recipe.executableDigest.slice(0, 12))}</strong></div></section><section class="io"><div class="band"><h2>Recipe inputs</h2>${portList(recipe.definition.spec.inputs)}</div><div class="band"><h2>Recipe outputs</h2>${portList(recipe.definition.spec.outputs)}</div></section><section class="flow"><div class="boundary">Source · ${roots.map(node => escape(node.nodeId)).join(", ") || "None"}</div><div class="arrow" aria-hidden="true">↓</div>${cards || '<p class="empty">No steps.</p>'}<div class="arrow" aria-hidden="true">↓</div><div class="boundary">Sink · ${terminals.map(node => escape(node.nodeId)).join(", ") || "None"}</div></section></main></body></html>`;
}

const MIME_BY_EXT: Record<string, string> = {
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif",
  webp: "image/webp", svg: "image/svg+xml", bmp: "image/bmp", avif: "image/avif",
};

/** Inline safe managed Markdown image references for a portable export. */
function inlineMarkdownAssets(html: string, area = "notes", category = ""): string {
  const safeArea = ["notes", "skills", "papers"].includes(area) ? area : "notes";
  const areaRoot = path.resolve(getStorePath(), safeArea);
  const documentDirectory = path.resolve(areaRoot, ...String(category || "").split("/").map(s => s.trim()).filter(Boolean));
  return html.replace(/(src\s*=\s*)("|')([^"']+)\2/gi, (m, pre, q, reference) => {
    try {
      const value = String(reference || "").replace(/&amp;/g, "&").replace(/[?#].*$/, "");
      if (!value || value.startsWith("/") || value.startsWith("\\") || value.startsWith("//") || /^[a-z][a-z0-9+.-]*:/i.test(value)) return m;
      const full = path.resolve(documentDirectory, decodeURIComponent(value));
      const relative = path.relative(areaRoot, full).replace(/\\/g, "/");
      if (!relative || relative.startsWith("../") || path.isAbsolute(relative)
        || !relative.split("/").some(isMarkdownAssetDirectory) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return m;
      const realRoot = fs.realpathSync(areaRoot);
      const realFile = fs.realpathSync(full);
      if (realFile !== realRoot && !realFile.startsWith(`${realRoot}${path.sep}`)) return m;
      const ext = (path.extname(realFile).slice(1) || "png").toLowerCase();
      const mime = MIME_BY_EXT[ext] || "application/octet-stream";
      const b64 = fs.readFileSync(realFile).toString("base64");
      return `${pre}${q}data:${mime};base64,${b64}${q}`;
    } catch { return m; }
  });
}

/** Serve a folder of exported note HTML files and open the entry file in the
 *  user's browser (works over Remote-SSH via asExternalUri). Used by the linked
 *  ("site") export so cross-note links resolve to sibling .html files. */
async function serveFolderInBrowser(dir: string, entry: string): Promise<boolean> {
  return await new Promise<boolean>((resolve) => {
    let settled = false;
    const accessToken = randomBytes(24).toString("base64url");
    const finish = (v: boolean) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const server = http.createServer((req, res) => {
        if (!authorizeEphemeralBrowserRequest(req, res, accessToken)) return;
        try {
          const urlPath = decodeURIComponent(String(req.url || "/").replace(/[?#].*$/, ""));
          const rel = urlPath === "/" ? entry : urlPath.replace(/^\/+/, "");
          const full = path.join(dir, rel);
          if (!full.startsWith(dir) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) {
            res.writeHead(404); res.end("Not found"); return;
          }
          const ext = path.extname(full).slice(1).toLowerCase();
          const mime = ext === "html" ? "text/html; charset=utf-8"
            : ext === "css" ? "text/css" : ext === "js" ? "text/javascript"
            : (MIME_BY_EXT[ext] || "application/octet-stream");
          res.writeHead(200, { "Content-Type": mime, "Cache-Control": "no-store" });
          res.end(fs.readFileSync(full));
        } catch { res.writeHead(500); res.end("error"); }
      });
      server.on("error", () => finish(false));
      const closeTimer = setTimeout(() => { try { server.close(); } catch { /* ignore */ } }, 600_000);
      closeTimer.unref?.();
      server.listen(0, "0.0.0.0", async () => {
        try {
          const port = (server.address() as any).port;
          const opened = await vscode.env.openExternal(vscode.Uri.parse(`http://${externalUrlHost()}:${port}/${encodeURIComponent(entry)}?_pkm_token=${accessToken}`));
          finish(!!opened);
        } catch { try { server.close(); } catch { /* ignore */ } finish(false); }
      });
    } catch { finish(false); }
  });
}

let liveNoteServer: http.Server | undefined;
let liveNoteBaseUrl: vscode.Uri | undefined;
let publicContentServer: http.Server | undefined;
let publicContentTimer: NodeJS.Timeout | undefined;
let publicContentActivePort = 0;
let publicContentEnsure: Promise<void> | undefined;

function externalLinkHostOptions(): { options: any[]; selected: string; resolved: string; unavailable: boolean } {
  const options = serverNetworkAddresses().map(item => ({ ...item, label: `${item.kind === "hostname" ? "Hostname" : item.interface} · ${item.address}` }));
  const configuration = vscode.workspace.getConfiguration("personalKnowledge");
  const configured = configuration.get<string>("externalLinkHost", "").trim()
    || configuration.get<string>("chatInviteHost", "").trim();
  const fallback = options.find(item => item.kind === "hostname")?.address || options[0]?.address || os.hostname().replace(/\.$/, "");
  const unavailable = !!configured && !options.some(item => item.address === configured);
  return { options, selected: configured || fallback, resolved: unavailable ? fallback : configured || fallback, unavailable };
}

function externalUrlHost(): string {
  const host = externalLinkHostOptions().resolved;
  return host.includes(":") && !host.startsWith("[") ? `[${host}]` : host;
}

function publicContentPort(): number {
  return vscode.workspace.getConfiguration("personalKnowledge").get<number>("contentGatewayPort", 39502);
}

function publicContentPath(kind: "note" | "skill" | "paper" | "script", key: string): string {
  return "/" + `${kind}s/${key}`.split("/").map(segment => encodeURIComponent(segment)).join("/") + ".html";
}

function publicContentRouteAllowed(pathname: string): boolean {
  const clean = pathname.replace(/^\/+/, "").replace(/\.html$/i, "");
  const match = /^(notes|skills|papers|scripts)\/(.+)$/.exec(clean);
  if (!match) return false;
  return !isContentPathPrivate(match[1] as PrivacyContentType, match[2]);
}

function publicContentIdentity(): { storeId: string; version: string } {
  return {
    storeId: createHash("sha256").update(path.resolve(getStorePath())).digest("hex").slice(0, 24),
    version: "1",
  };
}

async function ensurePublicContentGateway(context: vscode.ExtensionContext): Promise<void> {
  if (publicContentEnsure) return publicContentEnsure;
  const pending = withCrossProcessLock(
    path.join(context.globalStorageUri.fsPath, "services", "public-content.lock"),
    "Public Content Gateway transition",
    5_000,
    () => ensurePublicContentGatewayOnce(context),
  );
  publicContentEnsure = pending;
  try { await pending; }
  finally { if (publicContentEnsure === pending) publicContentEnsure = undefined; }
}

async function ensurePublicContentGatewayOnce(context: vscode.ExtensionContext): Promise<void> {
  if (!_storeReady || !getStorePath()) return;
  const port = publicContentPort();
  const identity = publicContentIdentity();
  try {
    const response = await fetch(`http://127.0.0.1:${port}/.well-known/pkm-content`, { signal: AbortSignal.timeout(500) });
    const active = await response.json() as { protocol?: string; storeId?: string };
    if (active.protocol === "pkm-content:v1" && active.storeId === identity.storeId) { publicContentActivePort = port; return; }
  } catch (error) {
    if (error instanceof Error && error.message.includes("another content service")) throw error;
  }
  try {
    await startPublicContentGatewayAt(context, port, identity);
  } catch (error: any) {
    if (error?.code !== "EADDRINUSE") throw error;
    for (let attempt = 0; attempt < 20; attempt++) {
      try {
        const response = await fetch(`http://127.0.0.1:${port}/.well-known/pkm-content`, { signal: AbortSignal.timeout(500) });
        const active = await response.json() as { protocol?: string; storeId?: string };
        if (active.protocol === "pkm-content:v1" && active.storeId === identity.storeId) { publicContentActivePort = port; return; }
      } catch { /* listener may still be publishing its identity endpoint */ }
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(`Public Content Gateway port ${port} is owned by an unrelated service. Choose another port in Config.`);
  }
}

async function startPublicContentGatewayAt(context: vscode.ExtensionContext, port: number, identity: { storeId: string; version: string }): Promise<void> {
  const started = await startLiveMarkdownServer(
    [
      { prefix: "notes", root: path.join(getStorePath(), "notes") },
      { prefix: "skills", root: path.join(getStorePath(), "skills") },
      { prefix: "papers", root: path.join(getStorePath(), "papers") },
      { prefix: "scripts", root: path.join(getStorePath(), "scripts") },
    ],
    documentPath => liveMarkdownHtml(documentPath, context, false),
    MIME_BY_EXT,
    { listenHost: "0.0.0.0", port, authorizePath: publicContentRouteAllowed, identity, favicon: browserIconBuffer(),
      mermaid: await browserMermaidResources(context), graph: await browserGraphResources(context) },
  );
  publicContentServer = started.server;
  publicContentActivePort = port;
  publicContentServer.once("close", () => { publicContentServer = undefined; publicContentActivePort = 0; });
}

function findAvailablePort(start: number): Promise<number> {
  return new Promise((resolve, reject) => {
    const tryPort = (port: number): void => {
      if (port > 65535 || port >= start + 100) { reject(new Error("No available Public Content Gateway port was found.")); return; }
      const probe = net.createServer();
      probe.once("error", () => tryPort(port + 1));
      probe.listen(port, "0.0.0.0", () => probe.close(() => resolve(port)));
    };
    tryPort(start);
  });
}

function stablePublicContentUrl(kind: "note" | "skill" | "paper" | "script", key: string): string {
  return `http://${externalUrlHost()}:${publicContentActivePort || publicContentPort()}${publicContentPath(kind, key)}`;
}

function markdownPreviewPath(kind: "note" | "skill" | "paper" | "script", key: string): string {
  const prefix = `${kind}s/`;
  return "/" + (prefix + key).split("/").map(segment => encodeURIComponent(segment)).join("/") + ".html";
}

function notePreviewPath(slug: string): string { return markdownPreviewPath("note", slug); }

function noteLinkIndex(notes: any[]): {
  bySlug: Map<string, any>;
  titleIndex: Map<string, number>;
  basenameIndex: Map<string, number>;
} {
  const bySlug = new Map<string, any>();
  const titleIndex = new Map<string, number>();
  const basenameIndex = new Map<string, number>();
  notes.forEach((note, index) => {
    const slug = String(note.slug || "").toLowerCase();
    const title = String(note.title || "").toLowerCase();
    if (slug && !bySlug.has(slug)) bySlug.set(slug, note);
    if (title && !titleIndex.has(title)) titleIndex.set(title, index);
    const basename = slug.split("/").pop() || slug;
    if (basename && !basenameIndex.has(basename)) basenameIndex.set(basename, index);
  });
  return { bySlug, titleIndex, basenameIndex };
}

function rewriteLiveNoteLinks(markdown: string, slug: string, includePrivate = false): string {
  const all = (noteList(undefined, Number.MAX_SAFE_INTEGER, true) as any[])
    .filter(note => includePrivate || !isContentPathPrivate("notes", String(note.slug || "")));
  const index = noteLinkIndex(all);
  const resolve = (target: string): string | null => {
    if (/\.md(?:[?#]|$)/i.test(target) || target.includes("/")) {
      const resolved = resolveNoteSlugFromPath(target, slug);
      const resolvedNote = resolved ? index.bySlug.get(resolved.toLowerCase()) : undefined;
      if (resolvedNote) return resolvedNote.slug;
    }
    const clean = target.replace(/\.md$/i, "");
    const directNote = index.bySlug.get(clean.toLowerCase());
    if (directNote) return directNote.slug;
    const needle = clean.toLowerCase();
    const base = needle.split("/").pop();
    const titleMatch = index.titleIndex.get(needle);
    const basenameMatch = base ? index.basenameIndex.get(base) : undefined;
    const hitIndex = titleMatch === undefined ? basenameMatch : basenameMatch === undefined ? titleMatch : Math.min(titleMatch, basenameMatch);
    const hit = hitIndex === undefined ? undefined : all[hitIndex];
    return hit?.slug || null;
  };
  return outsideCode(markdown, segment => segment
    .replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, (_match, target, alias) => {
      const linked = resolve(String(target).trim());
      const label = String(alias || target).trim();
      return linked ? `[${label}](${notePreviewPath(linked)})` : label;
    })
    .replace(/\[([^\]]*)\]\(\s*([^)]+?)\.md((?:[?#][^)]*)?)\s*\)/gi, (match, label, target, suffix) => {
      const linked = resolve(`${target}.md`);
      return linked ? `[${label}](${notePreviewPath(linked)}${suffix || ""})` : match;
    }));
}

function liveMarkdownNavigation(documentPath: string, includePrivate: boolean): string {
  const { browserResearchGraph, browserNavigationRuntime, browserPrivacyLock } = require("./ui/browser-navigation") as typeof import("./ui/browser-navigation");
  const esc = (value: unknown) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const groups = [
    { label:"Notes", type:"notes" as const, kind:"note" as const, items:(noteList(undefined, Number.MAX_SAFE_INTEGER, true) as any[]).map(note => ({key:String(note.slug || ""), title:String(note.title || note.slug || "")})) },
    { label:"Skills", type:"skills" as const, kind:"skill" as const, items:(skillList() as any[]).map(skill => ({key:[skill.category, skill.name].filter(Boolean).join("/"), title:String(skill.name || "")})) },
    { label:"Research", type:"papers" as const, kind:"paper" as const, items:paperList().map(paper => ({key:paper.slug, title:paper.title || paper.slug})) },
  ];
  const activeTab = documentPath.startsWith("skills/") ? "skills" : documentPath.startsWith("papers/") ? "papers" : "notes";
  const sections = groups.map(group => {
    const items = group.items.filter(item => item.key && (includePrivate || !isContentPathPrivate(group.type, item.key)))
      .sort((left, right) => left.key.localeCompare(right.key));
    interface NavigationFolder { folders: Map<string, NavigationFolder>; items: typeof items; }
    const root: NavigationFolder = { folders:new Map(), items:[] };
    for (const item of items) {
      let folder = root;
      for (const name of item.key.split("/").slice(0, -1)) {
        if (!folder.folders.has(name)) folder.folders.set(name, { folders:new Map(), items:[] });
        folder = folder.folders.get(name)!;
      }
      folder.items.push(item);
    }
    const renderFolder = (folder: NavigationFolder, parent: string[]): string => {
      const folders = [...folder.folders].map(([name, child]) => {
        const segments = [...parent, name];
        const active = documentPath.startsWith(`${group.type}/${segments.join("/")}/`);
        const locator = navigationItemPath({ nodeType:`${group.kind}-folder`, nodeData:{ relPath:segments.join("/") } });
        const privacy = isContentPathPrivate(group.type, segments.join("/")) ? browserPrivacyLock : "";
        return `<details class="reader-nav-folder"${active ? " open" : ""} data-folder="${esc(segments.join("/"))}"><summary data-pkm-path="${esc(locator)}">${esc(name)}${privacy}</summary><div class="reader-nav-children">${renderFolder(child, segments)}</div></details>`;
      }).join("");
      return folders + folder.items.map(item => {
        const active = documentPath === `${group.type}/${item.key}`;
        const locator = navigationItemPath({ nodeType:group.kind, nodeData:{ relPath:`${item.key}.md` } });
        const privacy = isContentPathPrivate(group.type, item.key) ? browserPrivacyLock : "";
        return `<a class="reader-nav-item" data-pkm-path="${esc(locator)}" href="${esc(markdownPreviewPath(group.kind, item.key))}" title="${esc(item.key)}"${active ? ' aria-current="page"' : ''}><span class="reader-nav-title">${esc(item.title)}</span>${privacy}</a>`;
      }).join("");
    };
    const links = renderFolder(root, []);
    const directory = links || '<p class="reader-nav-empty">No content</p>';
    return `<section class="reader-nav-group" role="tabpanel" id="library-${group.type}" aria-labelledby="tab-${group.type}" data-library-panel="${group.type}"${activeTab !== group.type ? " hidden" : ""}><h2>${group.label}</h2>${group.type === "papers" ? `<div class="reader-graph-tools" aria-label="Research view"><button type="button" data-graph-view="directory" aria-pressed="true">Directory</button><button type="button" data-graph-view="2d" aria-pressed="false">2D Graph</button><button type="button" data-graph-view="3d" aria-pressed="false">3D Graph</button></div><div class="reader-research-directory">${directory}</div>` : directory}</section>`;
  }).join("");
  const tabs = [...groups].sort((a, b) => ["skills", "notes", "papers"].indexOf(a.type) - ["skills", "notes", "papers"].indexOf(b.type)).map(group =>
    `<button type="button" role="tab" id="tab-${group.type}" aria-controls="library-${group.type}" data-library-tab="${group.type}" aria-selected="${activeTab === group.type}">${group.label}</button>`).join("");
  const graph = browserResearchGraph(paperGraph({ limit: 100000 }), key => includePrivate || !isContentPathPrivate("papers", key));
  const accessLabel = includePrivate ? "Private" : "Public";
  const accessDescription = includePrivate ? "Authenticated view: Public and Private knowledge" : "Public knowledge only";
  const accessBadge = `<footer class="reader-access" data-access="${includePrivate ? "private" : "public"}" aria-label="${accessDescription}" title="${accessDescription}"><span class="reader-access-dot" aria-hidden="true"></span><span class="reader-access-label">${accessLabel}</span></footer>`;
  return `<aside class="reader-sidebar" aria-label="Knowledge navigation"><details open><summary>Library</summary><label class="reader-search"><input type="search" aria-label="Search Notes, Skills and Research" placeholder="Search current library tab" oninput="const query=this.value.toLocaleLowerCase();const sidebar=this.closest('aside');sidebar.querySelectorAll('.reader-nav-item').forEach(item=>{item.hidden=!item.textContent.toLocaleLowerCase().includes(query)&&!item.title.toLocaleLowerCase().includes(query)});sidebar.querySelectorAll('.reader-nav-folder').forEach(folder=>{if(query){if(!('searchOpen' in folder.dataset))folder.dataset.searchOpen=String(folder.open);folder.hidden=!folder.querySelector('.reader-nav-item:not([hidden])');if(!folder.hidden)folder.open=true}else{folder.hidden=false;if('searchOpen' in folder.dataset){folder.open=folder.dataset.searchOpen==='true';delete folder.dataset.searchOpen}}})"></label><div class="reader-tabs" role="tablist" aria-label="Library tabs">${tabs}</div><nav>${sections}</nav></details>${accessBadge}</aside><section class="reader-graph-view" aria-label="Research graph" hidden><p class="reader-graph-status" role="status"></p><div class="reader-graph-canvas"></div></section>${browserNavigationRuntime(activeTab, graph)}`;
}

async function browserGraphResources(context: vscode.ExtensionContext): Promise<{ cytoscape: Buffer; forcegraph3d: Buffer }> {
  const directory = path.join(context.extensionPath, "dist", "webview");
  const [cytoscape, forcegraph3d] = await Promise.all([
    fs.promises.readFile(path.join(directory, "cytoscape.js")),
    fs.promises.readFile(path.join(directory, "forcegraph3d.js")),
  ]);
  return { cytoscape, forcegraph3d };
}

async function browserMermaidResources(context: vscode.ExtensionContext): Promise<{ library: Buffer; renderer: Buffer }> {
  const directory = path.join(context.extensionPath, "dist", "webview");
  const [library, renderer] = await Promise.all([
    fs.promises.readFile(path.join(directory, "mermaid.js")),
    fs.promises.readFile(path.join(directory, "standalone-mermaid.js")),
  ]);
  return { library, renderer };
}

function liveMarkdownHtml(documentPath: string, context: vscode.ExtensionContext, includePrivate = false): string | undefined {
  if (!includePrivate && !publicContentRouteAllowed(`/${documentPath}.html`)) return undefined;
  let item: any;
  let kind: "note" | "skill" | "paper" | "script";
  if (documentPath.startsWith("skills/")) {
    kind = "skill";
    const key = documentPath.slice("skills/".length);
    const listed = (skillList() as any[]).find(skill => (skill.category ? `${skill.category}/${skill.name}` : skill.name) === key);
    item = listed ? skillGet(listed.name) : undefined;
    if (item && [item.category, item.name].filter(Boolean).join("/") !== key) return undefined;
  } else if (documentPath.startsWith("papers/")) {
    kind = "paper";
    item = paperGet(documentPath.slice("papers/".length));
  } else if (documentPath.startsWith("scripts/")) {
    kind = "script";
    item = scriptGet(documentPath.slice("scripts/".length));
  } else if (documentPath.startsWith("notes/")) {
    kind = "note";
    item = noteGet(documentPath.slice("notes/".length));
  } else {
    kind = "note";
    item = noteGet(documentPath);
  }
  if (!item) return undefined;
  const { renderMarkdown } = require("./live-markdown") as { renderMarkdown(markdown: string): string };
  const markdown = kind === "note" ? rewriteLiveNoteLinks(item.content || "", item.slug, includePrivate) : item.content || "";
  const bodyHtml = kind === "script"
    ? `<pre><code>${String(item.content || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code></pre>`
    : renderMarkdown(markdown);
  return buildStandaloneNoteHtml({
    liveBrowser: true,
    title: item.title || item.name || item.file, slug: item.slug || item._key || item.path, category: item.category,
    tags: Array.isArray(item.tags) ? JSON.stringify(item.tags) : item.tags || "[]",
    noteType: kind, updatedAt: item.updated_at,
    bodyHtml: kind === "note" ? browserNoteTodo(bodyHtml, item.content || "", item.slug, item.title || item.slug, context.extensionPath, item.documentKind === "todo-board" ? noteWorkItemsRead(item.slug) : undefined, true, includePrivate && vscode.workspace.isTrusted !== false && !/^system(?:\/|$)/i.test(item.slug)) : bodyHtml,
    description: item.description, sourceProject: item.source_project,
    authors: item.authors, year: item.year, publisher: item.publisher, url: item.url,
    navigationHtml:liveMarkdownNavigation(documentPath, includePrivate),
  }, katexCssForExport(context), "/favicon.ico");
}

async function openLiveMarkdownPreview(kind: "note" | "skill" | "paper" | "script", key: string, context: vscode.ExtensionContext): Promise<boolean> {
  const privacyType = `${kind}s` as PrivacyContentType;
  if (!(kind === "note" && noteGet(key)?.documentKind === "todo-board") && !isContentPathPrivate(privacyType, key)) {
    await ensurePublicContentGateway(context);
    return vscode.env.openExternal(vscode.Uri.parse(stablePublicContentUrl(kind, key)));
  }
  if (!liveNoteServer) {
    const accessToken = randomBytes(24).toString("base64url");
    const started = await startLiveMarkdownServer(
      [
        { prefix: "notes", root: path.join(getStorePath(), "notes") },
        { prefix: "skills", root: path.join(getStorePath(), "skills") },
        { prefix: "papers", root: path.join(getStorePath(), "papers") },
        { prefix: "scripts", root: path.join(getStorePath(), "scripts") },
      ],
      documentPath => liveMarkdownHtml(documentPath, context, true),
      MIME_BY_EXT,
      { accessToken, favicon: browserIconBuffer(), mermaid: await browserMermaidResources(context), graph: await browserGraphResources(context),
        manageTodo: (documentPath, message) => manageBrowserTodo(documentPath, message, vscode.workspace.isTrusted !== false,
          currentProjectStore().list().projects.map(project=>({ projectId: project.projectId, name: project.name }))) },
    );
    liveNoteServer = started.server;
    liveNoteBaseUrl = await vscode.env.asExternalUri(vscode.Uri.parse(`${started.localBaseUrl}?_pkm_token=${encodeURIComponent(accessToken)}`));
  }
  const target = new URL(liveNoteBaseUrl!.toString());
  const token = target.search;
  target.pathname = markdownPreviewPath(kind, key);
  target.search = token;
  return vscode.env.openExternal(vscode.Uri.parse(target.toString()));
}

// Apply `fn` only OUTSIDE fenced/inline code so link handling never touches code
// blocks (e.g. a mermaid `[[Kafka]]` node), matching how marked tokenizes code.
function outsideCode(md: string, fn: (seg: string) => string): string {
  return String(md).split(/(```[\s\S]*?```|`[^`\n]*`)/g).map((p, i) => (i % 2 === 0) ? fn(p) : p).join("");
}

// Extract cross-note link targets ([[Title]] wiki links and [text](path.md)).
function extractNoteLinks(content: string): string[] {
  const out: string[] = [];
  outsideCode(content, seg => {
    let m: RegExpExecArray | null;
    const wiki = /\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g;
    while ((m = wiki.exec(seg))) out.push(m[1].trim());
    const md = /\[[^\]]*\]\(\s*([^)]+?\.md)(?:[?#][^)]*)?\s*\)/gi;
    while ((m = md.exec(seg))) out.push(m[1].trim());
    return seg;
  });
  return out;
}

// Rewrite a note's cross-note links to point at sibling exported .html files.
function rewriteNoteLinks(
  content: string, fromSlug: string,
  resolve: (t: string, from: string) => string | null,
  filenames: Map<string, string>,
): string {
  return outsideCode(content, seg => {
    seg = seg.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, (m, t, a) => {
      const label = String(a || t).trim();
      const slug = resolve(String(t).trim(), fromSlug);
      const fn = slug ? filenames.get(slug) : undefined;
      return fn ? `[${label}](${fn})` : label;
    });
    seg = seg.replace(/\[([^\]]*)\]\(\s*([^)]+?\.md)(?:[?#][^)]*)?\s*\)/gi, (m, label, pth) => {
      const slug = resolve(String(pth).trim(), fromSlug);
      const fn = slug ? filenames.get(slug) : undefined;
      return fn ? `[${label}](${fn})` : m;
    });
    return seg;
  });
}

/** Collect the transitive closure of notes reachable from `rootSlug` via links,
 *  assign each a flat .html filename, and rewrite links to those filenames. */
function collectLinkedNotes(rootSlug: string): any[] {
  const all = noteList(undefined, Number.MAX_SAFE_INTEGER, true) as any[];
  const index = noteLinkIndex(all);
  const root = index.bySlug.get(rootSlug.toLowerCase());
  if (!root) return [];
  const resolve = (target: string, fromSlug: string): string | null => {
    if (/\.md(\?|#|$)/i.test(target) || target.includes("/")) {
      const s = resolveNoteSlugFromPath(target, fromSlug);
      const resolvedNote = s ? index.bySlug.get(s.toLowerCase()) : undefined;
      if (resolvedNote) return resolvedNote.slug;
    }
    const direct = target.replace(/\.md$/i, "");
    const directNote = index.bySlug.get(direct.toLowerCase());
    if (directNote) return directNote.slug;
    const needle = direct.toLowerCase();
    const base = needle.split("/").pop() || needle;
    const candidates = [index.titleIndex.get(needle), index.basenameIndex.get(base), index.titleIndex.get(base)]
      .filter((value): value is number => value !== undefined);
    const hit = candidates.length ? all[Math.min(...candidates)] : undefined;
    return hit ? hit.slug : null;
  };
  const used = new Set<string>();
  const filenames = new Map<string, string>();
  const mkFilename = (slug: string, title: string): string => {
    const base = (safeFilePart(title || slug).replace(/\//g, "_").replace(/\s+/g, "_") || "note").slice(0, 100);
    let name = base + ".html", i = 2;
    while (used.has(name.toLowerCase())) name = `${base}-${i++}.html`;
    used.add(name.toLowerCase());
    return name;
  };
  const visited = new Map<string, any>();
  visited.set(rootSlug, root);
  filenames.set(rootSlug, mkFilename(rootSlug, root.title));
  const queue = [rootSlug];
  while (queue.length) {
    const cur = queue.shift()!;
    const note = visited.get(cur);
    for (const raw of extractNoteLinks(note.content || "")) {
      const tslug = resolve(raw, cur);
      if (tslug && !visited.has(tslug)) {
        const tn = index.bySlug.get(tslug.toLowerCase());
        if (tn) { visited.set(tslug, tn); filenames.set(tslug, mkFilename(tslug, tn.title)); queue.push(tslug); }
      }
    }
  }
  const out: any[] = [];
  for (const [slug, note] of visited) {
    out.push({
      slug, filename: filenames.get(slug),
      content: rewriteNoteLinks(note.content || "", slug, resolve, filenames),
    });
  }
  return out;
}

/** Wrap the webview-rendered note body in a self-contained, shareable HTML document. */
function buildStandaloneNoteHtml(msg: any, katexCss = "", faviconHref = ""): string {
  const esc = (s: string) => String(s ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  let tags: string[] = [];
  try { tags = JSON.parse(msg.tags || "[]"); } catch { tags = []; }
  const title = String(msg.title || msg.slug || "Note");
  // Live resources must pass the gateway's privacy check rather than being embedded.
  const body = msg.liveBrowser ? String(msg.bodyHtml || "") : inlineMarkdownAssets(String(msg.bodyHtml || ""), String(msg.area || "notes"), String(msg.category || ""));
  const metaBits = [
    msg.noteType ? `<span class="pill type">${esc(msg.noteType)}</span>` : "",
    msg.category ? `<span class="pill cat">${esc(msg.category)}</span>` : "",
    ...tags.map(t => `<span class="pill tag">#${esc(t)}</span>`),
    msg.updatedAt ? `<span class="upd">Updated ${esc(String(msg.updatedAt).slice(0, 10))}</span>` : "",
  ].filter(Boolean).join("");
  const authors = Array.isArray(msg.authors) ? msg.authors.join(", ") : String(msg.authors || "");
  const detailRows = [
    ["Description", msg.description], ["Source", msg.sourceProject],
    ["Authors", authors], ["Year", msg.year], ["Publisher", msg.publisher], ["URL", msg.url],
  ].filter(([, value]) => value !== undefined && value !== null && String(value).trim());
  const details = detailRows.length
    ? `<dl class="details">${detailRows.map(([label, value]) => `<dt>${esc(label)}</dt><dd>${esc(value)}</dd>`).join("")}</dl>`
    : "";
  const navigation = String(msg.navigationHtml || "");

  return `<!DOCTYPE html>
<html lang="en" spellcheck="true">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="generator" content="Personal Knowledge Manager (VS Code)">
${browserFaviconTag(faviconHref)}
<title>${esc(title)}</title>
<style>
:root{color-scheme:light}
*{box-sizing:border-box}
body{margin:0;background:#f6f7f9;color:#1f2328;font:16px/1.7 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{width:calc(100% - clamp(32px,5vw,96px));margin:clamp(16px,2vw,32px) auto;background:#fff;border:1px solid #e2e5e9;border-radius:8px;padding:clamp(24px,3vw,48px);box-shadow:0 1px 3px rgba(0,0,0,.06)}
h1.doc-title{font-size:28px;line-height:1.25;margin:0 0 12px;color:#0b1220}
.meta{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:20px;padding-bottom:18px;border-bottom:1px solid #eceef1;font-size:12px}
.pill{padding:2px 9px;border-radius:20px;font-weight:600}
.pill.type{background:#eef2ff;color:#4f46e5}
.pill.cat{background:#ecfdf5;color:#059669}
.pill.tag{background:#f1f5f9;color:#475569}
.upd{color:#8a929c;margin-left:auto}
.details{display:grid;grid-template-columns:max-content 1fr;gap:4px 14px;margin:0 0 20px;font-size:13px}.details dt{color:#667085;font-weight:600}.details dd{margin:0;overflow-wrap:anywhere}
.prose{font-size:16px}
.prose h1,.prose h2,.prose h3,.prose h4{line-height:1.3;margin:1.5em 0 .5em;color:#0b1220;font-weight:650}
.prose h1{font-size:1.6em}.prose h2{font-size:1.35em;border-bottom:1px solid #eceef1;padding-bottom:.2em}.prose h3{font-size:1.15em}
.prose p{margin:.7em 0}
.prose a{color:#2563eb;text-decoration:none}.prose a:hover{text-decoration:underline}
.prose ul,.prose ol{padding-left:1.5em;margin:.6em 0}
.prose li{margin:.25em 0}
.prose img{max-width:100%;border-radius:6px;margin:.4em 0}
.prose li.tk{list-style:none;position:relative}
.prose li.tk>.tkm{display:inline-block;width:16px;height:16px;line-height:15px;text-align:center;border-radius:3px;font-size:11px;font-weight:700;margin:0 .5em 0 -1.5em;vertical-align:1px;box-sizing:border-box}
.prose li.tk-todo>.tkm{border:1.5px solid #9aa2ad;background:#fff}
.prose li.tk-done>.tkm{background:#2da44e;color:#fff;border:1.5px solid #2da44e}
.prose li.tk-prog>.tkm{background:#d29922;color:#3d2c00;border:1.5px solid #d29922}
.prose li.tk-block>.tkm{background:#e5484d;color:#fff;border:1.5px solid #e5484d}
.mermaid-diagram{margin:1em 0;text-align:center;overflow-x:auto}
.mermaid-diagram svg{max-width:100%;height:auto}
.mermaid-error{color:#b91c1c;font-size:.9em;text-align:left;white-space:pre-wrap;border:1px solid #f1a9a9;border-radius:6px;padding:8px}
.prose blockquote{border-left:4px solid #d0d7de;color:#57606a;margin:.9em 0;padding:.1em 1em}
.prose hr{border:none;border-top:1px solid #e2e5e9;margin:1.6em 0}
.prose table{border-collapse:collapse;width:100%;margin:1em 0;font-size:.95em}
.prose th,.prose td{border:1px solid #e2e5e9;padding:6px 10px}
.prose th{background:#f6f8fa;text-align:left}
.prose code{background:#f1f3f5;border-radius:4px;padding:.15em .4em;font-size:.88em;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.prose pre{background:#0d1117;color:#e6edf3;border-radius:8px;padding:16px;overflow:auto;margin:1em 0}
.prose pre code{background:none;padding:0;font-size:.86em;color:inherit}
.wikilink{color:#7c3aed;border-bottom:1px dashed #c4b5fd;font-weight:600}
/* highlight.js (github-dark subset) */
.hljs-comment,.hljs-quote{color:#8b949e}
.hljs-keyword,.hljs-selector-tag,.hljs-literal,.hljs-type{color:#ff7b72}
.hljs-string,.hljs-meta .hljs-string,.hljs-regexp,.hljs-addition{color:#a5d6ff}
.hljs-number,.hljs-symbol,.hljs-bullet{color:#79c0ff}
.hljs-title,.hljs-name,.hljs-section,.hljs-title.function_,.hljs-title.class_{color:#d2a8ff}
.hljs-built_in,.hljs-builtin-name,.hljs-attr,.hljs-attribute{color:#ffa657}
.hljs-variable,.hljs-template-variable,.hljs-params{color:#e6edf3}
.hljs-deletion{color:#ffa198}
.hljs-emphasis{font-style:italic}.hljs-strong{font-weight:700}
.math-block{overflow-x:auto;padding:4px 2px;margin:.6em 0}
.katex-display{margin:.5em 0}
@media(max-width:700px){.wrap{width:100%;margin:0;border-width:0;border-radius:0;padding:20px 16px;box-shadow:none}.upd{width:100%;margin-left:0}}
@media print{body{background:#fff}.wrap{border:none;box-shadow:none;margin:0;max-width:none}}
.reader-layout{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh;background:#fff}
.reader-layout .wrap{width:100%;min-width:0;margin:0;border:0;border-radius:0;box-shadow:none;overflow-wrap:anywhere}
.reader-sidebar{position:sticky;top:0;align-self:start;height:100vh;overflow-y:auto;background:#f6f7f9;border-right:1px solid #e2e5e9;padding:16px 12px;font-size:13px}
.reader-sidebar summary{padding:4px 8px;font-size:15px;font-weight:650;cursor:pointer}
.reader-search{position:fixed;top:12px;right:16px;z-index:1000;width:min(320px,calc(100vw - 32px));padding:8px;background:#fff;border:1px solid #cdd3da;border-radius:4px;box-shadow:0 3px 12px #0002}.reader-search[hidden]{display:none}.reader-search input{width:100%;padding:8px 10px;border:1px solid #cdd3da;border-radius:4px;background:#fff;font:inherit}
.reader-layout:has(.reader-sidebar > details:not([open])){grid-template-columns:40px minmax(0,1fr)}
.reader-sidebar:has(> details:not([open])){padding:12px 4px}
.reader-sidebar > details:not([open]) > summary{writing-mode:vertical-rl;white-space:nowrap}
.reader-nav-group h2{margin:12px 8px 6px;font-size:12px;color:#57606a}
.reader-nav-folder summary{font-size:13px;font-weight:500;overflow-wrap:anywhere}.reader-nav-children{margin-left:12px;padding-left:6px;border-left:1px solid #d8dee4}.reader-nav-folder[hidden]{display:none}
.reader-nav-item{display:block;margin:2px 0;padding:7px 8px;border-radius:4px;color:#24292f;text-decoration:none;overflow-wrap:anywhere;line-height:1.45}
.reader-nav-item span,.reader-nav-item small{display:block}.reader-nav-item small{font-size:11px;color:#667085}
.reader-nav-item:hover{background:#e9edf2}.reader-nav-item[aria-current=page]{background:#dcebed;color:#145b60;box-shadow:inset 3px 0 #287f85}
.reader-nav-item:focus-visible,.reader-sidebar summary:focus-visible{outline:2px solid #287f85;outline-offset:2px}.reader-nav-item[hidden],.reader-nav-group[hidden]{display:none}
.reader-nav-empty{margin:8px;color:#667085}
@media(max-width:700px){.reader-layout{grid-template-columns:140px minmax(0,1fr)}.reader-sidebar{padding:8px 6px}.reader-layout .wrap{padding:20px 12px}}
@media print{.reader-sidebar{display:none}.reader-layout{display:block}}
${katexCss}
${navigation ? (require("./ui/browser-navigation") as typeof import("./ui/browser-navigation")).browserNavigationStyles : ""}
</style>
</head>
<body>
${navigation ? `<div class="reader-layout">${navigation}` : ""}
<div class="wrap">
<h1 class="doc-title">${esc(title)}</h1>
<div class="meta">${metaBits}</div>
${details}
<div class="prose">${body}</div>
</div>
${navigation ? "</div>" : ""}
</body>
</html>`;
}

// Cache the self-contained KaTeX CSS (fonts inlined as data URIs) for HTML export.
let _katexCssCache: string | undefined;
function katexCssForExport(context: vscode.ExtensionContext): string {
  if (_katexCssCache !== undefined) return _katexCssCache;
  try {
    const distDir = path.join(context.extensionPath, "dist", "webview");
    const srcDir  = path.join(context.extensionPath, "src",  "webview");
    const dir = fs.existsSync(path.join(distDir, "katex.css")) ? distDir : srcDir;
    const cssPath = path.join(dir, "katex.css");
    const fontsDir = path.join(dir, "fonts");
    if (!fs.existsSync(cssPath) || !fs.existsSync(fontsDir)) { _katexCssCache = ""; return ""; }
    let css = fs.readFileSync(cssPath, "utf-8");
    // Inline woff2 fonts as data URIs; drop the woff/ttf fallbacks (unused by modern browsers).
    css = css.replace(/url\(fonts\/([^)]+\.woff2)\)/g, (m, file) => {
      try {
        const b64 = fs.readFileSync(path.join(fontsDir, file)).toString("base64");
        return `url(data:font/woff2;base64,${b64})`;
      } catch { return m; }
    });
    css = css.replace(/,url\(fonts\/[^)]*\)\s*format\("[^"]*"\)/g, "");
    _katexCssCache = css;
  } catch {
    _katexCssCache = "";
  }
  return _katexCssCache;
}

// ── Panel management ───────────────────────────────────────────────────────
const panels = new PanelRegistry<vscode.WebviewPanel>();
function panelSession() { return panels.current(); }
// Navigation follows the requesting instance, otherwise the last-focused tab. Shared events broadcast.
function activePanel() { const target = panelSession().panel; return target && panels.instances.has(target) ? target : undefined; }
let _treeProvider: PkTreeProvider | undefined;
const MACHINE_STORE_PATH_KEY = "machineStorePath.v1";
const ONBOARDING_PENDING_KEY = "pkm.onboarding.pending.v2";
const ONBOARDING_COMPLETED_KEY = "pkm.onboarding.completed.v2";
const TOUR_LAST_SEEN_RELEASE_KEY = "pkm.tours.lastSeenRelease.v1";
const TOUR_SEEN_MODULES_KEY = "pkm.tours.seenModules.v1";
const LEGACY_LAST_SHOWN_VERSION_KEY = "pkm.whatsNew.lastShownVersion.v1";

function directoryExists(candidate: string): boolean {
  try { return fs.existsSync(candidate) && fs.statSync(candidate).isDirectory(); }
  catch { return false; }
}

function localAbsolutePathError(candidate: string): string | undefined {
  const value = String(candidate || "").trim();
  if (!value) return "Path is required";
  if (!isAbsoluteForPlatform(value) || isForeignAbsolutePath(value)) return `Enter an absolute ${process.platform === "win32" ? "Windows" : process.platform === "darwin" ? "macOS" : "Linux"} path for this Extension Host`;
  return undefined;
}

function resolvedStorePath(context: vscode.ExtensionContext): ReturnType<typeof resolveMachineStorePath> {
  const binding = readAccountMcpBinding();
  if (binding) return resolveMachineStorePath({ machinePath: binding.knowledgeRoot }, directoryExists);
  return resolveMachineStorePath({
    machinePath: context.globalState.get<string>(MACHINE_STORE_PATH_KEY, ""),
    configuredPath: vscode.workspace.getConfiguration("personalKnowledge").inspect<string>("storePath")?.globalValue || "",
    previousPath: context.globalState.get<string>("lastStorePath", ""),
  }, directoryExists);
}

async function rememberMachineStorePath(context: vscode.ExtensionContext, storePath: string, allowReconfigure = false): Promise<void> {
  const owner = !allowReconfigure ? readAccountMcpBinding()?.registrationOwner : undefined;
  const nativeSupported = _nativeMcpProvider || (typeof (vscode as any).lm?.registerMcpServerDefinitionProvider === "function" && typeof (vscode as any).McpStdioServerDefinition === "function");
  await writeAccountMcpBinding(storePath, owner || (nativeSupported ? "native-provider" : "manual-user"), allowReconfigure);
  if (context.globalState.get<string>(MACHINE_STORE_PATH_KEY) !== storePath) await context.globalState.update(MACHINE_STORE_PATH_KEY, storePath);
  if (context.globalState.get<string>("lastStorePath") !== storePath) await context.globalState.update("lastStorePath", storePath);
  if (context.globalState.get<boolean>("setupComplete") !== true) await context.globalState.update("setupComplete", true);
  const configuration = vscode.workspace.getConfiguration("personalKnowledge");
  if (configuration.inspect<string>("storePath")?.globalValue?.trim() !== storePath) {
    await configuration.update("storePath", storePath, vscode.ConfigurationTarget.Global);
  }
}
let _storeReady = false;                       // file store configured & migrated
let _nativeMcpProvider = false;
let _mcpDefinitionsChanged: vscode.EventEmitter<void> | undefined;
let _mcpRegenerationPromptedFor = "";

function refreshMcpDefinitions(): void {
  mcpRuntimeStatusCache = undefined;
  _mcpDefinitionsChanged?.fire();
}

function mcpClientRegistrationStatus(): object {
  const binding = readAccountMcpBinding();
  let launch: ReturnType<typeof mcpServerDefinitionData>;
  try { launch = mcpServerDefinitionData(); }
  catch (error) {
    return {
      vscode: { configured: _nativeMcpProvider && binding?.registrationOwner === "native-provider", definitionAvailable: false, detail: `Native definition unavailable: ${error instanceof Error ? error.message : String(error)}` },
      copilot: { path: copilotMcpConfigPath(), state: "unavailable", detail: "Finish managed runtime setup before inspecting the matching CLI launch." },
      verification: "Not verified: client discovery, trust, connection, tool listing and an actual check_version call.",
    };
  }
  return {
    vscode: {
      configured: _nativeMcpProvider && binding?.registrationOwner === "native-provider",
      definitionAvailable: _nativeMcpProvider && !!getStorePath() && binding?.registrationOwner !== "manual-user",
      detail: binding?.registrationOwner === "manual-user" ? "Account-wide native registration is disabled for user/profile or workspace MCP configuration. Use Configure PKM MCP to review the scope. Check MCP: List Servers to verify pkm."
        : !_nativeMcpProvider ? "This VS Code host does not support the native MCP provider. Use Configure PKM MCP to choose user/profile or workspace configuration."
          : "A native definition is available on this extension host; this is not evidence that Copilot has discovered or enabled it.",
    },
    copilot: inspectCopilotMcpRegistration(copilotMcpDefinition(launch)),
    verification: "Not verified: client discovery, trust, connection, tool listing and an actual check_version call.",
  };
}

async function configureNativeMcpDiscovery(context: vscode.ExtensionContext): Promise<boolean> {
  if (!_nativeMcpProvider) throw new Error("This VS Code host does not support native MCP discovery. Upgrade VS Code; no manual registration was written.");
  if (!_storeReady || !getStorePath()) throw new Error("Configure this extension host's Knowledge Root first.");
  const knowledgeRoot = getStorePath();
  const launch = mcpServerDefinitionData();
  const configFiles = [
    vscode.Uri.joinPath(context.globalStorageUri, "..", "..", "mcp.json"),
    ...(vscode.workspace.workspaceFolders || []).map(folder => vscode.Uri.joinPath(folder.uri, ".vscode", "mcp.json")),
  ];
  const checkManualEntries = async () => {
    for (const uri of configFiles) {
      let text: Uint8Array;
      try { text = await vscode.workspace.fs.readFile(uri); }
      catch (error) {
        if (error instanceof vscode.FileSystemError && error.code === "FileNotFound") continue;
        throw new Error(`Cannot inspect ${uri.toString()}; native ownership was not changed.`);
      }
      let config: unknown;
      try { config = parseNativeMcpConfiguration(Buffer.from(text).toString("utf8")); }
      catch { throw new Error(`Cannot safely inspect ${uri.toString()}. Repair its MCP JSONC before retrying. No file was changed.`); }
      assertNoManualPkm(config, launch);
    }
    assertNoManualPkm({ servers: vscode.workspace.getConfiguration("mcp").get("servers") }, launch);
  };
  await checkManualEntries();
  const host = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const selected = await vscode.window.showInformationMessage(
    "Let PKM register its MCP server with VS Code automatically?",
    { modal: true, detail: `Recommended: click "Use Native Provider". PKM then appears as "pkm" in "MCP: List Servers" and PKM Chat can use its tools. If unsure, choose it.\n\n${host}\nKnowledge Root: ${getStorePath()}\n\nOnly ~/.pkm/mcp-binding.json changes. It does not create VS Code user/workspace MCP entries, install anything, start a server or grant trust. If you once added a "pkm" server by hand in another VS Code profile, remove that entry to avoid duplicates.` },
    "Use Native Provider",
  );
  if (selected !== "Use Native Provider") return false;
  if (getStorePath() !== knowledgeRoot) throw new Error("The Knowledge Root changed during review. Review native discovery setup again.");
  await checkManualEntries();
  await writeAccountMcpBinding(knowledgeRoot, "native-provider", true);
  refreshMcpDefinitions();
  void vscode.window.showInformationMessage("Native PKM definition configured, not yet client-verified. Run MCP: List Servers in this host, select pkm, review trust and start it; enable its tools in Copilot Agent and call check_version. Repeat in a second workspace.");
  return true;
}

let _mcpConfigurationOffered = false;
let _mcpConfigurationOffer: Promise<void> | undefined;

function offerPkmMcpConfiguration(context: vscode.ExtensionContext, reason: string): Promise<void> {
  if (_mcpConfigurationOffer) return _mcpConfigurationOffer;
  if (_mcpConfigurationOffered) return Promise.resolve();
  _mcpConfigurationOffered = true;
  _mcpConfigurationOffer = (async () => {
    const choice = await vscode.window.showWarningMessage(
      `PKM MCP tools are unavailable. Chat cannot use PKM MCP tools until this is fixed. ${reason.slice(0, 400)}`,
      "Configure MCP", "Not now",
    );
    if (choice === "Configure MCP") await configurePkmMcp(context);
  })().finally(() => { _mcpConfigurationOffer = undefined; });
  return _mcpConfigurationOffer;
}

async function configurePkmMcp(context: vscode.ExtensionContext): Promise<boolean> {
  const scope = await vscode.window.showQuickPick([
    { label: "This machine's account (recommended)", description: "All workspaces on this host account; PKM manages registration.", id: "account" },
    { label: "VS Code user / profile", description: "Only this VS Code profile's MCP configuration.", id: "profile" },
    ...(vscode.workspace.workspaceFolders?.length ? [{ label: "Workspace folder", description: "Only the selected folder; writes .vscode/mcp.json (may be shared by Git).", id: "workspace" }] : []),
    { label: "Do not configure", description: "Leave configuration unchanged. Chat continues without PKM MCP tools.", id: "none" },
  ], { title: "Where should PKM MCP be available?", placeHolder: extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || ""), ignoreFocusOut: true });
  if (!scope || scope.id === "none") return false;
  if (vscode.workspace.isTrusted === false) throw new Error("Trust this workspace before configuring PKM MCP.");
  if (scope.id === "account") return configureNativeMcpDiscovery(context);
  if (!_storeReady || !getStorePath()) throw new Error("Configure the Knowledge Root and repair the managed MCP runtime in PKM Config first.");
  const knowledgeRoot = getStorePath(), launch = mcpServerDefinitionData();
  let uri = vscode.Uri.joinPath(context.globalStorageUri, "..", "..", "mcp.json");
  if (scope.id === "workspace") {
    const folders = vscode.workspace.workspaceFolders || [];
    const folder = folders.length === 1 ? folders[0] : await vscode.window.showQuickPick(folders.map(folder => ({ label: folder.name, folder })), { title: "Choose the workspace folder for PKM MCP" }).then(choice => choice?.folder);
    if (!folder) return false;
    uri = vscode.Uri.joinPath(folder.uri, ".vscode", "mcp.json");
  }
  const filename = uri.fsPath;
  const assertClean = () => {
    if (vscode.workspace.textDocuments.some(document => document.uri.toString() === uri.toString() && document.isDirty)) throw new Error("Save or discard unsaved MCP configuration edits before configuring PKM.");
  };
  assertClean();
  // Do not leave an equivalent registration enabled at another scope.
  const checkOtherScopes = async () => {
    for (const other of [vscode.Uri.joinPath(context.globalStorageUri, "..", "..", "mcp.json"), ...(vscode.workspace.workspaceFolders || []).map(folder => vscode.Uri.joinPath(folder.uri, ".vscode", "mcp.json"))]) {
      if (other.toString() === uri.toString()) continue;
      try { assertNoManualPkm(parseNativeMcpConfiguration(await fs.promises.readFile(other.fsPath, "utf8")), launch); }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
    }
  };
  await checkOtherScopes();
  const reviewed = inspectVscodeMcpRegistration(filename, launch);
  const binding = readAccountMcpBinding();
  if (!binding) throw new Error("Finish PKM account setup in Config before adding a scoped MCP registration.");
  const choice = await vscode.window.showInformationMessage("Configure PKM MCP here?", {
    modal: true, detail: `${filename}\n\nAdds only servers.pkm, preserving other entries and JSONC comments. An existing file is backed up. Account-wide native registration is disabled to avoid duplicates. VS Code may ask for trust before starting the server.\n\nKnowledge Root: ${knowledgeRoot}`,
  }, "Configure MCP");
  if (choice !== "Configure MCP") return false;
  assertClean();
  await checkOtherScopes();
  if (getStorePath() !== knowledgeRoot || JSON.stringify(mcpServerDefinitionData()) !== JSON.stringify(launch)
    || JSON.stringify(readAccountMcpBinding()) !== JSON.stringify(binding)) throw new Error("PKM setup changed during review. Review and confirm again; no configuration was changed.");
  await writeAccountMcpBinding(knowledgeRoot, "manual-user", true);
  try { await registerVscodeMcp(filename, launch, reviewed.revision); }
  catch (error) {
    if (binding) await writeAccountMcpBinding(binding.knowledgeRoot, binding.registrationOwner, true);
    throw error;
  } finally { refreshMcpDefinitions(); }
  void vscode.window.showInformationMessage(`PKM MCP configured in ${filename}. Run MCP: List Servers, choose pkm and review trust to start it. Tools are not verified until the server connects.`);
  return true;
}

async function registerCopilotMcpUserConfig(): Promise<boolean> {
  if (!_storeReady || !getStorePath()) throw new Error("Configure this extension host's Knowledge Root first.");
  const launch = mcpServerDefinitionData();
  if (!mcpStatus().installed) throw new Error("Generate the managed MCP server before registering Copilot CLI.");
  const definition = copilotMcpDefinition(launch);
  const reviewed = inspectCopilotMcpRegistration(definition);
  if (reviewed.state === "invalid" || reviewed.state === "conflict") throw new Error(reviewed.detail);
  if (reviewed.state === "matching") {
    void vscode.window.showInformationMessage(`${reviewed.detail} Run copilot mcp list and copilot mcp get pkm in this account, then verify check_version in a new chat.`);
    return true;
  }
  const host = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const selected = await vscode.window.showInformationMessage(
    "Register PKM in this host account's Copilot CLI user configuration?",
    { modal: true, detail: `${host}\n${reviewed.path}\nKnowledge Root: ${getStorePath()}\nCommand: ${launch.command}\nArguments: ${JSON.stringify(launch.args)}\nEnvironment: ${JSON.stringify(launch.env || {})}\n\nAdds only mcpServers.pkm (type local, tools ["*"]). Existing configuration is backed up beside the file; unrelated entries are preserved and conflicting entries are rejected. No project configuration, VS Code registration, server startup or trust approval is performed. A running CLI may notice this configuration; its normal consent rules still apply. In Remote SSH this does not register the local Windows account. Custom CLI --config-dir settings and clients already inheriting pkm must be reviewed separately.` },
    "Register User Configuration",
  );
  if (selected !== "Register User Configuration") return false;
  const currentLaunch = mcpServerDefinitionData();
  if (JSON.stringify(copilotMcpDefinition(currentLaunch)) !== JSON.stringify(definition)) throw new Error("The managed MCP launch changed during review. Review CLI registration again.");
  const result = await registerCopilotMcp(definition, reviewed.revision!);
  void vscode.window.showInformationMessage(`Copilot CLI user configuration ${result.changed ? "written" : "already matches"}.${result.backup ? ` Backup: ${result.backup}.` : ""} Discovery is not yet verified: run copilot mcp list and copilot mcp get pkm on this host, then start a new CLI chat and call check_version.`);
  return true;
}

function registerNativeMcpProvider(context: vscode.ExtensionContext): void {
  const api = vscode as any;
  if (typeof api.lm?.registerMcpServerDefinitionProvider !== "function" || typeof api.McpStdioServerDefinition !== "function") return;
  const changed = new vscode.EventEmitter<void>();
  _mcpDefinitionsChanged = changed;
  const createDefinition = () => {
    const data = mcpServerDefinitionData(true);
    const definition = new api.McpStdioServerDefinition(data.label, data.command, data.args, data.env || {}, data.version);
    definition.cwd = nativeMcpCwdUri(context.extensionUri, data.cwd, vscode.Uri.file);
    return definition;
  };
  const provider = {
    onDidChangeMcpServerDefinitions: changed.event,
    provideMcpServerDefinitions: () => {
      try {
        if (!getStorePath() || readAccountMcpBinding()?.registrationOwner === "manual-user") return [];
        return [createDefinition()];
      } catch (error) {
        log.warn(`PKM MCP definition unavailable: ${error instanceof Error ? error.message : String(error)}`);
        void offerPkmMcpConfiguration(context, error instanceof Error ? error.message : String(error)).catch(error => log.warn(`PKM MCP configuration failed: ${error instanceof Error ? error.message : String(error)}`));
        return [];
      }
    },
    resolveMcpServerDefinition: () => {
      const binding = readAccountMcpBinding();
      if (binding && (binding.registrationOwner !== "native-provider" || binding.knowledgeRoot !== fs.realpathSync(getStorePath()))) {
        throw new Error("PKM MCP binding changed or belongs to a manual adapter. Use explicit account setup; this window cannot adopt another binding.");
      }
      return createDefinition();
    },
  };
  context.subscriptions.push(changed, api.lm.registerMcpServerDefinitionProvider("personalKnowledge.pkm", provider));
  context.subscriptions.push(vscode.commands.registerCommand("personalKnowledge.startPkmMcp", async () => {
    if (vscode.workspace.isTrusted === false) throw new Error("PKM MCP requires a trusted workspace.");
    const runtime = mcpRuntimeStatus();
    if (!getStorePath() || !runtime.healthy || !mcpStatus().installed) throw new Error("PKM MCP is not ready. Check or repair its runtime in Config.");
    refreshMcpDefinitions();
    await new Promise<void>(resolve => setImmediate(resolve));
    await vscode.commands.executeCommand("workbench.mcp.startServer", "uone.personal-knowledge/pkm", { waitForLiveTools: true });
  }));
  _nativeMcpProvider = true;
}

/** Open an item in the panel; queues it if the webview isn't ready yet. */
function openInPanel(context: vscode.ExtensionContext, type: string, key: string, edit = false, tab?: string): void {
  const p = getOrCreatePanel(context);
  p.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) {
    p.webview.postMessage({ command: "openItem", type, key, edit, tab });
  } else {
    panelSession().pendingOpen = { type, key, edit, tab }; // flushed on the "ready" message
  }
}

function quickOpenSubscriptionGroups() {
  const market = getSharedMarket();
  return SHARED_CONTENT_TYPES.flatMap(type => market.cachedGroups(type, "", Number.MAX_SAFE_INTEGER));
}

async function openResolvedPkmLocator(context: vscode.ExtensionContext, target: ResolvedPkmLocator): Promise<void> {
  if (target.kind === "chat") {
    await vscode.commands.executeCommand("personalKnowledge.openApiChat", target.locator);
  } else if (target.kind === "panel") {
    openInPanel(context, target.type, target.key, false, target.tab);
  } else if (target.kind === "recipe") {
    if (!(await openRecipeEditorInBrowser(target.recipeId))) {
      throw new Error(`Could not open Recipe: ${target.title}`);
    }
  } else if (target.kind === "entity") {
    if (target.area === "projects") openProjectCockpit(context, target.id);
    else openActionWorkbench(context, undefined, target.id);
  } else {
    await vscode.commands.executeCommand("personalKnowledge.openSubscribedServer", target.key);
  }
  vscode.window.setStatusBarMessage(`$(go-to-file) Opened ${target.title}`, 3000);
}

async function goToPkmPath(context: vscode.ExtensionContext, provided?: string): Promise<void> {
  if (!(await ensureSetup(context))) return;
  let value = String(provided || "").trim();
  if (!value) {
    const clipboard = (await vscode.env.clipboard.readText()).trim();
    const initial = /^`?pkm:\/\//i.test(clipboard) ? clipboard : "";
    const entered = await vscode.window.showInputBox({
      title: "Go to PKM Path",
      prompt: "Paste a PKM path from an Agent response or Copy Path.",
      placeHolder: "pkm://knowledge/knowledge_ee2a7651bc4adc35bbf81ef7",
      value: initial,
      valueSelection: initial ? [0, initial.length] : undefined,
      ignoreFocusOut: true,
      validateInput: candidate => {
        try { parsePkmLocator(candidate); return undefined; }
        catch (error) { return error instanceof Error ? error.message : String(error); }
      },
    });
    if (entered === undefined) return;
    value = entered;
  }
  let parsed;
  try { parsed = parsePkmLocator(value); }
  catch (error) {
    vscode.window.showErrorMessage(`Go to PKM Path failed: ${error instanceof Error ? error.message : String(error)}`);
    return;
  }
  let subscriptionGroups: ReturnType<typeof quickOpenSubscriptionGroups> = [];
  try {
    subscriptionGroups = parsed.kind === "subscription" ? quickOpenSubscriptionGroups() : [];
  } catch (error) {
    vscode.window.showErrorMessage(`Go to PKM Path failed: ${error instanceof Error ? error.message : String(error)}`);
    return;
  }
  const entityInventory: { area: string; relativePath: string; slug: string; title: string; knowledgeId?: string }[] = [];
  try {
  if (parsed.kind === "entity" && parsed.area === "projects") {
    for (const project of currentProjectStore().list().projects) {
      entityInventory.push({ area: "projects", relativePath: project.projectId, slug: project.projectId, title: project.name });
    }
  } else if (parsed.kind === "entity" || parsed.kind === "knowledge" && parsed.knowledgeId.startsWith("action_")) {
    const catalog = await actionRequest(context, "catalog", {});
    for (const action of (catalog.actions || []) as { action_id: string; display_name?: string; knowledgeId?: string; source_id?: string }[]) {
      entityInventory.push({ area: action.source_id?.startsWith("pkm://components/") ? "components" : "actions",
        relativePath: action.action_id, slug: action.action_id, title: action.display_name || action.action_id, knowledgeId: action.knowledgeId });
    }
    if (parsed.kind === "entity" && parsed.area === "actions"
      && !entityInventory.some(entry => entry.area === "actions" && entry.slug === parsed.id)) {
      // Legacy platform Actions already have a logical provider but no editable
      // module file. Read that provider's contract; do not invent an executor.
      const result = await actionRequest(context, "locator_read", { reference: parsed.locator });
      const document = await vscode.workspace.openTextDocument({ language: "json", content: JSON.stringify(result.definition, null, 2) });
      await vscode.window.showTextDocument(document, { preview: true });
      return;
    }
  } else if (parsed.kind === "package-file") {
    const slash = parsed.path.indexOf("/");
    const file = packageFileGet(parsed.path.slice(0, slash), parsed.path.slice(slash + 1));
    if (file) entityInventory.push({ area: "packages", relativePath: parsed.path, slug: parsed.path, title: file.file });
  }
  } catch (error) {
    vscode.window.showErrorMessage(`Go to PKM Path failed (${parsed.locator}): ${error instanceof Error ? error.message : String(error)}`);
    return;
  }
  const resolve = () => {
    const inventory = knowledgeInventory?.entries() || [];
    if (parsed.kind === "script" || parsed.kind === "script-path") {
      const script = scriptGet(parsed.locator);
      if (!script) throw new PkmLocatorError("not-found", `Script was not found: ${parsed.locator}`);
      return resolvePkmLocator(value, [{
        area: "scripts", relativePath: script.path, slug: script.path, title: script.file,
        knowledgeId: script.knowledgeId, aliases: script.aliases,
      }], subscriptionGroups);
    }
    return resolvePkmLocator(value, [...inventory, ...entityInventory], subscriptionGroups);
  };
  let target: ResolvedPkmLocator;
  try {
    target = resolve();
  } catch (error) {
    if (error instanceof PkmLocatorError && error.code === "not-found" && parsed.kind !== "subscription") {
      await refreshKnowledgeInventory(context);
      try { target = resolve(); }
      catch (retryError) {
        vscode.window.showErrorMessage(`Go to PKM Path failed: ${retryError instanceof Error ? retryError.message : String(retryError)}`);
        return;
      }
    } else {
      vscode.window.showErrorMessage(`Go to PKM Path failed: ${error instanceof Error ? error.message : String(error)}`);
      return;
    }
  }
  try { await openResolvedPkmLocator(context, target); }
  catch (error) {
    vscode.window.showErrorMessage(`Go to PKM Path failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

function knowledgeContentUri(area: KnowledgeMarkdownArea, key: string): vscode.Uri {
  return vscode.Uri.from({ scheme: "pkm-content", authority: area, path: `/${key}.md` });
}

async function openStoreMarkdown(area: KnowledgeMarkdownArea, key: string): Promise<void> {
  if (area === "notes" && noteGet(key)?.documentKind === "todo-board") {
    if (!chatCtx) throw new Error("PKM is not initialized.");
    openInPanel(chatCtx, "note", key);
    return;
  }
  const doc = await vscode.workspace.openTextDocument(knowledgeContentUri(area, key));
  await vscode.window.showTextDocument(doc, { preview: false });
}

async function closeNavigationSidebar(): Promise<void> {
  await vscode.commands.executeCommand("workbench.action.closeSidebar");
}

function openChatroomPanel(context: vscode.ExtensionContext): void {
  const chatPanel = getOrCreatePanel(context);
  chatPanel.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) chatPanel.webview.postMessage({ command: "openTab", tab: "chatroom" });
  else panelSession().pendingTab = "chatroom";
}

function openPanelTab(context: vscode.ExtensionContext, tab: string): void {
  const target = getOrCreatePanel(context);
  target.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) target.webview.postMessage({ command: "openTab", tab });
  else panelSession().pendingTab = tab;
}

function openProjectCockpit(context: vscode.ExtensionContext, projectId: string): void {
  openPanelTab(context, "projects");
  if (panelSession().ready) void activePanel()?.webview.postMessage({ command: "openProject", projectId });
  else panelSession().pendingProjectId = projectId;
}

function openServerPanel(context: vscode.ExtensionContext, slug = ""): void {
  const target = getOrCreatePanel(context);
  target.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) target.webview.postMessage({ command: "focusServer", slug });
  else {
    panelSession().pendingTab = "servers";
    panelSession().pendingServerSlug = slug;
  }
}

function openEnvironmentPanel(context: vscode.ExtensionContext, environmentId = ""): void {
  const target = getOrCreatePanel(context);
  target.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) target.webview.postMessage({ command: "focusEnvironment", environmentId });
  else {
    panelSession().pendingTab = "environments";
    panelSession().pendingEnvironmentId = environmentId;
  }
}

function openSubscriptionPanel(context: vscode.ExtensionContext, shareId = ""): void {
  const target = getOrCreatePanel(context);
  target.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) target.webview.postMessage({ command: "openSubscription", shareId });
  else {
    panelSession().pendingTab = "subscriptions";
    panelSession().pendingSubscriptionShare = shareId;
  }
}

type KnowledgeMarkdownArea = "skills" | "notes" | "papers";

function knowledgeMarkdownInfo(uri: vscode.Uri): { area: KnowledgeMarkdownArea; key: string; category: string } | undefined {
  if (uri.scheme === "pkm-content" && ["skills", "notes", "papers"].includes(uri.authority)) {
    const key = uri.path.replace(/^\//, "").replace(/\.md$/i, "");
    const category = key.includes("/") ? key.slice(0, key.lastIndexOf("/")) : "";
    return { area: uri.authority as KnowledgeMarkdownArea, key, category };
  }
  if (uri.scheme !== "file" || path.extname(uri.fsPath).toLowerCase() !== ".md") return undefined;
  const store = path.resolve(getStorePath());
  const rel = path.relative(store, path.resolve(uri.fsPath)).split(path.sep).join("/");
  if (rel.startsWith("../") || path.isAbsolute(rel)) return undefined;
  const match = /^(skills|notes|papers)\/(.+)\.md$/i.exec(rel);
  if (!match) return undefined;
  const area = match[1].toLowerCase() as KnowledgeMarkdownArea;
  const key = match[2];
  const category = key.includes("/") ? key.slice(0, key.lastIndexOf("/")) : "";
  return { area, key, category };
}

class KnowledgeMetadataCodeLensProvider implements vscode.CodeLensProvider {
  provideCodeLenses(document: vscode.TextDocument): vscode.CodeLens[] {
    const info = knowledgeMarkdownInfo(document.uri);
    if (!info) return [];
    const range = new vscode.Range(0, 0, 0, 0);
    return [
      new vscode.CodeLens(range, { command: "personalKnowledge.editMarkdownContent", title: "$(edit) Edit Content", arguments: [info.area, info.key] }),
      new vscode.CodeLens(range, { command: "personalKnowledge.editMarkdownMetadata", title: "$(settings-gear) Edit Metadata", arguments: [document.uri] }),
    ];
  }
}

class KnowledgeContentFileSystem implements vscode.FileSystemProvider {
  private readonly changed = new vscode.EventEmitter<vscode.FileChangeEvent[]>();
  readonly onDidChangeFile = this.changed.event;
  watch(): vscode.Disposable { return new vscode.Disposable(() => undefined); }
  stat(uri: vscode.Uri): vscode.FileStat {
    const info = knowledgeMarkdownInfo(uri);
    if (!info || !this.get(info)) throw vscode.FileSystemError.FileNotFound(uri);
    return { type: vscode.FileType.File, ctime: 0, mtime: Date.now(), size: Buffer.byteLength(this.get(info).content || "") };
  }
  readDirectory(): [string, vscode.FileType][] { return []; }
  createDirectory(): void { throw vscode.FileSystemError.NoPermissions("Directories are not supported."); }
  readFile(uri: vscode.Uri): Uint8Array {
    const info = knowledgeMarkdownInfo(uri);
    const item = info && this.get(info);
    if (!info || !item) throw vscode.FileSystemError.FileNotFound(uri);
    return Buffer.from(item.content || "", "utf8");
  }
  writeFile(uri: vscode.Uri, content: Uint8Array): void {
    const info = knowledgeMarkdownInfo(uri);
    const item = info && this.get(info);
    if (!info || !item) throw vscode.FileSystemError.FileNotFound(uri);
    const body = Buffer.from(content).toString("utf8");
    if (info.area === "skills") skillUpsert({ ...item, name: item.name, content: body, tags: JSON.parse(item.tags || "[]") });
    else if (info.area === "notes") noteUpsert({ ...item, slug: item.slug, content: body, tags: JSON.parse(item.tags || "[]") });
    else paperUpsert({ ...item, slug: item.slug, content: body });
    gitCommit(`edit(content): ${info.area}/${info.key}`);
    this.changed.fire([{ type: vscode.FileChangeType.Changed, uri }]);
    _treeProvider?.refresh();
    postToPanel({ command: "reloaded" });
  }
  delete(): void { throw vscode.FileSystemError.NoPermissions("Delete from the Knowledge tree instead."); }
  rename(): void { throw vscode.FileSystemError.NoPermissions("Rename with Edit Metadata instead."); }
  private get(info: { area: KnowledgeMarkdownArea; key: string }): any {
    if (info.area === "skills") {
      const listed = (skillList() as any[]).find(item => (item.category ? `${item.category}/${item.name}` : item.name) === info.key);
      return listed ? skillGet(listed.name) : undefined;
    }
    return info.area === "notes" ? noteGet(info.key) : paperGet(info.key);
  }
}

class RecipeDraftFileSystem implements vscode.FileSystemProvider {
  private readonly changed = new vscode.EventEmitter<vscode.FileChangeEvent[]>();
  private readonly content = new Map<string, Uint8Array>();
  readonly onDidChangeFile = this.changed.event;
  watch(): vscode.Disposable { return new vscode.Disposable(() => undefined); }
  stat(uri: vscode.Uri): vscode.FileStat {
    const content = this.content.get(uri.toString());
    if (!content) throw vscode.FileSystemError.FileNotFound(uri);
    return { type: vscode.FileType.File, ctime: 0, mtime: Date.now(), size: content.byteLength };
  }
  readDirectory(): [string, vscode.FileType][] { return []; }
  createDirectory(): void { throw vscode.FileSystemError.NoPermissions("Directories are not supported."); }
  readFile(uri: vscode.Uri): Uint8Array {
    const content = this.content.get(uri.toString());
    if (!content) throw vscode.FileSystemError.FileNotFound(uri);
    return content;
  }
  writeFile(uri: vscode.Uri, content: Uint8Array): void {
    if (!this.content.has(uri.toString())) throw vscode.FileSystemError.FileNotFound(uri);
    const next = Uint8Array.from(content);
    this.content.set(uri.toString(), next);
    this.changed.fire([{ type: vscode.FileChangeType.Changed, uri }]);
    activePanel()?.webview.postMessage({ command: "recipeIntentEdited", data: {
      recipeId: uri.authority,
      nodeId: uri.path.replace(/^\//, "").replace(/\.md$/i, ""),
      guidance: Buffer.from(next).toString("utf8")
    } });
  }
  delete(): void { throw vscode.FileSystemError.NoPermissions("Recipe drafts are removed with their editor session."); }
  rename(): void { throw vscode.FileSystemError.NoPermissions("Recipe draft documents cannot be renamed."); }
  seed(uri: vscode.Uri, content: string): void {
    this.content.set(uri.toString(), Buffer.from(content, "utf8"));
    this.changed.fire([{ type: vscode.FileChangeType.Changed, uri }]);
  }
}

let recipeDraftFileSystem: RecipeDraftFileSystem | undefined;

async function openRecipeIntentEditor(recipeId: string, nodeId: string, guidance: string): Promise<void> {
  if (!/^[A-Za-z][A-Za-z0-9._-]{0,127}$/.test(recipeId) || !/^[A-Za-z][A-Za-z0-9._-]{0,127}$/.test(nodeId)) {
    throw new Error("Recipe or Step identity is invalid.");
  }
  const uri = vscode.Uri.from({ scheme: "pkm-recipe-draft", authority: recipeId, path: `/${nodeId}.md` });
  const open = vscode.workspace.textDocuments.find(document => document.uri.toString() === uri.toString());
  if (!open?.isDirty) recipeDraftFileSystem?.seed(uri, guidance);
  const document = open || await vscode.workspace.openTextDocument(uri);
  await vscode.window.showTextDocument(document, { preview: false });
}

async function editMarkdownMetadata(uri?: vscode.Uri): Promise<void> {
  const document = uri ? vscode.workspace.textDocuments.find(d => d.uri.toString() === uri.toString())
    ?? await vscode.workspace.openTextDocument(uri) : vscode.window.activeTextEditor?.document;
  if (!document) return;
  const info = knowledgeMarkdownInfo(document.uri);
  if (!info) { vscode.window.showInformationMessage("This is not a Personal Knowledge Manager Markdown file."); return; }
  if (document.isDirty && !(await document.save())) return;

  let current: any;
  if (info.area === "skills") {
    const listed = (skillList() as any[]).find(s => {
      const key = s.category ? `${s.category}/${s.name}` : s.name;
      return key === info.key;
    });
    current = skillGet(listed?.name || path.basename(info.key));
  } else if (info.area === "notes") current = noteGet(info.key);
  else current = paperGet(info.key);
  if (!current) { vscode.window.showWarningMessage("Knowledge metadata could not be read from disk."); return; }

  const oldTitle = info.area === "skills" ? current.name : current.title;
  const title = await vscode.window.showInputBox({
    title: "Edit Knowledge Metadata (1/4)", prompt: info.area === "skills" ? "Name" : "Title", value: oldTitle,
    validateInput: value => !value.trim() ? "Title is required" : /[\\/]/.test(value) ? "Title cannot contain slashes" : null,
  });
  if (title === undefined) return;
  const description = await vscode.window.showInputBox({
    title: "Edit Knowledge Metadata (2/4)", prompt: "Description", value: current.description || "",
  });
  if (description === undefined) return;
  const oldTags = Array.isArray(current.tags) ? current.tags : JSON.parse(current.tags || "[]");
  const tagsText = await vscode.window.showInputBox({
    title: "Edit Knowledge Metadata (3/4)", prompt: "Tags (comma-separated)", value: oldTags.join(", "),
  });
  if (tagsText === undefined) return;
  const category = await selectKnowledgeFolder(info.area, info.category);
  if (category === undefined) return;
  const cleanTitle = title.trim();
  const cleanCategory = category.split(/[\\/]/).map(part => part.trim()).filter(Boolean).join("/");
  const tags = tagsText.split(",").map(tag => tag.trim()).filter(Boolean);

  if (info.area === "skills") {
    const collision = skillGet(cleanTitle);
    const safeTitle = storeSafeName(cleanTitle);
    const destinationKey = cleanCategory ? `${cleanCategory}/${safeTitle}` : safeTitle;
    const destinationExists = destinationKey !== info.key && fs.existsSync(path.join(getStorePath(), "skills", `${destinationKey}.md`));
    if ((cleanTitle !== current.name && collision) || destinationExists) {
      vscode.window.showWarningMessage(`A skill file already exists at "${destinationKey}.md". No files were changed.`);
      return;
    }
    skillUpsert({
      name: cleanTitle, content: current.content, category: cleanCategory,
      description: description.trim(), tags, source_project: current.source_project,
    });
    if (cleanTitle !== current.name) skillDelete(current.name);
  } else if (info.area === "notes") {
    const safeTitle = storeSafeName(cleanTitle);
    const newKey = cleanCategory ? `${cleanCategory}/${safeTitle}` : safeTitle;
    if (newKey !== current.slug && noteGet(newKey)) { vscode.window.showWarningMessage(`Note already exists: ${newKey}`); return; }
    noteUpsert({
      slug: current.slug, title: cleanTitle, content: current.content, type: current.type,
      tags, category: cleanCategory, pinned: current.pinned, description: description.trim(),
    });
  } else {
    const safeTitle = storeSafeName(cleanTitle);
    const newKey = cleanCategory ? `${cleanCategory}/${safeTitle}` : safeTitle;
    if (newKey !== current.slug && paperGet(newKey)) { vscode.window.showWarningMessage(`Paper or idea already exists: ${newKey}`); return; }
    paperUpsert({ ...current, slug: current.slug, title: cleanTitle, description: description.trim(), tags, category: cleanCategory });
  }

  const safeTitle = storeSafeName(cleanTitle);
  const newKey = cleanCategory ? `${cleanCategory}/${safeTitle}` : safeTitle;
  gitCommit(`metadata(${info.area}): ${info.key} -> ${newKey}`);
  _treeProvider?.refresh();
  postToPanel({ command: "reloaded" });
  const newUri = knowledgeContentUri(info.area, newKey);
  const newDocument = await vscode.workspace.openTextDocument(newUri);
  await vscode.window.showTextDocument(newDocument, { preview: false });
  vscode.window.setStatusBarMessage("$(check) Knowledge metadata updated", 3000);
}

function categoryFromTreeItem(item?: PkTreeItem): string {
  return (item?.nodeData?.path ?? []).filter((segment: string) => segment !== "(uncategorized)").join("/");
}

type NavigationGroupArea = "skills" | "notes" | "papers" | "prompts" | "scripts";
interface NavigationGroupInfo { area: NavigationGroupArea; path: string; maxDepth?: number; }

function navigationGroupInfo(item?: PkTreeItem): NavigationGroupInfo | undefined {
  if (!item) return undefined;
  const roots: Partial<Record<PkNodeType, NavigationGroupArea>> = {
    "root-skills": "skills", "root-notes": "notes", "root-papers": "papers", "root-prompts": "prompts", "root-scripts": "scripts",
  };
  const rootArea = roots[item.nodeType];
  if (rootArea) return { area: rootArea, path: "", maxDepth: rootArea === "prompts" ? 3 : undefined };
  if (item.nodeType === "skill-folder" || item.nodeType === "note-folder" || item.nodeType === "paper-folder" || item.nodeType === "script-folder") {
    const areaByFolder: Record<string, NavigationGroupArea> = { "skill-folder": "skills", "note-folder": "notes", "paper-folder": "papers", "script-folder": "scripts" };
    const area = areaByFolder[item.nodeType];
    const relPath = String(item.nodeData.relPath || "");
    if (relPath === "(uncategorized)") return { area, path: "" };
    if (!relPath) return undefined;
    return { area, path: relPath };
  }
  if (item.nodeType === "prompt-project") return { area: "prompts", path: item.nodeData.project, maxDepth: 3 };
  if (item.nodeType === "prompt-task") return { area: "prompts", path: `${item.nodeData.project}/${item.nodeData.task}`, maxDepth: 3 };
  if (item.nodeType === "prompt-version") return { area: "prompts", path: `${item.nodeData.project}/${item.nodeData.task}/${item.nodeData.version}`, maxDepth: 3 };
  return undefined;
}

function normalizedSubgroupPath(value: string): string | undefined {
  const parts = String(value || "").split(/[\\/]/).map(part => part.trim()).filter(Boolean);
  if (!parts.length || parts.some(part => part === "." || part === ".." || /[<>:"|?*\u0000-\u001f]/.test(part))) return undefined;
  return parts.join("/");
}

function refreshKnowledgeGroups(): void {
  _treeProvider?.refresh();
  postToPanel({ command: "reloaded" });
}

type KnowledgeFolderArea = "skills" | "notes" | "papers" | "scripts";
type KnowledgeFolderPick = vscode.QuickPickItem & { action: "select" | "parent" | "child" | "create" | "type"; name?: string };

async function selectKnowledgeFolder(area: KnowledgeFolderArea, initial = ""): Promise<string | undefined> {
  let current = initial.replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  while (true) {
    const prefix = current ? `${current}/` : "";
    const children = [...new Set(folderList(area)
      .filter(folder => folder.startsWith(prefix))
      .map(folder => folder.slice(prefix.length).split("/")[0])
      .filter(Boolean))].sort((left, right) => left.localeCompare(right));
    const choices: KnowledgeFolderPick[] = [
      { label: "$(check) Select this folder", description: current || "Root", action: "select" },
    ];
    if (current) choices.push({ label: "$(arrow-left) Parent folder", description: current.slice(0, current.lastIndexOf("/")) || "Root", action: "parent" });
    for (const name of children) choices.push({ label: `$(folder) ${name}`, description: prefix + name, action: "child", name });
    choices.push(
      { label: "$(new-folder) New subfolder...", description: current || "Root", action: "create" },
      { label: "$(keyboard) Type a path...", description: "Enter a slash-separated path", action: "type" },
    );
    const picked = await vscode.window.showQuickPick(choices, {
      title: `Choose ${area === "papers" ? "Paper / Idea" : area[0].toUpperCase() + area.slice(1)} folder`,
      placeHolder: current ? `Current: ${current}` : "Current: Root",
    });
    if (!picked) return undefined;
    if (picked.action === "select") return current;
    if (picked.action === "parent") {
      current = current.includes("/") ? current.slice(0, current.lastIndexOf("/")) : "";
    } else if (picked.action === "child") {
      current = prefix + picked.name!;
    } else if (picked.action === "create") {
      const name = await vscode.window.showInputBox({
        title: "New subfolder", prompt: `Create inside ${current || "Root"}`,
        validateInput: value => !value.trim() ? "Folder name is required" : /[\\/]/.test(value) || value.trim() === "." || value.trim() === ".." ? "Enter one folder name" : null,
      });
      if (name === undefined) continue;
      const next = prefix + name.trim();
      if (!folderCreate(area, next)) { vscode.window.showErrorMessage(`Could not create folder: ${next}`); continue; }
      gitCommit(`add(folder): ${area}/${next}`);
      _treeProvider?.refresh();
      current = next;
    } else {
      const typed = await vscode.window.showInputBox({
        title: "Type folder path", prompt: "Slash-separated path; leave blank for Root", value: current,
        validateInput: value => value.split(/[\\/]/).some(part => part.trim() === "." || part.trim() === "..") ? "Path cannot contain '.' or '..'" : null,
      });
      if (typed === undefined) continue;
      const clean = typed.split(/[\\/]/).map(part => part.trim()).filter(Boolean).join("/");
      if (clean && !folderList(area).includes(clean) && !folderCreate(area, clean)) {
        vscode.window.showErrorMessage(`Could not create folder: ${clean}`);
        continue;
      }
      if (clean) gitCommit(`add(folder): ${area}/${clean}`);
      return clean;
    }
  }
}

async function createScriptAtFolder(folder: string): Promise<string | undefined> {
  const cleanFolder = await selectKnowledgeFolder("scripts", folder);
  if (cleanFolder === undefined) return undefined;
  const filename = await vscode.window.showInputBox({
    prompt: "New script filename (include extension)", placeHolder: "e.g. My New Query.script",
    validateInput: value => value?.trim() ? (/[\\/]/.test(value) ? "Filename cannot contain slashes" : null) : "Filename required",
  });
  if (!filename?.trim()) return undefined;
  const rel = cleanFolder ? `${cleanFolder}/${filename.trim()}` : filename.trim();
  const root = path.resolve(getStorePath(), "scripts");
  const full = path.resolve(root, rel);
  if (!full.startsWith(root + path.sep)) return undefined;
  if (fs.existsSync(full)) { vscode.window.showWarningMessage(`Script already exists: ${rel}`); return undefined; }
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, "");
  gitCommit(`add(script): ${rel}`);
  _treeProvider?.refresh();
  const document = await vscode.workspace.openTextDocument(vscode.Uri.file(full));
  await vscode.window.showTextDocument(document, { preview: false });
  return rel;
}

// ── Chatroom orchestrator ──────────────────────────────────────────────────
// Owns the (optional self-hosted) hub and a set of room connections — one person
// can hold multiple rooms at once. Keeps a per-room in-session chat buffer plus
// received-file buffers (never written to disk unless the user saves them), and
// forwards live events to the webview chatroom tab.
interface RoomConn {
  peer?: PeerSession;
  key:     string;             // durable Room UUID when available; URL+name for legacy Rooms
  url:     string;
  room:    string;
  roomId?: string;
  user:    string;
  client:  ChatClient;
  messages: ChatMessage[];
  members:  Member[];
  status:   string;
  statusDetail: string;
  unread:   number;
  selfHost: boolean;   // this client is the room's host (can moderate)
  selfMuted: boolean;  // the host has muted this client
  agentStates: Record<string, AgentRuntimeState>;
  meetings: MeetingRoomSnapshot;
  meetingHistorySynced: boolean;
  files:    Map<string, { meta: FileMeta; from: string; data: Buffer }>; // received, awaiting save
}

interface ManagedChatAgent {
  id: string;
  name: string;
  icon: string;
  backend: AiBackend;
  role: string;
  systemPrompt: string;
  roomKey: string;
  client: ChatClient;
  messages: ChatMessage[];
  pendingMessages: ChatMessage[];
  status: string;
  active: boolean;
  busy: boolean;
  generation: number;
}

interface HostedRoomNavigationItem {
  roomId: string;
  roomName: string;
  active: boolean;
  activeElsewhere?: boolean;
  activeUrl?: string;
  canForceClose?: boolean;
  canRehost: boolean;
  unavailableReason?: string;
}

interface PortalConnectionInfo { url: string; room: string; roomId: string; user: string; secret: string; host: boolean; port?: number; transport?: "portal" }

class ChatRoomManager {
  private portalHubPort?: PortalHubPortStatus;
  private endpointStore?: PortalEndpointStore;
  private endpointContext?: vscode.ExtensionContext;
  private endpointTimer?: NodeJS.Timeout;
  private readonly endpointConnecting = new Set<string>();
  private readonly endpointErrors = new Map<string, string>();
  private readonly endpointPaused = new Set<string>();
  private readonly endpointPersisting = new Map<string, string>();
  private readonly endpointLocks = new Map<string, () => void>();
  private readonly endpointSuspended = new Set<string>();
  private readonly endpointPeerBindings = new Map<string, string>();
  private endpointRefreshPending = false;
  private endpointStopped = false;
  private hub:   ChatHub | undefined;
  private rooms: Map<string, RoomConn> = new Map();
  private readonly portalTransports = new Map<string, RoomConn>();
  private readonly portalGrace = new Map<string, { timer: NodeJS.Timeout; since: number; reason: string }>();
  private portalStallTimer?: NodeJS.Timeout;
  private hostedKeys: Map<string, string> = new Map();   // room -> secret this host set
  private activeKey = "";
  private managedAgents: Map<string, ManagedChatAgent> = new Map();
  private storedRooms: StoredChatRoom[] = [];
  private archiveDir = "";
  private persistenceRoot = "";
  private installationId = "";
  private secretStorage: vscode.SecretStorage | undefined;
  private meetingStore: MeetingStateStore | undefined;
  private meetingLifecycle: ChatMeetingLifecycle | undefined;
  private archiveLimitBytes = 10 * 1024 * 1024;
  private crossWindowRefreshTimer: NodeJS.Timeout | undefined;
  private storedRoomsRefresh: Promise<void> | undefined;
  private navigationStatusSignature = "";
  private static readonly MAX_MSGS = 1000;   // bounded visible transcript; full history remains durable in the Room DB
  private static readonly DEFAULT_MANAGED_AGENT_ROLE = "Contribute relevant expertise, ask focused questions, review peer proposals, and help the Room reach concrete decisions.";

  private readonly chatPortals = new Map<string, { id: string; label: string; root: string; external: boolean; room?: RoomConn; executionChatId?: string }>();
  private readonly portalOpening = new Set<string>();
  private readonly portalPermissions = new Map<string, PortalPermissions>();
  /** External (MCP) reuse window, bound to the pairing and control direction it was granted for. */
  private readonly externalPortalExpiry = new Map<string, { expiresAt: number; pairId: string; role: string }>();
  private readonly externalPortalOffers = new Map<string, Promise<void>>();
  /** Unredeemed Portal links, memory only: never logged, persisted, synced or sent to MCP. */
  private readonly portalPendingLinks = new Map<string, { link: string; expiresAt: number; endpoint: string }>();
  private readonly portalExecutions = new Map<string, AbortController>();
  private portalCommandCaps: string[] = [`platform:${process.platform}`];
  private readonly portalCommandApprovals = new Map<string, { epoch: number; expiresAt: number }>();
  private readonly portalTaskChats = new Map<string, Map<string, { pairId: string; chatId: string }>>();
  private readonly portalFiles = new Map<string, PortalFiles>();
  private readonly portalTransfers = new Map<string, Map<string, PortalTransferStatus>>();
  private readonly portalEpochs = new Map<string, number>();
  private readonly portalConnections = new Map<string, PortalConnectionInfo>();
  private portalJournal: PortalConnectionJournal | undefined;
  private portalJournalSignature = "";
  private portalJournalSubscription?: { dispose(): void };
  private readonly portalCleanups = new Map<string, Promise<void>>();

  configurePortalJournal(_memento: vscode.Memento): void {
    if (this.portalJournal) return;
    this.portalJournal = new PortalConnectionJournal();
    this.portalJournalSubscription = onPortalChanged(() => this.postPortalConnections());
  }

  configurePersistentPortals(context: vscode.ExtensionContext): void {
    if (this.endpointStore) return;
    this.endpointContext = context;
    this.endpointStore = new PortalEndpointStore(context.workspaceState, context.secrets);
    this.endpointTimer = setInterval(() => {
      void this.refreshPersistentPortals().catch(error => log.error(`Portal endpoints: ${String(error)}`));
    }, 15_000);
    this.endpointTimer.unref();
    void this.refreshPersistentPortals().catch(error => {
      log.error(`Portal endpoints: ${String(error)}`);
      void vscode.window.showErrorMessage(`PKM Portal endpoints: ${String(error)}`);
    });
  }

  private endpoint(id: string): PortalEndpointRecord | undefined { return this.endpointStore?.get(id); }

  private endpointChatId(id: string): string | undefined {
    const endpoint = this.endpoint(id);
    return endpoint ? endpoint.deleted ? undefined : endpoint.chatId : id;
  }

  private endpointReady(id: string): boolean {
    const room = this.chatPortals.get(id)?.room;
    return room?.client.isConnected === true && room.peer?.endpointConfirmed === true
      && room.members?.some(member => member.participantId === room.peer?.binding?.peerId && member.present !== false) === true;
  }

  private async ownEndpoint(id: string): Promise<void> {
    if (this.endpointLocks.has(id)) return;
    const context = this.endpointContext;
    if (!context) throw new Error("Portal endpoint storage is not initialized.");
    let ready!: () => void, failed!: (error: unknown) => void;
    const acquired = new Promise<void>((resolve, reject) => { ready = resolve; failed = reject; });
    void withCrossProcessLock(path.join(context.globalStorageUri.fsPath, "portal-endpoint-locks", `${id}.lock`),
      "Portal endpoint", 100, async () => {
        if (this.endpointStopped) throw new Error("Portal endpoint manager is stopping.");
        await new Promise<void>(release => { this.endpointLocks.set(id, release); ready(); });
      }).catch(error => { failed(error); log.error(`Portal endpoint ownership: ${String(error)}`); });
    await acquired;
  }

  private async refreshPersistentPortals(): Promise<void> {
    if (!this.endpointStore || this.endpointStopped || this.endpointRefreshPending || !vscode.workspace.isTrusted) return;
    this.endpointRefreshPending = true;
    try {
      const endpoints = this.endpointStore.list().filter(item => item.root === getStorePath());
      const chats = endpoints.some(item => item.chatId && !item.deleted) ? await portalChatBindingsReader?.() : undefined;
      if (chats) for (const endpoint of endpoints) {
        if (endpoint.chatId && !endpoint.deleted && !chats.some(chat => chat.id === endpoint.chatId)) await this.portalChatRemoved(endpoint.chatId);
      }
      for (const endpoint of endpoints) {
        if (this.endpointStopped) return;
        if (!endpoint.paired || this.endpointPaused.has(endpoint.id) || this.endpointConnecting.has(endpoint.id)
          || this.chatPortals.get(endpoint.id)?.room) continue;
        try { await this.connectPersistentEndpoint(endpoint.id); }
        catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          if (this.endpointErrors.get(endpoint.id) !== message) portalLog("warn", `endpoint=${endpoint.id.slice(0, 8)} ${message}`);
          this.endpointErrors.set(endpoint.id, message);
        }
      }
      this.postPortalConnections(true);
    } finally { this.endpointRefreshPending = false; }
  }

  async portalChatRemoved(chatId: string): Promise<void> {
    for (const endpoint of this.endpointStore?.list() || []) if (endpoint.chatId === chatId && !endpoint.deleted) {
      this.endpointSuspended.add(endpoint.id);
      this.invalidatePortal(endpoint.id);
      const updated = await this.endpointStore!.update(endpoint.id, { deleted: true });
      this.applyEndpointPermissions(updated);
      this.endpointSuspended.delete(endpoint.id);
      this.publishEndpoint(updated.id);
    }
    this.postPortalConnections(true);
  }

  private publishEndpoint(id: string): void {
    const room = this.chatPortals.get(id)?.room;
    if (room?.client.isConnected && room.peer?.binding) {
      try { room.peer.publishEndpointState(); }
      catch (error) { portalLog("warn", `Portal endpoint state: ${String(error)}`); }
    }
    portalChanged();
  }

  private applyEndpointPermissions(endpoint: PortalEndpointRecord): void {
    this.portalPermissions.get(endpoint.id)?.invalidate("revoke");
    const binding = this.chatPortals.get(endpoint.id)?.room?.peer?.binding;
    if (!binding) return;
    const policy = new PortalPermissions({ chatId: endpoint.id, connectionId: binding.pairId });
    if (endpoint.acceptsIncoming && !endpoint.deleted && endpoint.permissions.length) {
      policy.grant({ mode: "scoped", permissions: endpoint.permissions, durationMs: null });
    }
    this.portalPermissions.set(endpoint.id, policy);
  }

  private async rememberEndpointPair(id: string, room: RoomConn): Promise<void> {
    const endpoint = this.endpoint(id), binding = room.peer?.binding, transport = this.portalConnections.get(id);
    if (!endpoint || !binding || !transport || !this.endpointContext) return;
    if (!binding.peerCapabilities?.includes("persistent-v1")) throw new Error("The remote Host must be upgraded before saving this Portal pairing.");
    if (endpoint.paired) return;
    const fingerprint = `${binding.pairId}:${binding.peerId}`;
    if (this.endpointPersisting.get(id) === fingerprint) return;
    this.endpointPersisting.set(id, fingerprint);
    try {
      await this.endpointStore!.pair(id, binding, {
        url: transport.url, roomId: transport.roomId, user: transport.user,
        cid: `${getChatCid(this.endpointContext)}${id.replace(/-/g, "")}`, host: transport.host, port: transport.port,
      }, transport.secret);
      this.applyEndpointPermissions(this.endpoint(id)!);
      this.publishEndpoint(id);
    } catch (error) { this.endpointPersisting.delete(id); throw error; }
  }

  private async connectPersistentEndpoint(id: string): Promise<void> {
    const endpoint = this.endpoint(id), context = this.endpointContext;
    if (!endpoint?.paired || !context || this.endpointStopped || endpoint.root !== getStorePath() || !vscode.workspace.isTrusted) throw new Error("Choose a paired Portal endpoint in the trusted current Knowledge Root.");
    const existing = this.chatPortals.get(id)?.room;
    if (existing?.client.isConnected && existing.peer?.binding) return;
    if (this.endpointConnecting.has(id)) return;
    this.endpointConnecting.add(id);
    try {
      await this.ownEndpoint(id);
      const secret = await this.endpointStore!.credential(id);
      if (this.endpointStopped || !vscode.workspace.isTrusted || endpoint.root !== getStorePath()) throw new Error("Portal context changed during reconnection.");
      if (!secret) throw new Error("Portal credential is unavailable. Pair again; no task was sent.");
      const transport = endpoint.paired.transport;
      this.closePortalTransport(id, "persistent-reconnect");
      this.chatPortals.set(id, { id, label: endpoint.name, root: endpoint.root, external: false });
      if (transport.host) {
        const hub = await this.startHub(transport.port ?? 7345);
        if (this.endpointStopped || !vscode.workspace.isTrusted || endpoint.root !== getStorePath()) throw new Error("Portal context changed while restoring its listener.");
        if (!hub.ok || this.hubPort !== transport.port) throw new Error(`The saved Portal listener port ${transport.port} is unavailable. No port was silently rotated: the remote endpoint still uses its saved address. Restore this listener/forwarding or remove and pair the endpoints again.${hub.error ? ` ${hub.error}` : ""}`);
        this.hub!.createPortalChannel(transport.roomId, secret);
      }
      this.portalConnections.set(id, { ...transport, room: "Portal", secret, transport: "portal" });
      const room = this.joinPortalTransport(id, { url: transport.url, room: "Portal", roomId: transport.roomId,
        user: transport.user, token: secret, cid: transport.cid });
      this.chatPortals.get(id)!.room = room;
      const peer = this.ensurePeer(room, endpoint.root, { id, label: endpoint.name }, context);
      peer.restore(endpoint.paired.binding);
      this.applyEndpointPermissions(endpoint);
      if (room.client.isConnected) this.publishEndpoint(id);
      this.endpointErrors.delete(id);
    } finally { this.endpointConnecting.delete(id); }
  }

  async managePersistentEndpoint(context: vscode.ExtensionContext, operation: string, id?: string): Promise<void> {
    this.portalPreflight();
    this.configurePersistentPortals(context);
    const store = this.endpointStore!;
    if (operation === "create") {
      const name = await vscode.window.showInputBox({ title: "New Portal endpoint", prompt: "Local endpoint name", ignoreFocusOut: true });
      if (name === undefined) return;
      const binding = await vscode.window.showQuickPick(["Bind PKM Chat", "General Enteray"], { title: "Endpoint session binding", ignoreFocusOut: true });
      if (!binding) return;
      const chat = binding === "Bind PKM Chat" ? await portalChooseContext?.() : undefined;
      if (binding === "Bind PKM Chat" && !chat) return;
      await store.create({ name, root: getStorePath(), localMachine: os.hostname(), chatId: chat?.id, chatName: chat?.label });
    } else {
      const endpoint = id ? store.get(id) : undefined;
      if (!endpoint || endpoint.root !== getStorePath()) throw new Error("Choose a local Portal endpoint in this Knowledge Root.");
      await this.ownEndpoint(endpoint.id);
      if (operation === "pair") {
        if (endpoint.paired) throw new Error("Remove the saved endpoint and create a new endpoint to pair a different peer.");
        if (this.chatPortals.get(endpoint.id)?.room) throw new Error("Disconnect the pending pairing before creating or accepting another code.");
        const action = await vscode.window.showQuickPick(["Create private pairing code", "Accept private pairing code"], { title: `Pair ${endpoint.name}`, ignoreFocusOut: true });
        if (!action) return;
        this.chatPortals.set(endpoint.id, { id: endpoint.id, label: endpoint.name, root: endpoint.root, external: false });
        if (action === "Create private pairing code") await this.startPortal(context, { id: endpoint.id, label: endpoint.name }, "controller");
        else {
          const code = await vscode.window.showInputBox({ title: "Private Portal pairing code", password: true, ignoreFocusOut: true });
          if (code === undefined) return;
          await this.acceptPortal(context, { id: endpoint.id, label: endpoint.name }, code);
        }
      } else if (operation === "connect") {
        this.endpointPaused.delete(endpoint.id); await this.connectPersistentEndpoint(endpoint.id);
      } else if (operation === "disconnect") {
        this.endpointPaused.add(endpoint.id); this.closePortalTransport(endpoint.id, "persistent-user-disconnect");
      } else if (operation === "bind") {
        const chat = await portalChooseContext?.();
        if (!chat) return;
        if ((store.list().some(item => item.id !== endpoint.id && item.chatId === chat.id && !item.deleted)) || this.chatPortals.has(chat.id)) throw new Error("This Chat already has a Portal binding.");
        this.endpointSuspended.add(endpoint.id);
        this.invalidatePortal(endpoint.id);
        const updated = await store.update(endpoint.id, { chatId: chat.id, chatName: chat.label, deleted: false, acceptsIncoming: false, permissions: [] });
        this.applyEndpointPermissions(updated); this.endpointSuspended.delete(endpoint.id); this.publishEndpoint(endpoint.id);
      } else if (operation === "external-access") {
        if (!endpoint.paired || endpoint.deleted) throw new Error("Pair a non-deleted endpoint before authorizing external MCP access.");
        const selected = await vscode.window.showQuickPick([
          { label: "Disabled", enabled: false, description: endpoint.externalAccess ? undefined : "Current setting" },
          { label: "Enable external MCP access", enabled: true, description: endpoint.externalAccess ? "Current setting" : undefined },
        ], { title: `External MCP access · ${endpoint.name}`, ignoreFocusOut: true });
        if (!selected) return;
        if (selected.enabled) {
          const confirm = await vscode.window.showWarningMessage(`Remember external MCP access for ${endpoint.name}?`, { modal: true,
            detail: "This authorizes all MCP clients on this Host, not one Copilot Chat, to inspect this endpoint and submit Portal requests. It survives reconnects and restarts until revoked here. The paired peer, Knowledge Root and local machine must match. Replacing either bound Chat clears access. Remote execution permissions and file-batch approvals remain separate." }, "Enable saved MCP access");
          if (confirm !== "Enable saved MCP access") return;
        }
        if (!vscode.workspace.isTrusted || endpoint.root !== getStorePath()) throw new Error("Portal context changed during external MCP authorization.");
        this.endpointSuspended.add(endpoint.id);
        this.invalidatePortal(endpoint.id);
        try {
          const updated = await store.update(endpoint.id, { externalAccess: selected.enabled }, endpoint.revision);
          this.applyEndpointPermissions(updated);
          this.publishEndpoint(endpoint.id);
        } finally { this.endpointSuspended.delete(endpoint.id); }
      } else if (operation === "permissions") {
        const selected = await vscode.window.showQuickPick(
          PORTAL_PERMISSION_DIMENSIONS.map(permission => ({ label: permission, picked: endpoint.permissions.includes(permission) })),
          { title: "Local permissions accepted from this remote endpoint", canPickMany: true, ignoreFocusOut: true });
        if (!selected) return;
        const enabled = await vscode.window.showQuickPick(["Disabled", "Enable receiving control"], { title: "Allow remote control of THIS machine?", ignoreFocusOut: true });
        if (!enabled) return;
        const confirm = await vscode.window.showWarningMessage(
          `Save long-term permissions for ${endpoint.name}?`, { modal: true,
            detail: `${selected.map(item => item.label).join(", ") || "No reusable permissions"}\nThese permissions survive restart, apply only to this endpoint and its paired peer, and remain until revoked. Selected dimensions are unscoped: file read/write access is not limited to workspace folders. Code execution grants arbitrary operating-system and network access. File batches still require approval. Chat replacement clears these grants.` }, "Save permissions");
        if (confirm !== "Save permissions") return;
        this.endpointSuspended.add(endpoint.id);
        this.invalidatePortal(endpoint.id);
        const updated = await store.update(endpoint.id, { acceptsIncoming: enabled === "Enable receiving control", permissions: selected.map(item => item.label) });
        this.applyEndpointPermissions(updated); this.endpointSuspended.delete(endpoint.id); this.publishEndpoint(endpoint.id);
      } else if (operation === "remove") {
        const choice = await vscode.window.showWarningMessage(`Remove Portal endpoint "${endpoint.name}" and revoke its pairing?`, { modal: true }, "Remove endpoint");
        if (choice !== "Remove endpoint") return;
        this.endpointPaused.add(endpoint.id);
        this.chatPortals.get(endpoint.id)?.room?.peer?.revoke();
        this.closePortalTransport(endpoint.id, "endpoint-removed");
        await store.remove(endpoint.id);
        this.chatPortals.delete(endpoint.id);
        this.endpointLocks.get(endpoint.id)?.(); this.endpointLocks.delete(endpoint.id);
        this.endpointPaused.delete(endpoint.id); this.endpointErrors.delete(endpoint.id);
        this.endpointPersisting.delete(endpoint.id); this.endpointPeerBindings.delete(endpoint.id);
        this.endpointSuspended.delete(endpoint.id);
      } else throw new Error("Unsupported Portal endpoint operation.");
    }
    this.postPortalConnections(true);
  }

  async cleanupPortalPersistence(context: vscode.ExtensionContext): Promise<void> {
    const root = getStorePath();
    let cleanup = this.portalCleanups.get(root);
    if (!cleanup) {
      cleanup = cleanupLegacyPortals(context.globalState, context.secrets, root);
      this.portalCleanups.set(root, cleanup);
    }
    try { await cleanup; }
    catch (error) { this.portalCleanups.delete(root); throw error; }
  }

  portalConnectionHistory(): PortalConnectionSnapshot {
    const live = new Map<string, PortalConnectionLive>();
    for (const entry of this.chatPortals.values()) {
      const binding = entry.room?.peer?.binding;
      const grace = binding ? this.portalGrace.get(entry.id) : undefined;
      live.set(entry.id, { pairId: binding?.pairId, connected: !!binding && !!entry.room?.client.isConnected,
        reconnecting: grace ? { since: grace.since, deadline: grace.since + PORTAL_GRACE_MS } : undefined,
        access: portalConnectionAccess(binding?.pairId, this.portalPermissions.get(entry.id)?.snapshot(),
          entry.external && this.externalAuthorized(entry.id) ? this.externalPortalExpiry.get(entry.id) : undefined) });
    }
    const snapshot = this.portalJournal?.snapshot(live) ?? { updatedAt: Date.now(), active: 0, connections: [] };
    const pendingInvitations: NonNullable<PortalConnectionSnapshot["pendingInvitations"]> = [];
    for (const [chatId, record] of this.portalPendingLinks) {
      const entry = this.chatPortals.get(chatId);
      const invitation = entry?.room?.peer?.pendingInvitation;
      if (record.expiresAt > Date.now() && invitation && !entry?.room?.peer?.binding && entry.root === getStorePath() && vscode.workspace.isTrusted && entry.room?.client.isConnected) {
        pendingInvitations.push({ chatId, chatLabel: entry.label, localMachine: os.hostname(), external: entry.external, role: invitation.role, expiresAt: record.expiresAt, endpoint: record.endpoint });
      }
    }
    const endpoints = (this.endpointStore?.list() || []).filter(item => item.root === getStorePath()).map(item => {
      const room = this.chatPortals.get(item.id)?.room;
      const state = room?.peer?.peerEndpoint;
      const binding = room?.peer?.binding || item.paired?.binding;
      const connected = this.endpointReady(item.id);
      return {
        id: item.id, name: item.name, localMachine: item.localMachine, chatId: item.chatId, chatName: item.chatName,
        deleted: item.deleted, acceptsIncoming: item.acceptsIncoming, permissions: item.permissions, paired: !!item.paired,
        externalAccess: item.externalAccess === true,
        state: connected ? "connected" as const : room ? "connecting" as const : "disconnected" as const,
        error: this.endpointErrors.get(item.id),
        ...(binding ? { peer: { name: state?.name || binding.peerName, machine: binding.peerMachine,
          chatId: state?.chatId || binding.peerChatId, chatName: state?.chatName || binding.peerChatName,
          deleted: state?.deleted, acceptsIncoming: state?.acceptsIncoming, confirmed: connected } } : {}),
      };
    });
    return { ...snapshot, connections: snapshot.connections.filter(item => !this.endpoint(item.chatId)), pendingInvitations, endpoints,
      ...(this.portalHubPort ? { hubPort: { ...this.portalHubPort } } : {}) };
  }

  forgetPortalConnection(pairId: string): void {
    if (this.portalConnectionHistory().connections.some(item => item.pairId === pairId)) throw new Error("Disconnect this Portal before removing it.");
    this.portalJournal?.forget(pairId);
    this.postPortalConnections(true);
  }

  private postPortalConnections(force = false): void {
    if (!this.portalJournal) return;
    const snapshot = this.portalConnectionHistory();
    const signature = JSON.stringify([snapshot.connections.map(item => [item.pairId, item.chatId, item.state, item.role, item.chatLabel, item.reconnecting?.deadline, item.access]), snapshot.pendingInvitations, snapshot.endpoints, snapshot.hubPort]);
    if (!force && signature === this.portalJournalSignature) return;
    this.portalJournalSignature = signature;
    postToPanel({ command: "portalConnections", data: snapshot });
  }

  portalStateForChat(id: string): Record<string, unknown> | undefined {
    id = this.portalOwnerId(id);
    if (!this.chatPortals.has(id)) return undefined;
    const permissions = this.portalPermissions.get(id)?.snapshot();
    const grant = permissions?.grants[permissions.grants.length - 1];
    const status = this.portalStatus(id);
    if (!status.binding && !status.pending) return undefined;
    return { ...status, permissions: { ...permissions, active: !!grant, mode: grant?.mode, expiresAt: grant?.expiresAt } };
  }

  portalToolAllowed(id: string, tool: string, resource?: string): boolean {
    id = this.portalOwnerId(id);
    const entry = this.chatPortals.get(id);
    const policy = this.portalPermissions.get(id);
    if (!entry || !entry.room?.peer?.binding || entry.root !== getStorePath() || !vscode.workspace.isTrusted) {
      policy?.invalidate("trust-change");
      return false;
    }
    if (!entry.room.client.isConnected) return false;
    const map = ChatRoomManager.PORTAL_TOOL_DIMENSIONS;
    const permission = map[tool.replace(/^remote:/, "")] || Object.entries(map).find(([name]) => toolPermissionScope("builtin", name) === tool)?.[1];
    if (!permission && /^(?:tool:|read-only$|non-destructive$)/.test(tool)) {
      return !!policy?.snapshot().grants.some(grant => grant.mode === "all");
    }
    if (!permission) return false;
    const once = policy?.snapshot().grants.some(grant => grant.mode === "once");
    const allowed = policy?.allows(permission, permission.startsWith("files-") && resource ? ChatRoomManager.portalScopePath(resource) : undefined) === true;
    if (once) portalChanged();
    return allowed;
  }

  private static readonly PORTAL_TOOL_DIMENSIONS: Record<string, typeof PORTAL_PERMISSION_DIMENSIONS[number]> = {
    read_file: "files-read", find_files: "files-read", search_text: "files-read", list_directory: "files-read",
    replace_text: "files-write", save_file: "files-write", run_process: "code-execute",
    run_process_background: "code-execute", process_cancel: "code-execute", process_get: "progress-read", process_output: "progress-read",
    pkm_search: "pkm-read", pkm_read: "pkm-read", note_todo_read: "pkm-read", memory_read: "chat-read", list_chats: "chat-read",
    session_info: "progress-read", record_harness: "progress-read", find_actions: "pkm-read",
  };

  /** Raw tool output may leave the controlled Host only under a reusable progress-read lease plus an unscoped lease for that tool's own dimension. */
  private portalMirrorObservation(id: string, observation: import("./chatroom/portal-observation").PortalObservation): import("./chatroom/portal-observation").PortalObservation {
    if (!observation.tools?.some(tool => tool.output !== undefined)) return observation;
    const grants = (this.portalPermissions.get(id)?.snapshot().grants || []).filter(grant => grant.mode !== "once");
    const unscoped = (dimension: string) => grants.some(grant => grant.permissions.includes(dimension as typeof PORTAL_PERMISSION_DIMENSIONS[number])
      && !grant.scopes[dimension as typeof PORTAL_PERMISSION_DIMENSIONS[number]]);
    const progress = unscoped("progress-read");
    const all = grants.some(grant => grant.mode === "all" && !Object.keys(grant.scopes).length);
    return { ...observation, tools: boundPortalToolOutputs(observation.tools.map(tool => {
      if (tool.output === undefined) return tool;
      const dimension = ChatRoomManager.PORTAL_TOOL_DIMENSIONS[tool.name];
      if (progress && (dimension ? unscoped(dimension) : all)) return tool;
      const { output: _withheld, ...rest } = tool;
      return { ...rest, outputWithheld: true };
    })) };
  }

  /** Canonical comparison form for Portal folder scopes (case-insensitive on Windows). */
  static portalScopePath(value: string): string {
    const resolved = path.resolve(value);
    return process.platform === "win32" ? resolved.toLowerCase() : resolved;
  }

  invalidatePortal(id: string): void {
    id = this.portalOwnerId(id);
    this.portalEpochs.set(id, (this.portalEpochs.get(id) || 0) + 1);
    this.portalPermissions.get(id)?.invalidate("revoke");
    this.portalPermissions.delete(id);
    this.portalTaskChats.delete(id);
    for (const key of this.portalCommandApprovals.keys()) if (key.startsWith(`${id}:`)) this.portalCommandApprovals.delete(key);
    this.externalPortalExpiry.delete(id);
    this.portalPendingLinks.delete(id);
    const execution = this.portalExecutions.get(id);
    const files = this.portalFiles.get(id);
    this.portalExecutions.delete(id);
    this.portalFiles.delete(id);
    this.portalTransfers.delete(id);
    execution?.abort();
    files?.dispose();
    portalChanged();
  }

  invalidatePortalsForContextChange(nextRoot: string): void {
    for (const entry of this.chatPortals.values()) if (entry.root !== nextRoot || !vscode.workspace.isTrusted) {
      this.invalidatePortal(entry.id);
      this.closePortalTransport(entry.id, "knowledge-root-or-trust-changed");
    }
  }

  async authorizePortalForChat(id: string): Promise<void> {
    id = this.portalOwnerId(id);
    const entry = this.chatPortals.get(id);
    if (!entry?.room || entry.root !== getStorePath()) throw new Error("This Chat has no live Portal.");
    await this.configurePortalPermissions(entry, entry.room);
  }

  private async portalPrompt(owner: { id: string; label: string }, interaction: import("./chat/portal-interaction").PortalInteraction) {
    const root = getStorePath(), epoch = this.portalEpochs.get(owner.id) || 0;
    const entry = this.chatPortals.get(owner.id);
    if (entry && entry.root !== root) throw new Error("The Portal Knowledge Root changed.");
    const room = entry?.room, binding = room?.peer?.binding;
    const current = () => vscode.workspace.isTrusted && root === getStorePath()
      && (this.portalEpochs.get(owner.id) || 0) === epoch
      && this.chatPortals.get(owner.id) === entry && entry?.room === room && room?.peer?.binding === binding
      && (!binding || room?.client.isConnected === true);
    if (entry?.external || this.endpoint(owner.id)) return requestNativePortalInteraction(interaction, current);
    if (!portalInteraction) throw new Error("Portal Chat controls are unavailable.");
    return portalInteraction(owner.id, interaction, current);
  }

  private portalOwnerId(id: string): string {
    return (this.endpointStore?.list() || []).find(endpoint => !endpoint.deleted && endpoint.chatId === id)?.id
      || [...this.chatPortals.values()].find(entry => entry.external && entry.executionChatId === id)?.id || id;
  }

  private async portalConfirm(owner: { id: string; label: string }, title: string, detail: string, label: string): Promise<boolean> {
    return (await this.portalPrompt(owner, { title, detail,
      choices: [{ value: "confirm", label }, { value: "cancel", label: "Cancel" }] }))?.action === "confirm";
  }

  private async configurePortalPermissions(owner: { id: string; label: string }, room: RoomConn): Promise<boolean> {
    if (this.endpoint(owner.id)) {
      await this.managePersistentEndpoint(this.endpointContext!, "permissions", owner.id);
      return !!this.endpoint(owner.id)?.acceptsIncoming;
    }
    const binding = room.peer?.binding;
    const epoch = this.portalEpochs.get(owner.id) || 0;
    if (!binding) throw new Error("Pair before granting reusable permissions.");
    const root = getStorePath();
    const response = await this.portalPrompt(owner, {
      title: `Portal permissions · ${binding.peerName}`,
      detail: `Only this Portal context and pairing. Unselected dimensions still require approval. Files ALWAYS require a separate controlled-side batch permit. Chat history is not automatically exported.\nWARNING: code-execute and Allow All can access the operating system and network; PKM cannot sandbox arbitrary code. Use only with a trusted controller. Activity never renews the expiry.`,
      choices: [{ value: "submit", label: "Grant selected permissions" }, { value: "revoke", label: "Revoke authorization" }, { value: "cancel", label: "Cancel" }],
      form: { type: "object", required: ["mode", "minutes", "scope"], properties: {
        mode: { type: "string", title: "Authorization", enum: ["Selected permissions", "Allow All"], default: "Selected permissions" },
        permissions: { type: "array", title: "Allowed dimensions", items: { type: "string", enum: [...PORTAL_PERMISSION_DIMENSIONS] }, uniqueItems: true },
        scope: { type: "string", title: "File scope", enum: ["Workspace boundaries", "Choose specific folders"], default: "Workspace boundaries" },
        minutes: { type: "number", title: "Duration in minutes (0 = until disconnected)", minimum: 0, maximum: 525600, default: 15 },
        once: { type: "boolean", title: "Use each selected permission once", default: false },
        longLived: { type: "boolean", title: "I accept extended exposure for more than 15 minutes or until disconnected", default: false },
      } },
      verify: async fields => {
        if (fields.mode !== "Allow All" && (!Array.isArray(fields.permissions) || !fields.permissions.length)) throw new Error("Select at least one permission.");
        if ((Number(fields.minutes) === 0 || Number(fields.minutes) > 15) && fields.longLived !== true) throw new Error("Explicitly acknowledge extended authorization.");
        if (!Number.isSafeInteger(Number(fields.minutes) * 60_000)) throw new Error("Enter a representable duration.");
      },
    });
    if (!response || response.action === "cancel") return false;
    if (response.action === "revoke") { this.invalidatePortal(owner.id); this.push(); return false; }
    const mode = response.fields.once === true ? "once" : response.fields.mode === "Allow All" ? "all" : "scoped";
    const requested = response.fields.permissions;
    const selection = response.fields.mode === "Allow All" ? [...PORTAL_PERMISSION_DIMENSIONS]
      : PORTAL_PERMISSION_DIMENSIONS.filter(permission => Array.isArray(requested) && requested.includes(permission));
    const fileDimensions = selection.filter(permission => permission === "files-read" || permission === "files-write");
    let folders: string[] = [];
    if (fileDimensions.length) {
      if (response.fields.scope === "Choose specific folders") {
        const picked = await vscode.window.showOpenDialog({ canSelectFiles: false, canSelectFolders: true, canSelectMany: true, openLabel: "Allow these folders", title: "Folders the remote controller may use" });
        if (!picked?.length) return false;
        folders = [...new Set(picked.filter(uri => uri.scheme === "file").map(uri => ChatRoomManager.portalScopePath(uri.fsPath)))];
        if (folders.length > 16) throw new Error("Choose at most 16 Portal scope folders.");
        if (!folders.length || folders.some(folder => path.parse(folder).root === folder)) throw new Error("Choose specific folders, not a drive or filesystem root.");
      }
    }
    const duration = Number(response.fields.minutes) === 0 ? null : Number(response.fields.minutes) * 60_000;
    if ((this.portalEpochs.get(owner.id) || 0) !== epoch || room.peer?.binding !== binding || root !== getStorePath() || !vscode.workspace.isTrusted || !room.client.isConnected) throw new Error("Portal changed during authorization.");
    const policy = new PortalPermissions({ chatId: owner.id, connectionId: binding.pairId });
    policy.grant({ mode, permissions: selection, durationMs: duration, ...(folders.length ? { scopes: Object.fromEntries(fileDimensions.map(permission => [permission, folders])) } : {}) });
    this.portalPermissions.set(owner.id, policy);
    portalChanged();
    this.push();
    return true;
  }

  async portalControl(context: vscode.ExtensionContext, args: Record<string, unknown>, external: boolean): Promise<unknown> {
    this.portalPreflight();
    await this.cleanupPortalPersistence(context);
    const operation = args.operation;
    if (operation === "reattach") throw new Error("Portal connections are temporary; open a new Portal and pair again.");
    if (!["open", "connections", "status", "send", "command", "route", "get", "attempts", "cancel", "disconnect", "switch", "permissions", "files"].includes(String(operation))) throw new Error("Unsupported Portal operation.");
    if (operation === "connections") return this.portalConnectionHistory();
    const requestedContext = typeof args.connectionId === "string" ? args.connectionId
      : typeof args.contextId === "string" ? this.portalOwnerId(args.contextId) : "";
    if (operation === "open" && external && !requestedContext) {
      const owner = { id: randomUUID(), label: "External agent" };
      this.chatPortals.set(owner.id, { ...owner, root: getStorePath(), external: true });
      await this.managePeer(context, owner);
      if (args.wait !== false) await this.waitForPortalPairing(this.chatPortals.get(owner.id)!);
      return { contextId: owner.id, label: owner.label, ...this.portalStatus(owner.id) };
    }
    const route = operation === "route" ? selectPortalRoute([...this.chatPortals.values()].filter(entry => (entry.external === external || this.endpoint(entry.id)) && entry.root === getStorePath()
      && (!requestedContext || requestedContext === entry.id)).map(entry => ({
        contextId: entry.id, machine: entry.room?.peer?.binding?.peerMachine, connected: !!entry.room?.client.isConnected,
        role: this.endpoint(entry.id) ? !this.endpoint(entry.id)!.deleted && this.endpointReady(entry.id) && entry.room?.peer?.peerEndpoint?.acceptsIncoming ? "controller" : undefined : entry.room?.peer?.binding?.role,
        capabilities: entry.room?.peer?.binding?.peerCapabilities || [],
      })), args.requirements) : undefined;
    const id = route?.contextId || requestedContext;
    const entry = this.chatPortals.get(id);
    if (!entry || entry.external !== external && !this.endpoint(id) || entry.root !== getStorePath()) throw new Error("Unknown Portal context for this Chat/Host. Open a Portal first; never use another Chat's context.");
    const offeredAuthorization = external ? this.externalPortalOffers.get(id) : undefined;
    if (offeredAuthorization) await offeredAuthorization;
    if (external && !this.externalAuthorized(id)) {
      const binding = entry.room?.peer?.binding;
      const epoch = this.portalEpochs.get(id) || 0;
      const canRemember = !!binding && entry.room?.client.isConnected === true;
      const answer = await this.externalPortalConsent(entry, `Allow Portal ${operation}?`,
        typeof args.prompt === "string" ? args.prompt.slice(0, 16000) : "", canRemember);
      if (answer?.action === "submit") {
        const duration = Number(answer.fields.minutes) === 0 ? null : Number(answer.fields.minutes) * 60_000;
        if (!canRemember || !entry.room?.client.isConnected || entry.room.peer?.binding !== binding
          || (this.portalEpochs.get(id) || 0) !== epoch || entry.root !== getStorePath() || !vscode.workspace.isTrusted) throw new Error("Portal changed during external authorization; approval was not remembered.");
        this.externalPortalExpiry.set(id, { expiresAt: duration === null ? Infinity : Date.now() + duration, pairId: binding!.pairId, role: binding!.role });
      } else if (answer?.action === "persistent") {
        await this.managePersistentEndpoint(context, "external-access", id);
        if (!this.externalAuthorized(id)) throw new Error("Saved endpoint external MCP access was not enabled.");
      } else if (answer?.action !== "once") throw new Error("External Portal request declined.");
    }
    if (entry.root !== getStorePath() || !vscode.workspace.isTrusted) throw new Error("Portal workspace or Knowledge Root changed during approval.");
    if (operation === "open") {
      if (this.endpoint(id)) {
        await this.managePersistentEndpoint(context, "connect", id);
        return this.portalStatus(id);
      }
      await this.managePeer(context, entry);
      if (args.wait !== false) await this.waitForPortalPairing(entry);
      return this.portalStatus(id);
    }
    if (operation === "status") return this.portalStatus(id);
    const room = entry.room;
    if (!room?.peer || !room.client.isConnected) throw new Error("This Chat's Portal is disconnected.");
    const peer = room.peer;
    if (this.endpoint(id)?.deleted && ["send", "command", "route"].includes(String(operation))) throw new Error("This Portal's bound Chat was deleted. Replace the Chat and authorize it again before sending new work.");
    if (this.endpoint(id) && this.endpointSuspended.has(id) && ["send", "command", "route"].includes(String(operation))) throw new Error("Portal binding authorization is being updated; no task was sent.");
    if (operation === "permissions") {
      await this.configurePortalPermissions(entry, room);
      return this.portalStateForChat(id);
    }
    if (operation === "files") {
      let paths: string[];
      if (args.paths === undefined) {
        const selected = await vscode.window.showOpenDialog({ title: "Select this batch of Portal files", canSelectMany: true, canSelectFiles: true, canSelectFolders: false });
        if (!selected?.length) throw new Error("File selection cancelled.");
        paths = selected.map(uri => uri.fsPath);
      } else {
        if (!Array.isArray(args.paths) || !args.paths.length || args.paths.some(value => typeof value !== "string" || !path.isAbsolute(value))) throw new Error("Provide absolute local file paths for one explicit batch.");
        paths = args.paths;
      }
      const offered = await this.filesForPortal(entry, room).offer(paths);
      void offered.done.then(() => portalChanged(), error => log.error(`Portal transfer completion: ${String(error)}`));
      return { contextId: id, transferId: offered.transferId, instruction: "Waiting for per-batch controlled-side permission. Inspect status for the receiver's verified receipt; offering is not delivery or installation." };
    }
    if (operation === "send") {
      if (typeof args.prompt !== "string" || typeof args.requestId !== "string") throw new Error("Portal send requires a prompt and stable UUID requestId.");
      const requestId = peer.submit(args.prompt, args.requestId);
      return { contextId: id, requestId, receipt: peer.receipts.get(requestId), endpoint: room.url };
    }
    if (operation === "command" || operation === "route") {
      if (typeof args.requestId !== "string") throw new Error("Portal direct command requires a stable UUID requestId.");
      const requestId = peer.submitCommand(parsePortalCommand(args.command), args.requestId);
      return { contextId: id, requestId, execution: "direct-command", modelCalls: 0, machine: peer.binding?.peerMachine,
        receipt: peer.receipts.get(requestId), ...(route ? { requirements: args.requirements } : {}) };
    }
    if (operation === "get" || operation === "attempts" || operation === "cancel") {
      if (typeof args.requestId !== "string" || !peer.receipts.has(args.requestId)) throw new Error("Unknown request in this Chat's Portal.");
      if (operation === "cancel") peer.cancel(args.requestId);
      const taskAttempts = operation === "attempts" ? await peer.inspectAttempts(args.requestId) : undefined;
      return { contextId: id, queriedRequestId: args.requestId, receipt: peer.receipts.get(args.requestId),
        observation: peer.observations.get(args.requestId), ...(taskAttempts === undefined ? {} : { taskAttempts }) };
    }
    if (operation === "switch") {
      if (this.endpoint(id)) throw new Error("Saved endpoints support both directions simultaneously. Enable incoming control independently on each machine.");
      await this.portalActions(room, peer, true);
      return this.portalStatus(id);
    }
    if (this.endpoint(id)) {
      await this.managePersistentEndpoint(context, "disconnect", id);
      return { contextId: id, connected: false, pairingSaved: true };
    }
    peer.revoke();
    this.closePortalTransport(id, "user-disconnect");
    entry.room = undefined;
    portalChanged();
    this.push();
    return { contextId: id, connected: false };
  }

  portalDiagnostics(): Record<string, unknown> {
    const short = (value: string | undefined) => (value || "-").slice(0, 8);
    return {
      generatedAt: new Date().toISOString(),
      machine: os.hostname(), platform: process.platform, remoteName: vscode.env.remoteName || "local",
      uiKind: vscode.env.uiKind === vscode.UIKind.Web ? "web" : "desktop",
      hub: { running: !!this.hub?.isRunning, port: this.hubPort, relayChannels: this.hub?.portalChannelsSnapshot() || [] },
      chats: [...this.chatPortals.values()].map(entry => {
        const room = entry.room, peer = room?.peer, binding = peer?.binding;
        const connection = this.portalConnections.get(entry.id);
        return {
          chat: short(entry.id), label: entry.label, external: !!entry.external,
          transport: room ? { endpoint: room.url, channel: short(room.roomId), status: room.status, detail: room.statusDetail,
            self: `${room.user}#${short(room.client.participantId)}`, hostedHere: !!connection?.host,
            members: room.members.map(member => `${member.user}#${short(member.participantId)}${member.present === false ? "(away)" : ""}`) } : null,
          pairing: binding ? { pair: short(binding.pairId), role: binding.role, peer: `${binding.peerName}#${short(binding.peerId)}`, peerEndpoint: binding.peerEndpoint }
            : peer?.pendingInvitation ? { pendingInvitation: { role: peer.pendingInvitation.role, expiresAt: new Date(peer.pendingInvitation.expiresAt).toISOString() } } : null,
          reconnecting: (grace => grace ? { since: new Date(grace.since).toISOString(), deadline: new Date(grace.since + PORTAL_GRACE_MS).toISOString(), reason: grace.reason } : null)(this.portalGrace.get(entry.id)),
        };
      }),
      recentEvents: portalEvents.slice(-150),
    };
  }

  private portalStatus(id: string): Record<string, unknown> & { connected: boolean } {
    const entry = this.chatPortals.get(id);
    const room = entry?.room;
    const binding = room?.peer?.binding;
    const invitation = room?.peer?.pendingInvitation;
    const link = this.portalPendingLinks.get(id);
    const pending = invitation ? { role: invitation.role, expiresAt: invitation.expiresAt, linkAvailable: !!link && link.expiresAt > Date.now(),
      ...(link ? { endpoint: link.endpoint, endpointScope: endpointScope(link.endpoint) } : {}) } : undefined;
    const savedEndpoint = this.endpoint(id);
    const connected = !!room?.client.isConnected && !!binding && (!savedEndpoint || this.endpointReady(id));
    const grace = binding ? this.portalGrace.get(id) : undefined;
    const external = entry?.external ? this.externalPortalExpiry.get(id) : undefined;
    const reviewMode = !binding ? undefined : binding.role === "controller" ? (entry!.external ? "manual" : "auto")
      : binding.peerCapabilities?.includes("auto-review-v1") ? "auto" : binding.peerCapabilities?.includes("review-mode-v1") ? "manual" : undefined;
    return { connected, reviewMode,
      ...(savedEndpoint ? { persistentEndpoint: true, localEndpoint: { id: savedEndpoint.id, name: savedEndpoint.name,
        chatId: savedEndpoint.chatId, deleted: savedEndpoint.deleted, acceptsIncoming: savedEndpoint.acceptsIncoming, externalAccess: savedEndpoint.externalAccess === true },
        remoteEndpoint: room?.peer?.peerEndpoint } : {}),
      state: grace ? "reconnecting" : connected ? "connected" : pending ? "awaiting-peer" : savedEndpoint && room ? "connecting" : "disconnected",
      ...(grace ? { reconnecting: { since: grace.since, deadline: grace.since + PORTAL_GRACE_MS, reason: grace.reason } } : {}),
      ...(pending ? { pending } : {}),
      ...(external && this.externalAuthorized(id) ? { externalAuthorization: { expiresAt: Number.isFinite(external.expiresAt) ? external.expiresAt : null } } : {}),
      endpoint: room?.url, endpointScope: endpointScope(room?.url),
      ...(binding?.peerEndpoint ? { peerEndpoint: binding.peerEndpoint, peerEndpointScope: endpointScope(binding.peerEndpoint) } : {}),
      binding: room?.peer?.binding, execution: room?.peer?.incomingActivity, switchPending: room?.peer?.swapPending,
      observations: room?.peer ? [...room.peer.observations.values()] : [],
      transfers: [...(this.portalTransfers.get(id)?.values() || [])],
      receipts: room?.peer ? [...room.peer.receipts.values()].map(({ requestId, state, error }) => ({ requestId, state, error })) : [] };
  }

  private externalAuthorized(id: string): boolean {
    if (portalEndpointAllowsExternalAccess(this.endpoint(id), {
      root: getStorePath(), localMachine: os.hostname(), trusted: vscode.workspace.isTrusted,
      suspended: this.endpointSuspended.has(id), binding: this.chatPortals.get(id)?.room?.peer?.binding,
    })) return true;
    const grant = this.externalPortalExpiry.get(id);
    const binding = this.chatPortals.get(id)?.room?.peer?.binding;
    if (!grant || grant.expiresAt <= Date.now() || !binding || binding.pairId !== grant.pairId || binding.role !== grant.role) {
      if (grant) this.externalPortalExpiry.delete(id);
      return false;
    }
    return true;
  }

  /** Bounded by the link's own 10-minute lifetime; ends early on pairing, expiry, void or disconnect. */
  private async waitForPortalPairing(entry: { id: string; room?: RoomConn }): Promise<void> {
    // A redeemed link is still awaiting local pairing approval; keep waiting until bound, rejected, expired or disconnected.
    const pending = (peer?: PeerSession) => peer?.pendingInvitation || peer?.pairingInProgress;
    const deadline = pending(entry.room?.peer)?.expiresAt;
    if (!deadline) return;
    const limit = Math.min(deadline, Date.now() + 10 * 60_000);
    while (Date.now() < limit) {
      const peer = entry.room?.peer;
      if (!peer || peer.binding || !pending(peer) || !entry.room?.client.isConnected) return;
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }

  private externalPortalConsent(owner: { id: string; label: string }, title: string, detail: string, remember: boolean, offerOnly = false) {
    const saved = this.endpoint(owner.id);
    return this.portalPrompt(owner, { title, detail: `${owner.label}\n${detail}\nMCP cannot authenticate individual Copilot conversations. Trust only the intended MCP clients. A remembered grant is bound to this pairing/direction, with a fixed deadline that activity never renews. Disconnect, switch, revoke or context change invalidates it. Controlled-side task approval remains separate.`,
      choices: [...(offerOnly ? [] : [{ value: "once", label: "Allow once" }]), ...(remember ? [{ value: "submit", label: "Remember temporarily" }] : []),
        ...(saved?.paired && !saved.deleted ? [{ value: "persistent", label: "Configure saved endpoint MCP access..." }] : []), { value: "cancel", label: "Cancel" }],
      ...(remember ? { form: { type: "object" as const, required: ["minutes"], properties: {
        minutes: { type: "number" as const, title: "Minutes (0 = until disconnected)", minimum: 0, maximum: 525600, default: 15 },
        longLived: { type: "boolean" as const, title: "I accept extended exposure beyond 15 minutes or until disconnected", default: false },
      } }, verify: async (fields: Record<string, unknown>) => {
        if (!Number.isSafeInteger(Number(fields.minutes) * 60_000)) throw new Error("Enter a representable duration.");
        if ((Number(fields.minutes) === 0 || Number(fields.minutes) > 15) && fields.longLived !== true) throw new Error("Explicitly acknowledge extended authorization.");
      } } : {}),
    });
  }

  private async offerExternalAuthorization(id: string): Promise<void> {
    const pending = this.externalPortalOffers.get(id);
    if (pending) return pending;
    const offer = this.requestExternalAuthorization(id);
    this.externalPortalOffers.set(id, offer);
    try { await offer; }
    finally { if (this.externalPortalOffers.get(id) === offer) this.externalPortalOffers.delete(id); }
  }

  /** One timed authorization card per pairing; status polling waits for it instead of asking again. */
  private async requestExternalAuthorization(id: string): Promise<void> {
    const entry = this.chatPortals.get(id);
    const binding = entry?.room?.peer?.binding;
    if (!entry?.external || !binding || this.externalAuthorized(id)) return;
    const epoch = this.portalEpochs.get(id) || 0;
    const answer = await this.externalPortalConsent(entry, `Remember external access · ${binding.peerMachine || binding.peerName}`,
      "Allow this external Chat to check status and send Portal requests without repeated prompts?", true, true);
    if (answer?.action === "persistent") {
      if (!this.endpointContext) throw new Error("Saved endpoint settings are unavailable.");
      await this.managePersistentEndpoint(this.endpointContext, "external-access", id);
      if (!this.externalAuthorized(id)) throw new Error("Saved endpoint external MCP access was not enabled.");
      return;
    }
    if (answer?.action !== "submit") return;
    const duration = Number(answer.fields.minutes) === 0 ? null : Number(answer.fields.minutes) * 60_000;
    const current = this.chatPortals.get(id)?.room?.peer?.binding;
    if (current !== binding || (this.portalEpochs.get(id) || 0) !== epoch || entry.root !== getStorePath() || !vscode.workspace.isTrusted || !entry.room?.client.isConnected) {
      throw new Error("The Portal changed during authorization; external access was not remembered.");
    }
    this.externalPortalExpiry.set(id, { expiresAt: duration === null ? Infinity : Date.now() + duration, pairId: binding.pairId, role: binding.role });
    portalChanged();
  }

  /** Re-copy or void this Chat's unredeemed Portal link from its Portal panel. */
  async portalPendingLink(id: string, action: "copy" | "void"): Promise<void> {
    const entry = this.chatPortals.get(id);
    const peer = entry?.room?.peer;
    const link = this.portalPendingLinks.get(id);
    if (!entry?.room || !peer?.pendingInvitation) { this.portalPendingLinks.delete(id); portalChanged(); throw new Error("This Chat has no unredeemed Portal link."); }
    if (action === "copy") {
      if (entry.root !== getStorePath() || !vscode.workspace.isTrusted || !entry.room.client.isConnected || peer.binding) throw new Error("The Portal context changed; no link was copied.");
      if (!link || link.expiresAt <= Date.now()) throw new Error("The link is no longer available; void it and start a new Portal.");
      await vscode.env.clipboard.writeText(link.link);
      vscode.window.setStatusBarMessage("$(remote) PKM Portal link copied again", 4000);
      return;
    }
    this.portalPendingLinks.delete(id);
    peer.revoke();
    peer.dispose();
    this.closePortalTransport(id, "pending-link-voided");
    entry.room = undefined;
    portalChanged();
    this.push();
  }

  async managePeer(context: vscode.ExtensionContext, owner?: { id: string; label: string }): Promise<void> {
    if (!owner) throw new Error("Open Portal from the intended Chat's toolbar, or use the MCP portal_control tool.");
    this.portalPreflight();
    await this.cleanupPortalPersistence(context);
    this.portalCommandCaps = await portalCommandCapabilities();
    let entry = this.chatPortals.get(owner.id);
    if (entry && entry.root !== getStorePath()) throw new Error("The Portal Knowledge Root changed. Reload before reconnecting.");
    if (!entry) { entry = { ...owner, root: getStorePath(), external: false }; this.chatPortals.set(owner.id, entry); }
    const portal = entry.room;
    if (portal?.peer?.binding) { await this.portalActions(portal, portal.peer); return; }
    if (this.portalOpening.has(owner.id)) throw new Error("This Chat already has a Portal opening.");
    this.portalOpening.add(owner.id);
    try {
      const response = await this.portalPrompt(owner, { title: "Connect Portal",
        detail: "Controller copies a one-time connection code. Controlled pastes that code and approves control. No Portal name is needed; private codes stay local.",
        choices: [{ value: "controller", label: "Controller" }, { value: "controlled", label: "Controlled" }, { value: "cancel", label: "Cancel" }],
      });
      if (response?.action !== "controller" && response?.action !== "controlled") return;
      let link: string | undefined;
      if (response.action === "controlled") {
        const answer = await this.portalPrompt(owner, { title: "Connect as Controlled",
          detail: "Paste the Controller's private connection code. You will approve control before connecting.",
          choices: [{ value: "submit", label: "Continue" }, { value: "cancel", label: "Cancel" }],
          form: { type: "object", required: ["link"], properties: {
            link: { type: "string", title: "Private connection code", minLength: 1, maxLength: 4000 },
          } }, secretFields: ["link"],
          verify: async fields => {
            if (parsePortalLink(String(fields.link)).role !== "controller") throw new Error("Use a code created by the Controller. Ask the other side to create a new Portal as Controller.");
          },
        });
        if (answer?.action !== "submit") return;
        link = String(answer.fields.link);
        if (parsePortalLink(link).role !== "controller") throw new Error("Use a code created by the Controller; no connection was opened.");
      }
      if (portal) {
        if (!await this.portalConfirm(owner, "Replace this pending or disconnected Portal?",
          "The old invitation and connection will be revoked. Other Chats are not affected.", "Replace")) return;
        portal.peer?.revoke();
        portal.peer?.dispose();
        this.closePortalTransport(owner.id, "replaced-by-new-portal");
        entry.room = undefined;
      }
      if (response.action === "controller") await this.startPortal(context, owner, "controller");
      else if (link) await this.acceptPortal(context, owner, link);
      else throw new Error("A Controller connection code is required; no connection was opened.");
    } finally {
      this.portalOpening.delete(owner.id);
    }
  }

  private portalPreflight(room?: RoomConn): string {
    if (!vscode.workspace.isTrusted) throw new Error("PKM Portal requires a trusted workspace.");
    if (room) {
      if (!room.client.isConnected || !room.roomId) throw new Error("Connect the Portal transport first.");
      assertPeerEndpoint(room.url);
    }
    const peerRoot = getStorePath();
    if (!peerRoot) throw new Error("Configure a Knowledge Root before using PKM Portal.");
    return peerRoot;
  }

  private ensurePeer(room: RoomConn, peerRoot: string, owner: { id: string; label: string }, context: vscode.ExtensionContext): PeerSession {
    if ([...this.chatPortals.values()].some(entry => entry.room === room && entry.id !== owner.id)) throw new Error("This transport belongs to another Chat.");
    if (room.peer) return room.peer;
    let announced = "";
    let onceShare = false;
    const peer = new PeerSession({
      ...(this.endpoint(owner.id) ? { persistent: {
        acceptsIncoming: () => {
          const endpoint = this.endpoint(owner.id);
          return !!endpoint?.acceptsIncoming && !endpoint.deleted && !this.endpointSuspended.has(owner.id);
        },
        localBinding: () => {
          const endpoint = this.endpoint(owner.id);
          if (!endpoint) throw new Error("Portal endpoint was removed.");
          return { endpointId: endpoint.id, name: endpoint.name, chatId: endpoint.chatId,
            chatName: endpoint.chatName, deleted: endpoint.deleted, revision: endpoint.revision };
        },
        changedPeer: (state: import("./chatroom/peer-session").PortalEndpointIdentity) => {
          const endpoint = this.endpoint(owner.id), previous = endpoint?.paired?.binding;
          const identity = JSON.stringify([state.endpointId, state.chatId, state.deleted]);
          const priorIdentity = this.endpointPeerBindings.get(owner.id);
          this.endpointPeerBindings.set(owner.id, identity);
          if (previous && (priorIdentity ? priorIdentity !== identity : previous.peerChatId !== state.chatId || state.deleted)) {
            this.endpointSuspended.add(owner.id);
            this.invalidatePortal(owner.id);
            void this.endpointStore!.update(owner.id, { acceptsIncoming: false, permissions: [], externalAccess: false }).then(async () => {
              const binding = room.peer?.binding;
              if (binding && !this.endpoint(owner.id)?.deleted) await this.endpointStore!.refreshPeer(owner.id, binding);
              this.endpointSuspended.delete(owner.id);
              this.publishEndpoint(owner.id);
            }).catch(error => {
              this.endpointErrors.set(owner.id, String(error)); portalLog("warn", `Portal Chat binding revocation: ${String(error)}`);
            });
          } else if (endpoint && !this.endpointSuspended.has(owner.id)) this.applyEndpointPermissions(endpoint);
          portalChanged();
        },
      } } : {}),
      log: message => portalLog("info", `chat=${owner.id.slice(0, 8)} ${message}`),
      profileSnapshots: true,
      roomId: room.roomId!,
      chatId: this.endpointChatId(owner.id) || owner.id,
      machine: os.hostname(),
      chatName: owner.label,
      endpoint: room.url,
      commandCapabilities: this.portalCommandCaps,
      commandActivity: activity => {
        if (this.chatPortals.get(owner.id)?.external || !portalCommandRecorder) return;
        const chatId = this.endpointChatId(owner.id);
        if (!chatId) return;
        void portalCommandRecorder(chatId, activity).catch(error => portalLog("warn", `chat=${owner.id.slice(0, 8)} command trace not recorded: ${error instanceof Error ? error.message : String(error)}`));
      },
      taskAttempts: async requestId => {
        const binding = room.peer?.binding;
        const task = this.portalTaskChats.get(owner.id)?.get(requestId);
        const epoch = this.portalEpochs.get(owner.id) || 0;
        if (!binding || !task || task.pairId !== binding.pairId || !remoteTaskAttemptsReader) throw new Error("Original task lineage is unavailable on this connection.");
        const allowed = await this.portalConfirm(owner, `Share retry results with ${binding.peerName}?`,
          `Only attempts linked to original request ${requestId} in its executing Chat will be shared. The original task receipt stays unchanged. No task or model is run.`, "Share task attempts");
        if (!allowed) throw new Error("Sharing task retry results was declined.");
        if (room.peer?.binding !== binding || task.pairId !== binding.pairId || peerRoot !== getStorePath()
          || !vscode.workspace.isTrusted || (this.portalEpochs.get(owner.id) || 0) !== epoch) throw new Error("Portal changed while authorizing task result sharing.");
        const result = await remoteTaskAttemptsReader(task.chatId, requestId);
        if (room.peer?.binding !== binding || peerRoot !== getStorePath() || !vscode.workspace.isTrusted
          || (this.portalEpochs.get(owner.id) || 0) !== epoch) throw new Error("Portal changed before task results could be shared.");
        return result;
      },
      approveCommand: async (name, command, requestId) => {
        const chatId = this.endpointChatId(owner.id) || (!this.chatPortals.get(owner.id)?.external ? owner.id : undefined);
        if (chatId) {
          try {
            if (!portalMutationPolicy) throw new Error("The local Chat workflow policy is unavailable.");
            await portalMutationPolicy(chatId);
          } catch (error) {
            const message = `Portal command blocked by Chat workflow: ${error instanceof Error ? error.message : String(error)}`;
            log.error(message);
            void vscode.window.showErrorMessage(message);
            return false;
          }
        }
        if (this.endpoint(owner.id) && (!this.endpoint(owner.id)!.acceptsIncoming || this.endpoint(owner.id)!.deleted || this.endpointSuspended.has(owner.id))) return false;
        const epoch = this.portalEpochs.get(owner.id) || 0;
        const policy = this.portalPermissions.get(owner.id);
        const grants = policy?.snapshot().grants.filter(grant => grant.remaining.includes("code-execute")) || [];
        let allowed = policy?.allows("code-execute") === true;
        let expiresAt = Math.max(0, ...grants.map(grant => grant.expiresAt ?? Infinity));
        if (!allowed) {
          const answer = await this.portalPrompt(owner, { title: `Run direct command from ${name}?`,
            detail: `${JSON.stringify(command)}\n\nRuns on this machine without a model or Chat. This grants arbitrary code execution, including its operating-system and network effects. stdout/stderr and exit status will be shared with the controller.\n"Always allow" approves every direct command from ${name} until this Portal disconnects; revoke it anytime from Portal permissions.`,
            choices: [{ value: "run", label: "Run once" }, { value: "always", label: "Always allow until disconnected" }, { value: "permissions", label: "Configure permissions" }, { value: "cancel", label: "Cancel" }] });
          if (answer?.action === "always") {
            const binding = room.peer?.binding;
            if (!binding || (this.portalEpochs.get(owner.id) || 0) !== epoch) return false;
            let current = this.portalPermissions.get(owner.id);
            if (!current || current.isClosed || current.snapshot().connectionId !== binding.pairId) {
              current = new PortalPermissions({ chatId: owner.id, connectionId: binding.pairId });
              this.portalPermissions.set(owner.id, current);
            }
            current.grant({ mode: "scoped", permissions: ["code-execute"], durationMs: null });
            this.push();
            allowed = true;
          } else if (answer?.action === "permissions") {
            allowed = await this.configurePortalPermissions(owner, room) && this.portalPermissions.get(owner.id)?.allows("code-execute") === true;
          } else {
            allowed = answer?.action === "run";
          }
          expiresAt = Infinity;
        }
        if (allowed && (this.portalEpochs.get(owner.id) || 0) === epoch) {
          this.portalCommandApprovals.set(`${owner.id}:${requestId}`, { epoch, expiresAt });
          portalChanged();
          return true;
        }
        return false;
      },
      executeCommand: async (command, signal, requestId) => {
        const chatId = this.endpointChatId(owner.id) || (!this.chatPortals.get(owner.id)?.external ? owner.id : undefined);
        if (chatId) {
          if (!portalMutationGuard) throw new Error("The local Chat workflow policy is unavailable.");
          portalMutationGuard(chatId);
        }
        const approved = this.portalCommandApprovals.get(`${owner.id}:${requestId}`);
        this.portalCommandApprovals.delete(`${owner.id}:${requestId}`);
        if (!approved || approved.epoch !== (this.portalEpochs.get(owner.id) || 0)) throw new Error("Portal command authorization was revoked.");
        const binding = room.peer?.binding;
        const controller = new AbortController();
        const cancel = () => controller.abort();
        signal.addEventListener("abort", cancel, { once: true });
        if (signal.aborted) cancel();
        this.portalExecutions.set(owner.id, controller);
        const timer = setInterval(() => {
          if (!vscode.workspace.isTrusted || peerRoot !== getStorePath() || room.peer?.binding !== binding
            || approved.epoch !== (this.portalEpochs.get(owner.id) || 0) || Date.now() >= approved.expiresAt) cancel();
        }, 100);
        try {
          const root = path.join(context.globalStorageUri.fsPath, "portal-processes", owner.id);
          const defaultCwd = vscode.workspace.workspaceFolders?.find(folder => folder.uri.scheme === "file")?.uri.fsPath || os.homedir();
          return await executePortalCommand(root, `${binding?.pairId}:${requestId}`, command, defaultCwd, controller.signal);
        } finally {
          clearInterval(timer); signal.removeEventListener("abort", cancel);
          if (this.portalExecutions.get(owner.id) === controller) this.portalExecutions.delete(owner.id);
        }
      },
      autoReview: () => !this.chatPortals.get(owner.id)?.external && !this.endpoint(owner.id),
      connected: () => room.client.isConnected && vscode.workspace.isTrusted && peerRoot === getStorePath(),
      send: (target, packet) => {
        if (!vscode.workspace.isTrusted || getStorePath() !== peerRoot) throw new Error("Portal workspace or Knowledge Root changed; pair again.");
        if (packet.operation === "files") return room.client.sendPeerAndWait(target, packet);
        room.client.sendPeer(target, packet);
      },
      approvePair: async name => this.portalConfirm(owner, `Allow ${name} to control this machine?`,
        "This pairs two participants on the current Chat transport. Each remote instruction still requires separate local approval. Local Allow All does not apply.", "Pair"),
      approveSwap: async (name, role) => this.portalConfirm(owner,
        role === "controlled" ? `${name} asks to switch direction: ${name} would control this machine.` : `${name} asks to switch direction: you would control ${name}.`,
        role === "controlled"
          ? `After switching, ${name} can send tasks to this machine and you can no longer send tasks to ${name}. Each task still needs your approval here.`
          : `After switching, you can send tasks to ${name}, and ${name} can no longer send tasks here.`, "Allow switch"),
      approveTask: async (name, prompt) => {
        if (this.endpoint(owner.id) && (!this.endpointChatId(owner.id) || !this.endpoint(owner.id)!.acceptsIncoming || this.endpointSuspended.has(owner.id))) return false;
        onceShare = false;
        if (this.portalPermissions.get(owner.id)?.snapshot().grants.length) return true;
        const answer = await this.portalPrompt(owner, { title: `Run remote task from ${name}?`,
          detail: `${prompt}\n\n${this.chatPortals.get(owner.id)?.external ? "You must select an existing PKM Chat before execution; its model/history apply. No Chat is created automatically." : "Only this bound Chat executes, with its model/history."} Charges may apply. Run once shares this task's public answer, stages and tool names/status (not hidden reasoning or unrelated history). Files ALWAYS need a separate batch permit.`,
          choices: [{ value: "run", label: "Run once" }, { value: "permissions", label: "Configure permissions" }, { value: "cancel", label: "Decline" }] });
        if (answer?.action === "permissions") return this.configurePortalPermissions(owner, room);
        onceShare = answer?.action === "run";
        return onceShare;
      },
      execute: async (prompt, signal, requestId, profileSnapshot) => {
        if (!vscode.workspace.isTrusted || getStorePath() !== peerRoot) throw new Error("Peer task workspace or Knowledge Root changed; pair again.");
        if (!remoteChatExecutor) throw new Error("The local PKM Chat backend is unavailable.");
        const binding = room.peer?.binding;
        if (!binding) throw new Error("Portal disconnected before execution.");
        const entry = this.chatPortals.get(owner.id);
        const epoch = this.portalEpochs.get(owner.id) || 0;
        let executionChatId = this.endpointChatId(owner.id) || owner.id;
        if (this.endpoint(owner.id) && (!this.endpointChatId(owner.id) || this.endpoint(owner.id)!.deleted)) throw new Error("Bind a non-deleted PKM Chat before running model tasks.");
        if (entry?.external) {
          if (!portalChooseContext) throw new Error("Existing Chat selection is unavailable; no task was executed.");
          const selected = await portalChooseContext();
          if (!selected) throw new Error("Existing Chat selection cancelled; no task was executed.");
          if (signal.aborted || !vscode.workspace.isTrusted || getStorePath() !== peerRoot
            || this.chatPortals.get(owner.id) !== entry || (this.portalEpochs.get(owner.id) || 0) !== epoch
            || room.peer?.binding !== binding || !room.client.isConnected) throw new Error("Portal changed during Chat selection; no task was executed.");
          if (this.chatPortals.has(selected.id) || this.portalOwnerId(selected.id) !== selected.id) throw new Error("The selected Chat already owns a Portal or is executing another Portal task.");
          executionChatId = selected.id;
          entry.executionChatId = selected.id;
        }
        const policy = this.portalPermissions.get(owner.id);
        const leased = !!policy?.snapshot().grants.length;
        const localController = new AbortController();
        this.portalExecutions.set(owner.id, localController);
        const cancel = () => localController.abort();
        signal.addEventListener("abort", cancel, { once: true });
        if (signal.aborted) cancel();
        const deadline = setInterval(() => {
          // Transport blips are covered by the reconnect grace period; only a cleared pairing cancels the task.
          if (!vscode.workspace.isTrusted || getStorePath() !== peerRoot || room.peer?.binding !== binding
            || leased && !policy?.snapshot().grants.length) cancel();
        }, 500);
        let taskChats = this.portalTaskChats.get(owner.id);
        if (!taskChats) { taskChats = new Map(); this.portalTaskChats.set(owner.id, taskChats); }
        taskChats.set(requestId, { pairId: binding.pairId, chatId: executionChatId });
        while (taskChats.size > 1000) taskChats.delete(taskChats.keys().next().value!);
        try {
        const result = await remoteChatExecutor(prompt, localController.signal, requestId, executionChatId, observation => {
          if (room.peer?.binding !== binding || !room.client.isConnected || !binding.peerCapabilities?.includes("observations-v1")) return;
          const allowed = onceShare || this.portalPermissions.get(owner.id)?.allows("progress-read");
          const scopedObservation = entry?.external ? { ...observation, chatId: owner.id } : observation;
          room.peer.observe(allowed ? this.portalMirrorObservation(owner.id, scopedObservation) : { requestId: observation.requestId, chatId: owner.id, sequence: observation.sequence, at: observation.at, state: "restricted", visibility: "restricted" });
        }, {
          hostname: binding.peerMachine || binding.peerName, endpoint: binding.peerEndpoint || room.url,
          chatId: binding.peerChatId, chatName: binding.peerChatName || binding.peerName, participantId: binding.peerId,
        }, profileSnapshot);
        if (localController.signal.aborted) throw new Error("Portal execution interrupted by cancellation, authorization expiry or context change. External side effects may still exist; inspect the original task instead of replaying it.");
        return onceShare || this.portalPermissions.get(owner.id)?.allows("progress-read") || this.portalPermissions.get(owner.id)?.allows("chat-read")
          ? result : { requestId, chatId: owner.id, visibility: "restricted", message: "Task completed; answer sharing is not authorized." };
        } finally {
          signal.removeEventListener("abort", cancel);
          clearInterval(deadline);
          if (this.portalExecutions.get(owner.id) === localController) this.portalExecutions.delete(owner.id);
          if (entry?.executionChatId === executionChatId) delete entry.executionChatId;
          onceShare = false;
        }
      },
      invalidated: () => this.invalidatePortal(owner.id),
      reviewNeeded: review => {
        const entry = this.chatPortals.get(owner.id);
        if (!entry || entry.external || this.endpoint(owner.id)) return;
        if (!portalReviewReceiver) {
          log.error("Portal review could not be delivered: Chat backend is unavailable.");
          void vscode.window.showErrorMessage("Portal needs controller review; Chat backend is unavailable. Read the original request manually.");
          return;
        }
        void portalReviewReceiver(owner.id, review).catch(error => {
          log.error(`Portal controller review: ${String(error)}`);
          void vscode.window.showErrorMessage(`Portal controller review was not started: ${error instanceof Error ? error.message : String(error)}`);
        });
      },
      files: async payload => {
        if (!vscode.workspace.isTrusted || getStorePath() !== peerRoot) {
          this.invalidatePortal(owner.id);
          throw new Error("Portal file transfer stopped after a Root or trust change.");
        }
        await this.filesForPortal(owner, room).handle(payload);
      },
      changed: () => {
        const binding = room.peer?.binding;
        const state = binding ? `${binding.pairId}:${binding.role}` : "";
        if (!state && announced) void Promise.resolve().then(() => {
          if (this.portalTransports.get(owner.id) === room && room.peer === peer && !peer.binding) this.closePortalTransport(owner.id, "peer-session-unbound");
        });
        const current = this.chatPortals.get(owner.id);
        if (binding && this.endpoint(owner.id) && !this.endpoint(owner.id)?.paired) {
          void this.rememberEndpointPair(owner.id, room).catch(error => {
            this.endpointErrors.set(owner.id, String(error));
            portalLog("warn", `Portal pairing was not saved: ${String(error)}`);
            this.closePortalTransport(owner.id, "persistent-pair-save-failed");
            void vscode.window.showErrorMessage(`Portal pairing was not saved: ${String(error)}`);
          });
        }
        if (current?.room === room || !current?.room) this.portalJournal?.observe({ chatId: owner.id, chatLabel: current?.label || owner.label, external: !!current?.external, localMachine: os.hostname(), endpoint: room.url }, binding);
        if (binding && !this.portalPermissions.has(owner.id)) this.portalPermissions.set(owner.id, new PortalPermissions({ chatId: owner.id, connectionId: binding.pairId }));
        if (binding || !room.peer?.pendingInvitation) this.portalPendingLinks.delete(owner.id);
        if (state && state !== announced && current?.external) void this.offerExternalAuthorization(owner.id).catch(error => log.error(`External Portal authorization: ${String(error)}`));
        if (state && state !== announced) {
          portalLog("info", `chat=${owner.id.slice(0, 8)} channel=${(room.roomId || "-").slice(0, 8)} pairing active role=${binding!.role} peer=${binding!.peerName}#${binding!.peerId.slice(0, 8)}${binding!.peerMachine ? ` machine=${binding!.peerMachine}` : ""}`);
          vscode.window.setStatusBarMessage(`$(remote) Portal connected: ${binding!.role} · ${binding!.peerName}`, 10_000);
        }
        if (state !== announced) void agentSessionProjectStateData().then(
          data => postToPanel({ command: "projectState", data }),
          error => log.error(`Portal navigation refresh: ${String(error)}`),
        );
        announced = state;
        portalChanged();
        this.push();
      },
      error: error => { log.error(`peer collaboration: ${error.message}`); void vscode.window.showErrorMessage(`PKM Portal: ${error.message}`); },
    });
    room.peer = peer;
    return peer;
  }

  private filesForPortal(owner: { id: string; label: string }, room: RoomConn): PortalFiles {
    const existing = this.portalFiles.get(owner.id);
    if (existing) return existing;
    const binding = room.peer?.binding;
    if (!binding || !room.client.isConnected) throw new Error("File transfer requires a live paired Portal.");
    if (!binding.peerCapabilities?.includes("files-v1")) throw new Error("Remote Host lacks approved file-transfer support. Upgrade both Hosts and pair again first.");
    const root = getStorePath();
    const epoch = this.portalEpochs.get(owner.id) || 0;
    const active = () => {
      if ((this.portalEpochs.get(owner.id) || 0) !== epoch || room.peer?.binding !== binding || !room.client.isConnected || root !== getStorePath() || !vscode.workspace.isTrusted) throw new Error("Portal changed; file batch is not authorized.");
    };
    const guard = () => {
      active();
      const chatId = this.endpointChatId(owner.id) || (!this.chatPortals.get(owner.id)?.external ? owner.id : undefined);
      if (chatId) {
        if (!portalMutationGuard) throw new Error("The local Chat workflow policy is unavailable.");
        portalMutationGuard(chatId);
      }
    };
    const preparePolicy = async () => {
      active();
      const chatId = this.endpointChatId(owner.id) || (!this.chatPortals.get(owner.id)?.external ? owner.id : undefined);
      if (chatId) {
        if (!portalMutationPolicy) throw new Error("The local Chat workflow policy is unavailable.");
        await portalMutationPolicy(chatId);
      }
      guard();
    };
    let lastTransferPublish = 0;
    const lastChatPublish = new Map<string, number>();
    const files = new PortalFiles({
      assertActive: guard,
      controlled: () => binding.role === "controlled",
      send: payload => { active(); return room.peer!.sendFiles(payload); },
      destination: async () => {
        await preparePolicy();
        const selected = await vscode.window.showOpenDialog({ title: `Save Portal files from ${binding.peerName} (never auto-install)`, canSelectMany: false, canSelectFolders: true, canSelectFiles: false });
        guard();
        return selected?.[0]?.fsPath;
      },
      approve: async batch => {
        await preparePolicy();
        const allowed = await this.portalConfirm(owner, `Permit file batch ${batch.direction === "incoming" ? "from" : "to"} ${binding.peerMachine || binding.peerName}?`,
          `Chat: ${owner.label}\nPeer: ${binding.peerChatName || binding.peerName} · ${room.url}\nDirection: ${batch.direction}\nTotal: ${batch.totalBytes} bytes\nDestination: ${batch.destination || "remote user-selected directory"}\n${batch.files.map((file, index) => `${file.name} · ${file.size} bytes · SHA-256 ${file.sha256}${batch.sources?.[index] ? `\nSource: ${batch.sources[index]}` : ""}`).join("\n")}\n\nOnly this immutable batch. No overwrite, execution, installation or reload. Allow All never skips controlled-side file-transfer approval.`,
          "Permit this batch");
        guard();
        return allowed;
      },
      onStatus: status => {
        let records = this.portalTransfers.get(owner.id);
        if (!records) { records = new Map(); this.portalTransfers.set(owner.id, records); }
        const previous = records.get(status.transferId);
        records.set(status.transferId, status);
        while (records.size > 32) records.delete(records.keys().next().value!);
        if (!this.chatPortals.get(owner.id)?.external && portalTransferRecorder
          && (previous?.state !== status.state || Date.now() - (lastChatPublish.get(status.transferId) || 0) >= 1000)) {
          lastChatPublish.set(status.transferId, Date.now());
          while (lastChatPublish.size > 32) lastChatPublish.delete(lastChatPublish.keys().next().value!);
          const chatId = this.endpointChatId(owner.id);
          if (chatId) void portalTransferRecorder(chatId, status, binding.peerName)
            .catch(error => portalLog("warn", `chat=${owner.id.slice(0, 8)} file trace not recorded: ${error instanceof Error ? error.message : String(error)}`));
        }
        if (previous?.state !== status.state || Date.now() - lastTransferPublish >= 100) {
          lastTransferPublish = Date.now();
          portalChanged();
        }
      },
    });
    this.portalFiles.set(owner.id, files);
    return files;
  }

  private async waitForRoom(predicate: () => boolean, timeoutMs: number, failure: string, rejection?: () => string | undefined): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (!predicate()) {
      const rejected = rejection?.();
      if (rejected) throw new Error(rejected);
      if (Date.now() > deadline) throw new Error(failure);
      await new Promise(resolve => setTimeout(resolve, 200));
    }
  }

  private static portalAlias(): string {
    return `${os.userInfo().username || "user"}@${os.hostname().split(".")[0] || "host"}`.slice(0, 60);
  }

  private async startPortal(context: vscode.ExtensionContext, owner: { id: string; label: string }, role: "controller" | "controlled"): Promise<void> {
    const peerRoot = this.portalPreflight();
    const hub = await this.startHub(vscode.workspace.getConfiguration("personalKnowledge").get<number>("chatHubPort") ?? 7345, true);
    if (!hub.ok) throw new Error(`Couldn't start the Chat Hub: ${hub.error || "unknown error"}`);
    const channel = this.hub!.createPortalChannel();
    const created = { room:"Portal", roomId:channel.channelId, secret:channel.secret };
    const user = `${ChatRoomManager.portalAlias().slice(0, 40)}-${owner.id.slice(0, 8)}`;
    this.portalConnections.set(owner.id, { url: `ws://127.0.0.1:${this.hubPort}${PORTAL_TRANSPORT_PATH}`, room: created.room, roomId: created.roomId, user, secret: created.secret, host: true, port: this.hubPort, transport:"portal" });
    try {
    const room = this.joinPortalTransport(owner.id, { url: `ws://127.0.0.1:${this.hubPort}${PORTAL_TRANSPORT_PATH}`, room: created.room, roomId: created.roomId, user, token: created.secret, cid: `${getChatCid(context)}${owner.id.replace(/-/g, "")}` });
    this.chatPortals.get(owner.id)!.room = room;
    await this.waitForRoom(() => room.client.isConnected && !!room.client.participantId, 30_000, "The Portal transport did not connect.");
    const peer = this.ensurePeer(room, peerRoot, owner, context);
    const code = role === "controller" ? peer.offer() : peer.invite();
    // In a Remote window this forwards the Hub port to the computer running the VS Code UI.
    const external = await vscode.env.asExternalUri(vscode.Uri.parse(`http://localhost:${this.hubPort}`));
    if (!vscode.workspace.isTrusted || getStorePath() !== peerRoot || this.chatPortals.get(owner.id)?.room !== room
      || !room.client.isConnected || room.peer !== peer || !peer.pendingInvitation) throw new Error("Portal changed while preparing the connection code; create a new Portal.");
    if (external.scheme !== "http" && external.scheme !== "https") throw new Error("Portal forwarding returned an unsupported address.");
    const url = `${external.scheme === "https" ? "wss" : "ws"}://${external.authority}${PORTAL_TRANSPORT_PATH}`;
    assertPeerEndpoint(url);
    const link = createPortalLink({ url, room: created.room, roomId: created.roomId, secret: created.secret, code, controller: room.client.participantId, name: room.user, role });
    const pendingInvitation = peer.pendingInvitation;
    if (pendingInvitation) this.portalPendingLinks.set(owner.id, { link, expiresAt: pendingInvitation.expiresAt, endpoint: url });
    portalLog("info", `chat=${owner.id.slice(0, 8)} channel=${created.roomId.slice(0, 8)} link issued role=${role} endpoint=${url} local=${this.hubPort} expires=${pendingInvitation ? new Date(pendingInvitation.expiresAt).toISOString() : "-"}`);
    portalChanged();
    await vscode.env.clipboard.writeText(link);
    vscode.window.setStatusBarMessage(`$(remote) Private Portal link copied · ${role} · expires in 10 minutes. Re-copy or void it in this Chat.`, 10_000);
    } catch (error) {
      this.closePortalTransport(owner.id, `portal-open-failed: ${error instanceof Error ? error.message : String(error)}`);
      this.portalPendingLinks.delete(owner.id);
      this.chatPortals.get(owner.id)!.room = undefined;
      portalChanged();
      throw error;
    }
  }

  private async acceptPortal(context: vscode.ExtensionContext, owner: { id: string; label: string }, input: string): Promise<void> {
    try { await this.acceptPortalLink(context, owner, input); }
    catch (error) {
      portalLog("warn", `chat=${owner.id.slice(0, 8)} accept failed: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }

  private async acceptPortalLink(context: vscode.ExtensionContext, owner: { id: string; label: string }, input: string): Promise<void> {
    const peerRoot = this.portalPreflight();
    const link = parsePortalLink(input);
    portalLog("info", `chat=${owner.id.slice(0, 8)} channel=${link.roomId.slice(0, 8)} redeeming link from ${link.name || "-"} role=${link.role || "-"} endpoint=${link.url}`);
    if ([...this.chatPortals.values()].some(entry => entry.room?.roomId === link.roomId && entry.id !== owner.id)) throw new Error("This Portal is already attached to another Chat. Create a separate link for this Chat.");
    const controlsRemote = link.role === "controlled";
    const ALLOW = controlsRemote ? "Connect as controller" : "Allow control";
    const consent = await this.portalConfirm(owner, controlsRemote
      ? `Connect Chat "${owner.label}" as controller of ${link.name || "the remote Chat"}?`
      : `Let ${link.name || "the Portal initiator"} control Chat "${owner.label}"?`,
      `Endpoint: ${link.url}\n${controlsRemote ? "This Chat will send tasks to the remote Chat, which must approve pairing and each task." : "The initiator can send tasks only to this bound Chat. Each task and tool needs local approval; model charges may apply."} Switching direction needs explicit approval on both sides.`,
      ALLOW);
    if (!consent) return;
    await preflightPortalEndpoint(link.url);
    if (getStorePath() !== peerRoot || !vscode.workspace.isTrusted) throw new Error("Portal workspace or Knowledge Root changed during approval.");
    if ([...this.chatPortals.values()].some(entry => entry.room?.roomId === link.roomId && entry.id !== owner.id)) throw new Error("This Portal was attached to another Chat during approval.");
    let user = ChatRoomManager.portalAlias();
    if (user === link.name) user = `${user}-2`;
    const dedicated = new URL(link.url).pathname === PORTAL_TRANSPORT_PATH;
    this.portalConnections.set(owner.id, { url: link.url, room: link.room, roomId: link.roomId, user, secret: link.secret, host: false, ...(dedicated ? { transport:"portal" as const } : {}) });
    const room = this.joinPortalTransport(owner.id, { url: link.url, room: link.room, roomId: link.roomId, user, token: link.secret,
      cid: dedicated ? `${getChatCid(context)}${owner.id.replace(/-/g, "")}` : getChatCid(context) });
    this.chatPortals.get(owner.id)!.room = room;
    await this.waitForRoom(() => room.client.isConnected && room.members.some(member => member.participantId === link.controller && member.present !== false), 30_000,
      `Couldn't reach the Portal initiator at ${link.url}. Keep the initiator's VS Code window open, and run this window on the computer where the initiator's window is displayed.`,
      () => !room.client.willReconnect ? room.statusDetail || "Portal transport rejected the connection." : undefined);
    const peer = this.ensurePeer(room, peerRoot, owner, context);
    if (controlsRemote) peer.pair(link.controller, link.code);
    else peer.accept(link.controller, link.code);
    await this.waitForRoom(() => !!peer.binding, 30_000, "Portal pairing was not approved, expired, or the peer disconnected. No task was sent.",
      () => peer.pairingFailure);
    portalLog("info", `chat=${owner.id.slice(0, 8)} channel=${link.roomId.slice(0, 8)} paired with ${peer.binding?.peerName || "-"} role=${peer.binding?.role || "-"}`);
    vscode.window.setStatusBarMessage("$(remote) PKM Portal: connecting…", 10_000);
  }

  private async portalActions(room: RoomConn, peer: PeerSession, switchOnly = false): Promise<void> {
    const binding = peer.binding!;
    const owner = [...this.chatPortals.values()].find(item => item.room === room);
    if (!owner) throw new Error("Portal owner is unavailable.");
    const root = getStorePath(), epoch = this.portalEpochs.get(owner.id) || 0;
    const SWITCH = "Switch control direction…";
    const actions = ["Status", "Permissions", "Send files", ...(binding.role === "controller" ? ["Send task", ...(binding.peerCapabilities?.includes("commands-v1") ? ["Run command (no model)"] : []), "Cancel task"] : []), SWITCH, "Disconnect"];
    const answer = switchOnly ? undefined : await this.portalPrompt(owner, {
      title: `Portal · ${binding.peerName}`, detail: `Current direction: ${binding.role}. Each action applies only to this Chat and pairing.`,
      choices: [{ value: "submit", label: "Continue" }, { value: "cancel", label: "Cancel" }],
      form: { type: "object", required: ["action"], properties: {
        action: { type: "string", title: "Action", enum: actions },
      } },
    });
    const selected = switchOnly ? SWITCH : answer?.action === "submit" ? answer.fields.action : undefined;
    if (selected === "Send files") {
      const owner = [...this.chatPortals.values()].find(item => item.room === room);
      if (!owner) throw new Error("Portal owner is unavailable.");
      const selectedFiles = await vscode.window.showOpenDialog({ title: "Select Portal file batch", canSelectMany: true, canSelectFiles: true, canSelectFolders: false });
      if (!selectedFiles?.length) return;
      const offered = await this.filesForPortal(owner, room).offer(selectedFiles.map(uri => uri.fsPath));
      void offered.done.then(() => portalChanged(), error => log.error(`Portal file transfer: ${String(error)}`));
    } else if (selected === "Permissions") {
      const owner = [...this.chatPortals.values()].find(item => item.room === room);
      if (!owner) throw new Error("Portal owner is unavailable.");
      await this.configurePortalPermissions(owner, room);
    } else if (selected === "Run command (no model)") {
      const command = await this.portalPrompt(owner, { title: `Direct command on ${binding.peerMachine || binding.peerName}`,
        detail: "No LLM or Chat is used. Only the executing machine grants command execution. A shell must be explicitly selected as the program; argument text is not automatically interpreted as shell code.",
        choices: [{ value: "submit", label: "Send command" }, { value: "cancel", label: "Cancel" }],
        form: { type: "object", required: ["program", "arguments"], properties: {
          program: { type: "string", title: "Executable (on remote machine)", minLength: 1, maxLength: 1024 },
          arguments: { type: "string", title: "Arguments as a JSON string array", default: "[]", maxLength: 8000 },
          cwd: { type: "string", title: "Remote working directory (empty = remote workspace)", maxLength: 4096 },
          timeoutSeconds: { type: "integer", title: "Timeout in seconds", minimum: 1, maximum: 86400, default: 60 },
        } },
        verify: async fields => { parsePortalCommand({ ...fields, arguments: JSON.parse(String(fields.arguments)), cwd: fields.cwd || undefined }); },
      });
      if (command?.action === "submit") {
        if (peer.binding !== binding || !room.client.isConnected || root !== getStorePath()
          || !vscode.workspace.isTrusted || (this.portalEpochs.get(owner.id) || 0) !== epoch) throw new Error("Portal changed; no command was sent.");
        const requestId = peer.submitCommand({ ...command.fields, arguments: JSON.parse(String(command.fields.arguments)), cwd: command.fields.cwd || undefined });
        vscode.window.setStatusBarMessage(`$(terminal) Direct command sent (${requestId}); awaiting executing Host authorization.`, 10_000);
      }
    } else if (selected === "Send task") {
      const task = await this.portalPrompt(owner, { title: `Remote task for ${binding.peerName}`,
        detail: "The target must approve this exact instruction. Existing local permissions are not shared. Model charges may apply.",
        choices: [{ value: "submit", label: "Send task" }, { value: "cancel", label: "Cancel" }],
        form: { type: "object", required: ["prompt"], properties: { prompt: { type: "string", title: "Instruction", minLength: 1, maxLength: 16_000 } } },
      });
      if (task?.action === "submit") {
        const prompt = String(task.fields.prompt);
        const owner = [...this.chatPortals.values()].find(item => item.room === room);
        if (!owner || !owner.external && !portalProfileReview) throw new Error("Portal Profile review is unavailable.");
        const snapshot = owner.external ? undefined : await portalProfileReview?.(owner.id);
        if (peer.binding !== binding || !room.client.isConnected || root !== getStorePath()
          || !vscode.workspace.isTrusted || (this.portalEpochs.get(owner.id) || 0) !== epoch) throw new Error("Portal changed during task review; no task was sent.");
        const requestId = peer.submit(prompt, undefined, snapshot);
        vscode.window.setStatusBarMessage(`$(remote) Remote task sent (${requestId}). Delivery is not execution approval; inspect this Chat's Portal status.`, 10_000);
      }
    } else if (selected === "Cancel task") {
      const requests = [...peer.receipts.values()].filter(receipt => ["running", "awaiting-approval"].includes(receipt.state)).map(receipt => receipt.requestId);
      if (!requests.length) throw new Error("No running or awaiting-approval Portal task to cancel.");
      if (requests.length > 100) throw new Error("More than 100 pending Portal tasks; cancel a specific original request through the control API.");
      const cancel = await this.portalPrompt(owner, { title: "Cancel original remote request", detail: "Recorded effects are not undone and the request will not be replayed.",
        choices: [{ value: "submit", label: "Cancel task" }, { value: "cancel", label: "Keep running" }],
        form: { type: "object", required: ["request"], properties: { request: { type: "string", title: "Request", enum: requests } } },
      });
      if (cancel?.action === "submit") peer.cancel(String(cancel.fields.request));
    } else if (selected === SWITCH) {
      const next = binding.role === "controller" ? "controlled" : "controller";
      const REQUEST = "Request switch";
      const confirmed = await this.portalConfirm(owner, next === "controlled" ? `Let ${binding.peerName} control this machine instead?` : `Ask to control ${binding.peerName} instead?`,
        `Roles change only after ${binding.peerName} also explicitly allows it. Until then nothing changes.${next === "controlled" ? " Afterwards each task from them still needs your approval here." : ""}`,
        REQUEST);
      if (confirmed) {
        peer.requestSwap();
        vscode.window.setStatusBarMessage(`$(remote) PKM Portal: waiting for ${binding.peerName} to allow the switch…`, 15_000);
      }
    } else if (selected === "Disconnect") {
      peer.revoke();
      const owner = [...this.chatPortals.values()].find(item => item.room === room);
      if (owner) { this.closePortalTransport(owner.id, "user-disconnect"); owner.room = undefined; portalChanged(); this.push(); }
    } else if (selected === "Status") {
      await this.portalPrompt(owner, { title: "Portal status",
        detail: JSON.stringify(this.portalStatus(owner.id), null, 2),
        choices: [{ value: "close", label: "Close" }] });
    }
  }

  private static roomKey(url: string, room: string, roomId?: string): string {
    return chatRoomIdentity(url, room, roomId);
  }

  setAdvertisedHost(host: string): void {
    if (!this.hub) {
      this.hub = new ChatHub(hubLog);
      this.bindHub(this.hub);
    }
    this.hub.setAdvertisedHost(host);
  }

  private advertisedHost(): string { return this.hub?.publicHost || ChatHub.localIp(); }

  private static managedAgentPrompt(name: string, role: string): string {
    return [
      `You are ${name}, an expert participant in a multi-agent engineering discussion.`,
      `Your role and background: ${role}`,
      "Chatroom protocol: remain in standby while connected. Respond only to messages directed to you or @all, then return to standby. The host may disconnect you with /stop.",
      "Respond to the latest addressed message using relevant shared context. Ask focused questions when evidence is missing. Propose concrete next steps, challenge weak assumptions, and keep replies concise. Do not emit Chatroom slash commands.",
    ].join("\n");
  }

  private bindHub(hub: ChatHub): void {
    hub.onApprovalsChanged(() => this.push());
    hub.onRoomDeactivating(async roomId => {
      const room = [...this.rooms.values()].find(candidate => candidate.roomId === roomId);
      try { await this.meetingLifecycle?.adjournRoom(roomId, room?.user); }
      catch (error) { log.warn(`chat: couldn't adjourn Meeting while closing Room: ${(error as Error).message}`); }
    });
  }

  private roomNameForId(roomId: string): string {
    return this.hub?.adminRooms().find(room => room.roomId === roomId)?.room || roomId.slice(0, 8);
  }

  /** Configure on-disk chat archiving (dir + byte cap). Applies to the live hub too. */
  configureArchive(dir: string, limitBytes: number): void {
    this.archiveDir = dir;
    this.archiveLimitBytes = limitBytes;
    this.hub?.configureArchive(dir, limitBytes);
  }

  configurePersistence(rootDir: string, installationId: string, secretStorage: vscode.SecretStorage): void {
    this.persistenceRoot = rootDir;
    this.installationId = installationId;
    this.secretStorage = secretStorage;
    this.meetingStore = new MeetingStateStore(rootDir, path.join(path.dirname(rootDir), "notes"));
    this.meetingLifecycle = new ChatMeetingLifecycle(this.meetingStore);
    if (!isTopLevelPrivate("notes", "Chatroom Meetings")) setTopLevelPrivacy("notes", "Chatroom Meetings", true);
    this.hub?.configureLifecycle(rootDir, this.archiveLimitBytes, installationId, secretStorage);
    void this.refreshStoredRooms().catch(error => log.warn(`chat: couldn't refresh Stored Rooms: ${(error as Error).message}`));
  }

  get activeRoom(): RoomConn | undefined { return this.rooms.get(this.activeKey); }
  activateRoom(url: string, room: string, roomId?: string): boolean {
    const key = ChatRoomManager.roomKey(url, room, roomId);
    if (!this.rooms.has(key)) return false;
    this.setActive(key);
    return true;
  }
  activateRoomById(roomId: string): boolean {
    const room = [...this.rooms.values()].find(candidate => candidate.roomId === roomId);
    if (!room) return false;
    this.setActive(room.key);
    return true;
  }
  async closeHostedRoomById(roomId: string): Promise<void> {
    const room = [...this.rooms.values()].find(candidate => candidate.roomId === roomId);
    if (!room) throw new Error("The active hosted Room was not found.");
    await this.closeOrLeaveRoom(room.key);
  }
  get hubIsRunning(): boolean { return !!this.hub?.isRunning; }
  get hubPort(): number { return this.hub?.port ?? 0; }

  /** Push the full snapshot (room list + active room detail) to the webview. */
  push(): void {
    const snapshot = this.state();
    postToPanel({ command: "chatState", data: snapshot });
    this.postPortalConnections();
    const status = summarizeChatNavigation(snapshot as any);
    const signature = `${status.kind}:${status.description}`;
    if (signature !== this.navigationStatusSignature) {
      this.navigationStatusSignature = signature;
      _treeProvider?.refreshChatStatus();
    }
  }

  private roomSummary(r: RoomConn) {
    return { key: r.key, room: r.room, roomId: r.roomId, url: r.url, status: r.status, unread: r.unread, selfHost: r.selfHost };
  }

  private meetingRoomId(room: RoomConn): string {
    return room.roomId || createHash("sha256").update(room.key).digest("hex");
  }

  private publishMeetingSnapshot(room: RoomConn): void {
    if (!room.selfHost || !this.meetingStore) return;
    room.meetings = this.meetingStore.snapshot(this.meetingRoomId(room));
    room.client.sendMeetingSnapshot({ ...room.meetings, trash: [] } as unknown as Record<string, unknown>);
  }

  meetingNoteKey(meetingId: string): string {
    const room = this.activeRoom;
    if (!room?.selfHost || !this.meetingStore) throw new Error("The canonical Meeting Note is available from its Host.");
    const snapshot = this.meetingStore.snapshot(this.meetingRoomId(room));
    const meeting = [snapshot.current, ...snapshot.history].find(candidate => candidate?.id === meetingId);
    if (!meeting) throw new Error("Meeting Note was not found.");
    return meeting.markdownPath.replace(/\\/g, "/").replace(/\.md$/i, "");
  }

  async startActiveMeeting(requestId: string, expectedRevision: number): Promise<void> {
    const room = this.activeRoom;
    if (!room || !room.selfHost) throw new Error("Only the Room Host can start a Meeting in this version.");
    if (!this.meetingStore) throw new Error("Meeting storage is not configured.");
    const trigger = [...room.messages].reverse().find(message => !message.system && message.mode === "discuss");
    if (!trigger) throw new Error("Send a Discuss message before starting the Meeting.");
    const problem = trigger.text.trim();
    const title = problem.split(/\r?\n/)[0].replace(/^#+\s*/, "").slice(0, 100) || "Chatroom Meeting";
    await this.meetingStore.startMeeting({
      roomId: this.meetingRoomId(room), roomName: room.room, title, problemStatement: problem,
      owner: trigger.discussionLead || room.user, lead: trigger.discussionLead || room.user, recorder: room.user,
      participants: [...new Set([room.user, ...room.members.filter(member => member.present !== false).map(member => member.user)])],
      host: room.user, triggerMessageId: trigger.id,
      requestId, expectedRevision,
    });
    this.publishMeetingSnapshot(room);
    this.push();
  }

  async adjournActiveMeeting(meetingId: string, requestId: string, expectedRevision: number): Promise<void> {
    const room = this.activeRoom;
    if (!room || !room.selfHost) throw new Error("Only the Room Host can adjourn a Meeting in this version.");
    if (!this.meetingStore) throw new Error("Meeting storage is not configured.");
    await this.meetingStore.adjournMeeting({
      roomId: this.meetingRoomId(room), meetingId, actor: room.user, requestId, expectedRevision,
    });
    this.publishMeetingSnapshot(room);
    this.push();
  }

  async mutateMeetingTrash(action: "trash" | "restore" | "delete", meetingId: string, requestId: string, expectedRevision: number): Promise<void> {
    const room = this.activeRoom;
    if (!room || !room.selfHost) throw new Error("Only the Room Host can change Meeting Trash.");
    if (!this.meetingStore) throw new Error("Meeting storage is not configured.");
    const input = { roomId: this.meetingRoomId(room), meetingId, actor: room.user, requestId, expectedRevision };
    if (action === "trash") await this.meetingStore.moveToTrash(input);
    else if (action === "restore") await this.meetingStore.restoreFromTrash(input);
    else await this.meetingStore.permanentlyDelete(input);
    this.publishMeetingSnapshot(room);
    this.push();
  }

  state(): object {
    const active = this.activeRoom;
    const locallyActiveRoomIds = new Set(this.hub?.adminRooms().map(room => room.roomId) || []);
    return {
      rooms: [...this.rooms.values()].map(r => this.roomSummary(r)),
      activeKey: this.activeKey,
      active: active ? {
        key: active.key, room: active.room, url: active.url,
        status: active.status, statusDetail: active.statusDetail,
        members: active.members, messages: active.messages, self: active.user,
        selfHost: active.selfHost, selfMuted: active.selfMuted,
        hasRoomKey: !!this.getRoomKey(active.room),
        agentStates: active.agentStates,
        files: [...active.files.values()].map(f => ({ fileId: f.meta.fileId, name: f.meta.name, from: f.from, size: f.meta.size, mime:f.meta.mime })),
        meetings: active.selfHost && this.meetingStore ? this.meetingStore.snapshot(this.meetingRoomId(active)) : active.meetings,
      } : null,
      hubRunning: !!this.hub?.isRunning,
      hubUrl:     this.hub?.isRunning ? `ws://${this.advertisedHost()}:${this.hub.port}` : "",
      hubHttpUrl: this.hub?.isRunning ? `http://${this.advertisedHost()}:${this.hub.port}` : "",
      hubPort:    this.hub?.port ?? 0,
      hubAdminRooms: this.hub?.isRunning
        ? this.hub.adminRooms().map(r => ({ ...r, hasKey: this.hostedKeys.has(r.roomId) }))
        : [],
      pendingApprovals: [],
      storedRooms: this.storedRooms.filter(room => !locallyActiveRoomIds.has(room.roomId)),
      managedAgents: [...this.managedAgents.values()].map(agent => ({
        id: agent.id, name: agent.name, icon: agent.icon, role: agent.role, backend: agent.backend.label,
        roomKey: agent.roomKey, status: agent.status,
        active: agent.active, busy: agent.busy,
      })),
    };
  }

  hostedRoomsForNavigation(): HostedRoomNavigationItem[] {
    const active = new Map(this.hub?.adminRooms().map(room => [room.roomId, room]) || []);
    const rows: HostedRoomNavigationItem[] = [...active.values()].map(room => ({
      roomId: room.roomId, roomName: room.room, active: true, canRehost: true,
    }));
    for (const stored of this.storedRooms) {
      if (active.has(stored.roomId)) continue;
      rows.push({ roomId: stored.roomId, roomName: stored.roomName, active: false,
        activeElsewhere: stored.activeElsewhere, activeUrl: stored.activeUrl, canForceClose: stored.canForceClose, canRehost: stored.canRehost, unavailableReason: stored.unavailableReason });
    }
    return rows.sort((left, right) => left.roomName.localeCompare(right.roomName));
  }

  async addManagedAgent(context: vscode.ExtensionContext): Promise<void> {
    const room = this.activeRoom;
    if (!room || !room.selfHost) {
      vscode.window.showWarningMessage("Host and open a room before adding a managed agent.");
      return;
    }
    const secret = this.getRoomKey(room.room);
    if (!secret) {
      vscode.window.showWarningMessage(`No host secret is available for room "${room.room}".`);
      return;
    }
    const backends = await listAiBackends(context);
    if (!backends.length) {
      vscode.window.showWarningMessage("No AI backend is available. Sign in to Copilot or configure an AI endpoint.");
      return;
    }
    const picked = await vscode.window.showQuickPick(
      backends.map(backend => ({ label: backend.label, backend })),
      { placeHolder: "Model for this Chatroom agent" },
    );
    if (!picked) return;
    const name = (await vscode.window.showInputBox({
      prompt: "Agent display name", placeHolder: "DockerAgent",
      validateInput: value => value.trim() ? undefined : "Enter a unique agent name",
    }))?.trim();
    if (!name) return;
    if ([...this.managedAgents.values()].some(agent => agent.roomKey === room.key && agent.name.toLowerCase() === name.toLowerCase())) {
      vscode.window.showWarningMessage(`Managed agent "${name}" already exists in this room.`);
      return;
    }
    this.createManagedAgent(context, room, secret, name, picked.backend, ChatRoomManager.DEFAULT_MANAGED_AGENT_ROLE);
  }

  private createManagedAgent(
    context: vscode.ExtensionContext,
    room: RoomConn,
    secret: string,
    name: string,
    backend: AiBackend,
    role: string,
  ): void {
    const id = randomBytes(6).toString("hex");
    const agent: ManagedChatAgent = {
      id, name, icon: "🤖", backend, role, roomKey: room.key, client: null as any,
      systemPrompt: ChatRoomManager.managedAgentPrompt(name, role),
      messages: [], pendingMessages: [], status: "connecting", active: true, busy: false, generation: 0,
    };
    agent.client = new ChatClient({
      onStatus: (status, detail) => {
        agent.status = detail ? `${status}: ${detail}` : status;
        if (status === "connected") {
          agent.active = true;
          agent.client.sendAgentState("standby");
          void this.drainManagedAgentMessages(context, agent);
        }
        if (status === "disconnected") {
          agent.active = false;
          agent.busy = false;
          agent.generation++;
        }
        this.push();
      },
      onMessage: message => this.onManagedAgentMessage(context, agent, message),
      onHistory: messages => { agent.messages = messages.slice(-80); },
      onPresence: () => {}, onFileComplete: () => {}, onAgentState: () => {},
      onRejected: (_code, message) => { agent.status = `error: ${message}`; agent.active = false; this.push(); },
      onRenamed: newName => { agent.name = newName; this.push(); },
      onRekey: () => {},
    }, message => log.debug(`managed-agent[${name}]: ${message}`));
    this.managedAgents.set(id, agent);
    agent.client.connect({ url: room.url, room: room.room, roomId: room.roomId, user: name, token: secret, kind: "agent", cid: `managed-${id}`, temporary: true });
    log.action("chat.managedAgent.add", { room: room.room, name, backend: backend.id });
    this.push();
  }

  private ensureDirectedReply(text: string, target: string): string {
    const value = text.trim();
    if (/@(?:"[^"\n]{1,60}"|[\p{L}\p{N}_][\p{L}\p{N}_-]{0,59})/u.test(value)) return value;
    const cleaned = target.replace(/"/g, "").trim() || "Host";
    const mention = /^[A-Za-z0-9_][\w-]{0,59}$/.test(cleaned) ? `@${cleaned}` : `@"${cleaned}"`;
    return `${mention} ${value}`;
  }

  private onManagedAgentMessage(context: vscode.ExtensionContext, agent: ManagedChatAgent, message: ChatMessage): void {
    if (message.id && agent.messages.some(existing => existing.id === message.id)) return;
    agent.messages.push(message);
    if (agent.messages.length > 80) agent.messages.splice(0, agent.messages.length - 80);
    const text = String(message.text || "").trim();
    if (!agent.active || message.from.toLowerCase() === agent.name.toLowerCase()) return;
    const directed = messageAddressesManagedAgent(message, agent.name);
    if (!directed) return;
    if (!agent.pendingMessages.some(existing => existing.id === message.id)) agent.pendingMessages.push(message);
    if (agent.pendingMessages.length > 32) agent.pendingMessages.splice(0, agent.pendingMessages.length - 32);
    if (agent.busy) {
      agent.status = `queued: ${agent.pendingMessages.length}`;
      this.push();
      return;
    }
    void this.drainManagedAgentMessages(context, agent);
  }

  private async drainManagedAgentMessages(context: vscode.ExtensionContext, agent: ManagedChatAgent): Promise<void> {
    if (!agent.active || agent.busy) return;
    const message = agent.pendingMessages.shift();
    if (!message) return;
    const generation = agent.generation;
    agent.busy = true;
    agent.status = agent.pendingMessages.length ? `working; ${agent.pendingMessages.length} queued` : "working";
    agent.client.sendAgentState("thinking");
    this.push();
    let failure = "";
    try {
      const messageIndex = agent.messages.findIndex(item => item.id === message.id);
      const transcriptEnd = messageIndex >= 0 ? messageIndex + 1 : agent.messages.length;
      const transcript = agent.messages.slice(Math.max(0, transcriptEnd - 30), transcriptEnd)
        .filter(item => !item.system)
        .map(item => `${item.from || "system"}: ${item.text}`)
        .join("\n");
      const prompt = `${agent.systemPrompt}\n\nChatroom transcript:\n${transcript}\n\nReply as ${agent.name} to the latest turn. Return only the message to post.`;
      const reply = await runAiPrompt(context, agent.backend, prompt);
      if (agent.generation === generation && reply.trim()) {
        const replyTarget = message.from === BOT_NAME
          ? [...agent.messages].reverse().find(item => item.from && item.from !== BOT_NAME && item.from.toLowerCase() !== agent.name.toLowerCase())?.from || "Host"
          : message.from || "Host";
        agent.client.sendAgentState("sending");
        agent.client.sendText(this.ensureDirectedReply(reply, replyTarget));
      }
    } catch (error: any) {
      failure = error?.message || String(error);
      if (agent.generation === generation) agent.client.sendText(`@Host I could not respond: ${failure}`);
      log.error(`managed agent ${agent.name} failed: ${error?.message || error}`);
    } finally {
      if (agent.generation === generation) agent.busy = false;
      if (agent.generation === generation) {
        agent.status = failure ? `error: ${failure}` : agent.pendingMessages.length ? `queued: ${agent.pendingMessages.length}` : agent.active ? "standby" : "idle";
        agent.client.sendAgentState(agent.pendingMessages.length ? "thinking" : agent.active ? "standby" : "idle");
      }
      this.push();
      if (agent.generation === generation && agent.active && agent.pendingMessages.length) {
        void this.drainManagedAgentMessages(context, agent);
      }
    }
  }

  removeManagedAgent(id: string): void {
    const agent = this.managedAgents.get(id);
    if (!agent) return;
    agent.active = false; agent.generation++;
    const room = this.rooms.get(agent.roomKey);
    const target = agent.client.participantId
      ? `participant:${agent.client.participantId}`
      : `cid:managed-${agent.id}:${agent.name.trim().toLowerCase()}`;
    if (room?.selfHost) room.client.sendAdmin("kick", target);
    try { agent.client.disconnect(); } catch { /* ignore */ }
    this.managedAgents.delete(id);
    log.action("chat.managedAgent.remove", { name: agent.name });
    this.push();
  }

  editManagedAgent(id: string, name: string, role: string, icon: string): void {
    const agent = this.managedAgents.get(id);
    if (!agent) return;
    const nextName = name.trim().slice(0, 60);
    const nextRole = role.trim().slice(0, 120);
    if (!nextName) return;
    const duplicate = [...this.managedAgents.values()].some(other => other.id !== id && other.roomKey === agent.roomKey && other.name.toLowerCase() === nextName.toLowerCase());
    if (duplicate) { vscode.window.showWarningMessage(`Managed agent "${nextName}" already exists in this room.`); return; }
    const room = this.rooms.get(agent.roomKey);
    const target = agent.client.participantId
      ? `participant:${agent.client.participantId}`
      : `cid:managed-${agent.id}:${agent.name.trim().toLowerCase()}`;
    if (!room?.selfHost || !room.client.sendAdmin("edit", target, nextName, nextRole)) {
      vscode.window.showWarningMessage("Reconnect the hosted room before editing this managed agent.");
      return;
    }
    agent.name = nextName;
    agent.role = nextRole;
    agent.icon = Array.from(icon.trim()).slice(0, 4).join("") || "🤖";
    agent.systemPrompt = ChatRoomManager.managedAgentPrompt(nextName, nextRole);
    log.action("chat.managedAgent.edit", { name: nextName, role: nextRole });
    this.push();
  }

  private joinPortalTransport(chatId: string, opts: Parameters<ChatClient["connect"]>[0]): RoomConn {
    const previous = this.portalTransports.get(chatId);
    previous?.peer?.dispose(); previous?.client.disconnect();
    let connection: RoomConn;
    const tag = `chat=${chatId.slice(0, 8)} channel=${(opts.roomId || "-").slice(0, 8)}`;
    let lastStatus = "", lastPresence = "";
    // A paired Portal survives transport loss for PORTAL_GRACE_MS: the client keeps reconnecting with the same identity.
    const evaluate = (): void => {
      if (this.portalTransports.get(chatId) !== connection) return;
      const binding = connection.peer?.binding;
      if (!binding) return;
      const peerPresent = connection.members.some(member => member.participantId === binding.peerId && member.present !== false);
      if (this.endpoint(chatId)) {
        if (connection.status === "connected" && peerPresent) {
          connection.peer?.publishEndpointState();
        }
        portalChanged();
        return;
      }
      if (connection.status === "connected" && peerPresent) {
        const grace = this.portalGrace.get(chatId);
        if (!grace) return;
        clearTimeout(grace.timer); this.portalGrace.delete(chatId);
        portalLog("info", `${tag} recovered after ${Math.round((Date.now() - grace.since) / 1000)}s (${grace.reason}); pairing kept`);
        connection.peer?.resync(grace.since - 90_000);
        vscode.window.setStatusBarMessage(`$(remote) Portal reconnected · ${binding.peerName}`, 10_000);
        portalChanged();
        return;
      }
      if (!client.willReconnect) {
        this.closePortalTransport(chatId, `transport-${connection.status}${connection.statusDetail ? `: ${connection.statusDetail}` : ""}`);
        return;
      }
      if (this.portalGrace.has(chatId)) return;
      const reason = connection.status !== "connected" ? `transport ${connection.status}${connection.statusDetail ? ` (${connection.statusDetail})` : ""}` : `peer ${binding.peerName} left presence`;
      const since = Date.now();
      const timer = setTimeout(() => {
        if (this.portalGrace.get(chatId)?.timer !== timer) return;
        this.portalGrace.delete(chatId);
        this.closePortalTransport(chatId, `grace-expired after ${PORTAL_GRACE_MS / 1000}s: ${reason}`);
        void vscode.window.showWarningMessage(`PKM Portal to ${binding.peerName} was lost: no reconnection within ${PORTAL_GRACE_MS / 60_000} minutes. Pair again to continue.`);
      }, PORTAL_GRACE_MS);
      timer.unref?.();
      this.portalGrace.set(chatId, { timer, since, reason });
      portalLog("warn", `${tag} interrupted: ${reason}; keeping pairing for ${PORTAL_GRACE_MS / 1000}s while reconnecting`);
      portalChanged();
    };
    const client = new ChatClient({
      onStatus: (status, detail) => {
        connection.status = status; connection.statusDetail = detail || "";
        const summary = `${status}${detail ? ` (${detail})` : ""}`;
        if (summary !== lastStatus) { lastStatus = summary; portalLog("info", `${tag} transport ${summary}`); }
        evaluate();
        portalChanged();
      },
      onPeer: delivery => { if (connection.peer) void connection.peer.receive(delivery); },
      onPresence: members => {
        connection.members = members;
        const binding = connection.peer?.binding;
        const summary = members.map(member => `${member.user}#${(member.participantId || "").slice(0, 8)}${member.present === false ? "(away)" : ""}`).join(",");
        if (summary !== lastPresence) { lastPresence = summary; portalLog("info", `${tag} presence [${summary}]${binding ? ` peer=${binding.peerName}#${binding.peerId.slice(0, 8)}` : ""}`); }
        evaluate();
        portalChanged();
      },
      onMessage: message => { if (message.system) { connection.statusDetail = message.text; portalLog("warn", `${tag} transport: ${message.text}`); portalChanged(); } },
      onHistory: () => {},
      onFileComplete: () => { log.warn("Portal transport rejected a Room file transfer; use Portal files instead."); },
      onRejected: (code, detail) => { connection.statusDetail = detail; portalLog("warn", `${tag} join rejected code=${code}: ${detail}`); evaluate(); portalChanged(); },
      onJoinApproved: (participantId, outcome) => portalLog("info", `${tag} joined as ${opts.user}#${participantId.slice(0, 8)} (${outcome}) via ${opts.url}`),
    }, message => portalLog("info", `${tag} ${message}`));
    connection = {
      key:chatId, url:opts.url, room:opts.room, roomId:opts.roomId, user:opts.user, client,
      messages:[], members:[], status:"connecting", statusDetail:"", unread:0, selfHost:false, selfMuted:false,
      agentStates:{}, meetings:{ current:null, history:[], trash:[] }, meetingHistorySynced:false, files:new Map(),
    };
    this.portalTransports.set(chatId, connection);
    this.startPortalStallMonitor();
    client.connect(opts);
    return connection;
  }

  /** Logs extension-host event-loop stalls while a Portal is open; a stalled host cannot answer relay heartbeats. */
  private startPortalStallMonitor(): void {
    if (this.portalStallTimer) return;
    let last = Date.now();
    this.portalStallTimer = setInterval(() => {
      const now = Date.now(), stalled = now - last - 1000;
      last = now;
      if (stalled > 5000) portalLog("warn", `extension host event loop stalled ~${Math.round(stalled / 1000)}s while a Portal is open`);
    }, 1000);
    this.portalStallTimer.unref?.();
  }

  private stopPortalStallMonitor(): void {
    if (this.portalStallTimer) { clearInterval(this.portalStallTimer); this.portalStallTimer = undefined; }
  }

  private closePortalTransport(chatId: string, reason: string): void {
    const grace = this.portalGrace.get(chatId);
    if (grace) { clearTimeout(grace.timer); this.portalGrace.delete(chatId); }
    const transport = this.portalTransports.get(chatId);
    this.portalTransports.delete(chatId);
    if (!this.portalTransports.size) this.stopPortalStallMonitor();
    const connection = this.portalConnections.get(chatId);
    this.portalConnections.delete(chatId);
    const entry = this.chatPortals.get(chatId);
    if (entry) { entry.room = undefined; delete entry.executionChatId; }
    if (transport) {
      const peer = transport.peer; transport.peer = undefined;
      peer?.dispose(); transport.client.disconnect();
    }
    this.invalidatePortal(chatId);
    this.portalJournal?.observe({chatId,chatLabel:"",external:false,localMachine:os.hostname()}, undefined);
    if (transport || connection) portalLog("info", `chat=${chatId.slice(0, 8)} channel=${(connection?.roomId || transport?.roomId || "-").slice(0, 8)} closed reason=${reason}${connection?.host ? " (host: closing relay channel)" : ""}`);
    if (connection?.host && connection.transport === "portal") this.hub?.closePortalChannel(connection.roomId, `host-closed: ${reason}`);
  }

  joinRoom(opts: { url: string; room: string; roomId?: string; user: string; token: string; cid?: string; hostToken?: string }): void {
    const key = ChatRoomManager.roomKey(opts.url, opts.room, opts.roomId);
    let rc = this.rooms.get(key);
    if (opts.roomId) {
      const sameRoom = [...this.rooms.values()].filter(item => item.roomId === opts.roomId);
      if (!rc && sameRoom.length) {
        rc = sameRoom[0];
        const previousKey = rc.key;
        this.rooms.delete(previousKey);
        rc.key = key;
        for (const agent of this.managedAgents.values()) {
          if (agent.roomKey === previousKey) agent.roomKey = key;
        }
        if (this.activeKey === previousKey) this.activeKey = key;
        this.rooms.set(key, rc);
      }
      for (const duplicate of sameRoom) {
        if (duplicate === rc) continue;
        duplicate.peer?.dispose();
        try { duplicate.client.disconnect(); } catch { /* ignore */ }
        this.rooms.delete(duplicate.key);
        if (this.activeKey === duplicate.key) this.activeKey = key;
        for (const [id, agent] of this.managedAgents) {
          if (agent.roomKey === duplicate.key) { try { agent.client.disconnect(); } catch { /* ignore */ } this.managedAgents.delete(id); }
        }
      }
    }
    if (rc) {
      rc.peer?.dispose(); rc.peer = undefined;
      rc.url = opts.url; rc.room = opts.room; rc.user = opts.user; rc.roomId = opts.roomId ?? rc.roomId;
      rc.client.connect({ ...opts, kind: "human" }); this.setActive(key); return;
    }

    rc = {
      key, url: opts.url, room: opts.room, roomId: opts.roomId, user: opts.user,
      client: null as any, messages: [], members: [], status: "connecting", statusDetail: "",
      unread: 0, selfHost: false, selfMuted: false, agentStates: {}, meetings: { current: null, history: [], trash: [] }, meetingHistorySynced: false, files: new Map(),
    };
    rc.client = new ChatClient(
      {
        onStatus:   (s, d) => {
          rc!.status = s; rc!.statusDetail = d ?? "";
          if (s === "connected") this.publishMeetingSnapshot(rc!);
          if (s === "disconnected") { rc!.peer?.dispose(); rc!.peer = undefined; }
          this.push();
        },
        onMessage:  m => this.addMessage(rc!, m),
        onPeer: delivery => { if (rc!.peer) void rc!.peer.receive(delivery); },
        onHistory:  ms => { rc!.messages = ms.slice(-ChatRoomManager.MAX_MSGS); if (rc!.selfHost) void this.syncMeetingFromHistory(rc!); if (rc!.key === this.activeKey) this.push(); },
        onPresence: mm => {
          rc!.members = mm;
          for (const member of mm) {
            if (member.kind === "agent" && member.runtimeState) rc!.agentStates[member.user] = member.runtimeState;
          }
          const me = mm.find(x => x.participantId && x.participantId === rc!.client.participantId);
          rc!.selfHost = !!me?.host;
          rc!.selfMuted = !!me?.muted;
          if (rc!.selfHost) void this.syncMeetingFromHistory(rc!);
          this.push();
        },
        onMeetingSnapshot: snapshot => {
          rc!.meetings = snapshot as unknown as MeetingRoomSnapshot;
          if (rc!.key === this.activeKey) this.push();
        },
        onAgentState: (user, state) => {
          rc!.agentStates[user] = state;
          postToPanel({ command: "chatAgentState", data: { key: rc!.key, user, state } });
        },
        onReadReceipt: (messageId, read, total) => this.updateReadReceipt(rc!, messageId, read, total),
        onFileComplete: (meta, from, data) => this.onFileReceived(rc!, meta, from, data),
        onRejected: (code, m) => this.onJoinRejected(rc!, code, m),
        onRenamed:  name => { rc!.user = name; this.push(); },
        onRekey:    secret => this.onRekey(rc!, secret),
      },
      m => log.debug(`chat[${rc!.room}]: ${m}`)
    );
    this.rooms.set(key, rc);
    this.activeKey = key;
    rc.client.connect({ ...opts, kind: "human" });
    log.action("chat.join", { room: opts.room, user: opts.user });
  }

  async closeOrLeaveRoom(key: string): Promise<void> {
    const rc = this.rooms.get(key);
    if (!rc) return;
    rc.peer?.dispose();
    const locallyHosted = this.hub?.adminRooms().find(room =>
      (!!rc.roomId && room.roomId === rc.roomId) ||
      (!rc.roomId && rc.selfHost && ChatHub.canonRoom(room.room) === ChatHub.canonRoom(rc.room)));
    if (locallyHosted && this.hub?.isRunning) {
      await this.hub.adminCloseRoom(locallyHosted.roomId);
    } else {
      try { rc.client.disconnect(); } catch { /* ignore */ }
    }
    for (const [id, agent] of this.managedAgents) {
      if (agent.roomKey !== key) continue;
      agent.active = false;
      agent.busy = false;
      agent.generation++;
      agent.pendingMessages = [];
      try { agent.client.disconnect(); } catch { /* ignore */ }
      this.managedAgents.delete(id);
    }
    this.rooms.delete(key);
    if (this.activeKey === key) this.activeKey = this.rooms.keys().next().value ?? "";
    if (locallyHosted) await this.refreshStoredRooms();
    log.action(locallyHosted ? "chat.closeRoom" : "chat.leave", { room: rc.room, roomId: rc.roomId });
    this.push();
  }

  async renameActiveRoom(roomId: string, roomName: string): Promise<void> {
    if (!this.hub?.isRunning) throw new Error("The Chat Hub is not running.");
    const rc = [...this.rooms.values()].find(room => room.roomId === roomId);
    if (!rc) throw new Error("The active Room connection was not found.");
    const previousKey = rc.key;
    const previousRoom = rc.room;
    const nextRoom = await this.hub.renameActiveRoom(roomId, roomName);
    const nextKey = ChatRoomManager.roomKey(rc.url, nextRoom, roomId);
    this.rooms.delete(previousKey);
    rc.room = nextRoom;
    rc.key = nextKey;
    this.rooms.set(nextKey, rc);
    for (const agent of this.managedAgents.values()) if (agent.roomKey === previousKey) agent.roomKey = nextKey;
    if (this.activeKey === previousKey) this.activeKey = nextKey;
    _treeProvider?.refresh();
    this.push();
  }

  setActive(key: string): void {
    if (!this.rooms.has(key)) return;
    this.activeKey = key;
    const rc = this.rooms.get(key)!;
    rc.unread = 0;
    this.push();
  }

  private addMessage(rc: RoomConn, m: ChatMessage): void {
    // Ignore a message we already have by id (e.g. history backfill overlapping a
    // live echo on reconnect) so previously-saved messages never pile up.
    if (m.id && rc.messages.some(x => x.id === m.id)) return;
    rc.messages.push(m);
    if (rc.messages.length > ChatRoomManager.MAX_MSGS) rc.messages.splice(0, rc.messages.length - ChatRoomManager.MAX_MSGS);
    void this.updateMeetingFromMessage(rc, m);
    if (rc.key === this.activeKey) {
      postToPanel({ command: "chatMessage", data: { key: rc.key, message: m } });
    } else {
      if (!m.system) rc.unread++;
      this.push();
    }
  }

  private async updateMeetingFromMessage(room: RoomConn, message: ChatMessage): Promise<void> {
    if (!room.selfHost || !this.meetingStore || message.system || !message.id || !message.text.trim()) return;
    const roomId = this.meetingRoomId(room);
    try {
      const current = this.meetingStore.snapshot(roomId).current;
      if (!current) {
        if (message.mode !== "discuss") return;
        const problem = message.text.trim();
        const title = problem.split(/\r?\n/)[0].replace(/^#+\s*/, "").slice(0, 100) || "Chatroom Meeting";
        await this.meetingStore.startMeeting({
          roomId, roomName: room.room, title, problemStatement: problem,
          owner: message.discussionLead || room.user, lead: message.discussionLead || room.user, recorder: room.user,
          participants: [...new Set([room.user, ...room.members.filter(member => member.present !== false).map(member => member.user)])],
          host: room.user, triggerMessageId: message.id, requestId: `auto-start:${message.id}`, expectedRevision: 0,
        });
      } else {
        await this.meetingStore.recordDiscussionMessage({
          roomId, participant: message.from, text: message.text, sourceMessageId: message.id,
          finalLeadSummary: isFinalLeadSummary(message, current.lead),
          recordedAt: message.ts ? new Date(message.ts).toISOString() : undefined,
        });
      }
      this.publishMeetingSnapshot(room);
      this.push();
    } catch (error: any) {
      log.warn(`chat: couldn't update live Meeting Summary: ${error?.message || String(error)}`);
    }
  }

  private async syncMeetingFromHistory(room: RoomConn): Promise<void> {
    if (room.meetingHistorySynced || !room.selfHost || !this.meetingStore) return;
    room.meetingHistorySynced = true;
    const roomId = this.meetingRoomId(room);
    try {
      let current = this.meetingStore.snapshot(roomId).current;
      if (!current) {
        const trigger = this.meetingLifecycle?.latestDiscussAfterLastMeeting(roomId, room.messages);
        if (!trigger?.id || !trigger.text.trim()) {
          room.meetingHistorySynced = false;
          return;
        }
        const problem = trigger.text.trim();
        const title = problem.split(/\r?\n/)[0].replace(/^#+\s*/, "").slice(0, 100) || "Chatroom Meeting";
        current = await this.meetingStore.startMeeting({
          roomId, roomName: room.room, title, problemStatement: problem,
          owner: trigger.discussionLead || room.user, lead: trigger.discussionLead || room.user, recorder: room.user,
          participants: [...new Set([room.user, ...room.members.filter(member => member.present !== false).map(member => member.user)])],
          host: room.user, triggerMessageId: trigger.id, requestId: `history-start:${trigger.id}`, expectedRevision: 0,
        });
      }
      const triggerIndex = room.messages.findIndex(message => message.id === current?.triggerMessageId);
      for (const message of room.messages.slice(Math.max(0, triggerIndex + 1))) {
        if (message.system || !message.id || !message.text.trim()) continue;
        await this.meetingStore.recordDiscussionMessage({
          roomId, participant: message.from, text: message.text, sourceMessageId: message.id,
          finalLeadSummary: isFinalLeadSummary(message, current.lead),
          recordedAt: message.ts ? new Date(message.ts).toISOString() : undefined,
        });
      }
      this.publishMeetingSnapshot(room);
      this.push();
    } catch (error: any) {
      room.meetingHistorySynced = false;
      log.warn(`chat: couldn't reconcile Meeting Summary from history: ${error?.message || String(error)}`);
    }
  }

  private updateReadReceipt(rc: RoomConn, messageId: string, read: number, total: number): void {
    const message = rc.messages.find(item => item.id === messageId);
    if (!message) return;
    message.receipt = { read, total };
    postToPanel({ command: "chatReadReceipt", data: { key: rc.key, messageId, read, total } });
  }

  private onFileReceived(rc: RoomConn, meta: FileMeta, from: string, data: Buffer): void {
    rc.files.set(meta.fileId, { meta, from, data });
    postToPanel({ command: "chatFileReady", data: { key: rc.key, fileId: meta.fileId, name: meta.name, from, size: meta.size, mime:meta.mime } });
    if (rc.key === this.activeKey) this.push();
    log.action("chat.fileReceived", { room: rc.room, name: meta.name, size: meta.size });
  }

  // The Hub has already persisted this rotation. Refresh live invite actions;
  // durable hosted Rooms never copy their secret into globalState recents.
  private onRekey(rc: RoomConn, secret: string): void {
    if (rc.roomId) this.hostedKeys.set(rc.roomId, secret);
    saveRekeyedSecret(rc.url, rc.room, secret, rc.roomId);
    this.push();
    log.action("chat.rekey", { room: rc.room });
  }

  // Terminal join failure (bad secret or duplicate name): drop the room and tell
  // the user so they can fix the name/secret and re-join.
  private onJoinRejected(rc: RoomConn, code: string, msg: string): void {
    try { rc.client.disconnect(); } catch { /* ignore */ }
    this.rooms.delete(rc.key);
    if (this.activeKey === rc.key) this.activeKey = this.rooms.keys().next().value ?? "";
    postToPanel({ command: "chatToast", data: { error: msg } });
    this.push();
    log.action("chat.joinRejected", { room: rc.room, code });
  }

  send(text: string, responseRequired?: boolean, replyPolicy?: ReplyPolicy, mode?: ChatMode, recipients?: string[], replyToMessageId?: string, discussionLead?: string, finalTopicSummary?: boolean, collaboration?: CollaborationMessageMetadata): boolean {
    const rc = this.activeRoom;
    return rc ? rc.client.sendText(text, responseRequired, replyPolicy, mode, recipients, replyToMessageId, discussionLead, finalTopicSummary, collaboration) : false;
  }

  /** Host-only: moderate a member in the active room. Target identified by its
   *  stable identity (sid) when available, else by display name. */
  moderate(action: "kick" | "mute" | "unmute" | "rename" | "edit", target: { participantId?: string; sid?: string; user: string }, name?: string, role?: string): void {
    const rc = this.activeRoom;
    if (!rc) return;
    const key = target.participantId
      ? `participant:${target.participantId}`
      : target.sid
        ? `cid:${target.sid}:${(target.user || "").trim().toLowerCase()}`
        : `name:${(target.user || "").trim().toLowerCase()}`;
    rc.client.sendAdmin(action, key, name, role);
  }

  /** Rename yourself in the active room. Allowed for any member; the hub rejects
   *  it if the new alias duplicates another present member. */
  renameSelf(newName: string): void {
    const rc = this.activeRoom;
    if (!rc) return;
    const nn = (newName || "").trim().slice(0, 60);
    if (!nn) return;
    const id = rc.client.identity;
    const selfKey = id ? `cid:${id}:${rc.user.trim().toLowerCase()}` : `name:${rc.user.trim().toLowerCase()}`;
    rc.client.sendAdmin("rename", selfKey, nn);
  }

  /** Your current display name in the active room ("" if none). */
  get selfName(): string { return this.activeRoom?.user ?? ""; }

  async sendImages(key: string, images: unknown, message: Parameters<ChatClient["sendText"]>): Promise<void> {
    const rc = this.rooms.get(key);
    if (!rc || key !== this.activeKey || !rc.client.isConnected) throw new Error("The selected Room changed or disconnected. Send again in the intended Room.");
    if (rc.selfMuted) throw new Error("You are muted by the host and cannot share images.");
    const decoded = decodeChatroomImages(images);
    for (const image of decoded) {
      const result = await rc.client.sendFile(image.name, image.mime, image.data);
      if (!result.ok || !result.file) throw new Error(result.error || "Image transfer was not queued.");
      this.onFileReceived(rc, result.file, rc.user, image.data);
    }
    if (message[0].trim() && !rc.client.sendText(...message)) throw new Error("Images were queued, but the message could not be sent. Check the connection before retrying.");
  }

  imagePreview(key: string, fileId: string): string {
    const file = this.rooms.get(key)?.files.get(fileId);
    if (!file) throw new Error("This image is no longer available. Shared files are live-only.");
    const mime = chatroomImageMime(file.data);
    if (!mime || mime !== file.meta.mime || file.data.length > MAX_CHATROOM_IMAGE_BYTES) throw new Error("This file is not a supported image preview (maximum 5 MB).");
    return `data:${mime};base64,${file.data.toString("base64")}`;
  }

  async sendFileToActive(): Promise<void> {
    const rc = this.activeRoom;
    if (!rc || !rc.client.isConnected) { vscode.window.showWarningMessage("Join a room before sharing a file."); return; }
    const picks = await vscode.window.showOpenDialog({ canSelectMany: false, openLabel: "Share to room" });
    if (!picks || !picks.length) return;
    const fsPath = picks[0].fsPath;
    try {
      const stat = fs.statSync(fsPath);
      if (stat.size > MAX_FILE_BYTES) { vscode.window.showErrorMessage(`File too large (max ${MAX_FILE_BYTES / 1024 / 1024} MB).`); return; }
      const data = fs.readFileSync(fsPath);
      const res = await rc.client.sendFile(path.basename(fsPath), "application/octet-stream", data);
      if (!res.ok) vscode.window.showErrorMessage(`Share failed: ${res.error}`);
      else log.action("chat.fileSent", { room: rc.room, name: path.basename(fsPath), size: stat.size });
    } catch (e: any) {
      vscode.window.showErrorMessage(`Share failed: ${e?.message ?? e}`);
    }
  }

  async saveReceivedFile(key: string, fileId: string): Promise<void> {
    const rc = this.rooms.get(key);
    const rec = rc?.files.get(fileId);
    if (!rec) { vscode.window.showWarningMessage("This file is no longer available (peers must be online to receive it)."); return; }
    const target = await vscode.window.showSaveDialog({ defaultUri: vscode.Uri.file(path.join(os.homedir(), rec.meta.name)), saveLabel: "Save shared file" });
    if (!target) return;
    try {
      fs.writeFileSync(target.fsPath, rec.data);
      rc?.files.delete(fileId);
      vscode.window.showInformationMessage(`Saved ${rec.meta.name}`);
      log.action("chat.fileSaved", { name: rec.meta.name });
    } catch (e: any) {
      vscode.window.showErrorMessage(`Save failed: ${e?.message ?? e}`);
    }
  }

  /** Export the active room's transcript to a Markdown or JSON file. */
  async exportActive(): Promise<void> {
    const rc = this.activeRoom;
    if (!rc || !rc.messages.length) { vscode.window.showWarningMessage("No messages to export in this room."); return; }
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const base  = `chatroom-${rc.room}-${stamp}`;
    const target = await vscode.window.showSaveDialog({
      defaultUri: vscode.Uri.file(path.join(os.homedir(), `${base}.md`)),
      filters: { Markdown: ["md"], JSON: ["json"] },
      saveLabel: "Download transcript",
    });
    if (!target) return;
    try {
      const isJson = target.fsPath.toLowerCase().endsWith(".json");
      const doc = isJson
        ? JSON.stringify({ room: rc.room, url: rc.url, exportedAt: new Date().toISOString(), messages: rc.messages }, null, 2)
        : this.toMarkdown(rc);
      fs.writeFileSync(target.fsPath, doc, "utf-8");
      vscode.window.showInformationMessage(`Transcript saved: ${path.basename(target.fsPath)}`);
      log.action("chat.export", { room: rc.room, count: rc.messages.length });
    } catch (e: any) {
      vscode.window.showErrorMessage(`Export failed: ${e?.message ?? e}`);
    }
  }

  private toMarkdown(rc: RoomConn): string {
    const lines: string[] = [`# Chatroom: ${rc.room}`, "", `_Exported ${new Date().toLocaleString()} · ${rc.messages.length} messages_`, ""];
    for (const m of rc.messages) {
      const t = new Date(m.ts).toLocaleTimeString();
      if (m.system) { lines.push(`> _${m.text}_  \`${t}\``, ""); continue; }
      const who = `${m.kind === "agent" ? "🤖 " : ""}${m.from}`;
      lines.push(`**${who}** · \`${t}\``, "", m.text, "");
    }
    return lines.join("\n");
  }

  async startHub(port: number, rotateOnConflict = false): Promise<{ ok: boolean; wsUrl?: string; httpUrl?: string; error?: string }> {
    const report = (state: PortalHubPortStatus["state"], reason: PortalHubPortStatus["reason"], actualPort?: number, error?: string): void => {
      this.portalHubPort = { requestedPort: port, state, reason, at: Date.now(),
        ...(actualPort === undefined ? {} : { actualPort }), ...(error ? { error } : {}) };
      portalChanged();
    };
    let reason: PortalHubPortStatus["reason"] = port === 0 ? "system-selected" : "configured";
    report("starting", reason);
    try {
      if (!this.hub) {
        this.hub = new ChatHub(hubLog);
        this.bindHub(this.hub);
      }
      this.hub.configureArchive(this.archiveDir, this.archiveLimitBytes);
      if (this.secretStorage && this.installationId) {
        this.hub.configureLifecycle(this.persistenceRoot, this.archiveLimitBytes, this.installationId, this.secretStorage);
      } else {
        this.hub.configurePersistence(this.persistenceRoot, this.archiveLimitBytes);
      }
      if (this.hub.isRunning) {
        const host = this.advertisedHost();
        report("ready", "reused", this.hub.port);
        return { ok: true, wsUrl: `ws://${host}:${this.hub.port}`, httpUrl: `http://${host}:${this.hub.port}` };
      }
      log.info(`chat: starting hub on port ${port}`);
      try {
        await this.hub.start(port);
      } catch (e: any) {
        if (e?.code === "EADDRINUSE" && port !== 0) {
          if (rotateOnConflict) {
            reason = "in-use";
            report("starting", reason);
            portalLog("warn", `Portal Hub port ${port} is occupied; selecting a free local port without stopping the existing listener.`);
            await this.hub.start(0);
          } else {
            try {
              const response = await fetch(`http://127.0.0.1:${port}/.well-known/pkm-chat-hub`, { signal: AbortSignal.timeout(500) });
              const active = await response.json() as { protocol?: string; installationId?: string };
              if (active.protocol === "pkm-chat-hub:v1" && active.installationId === this.installationId) {
                throw new Error(`Chat Hub is already active in another VS Code window on port ${port}. Use that window to host Rooms.`);
              }
            } catch (identityError) {
              if (identityError instanceof Error && identityError.message.includes("already active in another VS Code window")) throw identityError;
            }
            throw e;
          }
        } else {
          throw e;
        }
      }
      const host = this.advertisedHost();
      const wsUrl = `ws://${host}:${this.hub.port}`;
      const httpUrl = `http://${host}:${this.hub.port}`;
      report("ready", reason, this.hub.port);
      if (reason === "in-use") {
        portalLog("info", `Portal Hub port changed ${port} -> ${this.hub.port}: requested port occupied; existing Hub untouched. New invitations use the new endpoint; saved remote addresses were not changed.`);
        vscode.window.setStatusBarMessage(`$(remote) Portal Hub: ${port} occupied; using ${this.hub.port}. New pairing code uses the new port.`, 15_000);
      }
      log.info(`chat: hub ready — join URL ${wsUrl} · browser view ${httpUrl}`);
      log.action("chat.startHub", { port: this.hub.port });
      this.push();
      return { ok: true, wsUrl, httpUrl };
    } catch (e: any) {
      const detail = e?.message || String(e);
      report("failed", reason, undefined, detail);
      log.error(`chat.startHub failed (port ${port}): code=${e?.code ?? "?"} ${detail}`);
      if (e?.stack) log.error(e.stack);
      return { ok: false, error: detail };
    }
  }

  async refreshStoredRooms(): Promise<void> {
    if (this.storedRoomsRefresh) return this.storedRoomsRefresh;
    this.storedRoomsRefresh = this.refreshStoredRoomsNow();
    try { await this.storedRoomsRefresh; }
    finally { this.storedRoomsRefresh = undefined; }
  }

  private async refreshStoredRoomsNow(): Promise<void> {
    if (!this.persistenceRoot || !this.installationId || !this.secretStorage) return;
    if (!this.hub) {
      this.hub = new ChatHub(hubLog);
      this.bindHub(this.hub);
      this.hub.configureArchive(this.archiveDir, this.archiveLimitBytes);
      this.hub.configureLifecycle(this.persistenceRoot, this.archiveLimitBytes, this.installationId, this.secretStorage);
    }
    this.storedRooms = await this.hub.listStoredRooms();
    this.scheduleCrossWindowRefresh();
    _treeProvider?.refresh();
    this.push();
  }

  private scheduleCrossWindowRefresh(): void {
    if (this.crossWindowRefreshTimer) {
      clearTimeout(this.crossWindowRefreshTimer);
      this.crossWindowRefreshTimer = undefined;
    }
    if (!this.storedRooms.some(room => room.activeElsewhere)) return;
    this.crossWindowRefreshTimer = setTimeout(() => {
      this.crossWindowRefreshTimer = undefined;
      void this.refreshStoredRooms().catch(error => log.warn(`chat: active Room refresh failed: ${(error as Error).message}`));
    }, 2000);
    this.crossWindowRefreshTimer.unref?.();
  }

  async renameStoredRoom(roomId: string, roomName: string): Promise<void> {
    await this.hub?.renameStoredRoom(roomId, roomName);
    await this.refreshStoredRooms();
  }

  async repairStoredRoom(roomId: string): Promise<{ roomName: string; messageCount: number; closedOrphans: number }> {
    if (!this.hub) throw new Error("Chat Hub storage is unavailable.");
    const repaired = await this.hub.repairStoredRoom(roomId);
    await this.refreshStoredRooms();
    return repaired;
  }

  async forceCloseHostedRoom(roomId: string): Promise<void> {
    if (!this.hub) throw new Error("Chat Hub storage is unavailable.");
    await this.hub.forceCloseRemoteRoom(roomId);
    await this.refreshStoredRooms();
  }

  async deleteStoredRoom(roomId: string): Promise<void> {
    await this.hub?.deleteStoredRoom(roomId);
    await this.refreshStoredRooms();
  }

  async createHostedRoom(room: string, requestedSecret?: string, ownership?: { projectId: string; threadId: string }): Promise<{ roomId: string; room: string; secret: string; hostToken: string }> {
    if (!this.hub?.isRunning) throw new Error("Start the Chat Hub before creating a Room.");
    const created = await this.hub.createRoom(room, requestedSecret, ownership);
    this.hostedKeys.set(created.roomId, created.secret);
    await this.refreshStoredRooms();
    this.push();
    return created;
  }

  async rehostRoom(roomId: string): Promise<{ roomId: string; room: string; secret: string; hostToken: string }> {
    if (!this.hub?.isRunning) throw new Error("Start the Chat Hub before Rehosting a Room.");
    const rehosted = await this.hub.rehostRoom(roomId);
    this.hostedKeys.set(rehosted.roomId, rehosted.secret);
    await this.refreshStoredRooms();
    this.push();
    return rehosted;
  }

  async stopHub(): Promise<void> {
    await this.hub?.stop();
    if (this.portalHubPort) {
      this.portalHubPort = { requestedPort: this.portalHubPort.requestedPort, reason: this.portalHubPort.reason, state: "stopped", at: Date.now() };
      portalChanged();
    }
    this.hostedKeys.clear();
    await this.refreshStoredRooms();
    log.action("chat.stopHub");
    this.push();
  }

  async adminCloseRoom(roomId: string): Promise<void> {
    const room = this.hub?.adminRooms().find(item => item.roomId === roomId)?.room || roomId;
    await this.hub?.adminCloseRoom(roomId);
    if (roomId) this.hostedKeys.delete(roomId);
    await this.refreshStoredRooms();
    log.action("chat.adminCloseRoom", { room, roomId });
    this.push();
  }

  /** Rotate a hosted room's secret on demand. The rekey flows back via onRekey. */
  async rotateRoomSecret(room: string): Promise<boolean> {
    const roomId = this.hub?.adminRooms().find(item => item.roomId === room || ChatHub.canonRoom(item.room) === ChatHub.canonRoom(room))?.roomId;
    const s = await this.hub?.rotateRoomSecret(room);
    if (s && roomId) {
      this.hostedKeys.set(roomId, s);
      const active = [...this.rooms.values()].find(connection => connection.roomId === roomId);
      if (active) saveRekeyedSecret(active.url, active.room, s);
      log.action("chat.rotateSecret", { room });
    }
    return !!s;
  }

  async adminCloseAll(): Promise<void> {
    await this.hub?.adminCloseAll();
    this.hostedKeys.clear();
    await this.refreshStoredRooms();
    log.action("chat.adminCloseAll");
    this.push();
  }

  // Per-room secrets this host set, so we can copy/share them later.
  rememberRoomKey(room: string, key: string): void {
    const roomId = this.hub?.adminRooms().find(item => item.roomId === room || ChatHub.canonRoom(item.room) === ChatHub.canonRoom(room))?.roomId;
    if (roomId) this.hostedKeys.set(roomId, key);
  }
  getRoomKey(room: string): string | undefined {
    const roomId = this.hub?.adminRooms().find(item => item.roomId === room || ChatHub.canonRoom(item.room) === ChatHub.canonRoom(room))?.roomId;
    return roomId ? this.hostedKeys.get(roomId) : undefined;
  }

  roomInvite(room: string): { magicLink: string; message: string } | undefined {
    const secret = this.getRoomKey(room);
    if (!secret) return undefined;
    const hosted = this.hub?.adminRooms().find(item => item.roomId === room || ChatHub.canonRoom(item.room) === ChatHub.canonRoom(room));
    const connection = [...this.rooms.values()].find(item => item.roomId === room || ChatHub.canonRoom(item.room) === ChatHub.canonRoom(room));
    let base = this.hub?.port ? `ws://${this.advertisedHost()}:${this.hub.port}` : connection?.url || "";
    if (!base) return undefined;
    const parsed = new URL(base);
    parsed.pathname = `/${encodeURIComponent(hosted?.room || connection?.room || room)}`;
    parsed.search = ""; parsed.hash = "";
    const url = parsed.toString().replace(/\/$/, "");
    const roomId = hosted?.roomId;
    const magicLink = createChatMagicLink(url, secret, roomId);
    return { magicLink, message: chatInviteMessage(magicLink) };
  }

  async dispose(): Promise<void> {
    this.endpointStopped = true;
    if (this.endpointTimer) { clearInterval(this.endpointTimer); this.endpointTimer = undefined; }
    this.portalJournalSubscription?.dispose();
    this.portalJournalSubscription = undefined;
    if (this.crossWindowRefreshTimer) clearTimeout(this.crossWindowRefreshTimer);
    this.crossWindowRefreshTimer = undefined;
    for (const agent of this.managedAgents.values()) { try { agent.client.disconnect(); } catch { /* ignore */ } }
    this.managedAgents.clear();
    for (const rc of this.rooms.values()) { rc.peer?.dispose(); try { rc.client.disconnect(); } catch { /* ignore */ } }
    this.rooms.clear();
    for (const id of this.chatPortals.keys()) this.closePortalTransport(id, "extension-shutdown");
    for (const id of this.portalTransports.keys()) this.closePortalTransport(id, "extension-shutdown");
    this.chatPortals.clear();
    for (const release of this.endpointLocks.values()) release();
    this.endpointLocks.clear();
    this.externalPortalOffers.clear();
    try { await this.hub?.stop(); } catch { /* ignore */ }
  }
}

let chatMgr: ChatRoomManager | undefined;
let remoteChatExecutor: ((prompt: string, signal: AbortSignal, requestId: string, chatId: string, observer?: PortalObserver, source?: PortalSource, profileSnapshot?: PersonaSnapshot) => Promise<unknown>) | undefined;
let remoteTaskAttemptsReader: ((chatId: string, requestId: string, replyId?: string) => unknown) | undefined;
let portalProfileReview: ((chatId: string) => Promise<PersonaSnapshot | undefined>) | undefined;
let portalChatContext: ((chatId?: string, label?: string) => Promise<{ id: string; label: string }>) | undefined;
let portalChooseContext: (() => Promise<{ id: string; label: string } | undefined>) | undefined;
let todoBoardConversionChat: ((prompt: string, title: string) => Promise<void>) | undefined;
let portalMutationGuard: ((chatId: string) => void) | undefined;
let portalMutationPolicy: ((chatId: string) => Promise<void>) | undefined;
let portalChatBindingsReader: (() => Promise<Array<{ id: string; title: string }>>) | undefined;
let portalInteraction: ((chatId: string, interaction: import("./chat/portal-interaction").PortalInteraction, current: () => boolean) => Promise<import("./chat/portal-interaction").PortalInteractionAnswer | undefined>) | undefined;
let portalReviewReceiver: ((chatId: string, review: PortalReview) => Promise<void>) | undefined;
let portalCommandRecorder: ((chatId: string, activity: import("./chat/portal-command-activity").PortalCommandActivity) => Promise<void>) | undefined;
let portalTransferRecorder: ((chatId: string, status: PortalTransferStatus, peerName: string) => Promise<void>) | undefined;
function getChatMgr(): ChatRoomManager {
  if (!chatMgr) chatMgr = new ChatRoomManager();
  return chatMgr;
}

// Extension context kept for chat helpers that run outside a message handler
// (e.g. secret rotation triggered by a hub event).
let chatCtx: vscode.ExtensionContext | undefined;
function saveRekeyedSecret(url: string, room: string, secret: string, roomId?: string): void {
  if (!chatCtx) return;
  const id = chatRoomIdentity(url, room, roomId);
  const list = chatRecents(chatCtx);
  const entry = list.find(recent => chatRoomIdentity(recent.url, recent.room, recent.roomId) === id);
  if (entry && (!entry.host || !entry.roomId)) void chatCtx.secrets.store(chatRecentSecretKey(id), secret);
}

// A stable per-installation chat identity so this user is recognizable across
// reloads/reconnects (extension joins carry it as their cid). Persisted in
// globalState; generated once.
let chatCid = "";
function getChatCid(context: vscode.ExtensionContext): string {
  if (chatCid) return chatCid;
  chatCid = context.globalState.get<string>("chatIdentityCid", "") || "";
  if (!chatCid) {
    chatCid = randomBytes(4).toString("hex");
    void context.globalState.update("chatIdentityCid", chatCid);
  }
  return chatCid;
}

let chatInstallationId = "";
function getChatInstallationId(context: vscode.ExtensionContext): string {
  if (chatInstallationId) return chatInstallationId;
  chatInstallationId = context.globalState.get<string>("chatInstallationId", "") || "";
  if (!chatInstallationId) {
    chatInstallationId = randomUUID();
    void context.globalState.update("chatInstallationId", chatInstallationId);
  }
  return chatInstallationId;
}

/** Shared backend events invalidate every tab; request responses use the captured session instead. */
function postToPanel(m: object): void {
  panels.broadcast(m);
}

// ── Chatroom recents (persisted across sessions) ────────────────────────────
const CHAT_RECENTS_KEY = "pk.chat.recents";
interface RecentRoom { id: string; url: string; room: string; roomId?: string; user: string; host: boolean; port: number; secret?: string; lastJoined: number; }

function chatInviteHostOptions(context: vscode.ExtensionContext): { options: any[]; selected: string; unavailable: boolean } {
  const external = externalLinkHostOptions();
  return { options: external.options, selected: external.selected, unavailable: external.unavailable };
}

async function updateExternalLinkHost(address: string): Promise<void> {
  if (!serverNetworkAddresses().some(item => item.address === address)) throw new Error("Select an available hostname or network interface.");
  await vscode.workspace.getConfiguration("personalKnowledge").update("externalLinkHost", address, vscode.ConfigurationTarget.Global);
  if (chatCtx) applyChatInviteHost(chatCtx);
  if (sharedMarket) {
    const snapshot = sharedMarket.snapshot as any;
    if (snapshot.advertisedHost !== address) await sharedMarket.configure({ enabled: snapshot.enabled, port: snapshot.port, advertisedHost: address, displayName: snapshot.displayName });
  }
}

function applyChatInviteHost(context: vscode.ExtensionContext): { selected: string; unavailable: boolean } {
  const result = chatInviteHostOptions(context);
  if (result.selected && !result.unavailable) getChatMgr().setAdvertisedHost(result.selected);
  return result;
}

function chatRecentSecretKey(id: string): string {
  return `personalKnowledge.chatroom.recent.${createHash("sha256").update(id).digest("hex")}`;
}

async function chatRecentSecret(ctx: vscode.ExtensionContext, id: string): Promise<string> {
  return (await ctx.secrets.get(chatRecentSecretKey(id))) || "";
}

function chatUrlPort(wsUrl: string): number {
  try { return Number(new URL(wsUrl).port) || 7345; } catch { return 7345; }
}
function chatRecents(ctx: vscode.ExtensionContext): RecentRoom[] {
  return joinedRoomRecents(ctx.globalState.get<RecentRoom[]>(CHAT_RECENTS_KEY, []));
}
async function migrateChatRecents(ctx: vscode.ExtensionContext): Promise<void> {
  const raw = ctx.globalState.get<RecentRoom[]>(CHAT_RECENTS_KEY, []);
  const joined = joinedRoomRecents(raw.map(room => ({ ...room })));
  for (const room of joined) {
    if (room.secret) await ctx.secrets.store(chatRecentSecretKey(room.id), room.secret);
    delete room.secret;
  }
  if (JSON.stringify(raw) !== JSON.stringify(joined)) await ctx.globalState.update(CHAT_RECENTS_KEY, joined);
}
function chatRecentsForUi(ctx: vscode.ExtensionContext): object[] {
  return chatRecents(ctx).map(r => ({ id: r.id, url: r.url, room: r.room, roomId: r.roomId, user: r.user, host: r.host }));
}
async function saveChatRecent(ctx: vscode.ExtensionContext, e: { url: string; room: string; roomId?: string; user: string; secret?: string; host?: boolean }): Promise<void> {
  const current = chatRecents(ctx);
  if (e.host) {
    await ctx.globalState.update(CHAT_RECENTS_KEY, current);
    _treeProvider?.refresh();
    return;
  }
  const id = chatRoomIdentity(e.url, e.room, e.roomId);
  const prev = current.find(room => chatRoomIdentity(room.url, room.room, room.roomId) === id);
  const list = current.filter(room => chatRoomIdentity(room.url, room.room, room.roomId) !== id);
  if (e.secret) await ctx.secrets.store(chatRecentSecretKey(id), e.secret);
  list.unshift({ id, url: e.url, room: e.room, roomId: e.roomId ?? prev?.roomId, user: e.user, host: false, port: chatUrlPort(e.url), lastJoined: Date.now() });
  await ctx.globalState.update(CHAT_RECENTS_KEY, list.slice(0, 50));
  _treeProvider?.refresh();
}
async function forgetChatRecent(ctx: vscode.ExtensionContext, id: string): Promise<void> {
  await ctx.secrets.delete(chatRecentSecretKey(id));
  await ctx.globalState.update(CHAT_RECENTS_KEY, chatRecents(ctx).filter(r => r.id !== id));
  _treeProvider?.refresh();
}

async function openHostedRoom(context: vscode.ExtensionContext, roomId: string): Promise<void> {
  const manager = getChatMgr();
  if (manager.activateRoomById(roomId)) {
    openChatroomPanel(context);
    return;
  }
  await manager.refreshStoredRooms();
  const stored = manager.hostedRoomsForNavigation().find(room => room.roomId === roomId);
  if (!stored) throw new Error("Hosted Room was not found.");
  if (!stored.canRehost) throw new Error(stored.unavailableReason || "This Room cannot be Rehosted.");
  const cfg = vscode.workspace.getConfiguration("personalKnowledge");
  const started = await manager.startHub(cfg.get<number>("chatHubPort") ?? 7345);
  if (!started.ok) throw new Error(started.error || "Couldn't start Chat Hub.");
  const hosted = await manager.rehostRoom(roomId);
  const url = `ws://127.0.0.1:${manager.hubPort}`;
  manager.joinRoom({ url, room: hosted.room, roomId: hosted.roomId, user: "Host", token: hosted.secret,
    cid: getChatCid(context), hostToken: hosted.hostToken });
  openChatroomPanel(context);
}

async function promptRenameHostedRoom(room: HostedRoomNavigationItem): Promise<void> {
  const roomName = await vscode.window.showInputBox({
    title: room.active ? "Rename Active Room" : "Rename Stored Room",
    value: room.roomName,
    prompt: "Room UUID, history, identities, and Join secret remain unchanged.",
    validateInput: value => value.trim() ? undefined : "Room name is required.",
  });
  if (roomName === undefined || roomName.trim() === room.roomName.trim()) return;
  if (room.active) await getChatMgr().renameActiveRoom(room.roomId, roomName);
  else await getChatMgr().renameStoredRoom(room.roomId, roomName);
}

async function confirmAndDeleteStoredRoom(context: vscode.ExtensionContext, roomId: string, roomName: string): Promise<boolean> {
  const confirmed = await vscode.window.showWarningMessage(
    `Permanently delete Stored Room "${roomName}" and all of its messages, participants, alias history, and credentials?`,
    { modal: true }, "Continue",
  );
  if (confirmed !== "Continue") return false;
  const finalConfirmation = await vscode.window.showWarningMessage(
    `Final confirmation: permanently delete "${roomName}"? This cannot be undone or recovered by Rehost.`,
    { modal: true }, "Delete Data Permanently",
  );
  if (finalConfirmation !== "Delete Data Permanently") return false;
  await getChatMgr().deleteStoredRoom(roomId);
  await context.globalState.update(CHAT_RECENTS_KEY, chatRecents(context).filter(room => room.roomId !== roomId));
  _treeProvider?.refresh();
  return true;
}
/** Set store paths, run the one-time DB→files migration, mark ready, refresh. */
async function initStore(context: vscode.ExtensionContext, storePath: string): Promise<void> {
  invalidateSharedContentCatalog();
  getChatMgr().invalidatePortalsForContextChange(storePath);
  fsSetStorePath(storePath);
  storageSetStorePath(storePath);
  setPrivacyStoreRoot(storePath);
  setKnowledgeGroupStoreRoot(storePath);
  // Hidden, idempotent migration from the legacy SQLite DB to files-as-truth
  if (!context.globalState.get<boolean>("migratedToFiles", false)) {
    try {
      const r = await migrateDbToFiles(context.extensionPath);
      if (r.migrated) log.info(`migrated ${r.skills} skills, ${r.notes} notes from DB to files`);
      await context.globalState.update("migratedToFiles", true);
    } catch (e: any) { log.warn(`migration skipped: ${e?.message}`); }
  }
  try {
    const ideas = migrateLegacyMyIdeasFolder();
    if (ideas.moved) {
      gitCommit(`migrate(papers): move ${ideas.moved} ideas into MyIdeas`);
      log.info(`migrated ${ideas.moved} ideas into papers/MyIdeas and updated ${ideas.updatedReferences} citations`);
    }
  } catch (error) {
    const message = `MyIdeas folder migration failed: ${(error as Error).message}`;
    log.error(message);
    void vscode.window.showErrorMessage(message);
  }
  _storeReady = true;
  void ensurePublicContentGateway(context).catch(error => log.warn(`public content gateway: ${(error as Error).message}`));
  _treeProvider?.refresh();
  refreshMcpDefinitions();
}

// ── First-run example content ────────────────────────────────────────────────
/** True if the store has no user content in any of the file-backed types. */
function storeIsEmpty(): boolean {
  const root = getStorePath();
  const hasFiles = (dir: string): boolean => {
    if (!fs.existsSync(dir)) return false;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name.startsWith(".")) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { if (hasFiles(p)) return true; }
      else return true;
    }
    return false;
  };
  return !["skills", "notes", "papers", "prompts", "scripts", "packages"]
    .some(t => hasFiles(path.join(root, t)));
}

/** Seed a small set of example items (one per folder) + a getting-started guide,
 *  so brand-new users have something to mimic. Only called on an empty store. */
function seedExamples(): void {
  const GS = "Getting Started";
  const md = (...lines: string[]) => lines.join("\n") + "\n";

  const guide = md(
    "# Getting Started with Personal Knowledge Manager",
    "",
    "Welcome! Your knowledge base is just a folder of plain Markdown files — everything",
    "in the panel is a file on disk. You (or an AI assistant via MCP) can edit them directly.",
    "",
    "> Every item tagged **Getting Started** is an example. Open it, copy its structure for",
    "> your own work, then delete the examples when you're comfortable.",
    "",
    "## 🧠 Skills",
    "Reusable know-how (`skills/<Category>/<name>.md`). Add one with the **＋** button on the",
    "Skills tab, or right-click a sidebar folder → *Add skill here*.",
    "",
    "## 📝 Notes",
    "Quick Markdown notes with live preview — `[[wiki links]]`, pasted images, Mermaid",
    "diagrams, KaTeX math (`$...$`), and task lists (`[ ] [x] [~] [!]`). Pin a note or folder",
    "to keep it on top. Files: `notes/<Category>/<Title>.md`.",
    "",
    "## 📄 Papers",
    "Track research papers and your own **ideas** with a citation graph (2D/3D). Each paper is",
    "`papers/<Topic>/<Title>.md` with metadata, conclusions, citations, and an optional URL/file.",
    "",
    "## 🧩 Prompts",
    "Versioned prompt files: `prompts/<project>/<task>/<version>/<file>` — keep iterations side by side.",
    "",
    "## 📦 Packages",
    "Browse small reusable code packages (`packages/<name>/…`) you want handy across projects.",
    "",
    "## 📜 Scripts",
    "Organise scripts in a folder tree (`scripts/<Category>/<file>`) with language tags, syntax",
    "highlighting, and an **AI Summary** button.",
    "",
    "## Navigation and right-click menus",
    "Right-click any folder or document to copy its canonical PKM path. Menus group Open, Copy,",
    "Create, Edit, Organize, Control, and Danger actions so destructive operations remain last.",
    "",
    "## Privacy and browser links",
    "Top-level folder privacy is inherited. Public Notes, Skills, Papers, and Scripts can use stable",
    "browser links on the configured hostname/interface and fixed Content Gateway port. Private",
    "content is not publicly discoverable and returns 404; owner Preview uses temporary access.",
    "",
    "## 🐍 Python Environments",
    "Manage conda / venv / uv envs: Python version + size, compare two envs, find near-duplicates",
    "to merge, open an activated shell, or migrate an env into a central folder. (Machine-local.)",
    "",
    "## 🖥 Servers",
    "Run local servers as managed packages: start/stop, change port, view logs, and reach each",
    "through a stable proxy URL.",
    "",
    "## 🔄 Sync",
    "Share with another machine: the host generates a one-paste encrypted **Magic Code**; the receiver",
    "pastes it, then chooses to **merge directly** or drop everything into a **new group** to review.",
    "",
    "## Subscription Brokers",
    "Subscribe to another Broker to search its downloaded Skills, Notes, Papers, Prompts, Scripts,",
    "Packages, and Server links without merging them into local Knowledge. Realtime notifications",
    "refresh changed Brokers automatically; use right-click **Refresh from Broker** as a manual fallback.",
    "Subscribed Copy Path values work with MCP `get_subscribed_content_by_path`.",
    "",
    "## 🤖 MCP (for AI assistants)",
    "The Config tab manages a dedicated Python runtime and generates one unified `pkm` server with",
    "read/write Knowledge, Subscription, Skill workflow, and Chatroom tools. Update generated code",
    "when the Config version table reports it as outdated.",
    "",
    "---",
    "Files are the source of truth — edit here, in your editor, or via MCP, and the panel",
    "refreshes automatically. Everything is git-tracked, so nothing is lost.",
  );

  skillUpsert({
    name: "getting-started", category: GS,
    description: "How to use each part of Personal Knowledge Manager",
    tags: ["guide", "onboarding"], content: guide,
  });

  skillUpsert({
    name: "example-skill", category: GS,
    description: "A template skill — copy its structure for your own",
    tags: ["example"],
    content: md(
      "# Example Skill",
      "",
      "A **skill** is reusable know-how you want to find again — a checklist, a command, a gotcha.",
      "",
      "## When to use",
      "Describe the situation this applies to.",
      "",
      "## Steps",
      "1. First do this.",
      "2. Then that.",
      "",
      "## Gotchas",
      "- Note anything that bit you.",
      "",
      "_Delete this example once you've added your own skills._",
    ),
  });

  noteUpsert({
    slug: `${GS}/Welcome`, title: "Welcome", type: "general",
    tags: ["example"], category: GS, pinned: true,
    content: md(
      "# 👋 Welcome to Personal Knowledge Manager",
      "",
      "This is an **example note**. Notes render Markdown live:",
      "",
      "- Task list:",
      "  - [x] done",
      "  - [ ] todo",
      "  - [~] in progress",
      "  - [!] blocked",
      "- Math: $e^{i\\pi} + 1 = 0$",
      "- A diagram:",
      "",
      "```mermaid",
      "flowchart LR",
      "  Idea --> Note --> Skill",
      "```",
      "",
      "Jump to the [[getting-started]] guide. Paste an image straight in — it's stored next to",
      "the note. Pin this note (★) to keep it on top.",
      "",
      "_Delete this example once you're comfortable._",
    ),
  });

  paperUpsert({
    slug: "example-paper", title: "Example Paper — how papers work",
    category: GS, topic: GS, authors: ["You"], year: 2025, tags: ["example"],
    conclusions: ["Papers are plain Markdown with metadata", "The graph links citations you list"],
    content: md(
      "# Example Paper",
      "",
      "Papers track research (or your own **ideas**) with authors, year, conclusions, and",
      "citations. List a citation by another paper's title or slug and it shows up in the graph.",
      "",
      "Attach a remote **URL** or upload a local PDF. Toggle the 2D/3D graph to explore links.",
      "",
      "_Delete this example when you add real papers._",
    ),
  });

  promptImport([{
    project: "example-project", task: "summarize", version: "v1", file: "system.md",
    content: md(
      "# System prompt (example)",
      "",
      "You are a concise assistant. Summarize the user's text in 3 bullet points.",
      "",
      "Keep versions of a prompt side by side under prompts/<project>/<task>/<version>/.",
    ),
  }]);

  scriptImport([{
    category: GS, file: "hello.py",
    content: md(
      "#!/usr/bin/env python3",
      '"""Example script. Scripts get language tags, highlighting, and an AI Summary button."""',
      "",
      "def main() -> None:",
      '    print("Hello from your knowledge base!")',
      "",
      'if __name__ == "__main__":',
      "    main()",
    ),
  }]);

  packageImport([{
    name: "example-package",
    files: [
      { path: "README.md", content: md("# example-package", "", "Drop small reusable libraries here to keep them handy across projects.") },
      { path: "hello.py", content: md("def hello() -> str:", '    return "hi from example-package"') },
    ],
  }]);
}

/** Seed examples once, only for a brand-new (empty) store. */
async function maybeSeedExamples(context: vscode.ExtensionContext): Promise<void> {
  if (context.globalState.get<boolean>("examplesSeeded", false)) return;
  try {
    if (!storeIsEmpty()) { await context.globalState.update("examplesSeeded", true); return; }
    seedExamples();
    gitCommit("seed: getting-started examples");
    log.info("seeded getting-started examples into empty store");
  } catch (e: any) {
    log.warn(`example seeding skipped: ${e?.message}`);
  }
  await context.globalState.update("examplesSeeded", true);
}

/** Returns true if the file store is ready; otherwise runs the setup wizard. */
async function ensureSetup(context: vscode.ExtensionContext): Promise<boolean> {
  if (_storeReady) return true;

  const resolved = resolvedStorePath(context);
  if (resolved) {
    await rememberMachineStorePath(context, resolved.path);
    await initStore(context, resolved.path);
    return _storeReady;
  }

  const chosen = await firstTimeSetup(context, true);
  if (!chosen) {
    vscode.window.showErrorMessage(
      "Personal Knowledge Manager: you must complete setup before using this extension.",
      "Configure now"
    ).then(v => { if (v) ensureSetup(context); });
    return false;
  }
  await initStore(context, chosen);
  void maintainPkmIntegration(context);
  return _storeReady;
}

// Resolve a note-link target to a note slug. `target` is a relative (./, ../,
// sub/x.md) or absolute .md path; `from` is the source note's slug. Returns the
// resolved slug (relative path w/o .md) or null if it escapes the notes store.
function resolveNoteSlugFromPath(target: string, from: string): string | null {
  const notesDir = path.join(getStorePath(), "notes");
  let clean: string;
  try { clean = decodeURIComponent(target.replace(/[?#].*$/, "")); }
  catch { clean = target.replace(/[?#].*$/, ""); }
  // Absolute filesystem path pointing inside the notes store.
  if (path.isAbsolute(clean)) {
    const rel = path.relative(notesDir, clean).replace(/\\/g, "/");
    if (!rel || rel === ".." || rel.startsWith("../")) return null;
    return rel.replace(/\.md$/i, "");
  }
  // Relative to the source note's folder (slug dir).
  const fromDir = from.includes("/") ? from.slice(0, from.lastIndexOf("/")) : "";
  const joined = path.posix.normalize(path.posix.join(fromDir, clean));
  if (joined === ".." || joined.startsWith("../")) return null;
  return joined.replace(/^\.\//, "").replace(/^\/+/, "").replace(/\.md$/i, "");
}

function makeWebviewOptions(context: vscode.ExtensionContext): vscode.WebviewOptions & vscode.WebviewPanelOptions {
  return {
    enableScripts: true,
    retainContextWhenHidden: true,
    localResourceRoots: [
      vscode.Uri.joinPath(context.extensionUri, "dist", "webview"),
      vscode.Uri.joinPath(context.extensionUri, "src", "webview"),
      vscode.Uri.joinPath(context.extensionUri, "node_modules", "marked"),
      vscode.Uri.file(getStorePath()),                                             // note/skill _assets
      vscode.Uri.file(path.join(context.globalStorageUri.fsPath, "subscriptions", "cache")),
    ],
  };
}

function getWebviewHtml(webview: vscode.Webview, context: vscode.ExtensionContext): string {
  // prefer dist/webview (packaged), fall back to src/webview (dev)
  const distDir = path.join(context.extensionPath, "dist", "webview");
  const srcDir  = path.join(context.extensionPath, "src",  "webview");
  const webviewDir = fs.existsSync(path.join(distDir, "panel.html")) ? distDir : srcDir;
  const webviewResourceDir = webviewDir === distDir
    ? vscode.Uri.joinPath(context.extensionUri, "dist", "webview")
    : vscode.Uri.joinPath(context.extensionUri, "src", "webview");
  let html = fs.readFileSync(path.join(webviewDir, "panel.html"), "utf-8");

  const panelJs = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "panel.js"));
  const panelCss = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "panel.css"));
  const codiconCss = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "codicon.css"));
  html = html.replace(/%%PANEL_JS%%/g, panelJs.toString());
  html = html.replace(/%%HOST_HEALTH_JS%%/g, webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "host-health.js")).toString());
  html = html.replace(/%%HOST_HEALTH_CSS%%/g, webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "host-health.css")).toString());
  html = html.replace(/%%PANEL_CSS%%/g, panelCss.toString());
  html = html.replace(/%%AGENT_HARNESS_CSS%%/g, webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "agent-harness.css")).toString());
  html = html.replace(/%%CODICON_CSS%%/g, codiconCss.toString());

  // Load marked as an external file (inlining breaks HTML parsing due to <!-- --> in marked)
  const markedFsPath = fs.existsSync(path.join(distDir, "marked.umd.js"))
    ? path.join(distDir, "marked.umd.js")
    : path.join(context.extensionPath, "node_modules", "marked", "lib", "marked.umd.js");
  const markedResource = markedFsPath.startsWith(distDir)
    ? vscode.Uri.joinPath(webviewResourceDir, "marked.umd.js")
    : vscode.Uri.joinPath(context.extensionUri, "node_modules", "marked", "lib", "marked.umd.js");
  const markedUri = webview.asWebviewUri(markedResource);
  html = html.replace(/%%MARKED_SRC%%/g, markedUri.toString());

  // Syntax highlighting (highlight.js bundled locally with a custom Scope grammar)
  const hljsJs  = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "hljs.js"));
  const hljsCss = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "hljs.css"));
  html = html.replace(/%%HLJS_SRC%%/g, hljsJs.toString());
  html = html.replace(/%%HLJS_CSS%%/g, hljsCss.toString());

  // Math rendering (KaTeX bundled locally: JS + CSS + fonts). Fonts are loaded
  // by katex.css via relative url(fonts/...) which resolve under webviewDir.
  const katexJs  = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "katex.js"));
  const katexCss = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "katex.css"));
  html = html.replace(/%%KATEX_SRC%%/g, katexJs.toString());
  html = html.replace(/%%KATEX_CSS%%/g, katexCss.toString());

  // Graph rendering (Cytoscape.js bundled locally) for the Papers graph view.
  const cytoscapeJs = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "cytoscape.js"));
  html = html.replace(/%%CYTOSCAPE_SRC%%/g, cytoscapeJs.toString());

  // Diagram rendering (Mermaid bundled locally) for ```mermaid fenced blocks.
  const mermaidJs = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "mermaid.js"));
  html = html.replace(/%%MERMAID_SRC%%/g, mermaidJs.toString());

  // 3D citation graph (3d-force-graph + three.js bundled locally).
  const fg3dJs = webview.asWebviewUri(vscode.Uri.joinPath(webviewResourceDir, "forcegraph3d.js"));
  html = html.replace(/%%FORCEGRAPH3D_SRC%%/g, fg3dJs.toString());

  // Inject the webview CSP source — required for VS Code to allow scripts to run
  html = html.replace(/%%CSP_SOURCE%%/g, webview.cspSource);

  // Base URIs for portable Markdown resources. Relative image references are
  // resolved against the source document's directory inside the approved root.
  const skillsBase = webview.asWebviewUri(vscode.Uri.file(path.join(getStorePath(), "skills")));
  const notesBase = webview.asWebviewUri(vscode.Uri.file(path.join(getStorePath(), "notes")));
  const papersBase = webview.asWebviewUri(vscode.Uri.file(path.join(getStorePath(), "papers")));
  const subscriptionsBase = webview.asWebviewUri(vscode.Uri.file(path.join(context.globalStorageUri.fsPath, "subscriptions", "cache")));
  html = html.replace(/%%SKILLS_BASE%%/g, skillsBase.toString());
  html = html.replace(/%%NOTES_BASE%%/g, notesBase.toString());
  html = html.replace(/%%PAPERS_BASE%%/g, papersBase.toString());
  html = html.replace(/%%SUBSCRIPTIONS_BASE%%/g, subscriptionsBase.toString());

  // Stamp the extension version so the running webview build is always visible.
  const version = (context.extension?.packageJSON?.version as string) || "?";
  html = html.replace(/%%PKM_VERSION%%/g, version);
  const languageSetting = uiLanguageSetting();
  const localizationPayload = Buffer.from(JSON.stringify({
    setting: languageSetting,
    resolved: resolveUiLanguage(languageSetting, vscode.env.language, context.extensionPath),
    locales: loadLocaleManifest(context.extensionPath).locales,
    catalogs: loadLocaleCatalogs(context.extensionPath),
  }), "utf8").toString("base64");
  html = html.replace(/%%I18N_PAYLOAD_B64%%/g, localizationPayload);
  return html;
}

function getOrCreatePanel(context: vscode.ExtensionContext): vscode.WebviewPanel {
  const existing = activePanel();
  if (existing) { existing.reveal(); return existing; }

  return createPanelInstance(context, panels.staging.snapshot, true);
}

function injectPanelSnapshot(html: string, snapshot: unknown): string {
  const encoded = Buffer.from(JSON.stringify(snapshot || {})).toString("base64");
  return html.replace("<head>", `<head><meta name="pkm-panel-snapshot" content="${encoded}">`);
}

function createPanelInstance(context: vscode.ExtensionContext, snapshot: unknown = {}, transferPending = false): vscode.WebviewPanel {
  const created = vscode.window.createWebviewPanel(
    "personalKnowledge",
    "Personal Knowledge Manager",
    vscode.ViewColumn.One,
    makeWebviewOptions(context)
  );
  initializePanel(created, context, false, snapshot);
  if (transferPending) {
    const session = panels.instances.get(created)!;
    for (const key of Object.keys(panels.staging).filter(key => key.startsWith("pending"))) {
      (session as any)[key] = (panels.staging as any)[key];
      (panels.staging as any)[key] = undefined;
    }
  }
  return created;
}

function initializePanel(target: vscode.WebviewPanel, context: vscode.ExtensionContext, restored: boolean, snapshot: unknown = {}): void {
  const previousActive = panels.active;
  const session = panels.add(target, snapshot);
  if (!target.active && previousActive) panels.focus(previousActive);
  if (performanceStateDir && activationStartedAt) recordPerformanceMetric(performanceStateDir, "startup.framework_ms", Date.now() - activationStartedAt);
  target.webview.options = makeWebviewOptions(context);
  target.iconPath = vscode.Uri.joinPath(context.extensionUri, "resources", "brand-icon.svg");
  session.ready = false; // fresh webview; wait for its "ready" signal
  session.lastHeartbeat = Date.now();
  session.lastDiagnostic = "";
  const htmlStartedAt = Date.now();
  const html = getWebviewHtml(target.webview, context);
  const htmlDuration = Date.now() - htmlStartedAt;
  if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "startup.panel_html_ms", htmlDuration, html.length);
  target.webview.html = injectPanelSnapshot(html, session.snapshot);
  loadProfiler.record("host.panel.html_ready", {
    restored,
    durationMs: htmlDuration,
    htmlBytes: html.length,
  });
  log.info(`panel ${restored ? "restored" : "created"} (html ${html.length} bytes, generated ${htmlDuration}ms)`);
  if (session.recoveryTimer) clearTimeout(session.recoveryTimer);
  session.recoveryTimer = scheduleRestoredWebviewRecovery({
    restored,
    isReady: () => session.ready,
    isCurrent: () => panels.instances.has(target),
    recover: () => {
      session.recoveryTimer = undefined;
      log.warn("restored panel did not become ready; recreating the webview");
      target.dispose();
      setTimeout(() => createPanelInstance(context, session.snapshot), 0);
    },
  });
  session.recoveryTimer?.unref?.();

  // Debug: dump generated HTML for inspection (debug level only)
  if (vscode.workspace.getConfiguration("personalKnowledge").get<string>("logLevel", "info") === "debug") {
    const dbgDir = context.globalStorageUri.fsPath;
    void fs.promises.mkdir(dbgDir, { recursive: true })
      .then(() => fs.promises.writeFile(path.join(dbgDir, "panel-generated.html"), html))
      .catch(() => undefined);
  }

  target.webview.onDidReceiveMessage(
    msg => {
      log.debug(`webview → ${JSON.stringify(msg).slice(0, 200)}`);
      const traceId = String(msg.profileRequestId || "");
      const startedAt = performance.now();
      if (traceId) {
        loadProfiler.record("host.request.received", {
          traceId,
          command: String(msg.command || ""),
          surface: String(msg.profileSurface || ""),
          workspace: String(msg.profileWorkspace || ""),
        });
      }
      void panels.requests.run(session, () => handleMessage(msg, m => panels.reply(session, {
        ...m,
        ...(traceId ? { profileRequestId: traceId } : {}),
      }), context)).finally(() => {
        if (/^(save|delete|markDone|skillRename|skillMove|skillSet|noteSet|knowledgeTrash|createKnowledge|updateKnowledgeMetadata|recipe(?:Create|Update|Delete|Trash|Folder)|project(?:Create|Overview|Link|Lifecycle|Checkpoint)|ganttTask(?:Create|Update|Delete)|thread(?:Create|Rename|Move)|server(?:Update|Delete|Create)|envUpdate)/.test(String(msg.command || ""))) panels.broadcast({ command: "sharedDataChanged" }, target);
        if (traceId) {
          loadProfiler.record("host.request.completed", {
            traceId,
            command: String(msg.command || ""),
            surface: String(msg.profileSurface || ""),
            durationMs: Math.round(performance.now() - startedAt),
          });
        }
      });
    },
    undefined, context.subscriptions
  );

  target.onDidChangeViewState(() => {
    if (!target.active) return;
    panels.focus(target);
    if (session.ready) panels.reply(session, { command: "panelVisible" });
  }, undefined, context.subscriptions);
  target.onDidDispose(() => {
    if (session.recoveryTimer) clearTimeout(session.recoveryTimer);
    session.recoveryTimer = undefined;
    panels.remove(target);
    session.ready = false;
    loadProfiler.record("host.panel.disposed", { heartbeatAgeMs: Date.now() - session.lastHeartbeat });
    log.info(`panel disposed heartbeatAgeMs=${Date.now() - session.lastHeartbeat}${session.lastDiagnostic ? ` lastDiagnostic=${session.lastDiagnostic}` : ""}`);
  }, undefined, context.subscriptions);
}

// ── Shared message handler (panel + sidebar) ───────────────────────────────
async function serverListForUi(context: vscode.ExtensionContext, inspectExternalSlug = ""): Promise<any[]> {
  const autoForward = context.globalState.get<boolean>("servers.autoForward.global.v1", true);
  const externalLinkHost = externalLinkHostOptions().resolved;
  const servers = await serverList(inspectExternalSlug);
  const markers = brokerShareMarkers("servers", servers, (sharedMarket?.snapshot as any)?.shares || []);
  return servers.map(server => ({
    ...server,
    isPrivate: isContentItemPrivate("servers", server),
    brokerShares: markers.items[sharedContentIdentity("servers", server)]?.brokers || [],
    autoForward,
    remoteName: vscode.env.remoteName || "",
    externalLinkHost,
  }));
}

const subscribedServerHealth = new Map<string, { checkedAt: number; status: "running" | "unavailable" }>();
async function probeSubscribedServer(link: string): Promise<"running" | "unavailable"> {
  try {
    let response = await fetch(link, { method: "HEAD", redirect: "follow", signal: AbortSignal.timeout(3_000) });
    if (response.status === 405 || response.status === 501) {
      response = await fetch(link, { method: "GET", redirect: "follow", signal: AbortSignal.timeout(3_000) });
      await response.body?.cancel();
    }
    return response.status < 500 ? "running" : "unavailable";
  } catch {
    return "unavailable";
  }
}

async function subscribedServerGroupsForUi(subscriptionId = "", probe = false): Promise<any[]> {
  if (!sharedMarket) return [];
  const groups = sharedMarket.cachedGroups("servers");
  return Promise.all(groups.map(async group => ({
    ...group,
    items: await Promise.all(group.items.map(async item => {
      const server = sharedMarket!.cachedServerLinks(item.key);
      const link = server.links[0]?.url || "";
      const cached = subscribedServerHealth.get(link);
      let status: "running" | "unavailable" | "not-checked" = cached?.status || "not-checked";
      if (link && probe && group.subscriptionId === subscriptionId) {
        const probedStatus = await probeSubscribedServer(link);
        status = probedStatus;
        subscribedServerHealth.set(link, { checkedAt: Date.now(), status: probedStatus });
      }
      return { ...item, title: server.name, link, status };
    })),
  })));
}

async function ensureServerForwarding(context: vscode.ExtensionContext, slug: string): Promise<string> {
  if (!slug || !vscode.env.remoteName) return "";
  if (!context.globalState.get<boolean>("servers.autoForward.global.v1", true)) return "";
  const server = (await serverList()).find(item => item.slug === slug && item.status !== "stopped");
  if (!server?.localUrl) return "";
  try { return (await vscode.env.asExternalUri(vscode.Uri.parse(server.localUrl))).toString(); }
  catch (error: any) {
    vscode.window.showWarningMessage(`Couldn't forward ${server.localUrl}: ${error?.message || String(error)}`);
    return "";
  }
}

function panelEditIdentity(type: string, key: unknown): string { return type + ":" + String(key || ""); }
function panelEditValue(type: string, key: string): unknown {
  if (type === "skill") return skillGet(key);
  if (type === "note") return noteGet(key);
  if (type === "paper") return paperGet(key);
  if (type === "script") return scriptGet(key);
  return undefined;
}
function panelEditRevision(value: unknown): string { return createHash("sha256").update(JSON.stringify(value ?? null)).digest("hex"); }
function advancePanelEditBaseline(type: string, key: string, respond: (message: object) => void): void {
  const session = panelSession();
  const identity = panelEditIdentity(type, key);
  const revision = panelEditRevision(panelEditValue(type, key));
  session.revisions.set(identity, revision);
  session.snapshot.editRevisions ||= {};
  session.snapshot.editRevisions[identity] = revision;
  respond({ command: "panelEditBaseline", identity, revision });
}

function checkPanelEdit(msg: any): void {
  const types: Record<string, string> = { saveNote:"note", saveSkill:"skill", savePaper:"paper", saveScript:"script" };
  const type = types[msg.command];
  if (!type) return;
  const key = String(msg.name || msg.slug || msg.paper?.slug || msg.path || "");
  if (!key) return;
  const session = panelSession();
  const identity = panelEditIdentity(type, key);
  const baseline = session.snapshot.editRevisions?.[identity] || session.revisions.get(identity);
  if (baseline && baseline !== panelEditRevision(panelEditValue(type, key))) {
    throw new Error("This item changed in another PKM tab or on disk. Your draft was kept. Refresh/reopen the item before saving.");
  }
}

async function handleMessage(
  msg: any,
  respond: (m: object) => void,
  context: vscode.ExtensionContext
): Promise<void> {
  const panel = activePanel();
  const session = panelSession();
  try {
  checkPanelEdit(msg);
  // Log user-meaningful actions at info level; noisy list/detail at debug
    if (["saveNote", "saveSkill", "deleteNote", "deleteSkill", "markDone",
      "export", "import", "startSync", "joinSync", "revokeSync", "generateMcp", "setSkillRouterSolutionEnabled"].includes(msg.command)) {
    log.action(`webview.${msg.command}`);
  } else {
    log.debug(`handleMessage: ${msg.command}`);
  }
  switch (msg.command) {
    case "helpGuide": {
      const language = msg.language === "zh-hans" ? "zh-hans" : "en";
      const requestId = Number.isSafeInteger(msg.requestId) ? msg.requestId : 0;
      try {
        respond({ command: "helpGuide", data: { ...await readHelpGuide(context.extensionPath, language), requestId } });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        log.error(`PKM Help guide could not be loaded: ${message}`);
        respond({ command: "helpGuide", data: { language, requestId, error: message } });
      }
      break;
    }
    case "showLogs": {
      log.show();
      break;
    }
    case "panelViewState": {
      session.snapshot = panelsSnapshot(msg.state);
      break;
    }
    case "duplicatePanel": {
      createPanelInstance(context, msg.state || session.snapshot);
      break;
    }
    case "actionWorkbenchDocument": {
      if (!panel) break;
      const surface = msg.surface === "actionLibrary" ? "actionLibrary" : "actions";
      try { respond({ command: "actionWorkbenchDocument", surface, html: surface === "actionLibrary" ? renderEmbeddedActionLibrary(context, msg.state) : renderEmbeddedActionWorkbench(panel.webview, context, msg.state) }); }
      catch (error) { respond({ command: "actionWorkbenchDocument", surface, error: error instanceof Error ? error.message : String(error) }); }
      break;
    }
    case "actionWorkbenchRequest": {
      const surface = msg.surface === "actionLibrary" ? "actionLibrary" : "actions";
      const handler = surface === "actionLibrary" ? handleActionLibraryMessage : handleActionWorkbenchMessage;
      await handler(context, msg.message, message => respond({ command: "actionWorkbenchReply", surface, message }));
      panels.broadcast({ command: "sharedDataChanged" }, panel);
      break;
    }
    case "markdownDraftState": {
      session.markdownDraftOpen = msg.busy === true;
      break;
    }
    case "hostHealth": {
      if (typeof msg.id === "string" && msg.id.length <= 64) respond({ command: "hostHealth", id: msg.id });
      break;
    }
    case "setPanelTitle": {
      const title = String(msg.title || "").replace(/[\r\n\t]+/g, " ").trim().slice(0, 120);
      if (panel && title) panel.title = title;
      break;
    }

    case "webviewDiagnostic": {
      if (msg.kind === "heartbeat") {
        session.lastHeartbeat = Date.now();
      } else {
        session.lastDiagnostic = `${String(msg.kind || "error")}: ${String(msg.message || "unknown").slice(0, 500)}`;
        log.warn(`webview diagnostic ${session.lastDiagnostic}`);
      }
      break;
    }

    case "loadProfileEvent": {
      loadProfiler.record(String(msg.event || ""), {
        traceId: String(msg.traceId || ""),
        command: String(msg.profileCommand || ""),
        surface: String(msg.surface || ""),
        workspace: String(msg.workspace || ""),
        durationMs: Math.max(0, Math.round(Number(msg.durationMs) || 0)),
      });
      break;
    }

    case "setLoadProfiling": {
      const enabled = !!msg.enabled;
      if (!enabled) loadProfiler.record("profiling.disabled", { surface: "mcp" });
      await vscode.workspace.getConfiguration("personalKnowledge").update(
        "loadProfilingEnabled", enabled, vscode.ConfigurationTarget.Global);
      loadProfiler.refresh();
      if (enabled) loadProfiler.record("profiling.enabled", { surface: "mcp" });
      respond({ command: "mcpStatus", data: mcpPanelStatusData(String(msg.profileRequestId || "")) });
      break;
    }

    case "showLoadProfilingOutput": {
      loadProfiler.show();
      break;
    }

    case "openLoadProfilingLog": {
      await loadProfiler.open();
      break;
    }

    case "openGitHubSyncDiagnosticLog": {
      await githubSyncDiagnostics.open();
      break;
    }

    case "clearLoadProfilingLog": {
      loadProfiler.clear();
      if (loadProfiler.enabled()) loadProfiler.record("profiling.cleared", { surface: "mcp" });
      break;
    }

    case "webviewStartupTiming": {
      const scriptStartMs = Math.max(0, Number(msg.scriptStartMs) || 0);
      const firstPaintMs = Math.max(0, Number(msg.firstPaintMs) || 0);
      const firstContentfulPaintMs = Math.max(0, Number(msg.firstContentfulPaintMs) || 0);
      if (performanceStateDir) {
        recordPerformanceMetric(performanceStateDir, "startup.webview_script_ms", scriptStartMs);
        recordPerformanceMetric(performanceStateDir, "startup.webview_first_paint_ms", firstPaintMs);
        if (firstContentfulPaintMs) recordPerformanceMetric(performanceStateDir, "startup.webview_first_contentful_paint_ms", firstContentfulPaintMs);
      }
      loadProfiler.record("webview.startup", { scriptStartMs, firstPaintMs, firstContentfulPaintMs });
      log.info(`webview startup scriptStartMs=${scriptStartMs} firstPaintMs=${firstPaintMs} firstContentfulPaintMs=${firstContentfulPaintMs}`);
      break;
    }

    case "webviewLibraryTiming": {
      const durationMs = Math.max(0, Number(msg.durationMs) || 0);
      if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "startup.webview_libraries_ms", durationMs);
      loadProfiler.record("webview.libraries", {
        durationMs,
        loaded: Number(msg.loaded) || 0,
        failed: Number(msg.failed) || 0,
      });
      log.debug(`webview markdown libraries durationMs=${durationMs} loaded=${Number(msg.loaded) || 0} failed=${Number(msg.failed) || 0}`);
      break;
    }

    case "setUiLanguage": {
      const requested = String(msg.language || "auto") as UiLanguageSetting;
      const setting: UiLanguageSetting = requested === "auto" ? "auto" : normalizeUiLanguage(context.extensionPath, requested) || "auto";
      await vscode.workspace.getConfiguration("personalKnowledge").update("uiLanguage", setting, vscode.ConfigurationTarget.Global);
      const catalogs = loadLocaleCatalogs(context.extensionPath);
      const resolved = resolveUiLanguage(setting, vscode.env.language, context.extensionPath);
      respond({ command: "uiLanguage", data: { setting, resolved, locales: loadLocaleManifest(context.extensionPath).locales, catalogs } });
      _treeProvider?.refresh();
      break;
    }

    case "ready": {
      // Webview finished loading — flush any queued item to open
      if (session.recoveryTimer) clearTimeout(session.recoveryTimer);
      session.recoveryTimer = undefined;
      session.ready = true;
      respond({ command: "loadingProgress", data: { stage: "preparing", percent: 5, message: "Brewing the startup potion…" } });
      if (session.pendingOpen) {
        const { type, key, edit, tab } = session.pendingOpen;
        session.pendingOpen = undefined;
        respond({ command: "openItem", type, key, edit, tab });
      }
      if (session.pendingTab) {
        const tab = session.pendingTab;
        session.pendingTab = undefined;
        const helpSection = tab === "help" ? session.pendingHelpSection : undefined;
        session.pendingHelpSection = undefined;
        respond({ command: "openTab", tab, helpSection });
      }
      if (session.pendingActions) {
        respond({ command: "openEmbeddedActions", state: session.pendingActions });
        session.pendingActions = undefined;
      }
      if (session.pendingProjectId) {
        respond({ command: "openProject", projectId: session.pendingProjectId });
        session.pendingProjectId = undefined;
      }
      if (session.pendingNativeSessionId) {
        respond({ command:"openNativeHarness", sessionId:session.pendingNativeSessionId });
        session.pendingNativeSessionId = undefined;
      }
      if (session.pendingSubscriptionShare !== undefined) {
        const shareId = session.pendingSubscriptionShare;
        session.pendingSubscriptionShare = undefined;
        respond({ command: "openSubscription", shareId });
      }
      if (session.pendingServerSlug !== undefined) {
        const slug = session.pendingServerSlug;
        session.pendingServerSlug = undefined;
        respond({ command: "focusServer", slug });
      }
      if (session.pendingEnvironmentId !== undefined) {
        const environmentId = session.pendingEnvironmentId;
        session.pendingEnvironmentId = undefined;
        respond({ command: "focusEnvironment", environmentId });
      }
      if (session.pendingMcpRegenerateHighlight) {
        session.pendingMcpRegenerateHighlight = false;
        respond({ command: "highlightMcpRegenerate" });
      }
      if (session.pendingMcpSetupTarget) {
        respond({ command: "focusMcpSetup", target: session.pendingMcpSetupTarget });
        session.pendingMcpSetupTarget = undefined;
      }
      respond({
        command: "mcpSummary",
        data: {
          ...mcpStatus(),
          extensionVersion: String(context.extension?.packageJSON?.version || "unknown"),
          loadProfiling: { enabled: loadProfiler.enabled() },
        },
      });
      respond({ command: "backgroundTasks", data: backgroundTaskRegistry.snapshot() });
      const version = String(context.extension?.packageJSON?.version || "").trim();
      const previousVersion = context.globalState.get<string>(TOUR_LAST_SEEN_RELEASE_KEY, "")
        || context.globalState.get<string>(LEGACY_LAST_SHOWN_VERSION_KEY, "");
      const experience = decideInitialExperience({
        version,
        previousVersion,
        onboardingPending: context.globalState.get<boolean>(ONBOARDING_PENDING_KEY, false),
        onboardingCompleted: context.globalState.get<boolean>(ONBOARDING_COMPLETED_KEY, false),
        seenModuleIds: context.globalState.get<string[]>(TOUR_SEEN_MODULES_KEY, []),
      });
      respond({ command: "tourCatalog", data: { version, modules: FEATURE_TOUR_MODULES } });
      if (experience) respond({ command: "initialExperience", data: experience });
      break;
    }

    case "completeTourModules": {
      const validIds = new Set(FEATURE_TOUR_MODULES.map(module => module.id));
      const completedIds = Array.isArray(msg.moduleIds)
        ? msg.moduleIds.map((id: unknown) => String(id || "")).filter((id: string) => validIds.has(id))
        : [];
      const seen = new Set(context.globalState.get<string[]>(TOUR_SEEN_MODULES_KEY, []));
      completedIds.forEach((id: string) => seen.add(id));
      await context.globalState.update(TOUR_SEEN_MODULES_KEY, [...seen].sort());
      const currentRelease = minorRelease(String(context.extension?.packageJSON?.version || ""));
      if (currentRelease) await context.globalState.update(TOUR_LAST_SEEN_RELEASE_KEY, currentRelease);
      if (msg.audience === "new") {
        await context.globalState.update(ONBOARDING_COMPLETED_KEY, true);
        await context.globalState.update(ONBOARDING_PENDING_KEY, false);
      }
      break;
    }

    case "userProfile":
    case "userProfileEdit":
    case "userProfileFragmentAction": {
      if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before inspecting Profiles.");
      const root = getStorePath();
      if (msg.command === "userProfileFragmentAction" && msg.knowledgeRoot !== root) throw new Error("Knowledge Root changed. Refresh User Profile before changing fragments.");
      const store = new PersonaProfileStore(context.globalStorageUri.fsPath, root);
      if (msg.command === "userProfileEdit") await configureUserProfile(store);
      if (getStorePath() !== root) throw new Error("Knowledge Root changed. Refresh User Profile.");
      const fragments = await vscode.commands.executeCommand("personalKnowledge.userProfileFragments",
        msg.command === "userProfileFragmentAction" ? msg.operation : "read", msg.params || {});
      if (getStorePath() !== root) throw new Error("Knowledge Root changed. Refresh User Profile.");
      if (!fragments) throw new Error("User Profile fragment service did not return a snapshot.");
      respond({ command: "userProfile", data: { user: store.user(),
        scope: store.syncEnabled ? "Knowledge Root repository cards" : "Private Host cards", fragments } });
      break;
    }

    case "backgroundTasks": {
      respond({ command: "backgroundTasks", data: backgroundTaskRegistry.snapshot() });
      break;
    }

    case "backgroundProcesses": {
      try {
        const installed = readInstalledExtensionBuild(context.extensionPath, context.extension.id);
        respond({ command: "backgroundProcesses", data: {
          ...await backgroundProcessInventory.snapshot(installed), loadedExtension: loadedExtensionBuild,
        } });
      } catch (error) {
        const message = `Background process inventory failed: ${(error as Error).message}`;
        log.warn(message);
        respond({ command: "backgroundProcesses", data: { sampledAt: new Date().toISOString(),
          host: os.hostname(), platform: process.platform, processes: [], error: message } });
      }
      break;
    }

    case "retrievalPerformance": {
      try {
        const learning = await retrievalWorker?.observeLearning();
        respond({ command:"retrievalPerformance", data:{ learning, requestId:msg.requestId } });
      } catch (error) {
        log.warn(`Retrieval performance refresh failed: ${(error as Error).message}`);
        respond({ command:"retrievalPerformance", data:{ error:(error as Error).message, requestId:msg.requestId } });
      }
      break;
    }

    case "retrievalSolutions":
    case "retrievalAdaptiveCount":
    case "retrievalSolutionImport":
    case "retrievalModelDownload":
    case "retrievalModelDirectory":
    case "retrievalSolutionRuntime":
    case "retrievalSolutionEnable":
    case "retrievalSolutionRebuild":
    case "retrievalSolutionDisable":
    case "retrievalSolutionDelete": {
      try {
        const worker = await requireRetrievalWorker(context);
        if (msg.command === "retrievalModelDownload" || msg.command === "retrievalModelDirectory") {
          if (!enabledSkillRouterSolutions().includes("l1_online")) throw new Error("Enable Exact + BM25 before setting up model retrieval.");
          const source = msg.command === "retrievalModelDownload" ? "huggingface" : "directory";
          const selected = source === "directory" ? await vscode.window.showOpenDialog({
            canSelectMany:false, canSelectFiles:false, canSelectFolders:true,
            title:"Choose a Multilingual E5 Small model directory (downloaded by any method)",
          }) : undefined;
          if (source === "huggingface" || selected?.[0]) {
            const confirmed = await vscode.window.showWarningMessage(
              source === "huggingface" ? "Download and enable Multilingual E5 Small from Hugging Face?" : "Import and enable this local Multilingual E5 Small model?",
              { modal:true, detail:"PKM will prepare its own embedding Python environment, install CPU model dependencies, download or import about 470 MiB of verified model files, apply the configuration and build the index automatically. Allow several GB of free disk for dependencies, model files and index storage. System Python is unchanged. No custom model code runs, and no knowledge text is uploaded. Exact + BM25 stays available." },
              source === "huggingface" ? "Set up embedding retrieval" : "Import & set up");
            if (confirmed) {
              const task = backgroundTaskRegistry.producer({ id:"retrieval:setup", kind:"retrieval", label:"Set up embedding retrieval" });
              try {
                await vscode.window.withProgress({ location:vscode.ProgressLocation.Notification, title:"Embedding model loading started. See PKM for details.", cancellable:true }, async (_progress, token) => {
                  const controller = new AbortController();
                  const cancel = token.onCancellationRequested(() => controller.abort(new Error("Model setup cancelled. Verified imported files may remain; no calls are replayed.")));
                  try {
                    await worker.prepareModel(source, selected?.[0]?.fsPath, String(msg.requestId), controller.signal, setup => {
                      task.running({ detail:setup.detail || setup.phase, progress:setup.phase === "acquire" && setup.total ? { current:setup.current || 0, total:setup.total, unit:"bytes" } : undefined });
                      void postToPanel({ command:"retrievalModelSetup", data:setup });
                    });
                  } finally { cancel.dispose(); }
                });
                void vscode.window.showInformationMessage("Embedding model loading complete.");
              } catch (error) {
                void vscode.window.showErrorMessage("Embedding model loading failed. See PKM for details.");
                throw error;
              } finally { task.idle(); }
            }
          }
        } else if (msg.command === "retrievalSolutionImport") {
          const selected = await vscode.window.showOpenDialog({ canSelectMany: false, filters: { "Offline retrieval package": ["zip"] },
            title: "Import a trusted offline retrieval solution" });
          if (selected?.[0]) {
            const confirmed = await vscode.window.showWarningMessage(
              "Import this trusted model package? It contains local model weights and is not a signed publisher artifact.",
              { modal: true, detail: selected[0].fsPath }, "Import");
            if (confirmed === "Import") {
              const task = backgroundTaskRegistry.producer({ id: "retrieval:import", kind: "retrieval", label: "Import retrieval model package" });
              task.running({ detail: "Verifying and importing local weights" });
              try { await worker.prepareModel("archive", selected[0].fsPath, String(msg.requestId), new AbortController().signal,
                setup => { void postToPanel({ command:"retrievalModelSetup", data:setup }); }); }
              finally { task.idle(); }
            }
          }
        } else if (msg.command === "retrievalSolutionRuntime") {
          const selected = await vscode.window.showOpenDialog({ canSelectMany: false, title: "Choose an existing model-capable Python executable",
            defaultUri: vscode.Uri.file(worker.modelRuntime().python) });
          if (selected?.[0]) await worker.configureModelRuntime(selected[0].fsPath);
        } else if (msg.command === "retrievalAdaptiveCount") {
          if (typeof msg.enabled !== "boolean") throw new Error("Adaptive result count requires a boolean enabled value.");
          await worker.setAdaptiveResultCount(msg.enabled);
        } else if (msg.command !== "retrievalSolutions") {
          const action = ({ retrievalSolutionEnable: "enable", retrievalSolutionRebuild: "rebuild",
            retrievalSolutionDisable: "disable", retrievalSolutionDelete: "delete" } as const)[msg.command as
              "retrievalSolutionEnable" | "retrievalSolutionRebuild" | "retrievalSolutionDisable" | "retrievalSolutionDelete"];
          if ((action === "enable" || action === "rebuild") && !enabledSkillRouterSolutions().includes("l1_online")) {
            throw new Error("Enable Exact + BM25 before enabling model retrieval so the lexical path remains available.");
          }
          const identity = String(msg.packageId || "");
          let confirmed = true;
          if (action === "delete") confirmed = await vscode.window.showWarningMessage(
            "Delete this imported model and its derived indexes? Knowledge documents, original model files and metrics are kept.",
            { modal: true, detail: identity }, "Delete") === "Delete";
          if (confirmed) await worker.setSolution(action, action === "disable" ? undefined : identity);
        }
        const catalog = await worker.solutions(), status = await worker.status();
        respond({ command: "retrievalSolutions", data: { ...catalog, setup:worker.setupStatus(), modelRuntime: worker.modelRuntime(),
          runtimeStatus: { semanticStatus: status.semantic_status, solution: status.solution, skillServing: status.skill_serving },
          actionCompleted: msg.command !== "retrievalSolutions", operationId: msg.requestId } });
        scheduleRetrievalSolutionStatus(context);
      } catch (error) {
        log.warn(`Retrieval solution operation failed: ${(error as Error).message}`);
        respond({ command: "retrievalSolutions", data: { error: (error as Error).message,
          actionCompleted: msg.command !== "retrievalSolutions", operationId: msg.requestId } });
      }
      break;
    }

    case "portalConnections": {
      respond({ command: "portalConnections", data: getChatMgr().portalConnectionHistory() });
      break;
    }

    case "portalEndpointCreate": case "portalEndpointPair": case "portalEndpointConnect":
    case "portalEndpointDisconnect": case "portalEndpointBind": case "portalEndpointPermissions": case "portalEndpointExternalAccess": case "portalEndpointRemove": {
      const operations: Record<string, string> = { portalEndpointCreate: "create", portalEndpointPair: "pair",
        portalEndpointConnect: "connect", portalEndpointDisconnect: "disconnect", portalEndpointBind: "bind",
        portalEndpointPermissions: "permissions", portalEndpointExternalAccess: "external-access", portalEndpointRemove: "remove" };
      await getChatMgr().managePersistentEndpoint(context, operations[msg.command], typeof msg.endpointId === "string" ? msg.endpointId : undefined);
      respond({ command: "portalConnections", data: getChatMgr().portalConnectionHistory() });
      break;
    }

    case "portalConnectionCopyMagicLink": {
      const chatId = typeof msg.chatId === "string" && /^[a-f0-9-]{36}$/.test(msg.chatId) ? msg.chatId : "";
      if (!chatId) throw new Error("Choose a Portal connection.");
      await getChatMgr().portalPendingLink(chatId, "copy");
      break;
    }

    case "openApiChat": {
      await vscode.commands.executeCommand("personalKnowledge.openApiChat");
      break;
    }

    case "agentSessionGroupOpenChat":
    case "portalConnectionOpenChat": {
      const chatId = typeof msg.chatId === "string" && /^[a-f0-9-]{36}$/.test(msg.chatId) ? msg.chatId : "";
      if (!chatId) throw new Error("Choose a PKM Chat.");
      await vscode.commands.executeCommand("personalKnowledge.openApiChat", chatId);
      break;
    }

    case "portalConnectionPermissions": {
      const chatId = typeof msg.chatId === "string" && /^[a-f0-9-]{36}$/.test(msg.chatId) ? msg.chatId : "";
      if (!chatId) throw new Error("Choose a Portal connection.");
      await vscode.commands.executeCommand("personalKnowledge.portalPermissions", chatId);
      break;
    }

    case "portalConnectionForget": {
      if (typeof msg.pairId !== "string" || !msg.pairId) throw new Error("Choose a recorded Portal connection.");
      getChatMgr().forgetPortalConnection(msg.pairId);
      break;
    }

    case "reload": {
      // Files are the source of truth and always read fresh, so this just
      // re-renders the tree + current tab (external edits are already on disk).
      _treeProvider?.refresh();
      log.action("reload");
      respond({ command: "reloaded", data: { manual: true } });
      break;
    }

    case "refreshKnowledgeFolder": {
      const area = String(msg.area || "");
      const category = String(msg.category || "").replace(/^\/+|\/+$/g, "");
      if (!["skills", "notes", "papers", "scripts"].includes(area)) throw new Error(`Unsupported category tree: ${area}`);
      const root = path.resolve(getStorePath(), area);
      const target = path.resolve(root, category);
      if (target !== root && !target.startsWith(root + path.sep)) throw new Error("Category path escapes the Knowledge Root");
      let timeout: NodeJS.Timeout | undefined;
      try {
        await Promise.race([
          fs.promises.readdir(target),
          new Promise<never>((_, reject) => { timeout = setTimeout(() => reject(new Error("Folder scan timed out after 3 seconds")), 3_000); }),
        ]);
        invalidateSharedContentCatalog();
        _treeProvider?.refresh();
        respond({ command: "reloaded", data: { folderScan: true, changedPath: `${area}/${category}/` } });
        scheduleRetrievalRefresh(context);
      } catch (error: any) {
        respond({ command: "knowledgeFolderScanFailed", data: { category, error: error?.message || String(error) } });
      } finally {
        if (timeout) clearTimeout(timeout);
      }
      break;
    }

    case "subscriptionState": {
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      if (msg.refresh !== false) {
        void getSharedMarket().refreshGatewayStatus()
          .then(() => subscriptionStateData(context))
          .then(data => respond({ command: "subscriptionState", data }))
          .catch(error => log.warn(`Subscription gateway status refresh failed: ${error instanceof Error ? error.message : String(error)}`));
      }
      break;
    }

    case "subscriptionConfigure": {
      await getSharedMarket().configure({
        enabled: !!msg.enabled,
        port: Number(msg.port || 19877),
        advertisedHost: String(msg.advertisedHost || ""),
        displayName: String(msg.displayName || ""),
      });
      respond({ command: "subscriptionCompleted", data: { action: "configured" } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionSetOnline": {
      await getSharedMarket().setGatewayOnline(!!msg.online);
      respond({ command: "subscriptionCompleted", data: { action: msg.online ? "online" : "offline" } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionUpsertShare": {
      const contentTypes = (Array.isArray(msg.contentTypes) ? msg.contentTypes : [])
        .filter((type: unknown): type is SharedContentType => SHARED_CONTENT_TYPES.includes(String(type) as SharedContentType));
      const published = await getSharedMarket().upsertShare({
        shareId: String(msg.shareId || "") || undefined,
        name: String(msg.name || ""),
        visibility: msg.visibility === "unlisted" ? "unlisted" : "public",
        contentTypes,
        selected: msg.selected || {},
        folders: msg.folders || {},
        accessMode: msg.accessMode === "white-list" ? "white-list" : "block-list",
        ipRules: Array.isArray(msg.ipRules) ? msg.ipRules : [],
        accountMode: msg.accountMode === "white-list" ? "white-list" : msg.accountMode === "block-list" ? "block-list" : "open",
        accountRules: Array.isArray(msg.accountRules) ? msg.accountRules : [],
        protection: msg.protection === "secret-protected" ? "secret-protected" : "open",
        secret: String(msg.secret || ""),
        controlPort: Number(msg.controlPort || 0),
        dataPort: Number(msg.dataPort || 0),
      });
      respond({ command: "subscriptionCompleted", data: { action: String(msg.shareId || "") ? "published" : "created", shareId: published.shareId, name: published.name, revision: published.revision } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionDeleteShare": {
      const shareId = String(msg.shareId || "");
      const share = (getSharedMarket().snapshot as any).shares?.find((item: any) => item.shareId === shareId);
      if (!share) throw new Error("Broker not found.");
      const choice = await vscode.window.showWarningMessage(
        `Delete Broker “${share.name}”?`,
        { modal: true, detail: "This stops publishing and removes the local Broker definition, snapshots, secret, and statistics. Existing Subscriber caches on other machines are not deleted." },
        "Delete Broker",
      );
      if (choice !== "Delete Broker") {
        respond({ command: "subscriptionCompleted", data: { action: "brokerDeleteCancelled", name: share.name } });
        break;
      }
      await getSharedMarket().deleteShare(shareId);
      respond({ command: "subscriptionCompleted", data: { action: "brokerDeleted", name: share.name } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionSetSharePublished": {
      const share = await getSharedMarket().setSharePublished(String(msg.shareId || ""), !!msg.published);
      respond({ command: "subscriptionCompleted", data: { action: share.published === false ? "brokerPaused" : "brokerPublished", name: share.name } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionCopyLink": {
      await vscode.env.clipboard.writeText(getSharedMarket().magicLink(String(msg.shareId || "")));
      respond({ command: "subscriptionCompleted", data: { action: "copied" } });
      break;
    }

    case "subscriptionRevealSecret": {
      const secret = await getSharedMarket().shareSecret(String(msg.shareId || ""));
      respond({ command: "subscriptionSecret", data: { secret } });
      break;
    }

    case "subscriptionRotateSecret": {
      const result = await getSharedMarket().rotateShareSecret(String(msg.shareId || ""), Number(msg.controlPort || 0));
      respond({ command: "subscriptionSecret", data: { secret: result.secret } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionUnblockIp": {
      await getSharedMarket().unblockIp(String(msg.shareId || ""), String(msg.ip || ""));
      respond({ command: "subscriptionCompleted", data: { action: "unblocked", ip: String(msg.ip || "") } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionAdd": {
      const subscribed = await getSharedMarket().subscribe(String(msg.magicLink || ""), String(msg.alias || ""), String(msg.secret || ""));
      respond({ command: "subscriptionCompleted", data: { action: "subscribed", name: subscribed.alias || subscribed.brokerName || subscribed.shareId } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionMountGitHub": {
      let lastProgressAt = 0;
      const startedAt = Date.now();
      let latestProgress: any;
      const heartbeat = setInterval(() => {
        if (latestProgress) respond({ command: "subscriptionGitHubProgress", data: { ...latestProgress, elapsedMs: Date.now() - startedAt, heartbeat: true } });
      }, 1_000);
      let mounted;
      try {
        mounted = await mountGitHubBranchSubscription(context, {
          targetId: String(msg.targetId || "") || undefined, credentialTargetId: String(msg.credentialTargetId || "") || undefined,
          repository: String(msg.repository || "") || undefined, branch: String(msg.branch || "") || undefined,
          expectedCommit: String(msg.expectedCommit || "") || undefined,
          selectedPaths: Array.isArray(msg.selectedPaths) ? msg.selectedPaths.map(String) : undefined,
          selectedFolders: Array.isArray(msg.selectedFolders) ? msg.selectedFolders.map(String) : undefined,
        }, String(msg.alias || ""), progress => {
          const now = Date.now();
          latestProgress = { ...progress, operation: "subscribe", elapsedMs: now - startedAt };
          if (progress.stage === "caching" && progress.current < progress.total && now - lastProgressAt < 100) return;
          lastProgressAt = now;
          respond({ command: "subscriptionGitHubProgress", data: latestProgress });
        });
      } finally {
        clearInterval(heartbeat);
      }
      invalidateSharedContentCatalog();
      respond({ command: "subscriptionGitHubProgress", data: { stage: "indexing", operation: "subscribe", current: mounted.itemCount, total: mounted.itemCount, cachedBytes: latestProgress?.cachedBytes || 0, totalBytes: latestProgress?.totalBytes || 0, elapsedMs: Date.now() - startedAt } });
      scheduleRetrievalRefresh(context);
      respond({
        command: "subscriptionCompleted",
        data: {
          action: "githubMounted",
          id: mounted.id,
          name: mounted.alias || mounted.brokerName || mounted.shareId,
          itemCount: mounted.itemCount,
          counts: mounted.counts,
        },
      });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionTestGitHubBranch": {
      const request = { repository: String(msg.repository || ""), branch: String(msg.branch || "main"), credentialTargetId: String(msg.credentialTargetId || "") || undefined };
      const startedAt = Date.now();
      let stage = "credentials";
      const emitProgress = (heartbeat = false) => respond({
        command: "subscriptionGitHubProgress",
        data: { operation: "test", stage, current: 0, total: 0, cachedBytes: 0, totalBytes: 0, elapsedMs: Date.now() - startedAt, heartbeat },
      });
      emitProgress();
      const heartbeat = setInterval(() => emitProgress(true), 1_000);
      let tested;
      try {
        tested = await githubSubscriptionSnapshot(context, request, nextStage => {
          stage = nextStage;
          emitProgress();
        });
      } finally {
        clearInterval(heartbeat);
      }
      const { target, snapshot } = tested;
      testedGitHubSubscriptions.set(githubSubscriptionTestKey(context, request), { ...tested, testedAt: Date.now() });
      respond({ command: "subscriptionGitHubTestResult", data: { ...request, name: target.name, commit: snapshot.commit, files: snapshot.files, validation: snapshot.validation, authentication: tested.authentication, elapsedMs: Date.now() - startedAt } });
      break;
    }

    case "subscriptionRename": {
      const alias = String(msg.alias || "").trim();
      const subscriptionId = String(msg.id || "");
      getSharedMarket().renameSubscription(subscriptionId, alias);
      respond({ command: "subscriptionRenamed", data: { id: subscriptionId, alias } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionSetPriority": {
      const subscriptionId = String(msg.id || "");
      const priority = String(msg.priority || "").trim().toLowerCase();
      if (priority !== "normal" && priority !== "high" && priority !== "highest") {
        throw new Error("Subscription priority must be normal, high, or highest.");
      }
      const updated = getSharedMarket().setSubscriptionPriority(subscriptionId, priority);
      scheduleRetrievalRefresh(context);
      respond({ command: "subscriptionCompleted", data: { action: "prioritySet", name: updated.alias || updated.brokerName || updated.shareId } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionRefresh": {
      const subscription = getSharedMarket().subscription(String(msg.id || ""));
      const refreshed = subscription.source?.type === "github"
        ? await mountGitHubBranchSubscription(context, {
            repository: subscription.source.repository, branch: subscription.source.branch,
            credentialTargetId: subscription.source.credentialTargetId || subscription.source.targetId,
            selectedPaths: subscription.source.selectedPaths, selectedFolders: subscription.source.selectedFolders,
          }, subscription.alias)
        : await getSharedMarket().refresh(subscription.id, !!msg.force);
      if (subscription.source?.type === "github") { invalidateSharedContentCatalog(); scheduleRetrievalRefresh(context); }
      respond({ command: "subscriptionCompleted", data: { action: "refreshed", name: refreshed.alias || refreshed.brokerName || refreshed.shareId, revision: refreshed.revision } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionRemove": {
      getSharedMarket().removeSubscription(String(msg.id || ""));
      respond({ command: "subscriptionCompleted", data: { action: "removed" } });
      respond({ command: "subscriptionState", data: await subscriptionStateData(context) });
      break;
    }

    case "subscriptionOpenServerLink": {
      const server = getSharedMarket().cachedServerLinks(String(msg.key || ""));
      const link = server.links[Number(msg.index)];
      if (!link) throw new Error("Subscribed Server link was not found.");
      await vscode.env.openExternal(vscode.Uri.parse(link.url));
      respond({ command: "subscriptionCompleted", data: { action: "serverOpened", name: server.name } });
      break;
    }

    case "nativeHarness": {
      try {
        const params = msg.params && typeof msg.params === "object" ? msg.params : {};
        if (params.chatId !== undefined) {
          if (typeof params.chatId !== "string") throw new Error("Choose a PKM Chat.");
          const data = await vscode.commands.executeCommand("personalKnowledge.readChatHarness", params.chatId, String(msg.method || ""), params);
          respond({ command:"nativeHarnessResult", requestId:msg.requestId, data });
          break;
        }
        const data = msg.method === "openBrowser"
          ? await openNativeHarnessBrowser(context, String(params.sessionId || ""))
          : await nativeHarnessRequest(String(msg.method || ""), params);
        respond({ command:"nativeHarnessResult", requestId:msg.requestId, data });
      } catch (error) {
        respond({ command:"nativeHarnessResult", requestId:msg.requestId, error:error instanceof Error ? error.message : String(error) });
      }
      break;
    }

    case "projectState": {
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSessionTrash": {
      const action = String(msg.action || "");
      if (!(["move", "restore", "delete", "empty"] as string[]).includes(action)) throw new Error("Unsupported Agent Session Trash action.");
      await mutateAgentSessionTrash(action as "move" | "restore" | "delete" | "empty", String(msg.sessionId || ""));
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSessionGroupDelete": {
      await deleteAgentSessionGroup(path.join(getStorePath(), ".pkm", "state"), String(msg.groupId || ""));
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSessionStop": {
      await stopAgentSession(path.join(getStorePath(), ".pkm", "state"), String(msg.sessionId || ""), {
        reason: "user-requested",
        summary: String(msg.summary || "Stopped from the Agent Sessions UI."),
      });
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }
    case "agentSessionConfigure": {
      await vscode.commands.executeCommand("personalKnowledge.configureApiChatSession", String(msg.sessionId || ""), String(msg.section || "memory"));
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSnapshotCreate": {
      const created = createAgentSnapshot(getStorePath(), String(msg.sessionId || ""), String(msg.reason || "manual"));
      let copied = true;
      try {
        await vscode.env.clipboard.writeText(created.recoveryPrompt);
      } catch (error) {
        copied = false;
        void vscode.window.showWarningMessage(`Agent Snapshot created, but the Recovery Prompt could not be copied: ${(error as Error).message}`);
      }
      respond({ command: "agentSnapshotCreated", data: { ...created, copied } });
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSnapshotContents": {
      const snapshotId = String(msg.snapshotId || "");
      try {
        respond({ command: "agentSnapshotContents", data: readAgentSnapshotContents(getStorePath(), snapshotId) });
      } catch (error) {
        respond({ command: "agentSnapshotContents", data: { snapshotId, error: (error as Error).message } });
      }
      break;
    }

    case "agentSnapshotRecover": {
      const recovered = await vscode.commands.executeCommand<{ chatId: string; sessionId: string }>("personalKnowledge.recoverAgentSnapshot", String(msg.snapshotId || ""));
      respond({ command: "agentSnapshotRecovered", data: { snapshotId: String(msg.snapshotId || ""), ...recovered } });
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSnapshotRename": {
      renameAgentSnapshot(getStorePath(), String(msg.snapshotId || ""), String(msg.name || ""));
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "agentSnapshotDelete": {
      deleteAgentSnapshot(getStorePath(), String(msg.snapshotId || ""));
      respond({ command: "projectState", data: await agentSessionProjectStateData() });
      break;
    }

    case "projectCreate":
    case "projectOverview":
    case "projectLink":
    case "projectLifecycle":
    case "projectCheckpoint":
    case "projectOpenSource": {
      const store = currentProjectStore();
      try {
        await handleProjectCockpitRequest({
          store, root: getStorePath(), command: (operation, input) => projectCommand(store, operation, input),
          snapshot: agentSessionProjectStateData, respond,
          action: (method, params) => actionRequest(context, method, params),
          openSource: id => /^action_run_[0-9a-f]{32}$/.test(id) ? openActionWorkbench(context, id) : openPanelTab(context, "agentSessions"),
        }, msg);
      } catch (error) {
        respond({ command: "projectState", data: await agentSessionProjectStateData() });
        throw error;
      }
      break;
    }

    case "threadCreate": {
      const store = currentProjectStore();
      const input = { projectId: String(msg.projectId || ""), name: String(msg.name || "") };
      const result = store.createThread(projectCommand(store, "thread-create", input), input.projectId, input.name);
      respond({ command: "projectResult", data: { action: "threadCreate", ...result } });
      break;
    }

    case "threadRename": {
      const store = currentProjectStore();
      const input = { threadId: String(msg.threadId || ""), name: String(msg.name || "") };
      const result = store.renameThread(projectCommand(store, "thread-rename", input), input.threadId, input.name);
      respond({ command: "projectResult", data: { action: "threadRename", ...result } });
      break;
    }

    case "threadOpenChatroom": {
      const store = currentProjectStore();
      const snapshot = store.list();
      const thread = snapshot.threads.find(candidate => candidate.threadId === String(msg.threadId || ""));
      if (!thread) throw new ProjectModelError("thread-not-found", "Thread was not found.");
      const project = snapshot.projects.find(candidate => candidate.projectId === thread.projectId);
      if (!project) throw new ProjectModelError("project-not-found", "Thread Project was not found.");
      if (thread.chatroom) {
        await openHostedRoom(context, thread.chatroom.roomId);
        respond({ command: "projectResult", data: { action: "threadOpenChatroom", snapshot: store.list(), entityId: thread.threadId, replayed: true } });
        break;
      }
      const manager = getChatMgr();
      const cfg = vscode.workspace.getConfiguration("personalKnowledge");
      const started = await manager.startHub(cfg.get<number>("chatHubPort") ?? 7345);
      if (!started.ok) throw new Error(started.error || "Couldn't start Chat Hub.");
      const hosted = await manager.createHostedRoom(`${project.name} · ${thread.name}`, undefined, {
        projectId: project.projectId,
        threadId: thread.threadId
      });
      const url = `ws://127.0.0.1:${manager.hubPort}`;
      manager.joinRoom({ url, room: hosted.room, roomId: hosted.roomId, user: "Host", token: hosted.secret,
        cid: getChatCid(context), hostToken: hosted.hostToken });
      const association = { roomId: hosted.roomId, roomName: hosted.room, linkedAt: new Date().toISOString() };
      const result = store.linkThreadChatroom(projectCommand(store, "thread-chatroom-link", { threadId: thread.threadId, ...association }), thread.threadId, association);
      openChatroomPanel(context);
      respond({ command: "projectResult", data: { action: "threadOpenChatroom", ...result } });
      break;
    }

    case "ganttTaskCreate":
    case "ganttTaskUpdate": {
      const store = currentProjectStore();
      const input: GanttTaskInput = {
        threadId: String(msg.threadId || "") || undefined,
        title: String(msg.title || ""),
        startDate: String(msg.startDate || ""),
        endDate: String(msg.endDate || ""),
        progress: Number(msg.progress),
        status: String(msg.status || "") as GanttTaskInput["status"],
        owners: Array.isArray(msg.owners) ? msg.owners.map((owner: any) => ({ name: String(owner?.name || ""), role: String(owner?.role || "") })) : [],
        dependencyIds: Array.isArray(msg.dependencyIds) ? msg.dependencyIds.map(String) : []
      };
      const taskId = String(msg.taskId || "");
      const projectId = String(msg.projectId || "");
      const operation = msg.command === "ganttTaskCreate" ? "gantt-task-create" : "gantt-task-update";
      const result = msg.command === "ganttTaskCreate"
        ? store.createGanttTask(projectCommand(store, operation, { projectId, ...input }), projectId, input)
        : store.updateGanttTask(projectCommand(store, operation, { taskId, ...input }), taskId, input);
      respond({ command: "projectResult", data: { action: msg.command, ...result } });
      break;
    }

    case "ganttTaskDelete": {
      const store = currentProjectStore();
      const taskId = String(msg.taskId || "");
      const result = store.deleteGanttTask(projectCommand(store, "gantt-task-delete", { taskId }), taskId);
      respond({ command: "projectResult", data: { action: "ganttTaskDelete", ...result } });
      break;
    }

    case "collaborationCreate": {
      const store = currentProjectStore();
      const projectId = String(msg.projectId || "");
      const input = {
        collaborationId: String(msg.collaborationId || ""),
        title: String(msg.title || ""),
        threadId: String(msg.threadId || ""),
        ganttTaskId: String(msg.ganttTaskId || "") || undefined,
        lead: String(msg.lead || ""),
        owners: Array.isArray(msg.owners) ? msg.owners.map(String) : [],
        reviewers: Array.isArray(msg.reviewers) ? msg.reviewers.map(String) : [],
        expectedResponders: Array.isArray(msg.expectedResponders) ? msg.expectedResponders.map(String) : [],
        deadlineAt: String(msg.deadlineAt || "") || undefined,
        agentSessionId: String(msg.agentSessionId || "") || undefined,
        recipeRunId: String(msg.recipeRunId || "") || undefined,
        objective: String(msg.objective || "") || undefined,
        context: String(msg.context || "") || undefined,
        expectedOutput: String(msg.expectedOutput || "") || undefined,
        artifactType: String(msg.artifactType || "") || undefined,
        acceptanceCriteria: Array.isArray(msg.acceptanceCriteria) ? msg.acceptanceCriteria.map(String) : [],
        decisionRequired: msg.decisionRequired === true,
        primaryOwner: String(msg.primaryOwner || "") || undefined,
        ownerPartitions: Array.isArray(msg.ownerPartitions) ? msg.ownerPartitions.map((item: any) => ({
          owner: String(item?.owner || ""), scope: String(item?.scope || "")
        })) : [],
        at: String(msg.at || new Date().toISOString()),
      };
      const result = store.createCollaborationTask(projectCommand(store, "collaboration-create", { projectId, ...input }), projectId, input);
      respond({ command: "projectResult", data: { action: "collaborationCreate", ...result } });
      break;
    }

    case "collaborationTransition": {
      const store = currentProjectStore();
      const transition: CollaborationTransition = {
        collaborationId: String(msg.collaborationId || ""),
        expectedVersion: Number(msg.expectedVersion),
        action: String(msg.action || "") as CollaborationTransition["action"],
        actor: String(msg.actor || ""),
        actorRole: String(msg.actorRole || "") as CollaborationTransition["actorRole"],
        at: String(msg.at || new Date().toISOString()),
        note: String(msg.note || "") || undefined,
        expectedResponders: Array.isArray(msg.expectedResponders) ? msg.expectedResponders.map(String) : undefined,
        deadlineAt: String(msg.deadlineAt || "") || undefined,
        expectedGanttTaskVersion: msg.expectedGanttTaskVersion == null ? undefined : Number(msg.expectedGanttTaskVersion),
        evidenceLinks: Array.isArray(msg.evidenceLinks) ? msg.evidenceLinks.map(String) : undefined,
        evidenceSummary: String(msg.evidenceSummary || "") || undefined,
        decisionResult: String(msg.decisionResult || "") || undefined,
        resultArtifact: String(msg.resultArtifact || "") || undefined,
        blockedWaitingOn: Array.isArray(msg.blockedWaitingOn) ? msg.blockedWaitingOn.map(String) : undefined,
        completionClaim: msg.completionClaim === true,
        resolvedResponders: Array.isArray(msg.resolvedResponders) ? msg.resolvedResponders.map(String) : undefined,
        evidenceMatchesContract: typeof msg.evidenceMatchesContract === "boolean" ? msg.evidenceMatchesContract : undefined,
      };
      const result = store.transitionCollaborationTask(projectCommand(store, `collaboration-${transition.action}`, transition), transition);
      respond({ command: "projectResult", data: { action: "collaborationTransition", ...result } });
      break;
    }

    case "recipeCreate": {
      const store = currentProjectStore();
      const input = {
        scope: msg.scope === "global" ? "global" as const : "project" as const,
        projectId: String(msg.projectId || ""),
        name: String(msg.name || ""),
        category: String(msg.category || "")
      };
      const scope = input.scope === "global" ? { kind: "global" as const } : { kind: "project" as const, projectId: input.projectId };
      const result = store.createRecipe(projectCommand(store, "recipe-create", input), scope, input.name, input.category);
      respond({ command: "projectResult", data: { action: "recipeCreate", ...result } });
      break;
    }

    case "recipeFolderCreate": {
      const store = currentProjectStore();
      const input = { parent: String(msg.parent || ""), name: String(msg.name || "") };
      const result = store.createRecipeFolder(projectCommand(store, "recipe-folder-create", input), input.parent, input.name);
      _treeProvider?.refresh();
      respond({ command: "projectResult", data: {
        action: "recipeFolderCreate",
        ...result,
        snapshot: { ...result.snapshot, privateTopLevels: privateTopLevels("recipes") }
      } });
      break;
    }

    case "recipeFolderDelete": {
      const store = currentProjectStore();
      const folder = String(msg.folder || "");
      const result = store.deleteRecipeFolder(projectCommand(store, "recipe-folder-delete", { folder }), folder);
      if (!folder.includes("/") && isTopLevelPrivate("recipes", folder)) setTopLevelPrivacy("recipes", folder, false);
      _treeProvider?.refresh();
      respond({ command: "projectResult", data: {
        action: "recipeFolderDelete",
        ...result,
        snapshot: { ...result.snapshot, privateTopLevels: privateTopLevels("recipes") }
      } });
      break;
    }

    case "recipeUpdate": {
      const store = currentProjectStore();
      const recipeId = String(msg.recipeId || "");
      const previous = store.list().recipes.find(recipe => recipe.recipeId === recipeId);
      if (typeof msg.expectedRecipeRevision === "number" && previous?.revision !== msg.expectedRecipeRevision) {
        throw new Error("This Recipe changed in another PKM tab. Your draft was kept; reopen the Recipe before saving.");
      }
      const input = {
        name: String(msg.name || ""),
        category: String(msg.category || ""),
        description: String(msg.description || ""),
        methodology: msg.methodology as RecipeRecord["methodology"],
        metadata: msg.metadata as RecipeMetadata | undefined,
        editorLayout: msg.editorLayout as RecipeRecord["editorLayout"],
        definition: msg.definition as WorkflowDefinitionV1,
        nodeBindings: hydrateRecipeNodeBindings(msg.nodeBindings)
      };
      const result = store.updateRecipe(projectCommand(store, "recipe-update", { recipeId, ...input }), recipeId, input);
      respond({ command: "projectResult", data: { action: "recipeUpdate", ...result } });
      break;
    }

    case "recipeDelete": {
      const store = currentProjectStore();
      const recipeId = String(msg.recipeId || "");
      const result = store.deleteRecipe(projectCommand(store, "recipe-delete", { recipeId }), recipeId);
      respond({ command: "projectResult", data: { action: "recipeDelete", ...result } });
      break;
    }

    case "recipeTrash": {
      const store = currentProjectStore();
      const recipeId = String(msg.recipeId || "");
      const action = String(msg.action || "");
      if (action === "empty") {
        for (const recipe of store.list().recipeTrash.filter(candidate => candidate.scope === "global")) {
          store.deleteRecipeFromTrash(projectCommand(store, "recipe-trash-delete", { recipeId: recipe.recipeId }), recipe.recipeId);
        }
        respond({ command: "projectState", data: await agentSessionProjectStateData() });
        break;
      }
      const recipe = store.list().recipes.find(candidate => candidate.recipeId === recipeId);
      const command = projectCommand(store, `recipe-trash-${action}`, { recipeId });
      const result = action === "move" ? store.moveRecipeToTrash(command, recipeId)
        : action === "restore" ? store.restoreRecipeFromTrash(command, recipeId)
          : action === "delete" ? store.deleteRecipeFromTrash(command, recipeId)
            : (() => { throw new Error("Unsupported Recipe Trash action."); })();
      if (action === "move" && recipe) {
        await mutateGitHubSyncTargets(context, `recipe deletion evidence ${recipeId}`, targets => {
          for (const target of targets) {
            const evidence = {
              type: "recipes" as const,
              itemId: recipeId,
              deletedAt: new Date().toISOString(),
              category: recipe.category || "",
              privacy: isContentItemPrivate("recipes", recipe) ? "private" as const : "public" as const,
            };
            target.pendingDeletions = [
              ...(target.pendingDeletions || []).filter(item => !(item.type === "recipes" && item.itemId === recipeId)),
              evidence,
            ];
          }
          return { targets, result: undefined };
        });
      } else if (action === "restore") {
        await mutateGitHubSyncTargets(context, `remove recipe deletion evidence ${recipeId}`, targets => {
          for (const target of targets) {
            target.pendingDeletions = (target.pendingDeletions || [])
              .filter(item => !(item.type === "recipes" && item.itemId === recipeId));
          }
          return { targets, result: undefined };
        });
      }
      respond({ command: "projectResult", data: { action: "recipeTrash", ...result } });
      break;
    }

    case "recipeValidateDefinition": {
      const compiled = compileWorkflowDefinitionV1(msg.definition);
      if (!compiled.ok) throw new ProjectModelError("recipe-definition-invalid", "Recipe definition cannot be parsed into a valid Graph.", { diagnostics: compiled.diagnostics });
      respond({ command: "recipeValidationResult", data: {
        definition: compiled.model,
        executableDigest: compiled.executableDigest,
        nodeCount: compiled.model.spec.nodes.length
      } });
      break;
    }

    case "recipeEditIntent": {
      await openRecipeIntentEditor(String(msg.recipeId || ""), String(msg.nodeId || ""), String(msg.guidance || ""));
      break;
    }

    case "recipeOpenBrowser": {
      const recipeId = String(msg.recipeId || "");
      const recipe = currentProjectStore().list().recipes.find(candidate => candidate.recipeId === recipeId);
      if (!recipe) throw new ProjectModelError("recipe-not-found", "Recipe was not found.");
      const opened = await openRecipeEditorInBrowser(recipeId);
      if (!opened) throw new ProjectModelError("recipe-browser-open-failed", "The Recipe workbench could not be opened in the browser.");
      vscode.window.setStatusBarMessage(`$(globe) Opened ${recipe.name} in browser`, 3000);
      respond({ command: "projectResult", data: { action: "recipeOpenBrowser", recipeId } });
      break;
    }

    case "projectRecipesExport": {
      const exported = await exportProjectRecipes(String(msg.projectId || ""));
      if (exported) {
        vscode.window.showInformationMessage(`Project Recipes exported to ${path.basename(exported)}.`);
        respond({ command: "projectExported", data: { path: exported } });
      }
      break;
    }

    case "threadMove": {
      const store = currentProjectStore();
      const input = {
        threadId: String(msg.threadId || ""),
        destinationProjectId: String(msg.destinationProjectId || ""),
        linkedActiveRunIds: [] as string[],
        includedRunIds: [] as string[],
        audienceChanges: false,
        audienceChangeConfirmed: false
      };
      const result = store.moveThread(projectCommand(store, "thread-move", input), input);
      respond({ command: "projectResult", data: { action: "threadMove", ...result } });
      break;
    }

    // ── Chatroom (agent room) ────────────────────────────────────────────
    case "chatState": {
      // Webview opened the tab — send current config defaults + live state.
      const cfg = vscode.workspace.getConfiguration("personalKnowledge");
      const inviteHost = applyChatInviteHost(context);
      respond({
        command: "chatConfig",
        data: {
          hubUrl:      (cfg.get<string>("chatHubUrl") || "").trim(),
          room:        (cfg.get<string>("chatRoom") || "general").trim(),
          displayName: (cfg.get<string>("chatDisplayName") || os.userInfo().username || "user").trim(),
          hasSecret:   !!(cfg.get<string>("chatSharedSecret") || "").trim(),
          hubPort:     cfg.get<number>("chatHubPort") ?? 7345,
          inviteHosts: chatInviteHostOptions(context).options,
          inviteHost: inviteHost.selected,
          inviteHostUnavailable: inviteHost.unavailable,
        },
      });
      getChatMgr().push();
      respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      break;
    }

    case "peerCollaboration": {
      await vscode.commands.executeCommand("personalKnowledge.peerCollaboration", typeof msg.chatId === "string" ? { id: msg.chatId } : undefined);
      break;
    }

    case "chatSetInviteHost": {
      const address = String(msg.address || "").trim();
      try { await updateExternalLinkHost(address); }
      catch { respond({ command: "chatToast", data: { error: `External link host is unavailable on this Extension Host: ${address}` } }); break; }
      getChatMgr().push();
      const inviteHost = chatInviteHostOptions(context);
      respond({ command: "chatConfig", data: { inviteHosts: inviteHost.options, inviteHost: inviteHost.selected, inviteHostUnavailable: false } });
      break;
    }

    case "chatConnect": {
      // Per-room secret: the joiner enters the room's secret (given by the host).
      const secret = (msg.secret || "").toString().trim();
      if (!secret) {
        respond({ command: "chatToast", data: { error: "Enter the room secret the host gave you." } });
        break;
      }
      let url  = (msg.url  || "").trim();
      let room = (msg.room || "").trim();
      // A connection string may embed the room: ws://host:port/room
      if (url) {
        try {
          const u = new URL(url);
          const seg = u.pathname.replace(/^\/+|\/+$/g, "");
          if (seg && !room) room = decodeURIComponent(seg.split("/").pop() || "");
          if (seg) url = `${u.protocol}//${u.host}`;
        } catch { /* leave as-is */ }
      }
      if (!room) room = "general";
      const user = (msg.user || os.userInfo().username || "user").trim();
      if (!url) {
        respond({ command: "chatToast", data: { error: "Enter a hub URL (ws://host:port)." } });
        break;
      }
      getChatMgr().joinRoom({ url, room, user, token: secret, cid: getChatCid(context) });
      await saveChatRecent(context, { url, room, user, secret, host: false });
      respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      break;
    }

    case "chatRejoin": {
      const id = String(msg.id || "");
      const entry = chatRecents(context).find(r => r.id === id);
      if (!entry) break;
      const recentSecret = (await chatRecentSecret(context, entry.id)).trim();
      if (!entry.host && !recentSecret) { respond({ command: "chatToast", data: { error: `No stored secret for room "${entry.room}". Use ＋ Join room and enter it.` } }); break; }

      const reachable = await probeChatRoomActive(entry.url, entry.room, entry.roomId);
      if (reachable) {
        const secret = entry.host ? getChatMgr().getRoomKey(entry.room) : recentSecret;
        if (!secret) { respond({ command: "chatToast", data: { error: `Room "${entry.room}" is reachable but not active in this Extension instance.` } }); break; }
        getChatMgr().joinRoom({ url: entry.url, room: entry.room, roomId: entry.roomId, user: entry.user, token: secret, cid: getChatCid(context) });
        await saveChatRecent(context, entry);
      } else if (entry.host) {
        const REHOST = "Rehost & Join", REMOVE = "Remove";
        const pick = await vscode.window.showInformationMessage(
          `Your hub for room "${entry.room}" isn't running.`, REHOST, REMOVE);
        if (pick === REHOST) {
          const res = await getChatMgr().startHub(entry.port);
          if (!res.ok) { vscode.window.showErrorMessage(`Couldn't start hub: ${res.error}`); break; }
          try {
            const hosted = entry.roomId
              ? await getChatMgr().rehostRoom(entry.roomId)
              : await getChatMgr().createHostedRoom(entry.room, recentSecret || undefined);
            const localUrl = `ws://127.0.0.1:${getChatMgr().hubPort}`;
            getChatMgr().joinRoom({ url: localUrl, room: hosted.room, roomId: hosted.roomId, user: entry.user, token: hosted.secret, cid: getChatCid(context), hostToken: hosted.hostToken });
            await saveChatRecent(context, { url: localUrl, room: hosted.room, roomId: hosted.roomId, user: entry.user, host: true });
          } catch (error: any) {
            vscode.window.showErrorMessage(`Couldn't Rehost Room: ${error?.message || error}`);
          }
        } else if (pick === REMOVE) {
          await forgetChatRecent(context, id);
        }
      } else {
        const REMOVE = "Remove from recents", KEEP = "Keep";
        const pick = await vscode.window.showWarningMessage(
          `Room "${entry.room}" at ${entry.url} seems offline (the host may not be online).`, REMOVE, KEEP);
        if (pick === REMOVE) await forgetChatRecent(context, id);
      }
      respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      break;
    }

    case "chatForgetRoom": {
      await forgetChatRecent(context, String(msg.id || ""));
      respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      break;
    }

    case "chatSetActive": {
      getChatMgr().setActive((msg.key || "").toString());
      break;
    }

    case "chatLeave": {
      await getChatMgr().closeOrLeaveRoom((msg.key || "").toString());
      break;
    }

    case "chatSend": {
      const responseRequired = typeof msg.responseRequired === "boolean" ? msg.responseRequired : undefined;
      const replyPolicy = ["none", "required", "optional"].includes(String(msg.replyPolicy)) ? msg.replyPolicy as ReplyPolicy : undefined;
      const mode = ["announce", "ask", "discuss"].includes(String(msg.mode)) ? msg.mode as ChatMode : undefined;
      const recipients = Array.isArray(msg.recipients) ? msg.recipients.map((name: unknown) => String(name || "")).filter(Boolean) : undefined;
      const replyToMessageId = String(msg.replyToMessageId || "").slice(0, 120) || undefined;
      const discussionLead = mode === "discuss" ? String(msg.discussionLead || "").slice(0, 60) || undefined : undefined;
      const finalTopicSummary = msg.finalTopicSummary === true;
      const collaboration = msg.collaboration && typeof msg.collaboration === "object"
        ? msg.collaboration as CollaborationMessageMetadata : undefined;
      if (msg.images !== undefined) {
        try {
          await getChatMgr().sendImages(String(msg.key || ""), msg.images, [
            String(msg.text || ""), responseRequired, replyPolicy, mode, recipients, replyToMessageId, discussionLead, finalTopicSummary, collaboration,
          ]);
          respond({ command:"chatSendImagesResult", data:{ key:msg.key, requestId:msg.requestId, ok:true } });
        } catch (error) {
          respond({ command:"chatSendImagesResult", data:{ key:msg.key, requestId:msg.requestId, ok:false, error:error instanceof Error ? error.message : String(error) } });
        }
        break;
      }
      const ok = getChatMgr().send((msg.text || "").toString(), responseRequired, replyPolicy, mode, recipients, replyToMessageId, discussionLead, finalTopicSummary, collaboration);
      if (!ok) getChatMgr().push();
      break;
    }

    case "chatImagePreview": {
      try {
        respond({ command:"chatImagePreview", data:{ key:msg.key, fileId:msg.fileId, src:getChatMgr().imagePreview(String(msg.key || ""), String(msg.fileId || "")) } });
      } catch (error) {
        respond({ command:"chatImagePreview", data:{ key:msg.key, fileId:msg.fileId, error:error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "chatMeetingStart": {
      try {
        await getChatMgr().startActiveMeeting(String(msg.requestId || ""), Number(msg.expectedRevision || 0));
      } catch (error: any) {
        respond({ command: "chatToast", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "chatMeetingAdjourn": {
      try {
        await getChatMgr().adjournActiveMeeting(String(msg.meetingId || ""), String(msg.requestId || ""), Number(msg.expectedRevision || 0));
      } catch (error: any) {
        respond({ command: "chatToast", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "chatMeetingOpenNote": {
      try {
        respond({ command: "openItem", type: "note", key: getChatMgr().meetingNoteKey(String(msg.meetingId || "")), tab: "notes" });
      } catch (error: any) {
        respond({ command: "chatToast", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "chatMeetingTrash":
    case "chatMeetingRestore":
    case "chatMeetingDelete": {
      try {
        const action = msg.command === "chatMeetingTrash" ? "trash" : msg.command === "chatMeetingRestore" ? "restore" : "delete";
        await getChatMgr().mutateMeetingTrash(action, String(msg.meetingId || ""), String(msg.requestId || ""), Number(msg.expectedRevision || 0));
      } catch (error: any) {
        respond({ command: "chatToast", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "chatAddManagedAgent": {
      respond({ command: "chatAddManagedAgentProgress", data: { percent: 15, message: "Detecting available AI models…" } });
      try {
        await getChatMgr().addManagedAgent(context);
        respond({ command: "chatAddManagedAgentResult", data: { ok: true } });
      } catch (error: any) {
        respond({ command: "chatAddManagedAgentResult", data: { ok: false, error: error?.message || String(error) } });
      }
      break;
    }

    case "chatRemoveManagedAgent": {
      getChatMgr().removeManagedAgent(String(msg.id || ""));
      break;
    }
    case "chatEditManagedAgent": {
      const id = String(msg.id || "");
      const currentName = String(msg.name || "");
      const icon = await vscode.window.showInputBox({
        prompt: `Profile icon for managed agent "${currentName}"`, value: String(msg.icon || "🤖"),
        placeHolder: "Emoji or up to 4 characters",
        validateInput: value => Array.from(value.trim()).length > 4 ? "Use at most 4 characters" : undefined,
      });
      if (icon === undefined) break;
      const name = await vscode.window.showInputBox({
        prompt: `New name for managed agent "${currentName}"`, value: currentName,
        validateInput: value => value.trim() ? undefined : "Enter a name",
      });
      if (!name) break;
      const role = await vscode.window.showInputBox({
        prompt: `Role for "${name.trim()}" (leave empty to clear)`, value: String(msg.role || ""),
        placeHolder: "e.g. Security reviewer, Research agent",
      });
      if (role === undefined) break;
      getChatMgr().editManagedAgent(id, name, role, icon);
      break;
    }

    case "chatShareFile": {
      await getChatMgr().sendFileToActive();
      break;
    }

    case "chatSaveFile": {
      await getChatMgr().saveReceivedFile((msg.key || "").toString(), (msg.fileId || "").toString());
      break;
    }

    case "chatExport": {
      await getChatMgr().exportActive();
      break;
    }

    case "chatStartHub": {
      const inviteHost = applyChatInviteHost(context);
      if (!inviteHost.selected || inviteHost.unavailable) {
        respond({ command: "chatHubResult", data: { ok: false, error: "Choose an available Invite interface before hosting a Room." } });
        break;
      }
      const cfg = vscode.workspace.getConfiguration("personalKnowledge");
      // Port: 0 (or blank) means auto-pick a free port; otherwise try the given
      // port and fall back to a free one if it's busy. Persist a chosen port.
      let port = Number(msg.port);
      if (!Number.isFinite(port)) port = cfg.get<number>("chatHubPort") ?? 7345;
      if (port > 0) await cfg.update("chatHubPort", port, vscode.ConfigurationTarget.Global);
      const room = (String(msg.room || "").trim()) || (cfg.get<string>("chatRoom") || "general").trim();
      const user = (String(msg.user || "").trim()) || "Host";   // hosts default to "Host"
      // Per-room secret: use the host's typed key, reuse a prior one, or generate one.
      let key = String(msg.key || "").trim();
      if (!key) key = getChatMgr().getRoomKey(room) || randomBytes(9).toString("base64url");

      const res = await getChatMgr().startHub(port);
      log.info(`chat: startHub result ok=${res.ok}${res.error ? " error=" + res.error : ""}${res.wsUrl ? " url=" + res.wsUrl : ""}`);
      respond({ command: "chatHubResult", data: res });
      if (res.ok) {
        let created: { roomId: string; room: string; secret: string; hostToken: string };
        try { created = await getChatMgr().createHostedRoom(room, key); }
        catch (error: any) {
          vscode.window.showErrorMessage(`Couldn't create Room: ${error?.message || error}`);
          break;
        }
        key = created.secret;
        if (room) await cfg.update("chatRoom", room, vscode.ConfigurationTarget.Global);
        const localUrl = `ws://127.0.0.1:${getChatMgr().hubPort}`;
        getChatMgr().joinRoom({ url: localUrl, room: created.room, roomId: created.roomId, user, token: key, cid: getChatCid(context), hostToken: created.hostToken });
        await saveChatRecent(context, { url: localUrl, room: created.room, roomId: created.roomId, user, host: true });
        respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
        const browserUrl = `${res.httpUrl}/room/${encodeURIComponent(room)}`;
        const COPY = "Copy Magic Link Invite", BROWSER = "Open Browser View";
        vscode.window.showInformationMessage(
          `Hosting room "${room}" as ${user}. Copy one message to let an MCP agent join; browser viewers can still open the room link.`,
          COPY, BROWSER
        ).then(pick => {
          if (pick === COPY) {
            const invite = getChatMgr().roomInvite(room);
            if (invite) vscode.env.clipboard.writeText(invite.message);
          }
          else if (pick === BROWSER) vscode.env.openExternal(vscode.Uri.parse(browserUrl));
        });
      } else {
        const SHOW = "Show Logs";
        vscode.window.showErrorMessage(`Couldn't start chat hub: ${res.error || "unknown error"}`, SHOW)
          .then(pick => { if (pick === SHOW) vscode.commands.executeCommand("personalKnowledge.showLogs"); });
      }
      break;
    }

    case "chatStopHub": {
      await getChatMgr().stopHub();
      break;
    }

    case "chatCopyInvite": {
      const roomId = String(msg.roomId || "").trim();
      const roomName = String(msg.roomName || roomId);
      const invite = getChatMgr().roomInvite(roomId);
      if (!invite) { vscode.window.showWarningMessage(`Couldn't create an invite for room "${roomName}".`); break; }
      await vscode.env.clipboard.writeText(invite.message);
      vscode.window.setStatusBarMessage("$(copy) Chatroom Magic Link invite copied", 4000);
      break;
    }

    case "chatAdminCloseRoom": {
      await getChatMgr().adminCloseRoom(String(msg.roomId || ""));
      break;
    }

    case "chatRehostStoredRoom": {
      const roomId = String(msg.roomId || "").trim();
      if (!roomId) break;
      const cfg = vscode.workspace.getConfiguration("personalKnowledge");
      const port = cfg.get<number>("chatHubPort") ?? 7345;
      const manager = getChatMgr();
      const started = await manager.startHub(port);
      if (!started.ok) {
        vscode.window.showErrorMessage(`Couldn't start Chat Hub: ${started.error || "unknown error"}`);
        break;
      }
      try {
        const hosted = await manager.rehostRoom(roomId);
        const recent = chatRecents(context).find(room => room.host && room.roomId === roomId);
        const user = recent?.user || "Host";
        const localUrl = `ws://127.0.0.1:${manager.hubPort}`;
        manager.joinRoom({ url: localUrl, room: hosted.room, roomId: hosted.roomId, user, token: hosted.secret, cid: getChatCid(context), hostToken: hosted.hostToken });
        await saveChatRecent(context, { url: localUrl, room: hosted.room, roomId, user, host: true });
        respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't Rehost Room: ${error?.message || error}`);
        await manager.refreshStoredRooms();
      }
      break;
    }

    case "chatForceCloseHostedRoom": {
      const roomId = String(msg.roomId || "").trim();
      const roomName = String(msg.roomName || roomId);
      const owned = getChatMgr().hostedRoomsForNavigation().find(room => room.roomId === roomId && room.canForceClose);
      if (!owned) { vscode.window.showErrorMessage("Force Close is available only for your own Room hosted elsewhere."); break; }
      const choice = await vscode.window.showWarningMessage(
        `Force the active Host to close “${roomName}”? Connected participants will be disconnected. History and Room credentials are preserved so you can Rehost it here.`,
        { modal: true, detail: `Active endpoint: ${owned.activeUrl || "unavailable"}` },
        "Force Close Host",
      );
      if (choice !== "Force Close Host") break;
      try {
        await getChatMgr().forceCloseHostedRoom(roomId);
        vscode.window.showInformationMessage(`Closed the active Host for “${roomName}”. You can now Rehost it.`);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't force-close the active Host: ${error?.message || error}`);
      }
      break;
    }

    case "chatRenameStoredRoom": {
      const roomId = String(msg.roomId || "");
      const currentName = String(msg.roomName || "");
      const roomName = await vscode.window.showInputBox({
        title: "Rename Stored Room",
        value: currentName,
        prompt: "The Room UUID, history, participants, and Join secret stay unchanged.",
        validateInput: value => value.trim() ? undefined : "Room name is required.",
      });
      if (roomName === undefined || roomName.trim() === currentName.trim()) break;
      try { await getChatMgr().renameStoredRoom(roomId, roomName); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't rename Room: ${error?.message || error}`); }
      break;
    }

    case "chatRepairStoredRoom": {
      const roomId = String(msg.roomId || "").trim();
      if (!roomId) break;
      try {
        const repaired = await getChatMgr().repairStoredRoom(roomId);
        const orphanDetail = repaired.closedOrphans
          ? ` Closed ${repaired.closedOrphans} inactive local Room instance${repaired.closedOrphans === 1 ? "" : "s"}.`
          : "";
        vscode.window.showInformationMessage(`Repaired "${repaired.roomName}". Preserved ${repaired.messageCount} message${repaired.messageCount === 1 ? "" : "s"}.${orphanDetail}`);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't repair Stored Room: ${error?.message || error}`);
      }
      break;
    }

    case "chatRenameActiveRoom": {
      const roomId = String(msg.roomId || "");
      const currentName = String(msg.roomName || "");
      const roomName = await vscode.window.showInputBox({
        title: "Rename Active Room",
        value: currentName,
        prompt: "Connected members stay in the Room; Room UUID, history, identities, and Join secret remain unchanged.",
        validateInput: value => value.trim() ? undefined : "Room name is required.",
      });
      if (roomName === undefined || roomName.trim() === currentName.trim()) break;
      try { await getChatMgr().renameActiveRoom(roomId, roomName); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't rename active Room: ${error?.message || error}`); }
      break;
    }

    case "chatDeleteStoredRoom": {
      const roomId = String(msg.roomId || "");
      const roomName = String(msg.roomName || "");
      try {
        await confirmAndDeleteStoredRoom(context, roomId, roomName);
        respond({ command: "chatRecents", data: { recents: chatRecentsForUi(context) } });
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't delete Room data: ${error?.message || error}`);
      }
      break;
    }

    case "chatRevealSecret": {
      const secret = (vscode.workspace.getConfiguration("personalKnowledge").get<string>("chatSharedSecret") || "").trim();
      respond({ command: "chatSecret", data: { secret } });
      break;
    }

    case "chatRotateSecret": {
      const roomId = String(msg.roomId || "").trim();
      const roomName = String(msg.roomName || roomId);
      if (!roomId) break;
      const pick = await vscode.window.showWarningMessage(
        `Refresh the key and Magic Link for room "${roomName}"? Current members stay connected; the old Magic Link stops working.`,
        { modal: true }, "Refresh Key");
      if (pick !== "Refresh Key") break;
      if (!await getChatMgr().rotateRoomSecret(roomId)) { vscode.window.showWarningMessage(`Room "${roomName}" has no secret to rotate.`); break; }
      const invite = getChatMgr().roomInvite(roomId);
      if (invite) {
        await vscode.env.clipboard.writeText(invite.message);
        vscode.window.showInformationMessage("New key generated. The refreshed Magic Link invite was copied.");
      }
      break;
    }

    case "chatModerate": {
      const action = String(msg.action || "");
      if (!["kick", "mute", "unmute", "rename", "edit"].includes(action)) break;
      const sid  = msg.sid ? String(msg.sid) : "";
      const participantId = msg.participantId ? String(msg.participantId) : "";
      const user = String(msg.user || "member");
      let name: string | undefined;
      let role: string | undefined;
      if (action === "kick") {
        const pick = await vscode.window.showWarningMessage(
          `Permanently remove "${user}" from this room roster? They will disappear from Earlier. If online, they will be disconnected and the room key will rotate.`,
          { modal: true }, "Remove Permanently");
        if (pick !== "Remove Permanently") break;
      }
      if (action === "rename" || action === "edit") {
        const input = await vscode.window.showInputBox({
          prompt: `New name for "${user}"`, value: user,
          validateInput: v => v.trim() ? undefined : "Enter a name",
        });
        if (!input) break;
        name = input.trim();
      }
      if (action === "edit") {
        const input = await vscode.window.showInputBox({
          prompt: `Role for "${name}" (leave empty to clear)`, value: String(msg.role || ""),
          placeHolder: "e.g. Security reviewer, Research agent",
        });
        if (input === undefined) break;
        role = input.trim();
      }
      getChatMgr().moderate(action as "kick" | "mute" | "unmute" | "rename" | "edit", { participantId, sid, user }, name, role);
      break;
    }

    case "chatRenameSelf": {
      const cur = getChatMgr().selfName || String(msg.user || "");
      const input = await vscode.window.showInputBox({
        prompt: "Your new display name in this room", value: cur,
        validateInput: v => v.trim() ? undefined : "Enter a name",
      });
      if (!input) break;
      getChatMgr().renameSelf(input.trim());
      break;
    }

    case "chatAdminCloseAll": {
      const pick = await vscode.window.showWarningMessage(
        "Deactivate ALL rooms on your hub? Everyone will be disconnected.",
        { modal: true }, "Close All Rooms");
      if (pick === "Close All Rooms") await getChatMgr().adminCloseAll();
      break;
    }

    case "openExternal": {
      const url = String(msg.url || "").trim();
      if (url) { try { await vscode.env.openExternal(vscode.Uri.parse(url)); } catch { /* ignore */ } }
      break;
    }

    case "contentSetPrivacy": {
      const type = String(msg.type || "") as PrivacyContentType;
      const topLevel = String(msg.topLevel || "");
      if (!(SHARED_CONTENT_TYPES as readonly string[]).includes(type) && !["recipes", "actions", "action-module-sets"].includes(type)) throw new Error(`Unsupported privacy content type: ${type}`);
      if (["actions", "action-module-sets"].includes(type) && !msg.isPrivate) {
        if (await vscode.window.showWarningMessage("Make this Action source Public? Selected public GitHub Sync targets may publish its definition or bundled source. Review it for secrets first.", { modal:true }, "Make Public") !== "Make Public") break;
      }
      setTopLevelPrivacy(type, topLevel, !!msg.isPrivate);
      invalidateSharedContentCatalog();
      gitCommit(`privacy(${type}): ${topLevel} ${msg.isPrivate ? "private" : "public"}`);
      const changed = await sharedMarket?.refreshPublishedShares() || 0;
      _treeProvider?.refresh();
      respond({ command: "privacyChanged", data: { type, topLevel, isPrivate: !!msg.isPrivate, brokersRefreshed: changed } });
      if (["actions", "action-module-sets"].includes(type)) respond({ command:"githubSyncState", data:await githubSyncStateData(context, false) });
      break;
    }

    case "githubSyncState": {
      respond({ command: "githubSyncState", data: await githubSyncStateData(context, false) });
      void githubSyncStateData(context, true)
        .then(data => panel?.webview.postMessage({ command: "githubSyncState", data }))
        .catch(error => {
          const message = error instanceof Error ? error.message : String(error);
          log.warn(`GitHub Sync background state refresh failed: ${message}`);
          panel?.webview.postMessage({ command: "githubSyncError", data: { action: "githubSyncState", error: message } });
        });
      break;
    }

    case "githubSyncRuntimeSnapshot": {
      respond({ command: "githubSyncRuntimeSnapshot", data: githubSyncScheduler?.snapshot() || {} });
      break;
    }

    case "githubSyncRepairResume": {
      const targetId = String(msg.targetId || "");
      await withGitHubSyncTargetLock(context, targetId, async () => {
        requireGitHubSyncManualMode(githubSyncTargetById(context, targetId), "resuming an item");
        await mutateGitHubSyncTargets(context, `resume item ${targetId}`, targets => {
          const target = targets.find(target => target.id === targetId);
          if (!target) throw new Error("GitHub Sync target was not found.");
          requireGitHubSyncManualMode(target, "resuming an item");
          if (!target.pausedItems?.some(item => item.type === msg.type && item.itemId === msg.itemId)) {
            throw new Error("This item is no longer paused. Refresh GitHub Sync.");
          }
          target.pausedItems = target.pausedItems.filter(item => item.type !== msg.type || item.itemId !== msg.itemId);
          return { targets, result: undefined };
        });
        await revalidateGitHubSyncLocalContent(context, targetId);
      });
      configureGitHubSyncScheduler(context);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context, false) });
      respond({ command: "githubSyncRepairResult", data: { targetId, action:msg.command,
        repairRequestId:msg.repairRequestId,
        message:"Item resumed and local validation refreshed. No Sync was started." } });
      break;
    }

    case "githubSyncRepairPause":
    case "githubSyncRepairTrash":
    case "githubSyncRepairRevalidateOnly":
    case "githubSyncRepairOpen":
    case "githubSyncRepairPreview":
    case "githubSyncRepairApply":
    case "githubSyncRecipeRecompilePreview":
    case "githubSyncRecipeRecompileApply":
    case "githubSyncRepairRevalidate": {
      const targetId = String(msg.targetId || "");
      githubSyncTargetById(context, targetId);
      let cancelled = false;
      let message = "";
      await withGitHubSyncTargetLock(context, targetId, async () => {
        const record = readGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
        if (!record || record.id !== msg.repairId) throw new Error("The repair list changed. Refresh GitHub Sync before continuing.");
        if (msg.command === "githubSyncRepairRevalidateOnly") {
          await revalidateGitHubSyncLocalContent(context, targetId);
          const remaining = readGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId)?.issues.length || 0;
          message = remaining ? `Validation finished: ${remaining} issue(s) still need attention. No Sync was started.`
            : "Local validation passed. No Sync was started.";
        } else if (msg.command !== "githubSyncRepairRevalidate") {
          const issue = record.issues.find(issue => issue.path === msg.path && (!msg.reason || issue.reason === msg.reason));
          if (!issue) throw new Error("The requested repair file is no longer in the pending list.");
          if (msg.command === "githubSyncRepairPause") {
            requireGitHubSyncManualMode(githubSyncTargetById(context, targetId), "pausing an item");
            const approval = await vscode.window.showWarningMessage(
              `Pause ${issue.path} for this target? Local and existing GitHub files are preserved. Folder selections will not re-include it until you resume it. No Sync will run.`,
              { modal: true }, "Pause this item");
            cancelled = approval !== "Pause this item";
            if (approval === "Pause this item") {
              await mutateGitHubSyncTargets(context, `pause repair ${targetId}`, targets => {
                const target = targets.find(target => target.id === targetId);
                if (!target) throw new Error("GitHub Sync target was not found.");
                requireGitHubSyncManualMode(target, "pausing an item");
                target.pausedItems = [...(target.pausedItems || []).filter(item =>
                  item.type !== issue.type || item.itemId !== issue.itemId), { type: issue.type, itemId: issue.itemId }];
                return { targets, result: undefined };
              });
              await revalidateGitHubSyncLocalContent(context, targetId);
              configureGitHubSyncScheduler(context);
              message = "Item paused for this target. Both copies are preserved. No Sync was started.";
            }
          } else if (msg.command === "githubSyncRepairTrash") {
            const assertManualTrash = (): void => {
              for (const target of readGitHubSyncTargets(context)) {
                requireGitHubSyncManualMode(target, "moving shared knowledge to Trash");
              }
            };
            assertManualTrash();
            if (!["skills", "notes", "papers", "prompts", "scripts"].includes(issue.type)) {
              throw new Error("This generated item must be managed in its library.");
            }
            const source = contentRepairSource(getStorePath(), issue);
            const assertUnchangedSource = (): string => {
              if (vscode.workspace.textDocuments.some(document => document.isDirty && document.uri.scheme === "file"
                && sameKnowledgeRoot(document.uri.fsPath, source))) {
                throw new Error("This file has unsaved changes. Save or discard them and revalidate before moving it to Trash.");
              }
              const bytes = fs.readFileSync(source);
              const digest = createHash("sha256").update(bytes).digest("hex");
              if (contentRepairDigest(bytes.toString("utf8")) !== issue.digest
                || issue.sourceDigest && issue.sourceDigest !== digest) {
                throw new Error("The source changed since review. Revalidate; nothing was moved.");
              }
              return digest;
            };
            const digest = assertUnchangedSource();
            const approval = await vscode.window.showWarningMessage(
              `Move ${issue.path} to PKM Trash through MCP? This removes the shared local file for all targets; it can be restored from Trash. A deletion journal entry will be recorded; a later Sync can propose deleting its GitHub copy. No Sync or push happens now.`,
              { modal: true }, "Move to Trash");
            cancelled = approval !== "Move to Trash";
            if (approval === "Move to Trash") {
              await withGitHubSyncApplyLock(context, async () => {
                assertManualTrash();
                if (assertUnchangedSource() !== digest) throw new Error("The source changed during approval. Revalidate.");
                const relative = path.relative(fs.realpathSync.native(getStorePath()), source).replace(/\\/g, "/");
                if (!relative.startsWith(`${issue.type}/`)) throw new Error("The repair source does not match its content area.");
                await trashKnowledgeFileViaMcp(context.extensionPath, getStorePath(), issue.type,
                  relative.slice(issue.type.length + 1), digest);
                invalidateSharedContentCatalog();
                githubSyncDiagnostics.record("github_sync.content_trashed", { targetId, path: issue.path, attemptId: record.id });
              });
              await revalidateGitHubSyncLocalContent(context, targetId);
              refreshKnowledgeGroups();
              message = "File moved to PKM Trash. No Sync or push was started.";
            }
          } else if (issue.recipeId && (msg.command === "githubSyncRepairOpen" || msg.command.startsWith("githubSyncRecipeRecompile"))) {
            if (msg.command === "githubSyncRepairOpen") {
              if (!(await openRecipeEditorInBrowser(issue.recipeId))) throw new Error("Recipe editor could not open. Review Recipe library diagnostics.");
            } else {
              if (issue.reason !== "recipe-digest") throw new Error("Only verified legacy Recipe digest issues support recompile.");
              const store = currentProjectStore();
              const directory = path.join(githubSyncStateDirectory(context), "content-repairs", record.targetId);
              fs.mkdirSync(directory, { recursive: true });
              const previewPath = path.join(directory, "recipe-preview.json");
              if (msg.command === "githubSyncRecipeRecompilePreview") {
                const preview = store.previewRecipeRecompile(issue.recipeId);
                const exported = JSON.parse(issue.content);
                const original = { ...preview.original };
                delete original.editorLayout;
                if (canonicalJson(exported) !== canonicalJson(original)) throw new Error("Recipe changed since preflight. Revalidate before preview.");
                fs.writeFileSync(previewPath, JSON.stringify({ repairId: record.id, preview }), { mode: 0o600 });
                const before = path.join(directory, "recipe-original.json");
                const after = path.join(directory, "recipe-candidate.json");
                fs.writeFileSync(before, JSON.stringify(preview.original, null, 2), { mode: 0o600 });
                fs.writeFileSync(after, JSON.stringify(preview.compiled, null, 2), { mode: 0o600 });
                await vscode.commands.executeCommand("vscode.diff", vscode.Uri.file(before), vscode.Uri.file(after),
                  `${issue.recipeId}: recompile preview, revision ${preview.original.revision} → ${preview.compiled.revision} (not applied)`);
                if (preview.pinnedConsumers.length) {
                  await vscode.window.showWarningMessage(`Recompile is blocked by pinned consumers: ${preview.pinnedConsumers.join(", ")}. Update their references explicitly; no pins are rewritten.`);
                }
              } else {
                if (!fs.existsSync(previewPath)) throw new Error("Preview the Recipe recompile before applying.");
                const saved = JSON.parse(fs.readFileSync(previewPath, "utf8"));
                if (saved.repairId !== record.id || saved.preview.recipeId !== issue.recipeId) throw new Error("Recompile preview is stale. Preview again.");
                const approval = await vscode.window.showWarningMessage(
                  `Recompile ${issue.recipeId} as revision ${saved.preview.compiled.revision}? Frozen runs are unchanged. Pinned consumers must be updated explicitly and block this repair. No sync or push is performed.`,
                  { modal: true }, "Apply Recipe recompile");
                cancelled = approval !== "Apply Recipe recompile";
                if (approval === "Apply Recipe recompile") {
                  await withGitHubSyncApplyLock(context, async () => {
                    store.applyRecipeRecompile({
                      commandId: randomUUID(), fingerprint: createHash("sha256").update(canonicalJson(saved)).digest("hex"),
                      expectedStoreVersion: saved.preview.storeVersion,
                    }, saved.preview);
                    invalidateSharedContentCatalog();
                    fs.rmSync(previewPath, { force: true });
                    githubSyncDiagnostics.record("github_sync.recipe_recompiled", { targetId, recipeId: issue.recipeId, attemptId: record.id });
                  });
                }
              }
            }
          } else {
          const source = contentRepairSource(getStorePath(), issue);
          if (msg.command === "githubSyncRepairOpen") {
            const document = await vscode.workspace.openTextDocument(vscode.Uri.file(source));
            const line = Math.max(0, (issue.lines[0] || 1) - 1);
            await vscode.window.showTextDocument(document, { selection: new vscode.Range(line, 0, line, 0) });
          } else {
            const content = fs.readFileSync(source, "utf8");
            if (contentRepairDigest(content) !== issue.digest
              || issue.sourceDigest && createHash("sha256").update(Buffer.from(content, "utf8")).digest("hex") !== issue.sourceDigest) {
              throw new Error("The source changed. Revalidate to refresh its markers and candidate.");
            }
            const candidate = inspectConflictMarkers(content).candidate;
            if (candidate === undefined) throw new Error("No safe empty-block candidate exists. Edit the file manually, then revalidate.");
            if (msg.command === "githubSyncRepairPreview") {
              const directory = path.join(githubSyncStateDirectory(context), "content-repairs", record.targetId);
              fs.mkdirSync(directory, { recursive: true });
              const before = path.join(directory, "original.txt");
              const after = path.join(directory, "candidate.txt");
              fs.writeFileSync(before, content, { mode: 0o600 });
              fs.writeFileSync(after, candidate, { mode: 0o600 });
              await vscode.commands.executeCommand("vscode.diff", vscode.Uri.file(before), vscode.Uri.file(after),
                `${issue.path}: empty conflict block cleanup (not applied)`);
            } else {
              const assertSavedSource = (): void => {
                if (vscode.workspace.textDocuments.some(document => document.isDirty && document.uri.scheme === "file"
                  && sameKnowledgeRoot(document.uri.fsPath, source))) {
                  throw new Error("This file has unsaved editor changes. Save or discard them, then revalidate before applying a candidate.");
                }
              };
              assertSavedSource();
              const approval = await vscode.window.showWarningMessage(
                `Remove only complete empty conflict blocks from ${issue.path}? All non-conflict bytes are preserved. No GitHub version is being selected.`,
                { modal: true }, "Apply empty-block cleanup");
              cancelled = approval !== "Apply empty-block cleanup";
              if (approval === "Apply empty-block cleanup") {
                await withGitHubSyncApplyLock(context, async () => {
                  assertSavedSource();
                  applyGitHubSyncEmptyMarkerCandidate(getStorePath(), issue);
                  invalidateSharedContentCatalog();
                  githubSyncDiagnostics.record("github_sync.content_repaired", {
                    targetId, attemptId: record.id, path: issue.path, originalDigest: issue.digest,
                  });
                });
              }
              }
            }
          }
        }
      });
      if (msg.command === "githubSyncRepairRevalidate") {
        invalidateSharedContentCatalog();
        if (!githubSyncScheduler) throw new Error("PKM service is disconnected. Reopen GitHub Sync before revalidating.");
        const queued = await githubSyncScheduler.request(targetId, "manual");
        respond({ command: "githubSyncRunQueued", data: { targetId, queued } });
        message = queued ? "Sync queued. Follow progress on this target." : "Sync is already queued or running.";
      }
      respond({ command: "githubSyncState", data: await githubSyncStateData(context, false) });
      const messages: Record<string, string> = {
        githubSyncRepairOpen:"Editor opened. Save changes, then revalidate.",
        githubSyncRepairPreview:"Cleanup preview opened. No source was changed.",
        githubSyncRepairApply:"Cleanup applied. Revalidate to refresh the issue list.",
        githubSyncRecipeRecompilePreview:"Recompile preview opened. No source was changed.",
        githubSyncRecipeRecompileApply:"Recipe recompiled. Revalidate to refresh the issue list.",
      };
      respond({ command: "githubSyncRepairResult", data: { targetId, action:msg.command, repairRequestId:msg.repairRequestId, cancelled,
        message:cancelled ? "Cancelled. No changes were made." : message || messages[msg.command] } });
      break;
    }

    case "githubSyncPickIdentity": {
      const sshDirectory = path.join(os.homedir(), ".ssh");
      const picked = await vscode.window.showOpenDialog({
        canSelectFolders: false,
        canSelectFiles: true,
        canSelectMany: false,
        defaultUri: fs.existsSync(sshDirectory) ? vscode.Uri.file(sshDirectory) : vscode.Uri.file(os.homedir()),
        title: "Select a GitHub SSH private key",
        openLabel: "Select SSH Key",
      });
      respond({ command: "githubSyncIdentityPicked", data: { identityFile: picked?.[0]?.fsPath || "" } });
      break;
    }

    case "githubSyncCreateIdentity": {
      const expectedLogin = String(msg.expectedLogin || "").trim();
      const created = await createGitHubSyncIdentity(expectedLogin, path.join(os.homedir(), ".ssh"));
      await vscode.env.clipboard.writeText(created.publicKey);
      await vscode.env.openExternal(vscode.Uri.parse("https://github.com/settings/ssh/new"));
      respond({ command: "githubSyncIdentityCreated", data: { identityFile: created.identityFile, expectedLogin } });
      break;
    }

    case "githubSyncTestAuthentication": {
      const authentication = msg.target?.authentication || {};
      const repository = String(msg.target?.repository || "");
      const expectedLogin = String(authentication.expectedLogin || "");
      let result;
      if (authentication.method === "vscode") {
        const target = normalizeGitHubSyncTarget(msg.target, () => "authentication-test");
        await connectGitHubSyncVscodeAccount(context, target, !!String(msg.target?.id || ""));
        respond({ command: "githubSyncAuthenticationResult", data: {
          host: new URL(repository).hostname,
          login: expectedLogin,
          fingerprint: "VS Code GitHub Authentication · repository access verified",
          credentialsStored: true,
        } });
        break;
      }
      result = authentication.method === "https"
        ? await probeGitHubSyncHttpsAuthentication(repository, expectedLogin)
        : await probeGitHubSyncAuthentication(repository, String(authentication.identityFile || ""), expectedLogin);
      respond({ command: "githubSyncAuthenticationResult", data: result });
      break;
    }

    case "githubSyncSave": {
      const target = normalizeGitHubSyncTarget(msg.target);
      const previous = readGitHubSyncTargets(context).find(candidate => candidate.id === target.id);
      const approvedRoot = path.resolve(getStorePath());
      await authorizeGitHubSyncProfiles(target, previous, approvedRoot,
        new PersonaProfileStore(context.globalStorageUri.fsPath, getStorePath()).syncEnabled,
        async () => await vscode.window.showWarningMessage("Allow User / Agent Profiles to sync to this GitHub destination?", {modal:true,
          detail:`Knowledge Root: ${getStorePath()}\nRepository: ${target.repository}\nBranch: ${target.branch}\nSelection: ${JSON.stringify(target.selection.private.profiles)}\n\nThese JSON cards may contain personal preferences and responsibility boundaries. Private is a PKM content classification, NOT encryption or a guarantee that this GitHub repository is private. Anyone with repository access can read them; Git history may retain older versions after deletion. This approval includes future edits/cards covered by your selection. It does not include Chat history, credentials or long-term Memory. Deselect Profiles to stop future transfer; published copies and history remain.`,
        }, "Allow Profile Sync") === "Allow Profile Sync");
      if (target.authentication?.method === "vscode") await authorizeGitHubSyncTarget(context, target);
      else if (target.authentication) await testGitHubSyncAuthentication(target);
      delete target.lastFailure;
      const saveResult = await withGitHubSyncTargetLock(context, target.id, async () => {
        const result = await mutateGitHubSyncTargets(context, `save ${target.id}`, targets => {
          const existing = targets.find(candidate => candidate.id === target.id);
          if (path.resolve(getStorePath()) !== approvedRoot
            || JSON.stringify(existing?.profileSyncConsent) !== JSON.stringify(previous?.profileSyncConsent)) {
            throw new Error("Profile Sync destination or authorization changed during approval. Reopen the target and review it again.");
          }
          const duplicate = targets.find(candidate => candidate.id !== target.id && candidate.repository === target.repository && candidate.branch === target.branch);
          if (duplicate) throw new Error(`Target ${duplicate.name} already synchronizes this repository and branch.`);
          const changed = !!existing && (existing.repository !== target.repository || existing.branch !== target.branch);
          const initialSyncCompleted = !changed && existing?.automation.initialSyncCompleted === true;
          const automationBlocked = target.automation.enabled && !initialSyncCompleted;
          target.automation.initialSyncCompleted = initialSyncCompleted;
          if (automationBlocked) target.automation.enabled = false;
          if (!changed) {
            target.lastSync = existing?.lastSync;
            target.lastResolutionReport = existing?.lastResolutionReport;
            target.pendingDeletions = existing?.pendingDeletions;
            target.publication = existing?.publication;
            target.pausedItems = existing?.pausedItems;
          }
          const next = [...targets.filter(candidate => candidate.id !== target.id), target].sort((left, right) => left.name.localeCompare(right.name));
          return { targets: next, result: { endpointChanged: changed, automationBlocked, initialSetup: !existing || changed || !initialSyncCompleted } };
        });
        if (result.endpointChanged) {
          fs.rmSync(path.join(githubSyncStateDirectory(context), "checkouts", target.id), { recursive: true, force: true });
          clearGitHubSyncConflict(githubSyncStateDirectory(context), target.id);
        }
        return result;
      });
      if (saveResult.automationBlocked) {
        vscode.window.showWarningMessage("Automatic synchronization remains off. Run Initial Sync successfully, resolve and push every conflict, then enable automation manually.");
      }
      if (target.authentication?.method !== "vscode") await context.secrets.delete(githubSyncSecretKey(target.id));
      configureGitHubSyncScheduler(context);
      if (saveResult.initialSetup) {
        const savedTarget = githubSyncTargetById(context, target.id);
        const credentials = await readGitHubSyncCredentials(context, savedTarget);
        const catalog = await githubSyncCatalog();
        const preview = await withGitHubSyncTargetLock(context, target.id, () => previewGitHubSyncTarget(
          savedTarget,
          catalog,
          path.join(githubSyncStateDirectory(context), "checkouts"),
          credentials,
          getStorePath(),
        ));
        clearGitHubSyncConflict(githubSyncStateDirectory(context), target.id);
        if (preview.differences.length) {
          storeGitHubSyncConflict(
            githubSyncStateDirectory(context),
            target.id,
            new GitHubSyncConflictError(preview.remoteCommit, preview.differences, [], [], {}, [], [], {
              totalFiles: preview.same + preview.differences.length,
              rules: {
                unchanged: preview.same,
                "remote-only": preview.remoteOnly,
                "local-only": preview.localOnly,
                "human-required": preview.modified,
              },
              generatedAt: new Date().toISOString(),
            }),
            "initial-preview",
            preview.remoteSchema,
          );
        } else {
          vscode.window.showInformationMessage(`Initial GitHub comparison found no differences for ${savedTarget.name}.`);
        }
        if (preview.remoteSchema === 3) {
          await mutateGitHubSyncTargets(context, `record schema compatibility ${target.id}`, targets => {
            const current = targets.find(candidate => candidate.id === target.id);
            if (!current) throw new Error("GitHub Sync target was not found.");
            current.publication = {
              requiredCapability: "stable-entity-identity",
              sourceCommit: preview.remoteCommit,
              sourceDigest: createHash("sha256").update(preview.remoteCommit).digest("hex"),
              manualVerificationCompleted: true,
            };
            return { targets, result: undefined };
          });
        }
        if (preview.remoteSchema !== 3) {
          vscode.window.showWarningMessage(
            `GitHub uses PKM manifest schema ${preview.remoteSchema}. Complete the one-time publication migration before applying the initial sync choices.`
          );
        }
      }
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncDelete": {
      const targetId = String(msg.targetId || "");
      githubSyncTargetById(context, targetId);
      const mounted = ((getSharedMarket().snapshot as any).subscriptions || []).find((subscription: any) => subscription.source?.type === "github" && (subscription.source.credentialTargetId || subscription.source.targetId) === targetId);
      if (mounted) throw new Error(`Remove the mounted subscription "${mounted.alias || mounted.brokerName || mounted.shareId}" before deleting this GitHub target.`);
      await mutateGitHubSyncTargets(context, `delete ${targetId}`, currentTargets => ({
        targets: currentTargets.filter(target => target.id !== targetId),
        result: undefined,
      }));
      await context.secrets.delete(githubSyncSecretKey(targetId));
      configureGitHubSyncScheduler(context);
      try {
        clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
        clearGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
      } catch (error) {
        log.warn(`GitHub Sync target ${targetId} conflict cleanup is deferred: ${error instanceof Error ? error.message : String(error)}`);
      }
      cleanupDeletedGitHubSyncTarget(context, targetId);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncAutomationToggle": {
      const targetId = String(msg.targetId || "");
      const enabled = msg.enabled === true;
      if (enabled && readGitHubSyncConflict(githubSyncStateDirectory(context), targetId)) {
        throw new Error("Resolve every GitHub Sync conflict before enabling automatic synchronization.");
      }
      await mutateGitHubSyncTargets(context, `automation ${targetId} ${enabled ? "on" : "off"}`, targets => {
        const target = targets.find(candidate => candidate.id === targetId);
        if (!target) throw new Error("GitHub Sync target was not found.");
        if (enabled && !target.automation.initialSyncCompleted) {
          throw new Error("Run Initial Sync successfully before enabling automatic synchronization.");
        }
        if (enabled && target.publication && !target.publication.manualVerificationCompleted) {
          throw new Error("Complete a manual Fetch/Pull, conflict resolution, Commit, Push, inventory refresh, and retrieval refresh before enabling automatic synchronization.");
        }
        target.automation.enabled = enabled;
        return { targets, result: undefined };
      });
      configureGitHubSyncScheduler(context);
      respond({ command: "githubSyncAutomationResult", data: { targetId, enabled } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncMigration": {
      const targetId = String(msg.targetId || "");
      const action = String(msg.action || "");
      const receipt = await withGitHubSyncTargetLock(context, targetId, async () => {
        const target = githubSyncTargetById(context, targetId);
        const source = await githubPublicationMigrationSource(context, target, action === "stage");
        const migration = githubPublicationMigration(context, targetId);
        const result = action === "preview" ? migration.preview(source)
          : action === "restart-preview" ? migration.restartPreview(source)
          : action === "stage" ? migration.stage(source)
            : action === "verify" ? migration.verify(source)
              : action === "cutover" ? migration.cutover(source)
                : action === "rollback" ? migration.rollback(source)
                  : (() => { throw new Error("Unsupported GitHub publication migration action."); })();
        if (["stage", "cutover", "rollback", "restart-preview"].includes(action)) {
          await mutateGitHubSyncTargets(context, `migration ${action} ${targetId}`, targets => ({
            targets: targets.map(candidate => candidate.id === targetId ? target : candidate),
            result: undefined,
          }));
        }
        return result;
      });
      configureGitHubSyncScheduler(context);
      respond({ command: "githubSyncMigrationResult", data: { targetId, action, receipt } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncRun": {
      const targetId = String(msg.targetId || "");
      let target = githubSyncTargetById(context, targetId);
      const migration = githubPublicationMigration(context, targetId).status();
      if (migration && migration.phase !== "cutover" && migration.phase !== "rolled-back") {
        throw new Error(`Complete or roll back the ${migration.phase} GitHub publication migration before synchronization.`);
      }
      if (msg.pauseAutomation === true) {
        await mutateGitHubSyncTargets(context, `pause automation and retry ${targetId}`, targets => {
          const selected = targets.find(candidate => candidate.id === targetId);
          if (!selected) throw new Error("GitHub Sync target was not found.");
          selected.automation.enabled = false;
          return { targets, result: undefined };
        });
        configureGitHubSyncScheduler(context);
        target = githubSyncTargetById(context, targetId);
      }
      requireGitHubSyncManualMode(target, "running Sync with Remote");
      if (target.publication && !target.publication.manualVerificationCompleted) {
        target.automation.enabled = false;
      }
      const queued = await githubSyncScheduler?.request(targetId, "manual") === true;
      respond({ command: "githubSyncRunQueued", data: { targetId, queued } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncForceUpdate": {
      const targetId = String(msg.targetId || "");
      const target = githubSyncTargetById(context, targetId);
      const publicationUpgrade = msg.publicationUpgrade === true;
      const actionLabel = publicationUpgrade ? "Upgrade from this machine" : "Force use Local";
      requireGitHubSyncManualMode(target, `using ${actionLabel}`);
      if (publicationUpgrade && target.publication?.manualVerificationCompleted) {
        throw new Error("This GitHub target already uses the current publication format.");
      }
      const migration = githubPublicationMigration(context, targetId).status();
      if (!publicationUpgrade && migration && migration.phase !== "cutover" && migration.phase !== "rolled-back") {
        throw new Error(`Complete or roll back the ${migration.phase} GitHub publication migration before Force use Local.`);
      }
      const comment = await vscode.window.showInputBox({
        title: `${actionLabel} · ${target.name}`,
        prompt: publicationUpgrade
          ? "Audit comment for the one-time upgrade commit. Press Enter to keep the default."
          : "Explain why this destructive local-authority update is required.",
        placeHolder: "Required audit comment",
        value: publicationUpgrade ? "One-time GitHub publication upgrade from this machine" : undefined,
        ignoreFocusOut: true,
        validateInput: value => value.trim() ? undefined : "A reason is required.",
      });
      if (comment === undefined) {
        respond({ command: "githubSyncRunQueued", data: { targetId, queued: false } });
        break;
      }
      const actor = target.authentication?.expectedLogin || os.userInfo().username;
      const confirmation = await vscode.window.showWarningMessage(
        `${actionLabel} · ${target.name}?`,
        {
          modal: true,
          detail: publicationUpgrade
            ? `Actor: ${actor}\nReason: ${comment.trim()}\n\nThis machine becomes the source of truth. PKM publishes the selected local content to GitHub in the current format and finishes the one-time upgrade; no Stage, Verify, or Cut over is needed. Selected GitHub files that are absent locally will be deleted, and GitHub edits that differ from this machine will be overwritten. Unselected GitHub content is preserved, and earlier versions stay in Git history.`
            : `Actor: ${actor}\nReason: ${comment.trim()}\n\nThis makes the current machine-local selected projection authoritative. Selected GitHub files that are absent locally will be deleted, and conflicting GitHub edits will be overwritten. Unselected GitHub content is preserved. The branch is fetched again and protected by a compare-and-swap lease before push.`,
        },
        actionLabel,
      );
      if (confirmation !== actionLabel) {
        respond({ command: "githubSyncRunQueued", data: { targetId, queued: false } });
        break;
      }
      requireGitHubSyncManualMode(githubSyncTargetById(context, targetId), `using ${actionLabel}`);
      if (publicationUpgrade) {
        await withGitHubSyncTargetLock(context, targetId, async () => {
          githubPublicationMigration(context, targetId).supersedeWithLocalAuthority();
        });
      }
      clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
      githubSyncForceUpdateAudit.set(targetId, { actor, comment: comment.trim() });
      const queued = await githubSyncScheduler?.request(targetId, "force-local-authority") === true;
      if (!queued) githubSyncForceUpdateAudit.delete(targetId);
      respond({ command: "githubSyncRunQueued", data: { targetId, queued } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncForceRemote": {
      const targetId = String(msg.targetId || "");
      const target = githubSyncTargetById(context, targetId);
      requireGitHubSyncManualMode(target, "using Force use Remote");
      const assertMigrationReady = (): void => {
        const migration = githubPublicationMigration(context, targetId).status();
        if (migration && !["cutover", "rolled-back"].includes(migration.phase)) {
          throw new Error(`Complete or roll back the ${migration.phase} publication migration before Force use Remote.`);
        }
      };
      assertMigrationReady();
      const storeRoot = path.resolve(getStorePath());
      const checkoutRoot = path.join(githubSyncStateDirectory(context), "checkouts");
      const credentials = await readGitHubSyncCredentials(context, target);
      const plan = await withGitHubSyncTargetLock(context, targetId, async () => {
        invalidateSharedContentCatalog();
        return previewGitHubRemoteAuthority(target, await buildGitHubSyncCatalog(), checkoutRoot, storeRoot, credentials);
      });
      const cancel = (): void => respond({ command: "githubSyncForceRemoteResult", data: { targetId, cancelled: true } });
      const items = [
        ...plan.writes.map(item => ({ label: `${item.expectedLocal === undefined ? "$(add) Create" : "$(edit) Overwrite"} · ${item.file.path}`, picked: true })),
        ...plan.deletes.map(item => ({ label: `$(trash) Delete Local · ${item.file.path}`, picked: true })),
      ];
      if (items.length) {
        const reviewed = await vscode.window.showQuickPick(items, {
          canPickMany: true, matchOnDescription: true, ignoreFocusOut: true,
          title: `Force use Remote · ${target.name} · ${plan.commit.slice(0, 10)}`,
          placeHolder: `Review ALL ${plan.writes.length} writes and ${plan.deletes.length} deletions. Unchecking anything cancels this full-scope operation.`,
        });
        if (!reviewed || reviewed.length !== items.length) { cancel(); break; }
      }
      const comment = await vscode.window.showInputBox({
        title: `Force use Remote · ${target.name}`,
        prompt: "Explain why this machine's selected Local content must be replaced by GitHub.",
        ignoreFocusOut: true, validateInput: value => value.trim() ? undefined : "A recovery audit reason is required.",
      });
      if (comment === undefined) { cancel(); break; }
      const actor = target.authentication?.expectedLogin || os.userInfo().username;
      const choice = await vscode.window.showWarningMessage(`Force use Remote · ${target.name}?`, {
        modal: true,
        detail: `GitHub commit: ${plan.commit}\nActor: ${actor}\nReason: ${comment.trim()}\n\n${plan.writes.length} local writes; ${plan.deletes.length} local deletions.${!plan.writes.length && plan.deletes.length ? "\nWARNING: Remote has no replacement files; the listed Local-only content will be removed." : ""}\n\nOnly the selected scope is replaced. Unselected, ignored and System content are preserved. Originals are backed up outside the Knowledge Root. GitHub is never pushed. Auto Sync remains off. Any changed preview requires another review.`,
      }, "Force use Remote");
      if (choice !== "Force use Remote") { cancel(); break; }
      const result = await withGitHubSyncTargetLock(context, targetId, () => withGitHubSyncApplyLock(context, async () => {
        const current = githubSyncTargetById(context, targetId);
        requireGitHubSyncManualMode(current, "using Force use Remote");
        assertMigrationReady();
        const validateHostState = (): void => {
          if (!sameKnowledgeRoot(storeRoot, getStorePath())
            || JSON.stringify(githubSyncTargetById(context, targetId)) !== JSON.stringify(current)) {
            throw new Error("Knowledge Root or target settings changed. Generate a new Force use Remote preview.");
          }
          const paths = new Set([...plan.writes, ...plan.deletes].filter(item => item.file.type !== "recipes").map(item =>
            path.resolve(storeRoot, item.file.path.startsWith("agentSnapshots/")
              ? `.pkm/state/agent-snapshots/${item.file.path.slice("agentSnapshots/".length)}` : item.file.path)));
          const dirty = vscode.workspace.textDocuments.filter(document =>
            document.isDirty && document.uri.scheme === "file" && paths.has(path.resolve(document.uri.fsPath)));
          if (dirty.length) throw new Error(`Save or discard unsaved editor changes first: ${dirty.map(document => document.uri.fsPath).join(", ")}`);
        };
        validateHostState();
        invalidateSharedContentCatalog();
        const applied = await applyGitHubRemoteAuthority(current, await buildGitHubSyncCatalog(), checkoutRoot, getStorePath(),
          plan, actor, comment.trim(), (pulls, deletes, privateTopLevels) => {
            applyGitHubSyncRecipePulls(pulls);
            applyGitHubSyncRecipeDeletes(deletes);
            for (const [type, topLevels] of Object.entries(privateTopLevels)) {
              for (const topLevel of topLevels || []) setTopLevelPrivacy(type as PrivacyContentType, topLevel, true);
            }
          }, credentials, validateHostState, async () => {
            invalidateSharedContentCatalog();
            return buildGitHubSyncCatalog();
          });
        try {
          invalidateSharedContentCatalog();
          const catalog = await buildGitHubSyncCatalog();
          const excluded = await githubSyncExcludedPaths(storeRoot, GITHUB_SYNC_CONTENT_TYPES.flatMap(type =>
            catalog[type].flatMap(item => [item.destination, ...(item.dependencies || []).map(member => member.destination)])));
          const fingerprints = githubSyncLocalFingerprints(current, catalog, excluded);
          await mutateGitHubSyncTargets(context, `force use Remote ${targetId}`, targets => {
            const updated = targets.find(item => item.id === targetId);
            if (!updated) throw new Error("Target was removed before Remote recovery finished.");
            if (!sameKnowledgeRoot(storeRoot, getStorePath())
              || JSON.stringify(updated) !== JSON.stringify(current)) {
              throw new Error("Knowledge Root or target settings changed before recovery baseline finalization.");
            }
            updated.lastSync = { at: new Date().toISOString(), commit: applied.commit, fingerprints,
              repository: current.repository, branch: current.branch, storeRoot };
            const replaced = new Set(plan.itemKeys);
            updated.pendingDeletions = (updated.pendingDeletions || []).filter(item => !replaced.has(`${item.type}\0${item.itemId}`));
            delete updated.lastFailure;
            delete updated.lastResolutionReport;
            return { targets, result: undefined };
          });
          clearGitHubSyncContentRepair(githubSyncStateDirectory(context), targetId);
          clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
          completeGitHubRemoteAuthorityBackup(applied.backupDirectory);
        } catch (error) {
          throw new Error(`Local Remote recovery applied, but its baseline was not fully finalized. Keep Auto Sync off. Recovery backup: ${applied.backupDirectory}. ${error instanceof Error ? error.message : String(error)}`);
        }
        return applied;
      }));
      invalidateSharedContentCatalog();
      _treeProvider?.refresh();
      try {
        await refreshKnowledgeInventory(context);
        await refreshRetrievalIndex(context);
      } catch (error) {
        const detail = error instanceof Error ? error.message : String(error);
        log.warn(`Force use Remote target=${targetId} applied=${result.commit}; inventory/retrieval refresh failed: ${detail}`);
        scheduleRetrievalRefresh(context, 0);
        vscode.window.showWarningMessage(`Remote replacement succeeded, but inventory/retrieval refresh must retry: ${detail}. Recovery backup: ${result.backupDirectory}`);
      }
      configureGitHubSyncScheduler(context);
      respond({ command: "githubSyncForceRemoteResult", data: { targetId, ...result } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      vscode.window.showInformationMessage(`Force use Remote completed: ${result.restored.length} writes, ${result.deleted.length} deletions. Recovery backup: ${result.backupDirectory}`);
      break;
    }

    case "githubSyncConflictOpen": {
      const targetId = String(msg.targetId || "");
      const record = readGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
      if (!record) throw new Error("GitHub Sync conflict was not found.");
      await openGitHubSyncResolutionWorkbench(context, targetId, String(msg.path || "") || undefined);
      break;
    }

    case "githubSyncConflictChoose": {
      const targetId = String(msg.targetId || "");
      const relative = String(msg.path || "");
      const source = String(msg.source || "");
      if (source !== "local" && source !== "remote" && source !== "base") throw new Error("Choose this machine, GitHub, or the common base.");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectGitHubSyncConflictCandidate(githubSyncStateDirectory(context), targetId, relative, source));
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictChooseAll": {
      const targetId = String(msg.targetId || "");
      const source = String(msg.source || "");
      if (source !== "local" && source !== "remote") throw new Error("Choose this machine or GitHub for bulk conflict resolution.");
      const result = await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectAllGitHubSyncConflictCandidates(githubSyncStateDirectory(context), targetId, source));
      const unavailable = result.unavailable.length
        ? ` ${result.unavailable.length} file${result.unavailable.length === 1 ? "" : "s"} do not have a ${source === "remote" ? "GitHub" : "machine-local"} version and remain unchanged.`
        : "";
      vscode.window.showInformationMessage(`Prepared ${result.selected} ${source === "remote" ? "GitHub" : "machine-local"} conflict candidate${result.selected === 1 ? "" : "s"}.${unavailable}`);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictDelete": {
      const targetId = String(msg.targetId || "");
      const relative = String(msg.path || "");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectGitHubSyncConflictDeletion(githubSyncStateDirectory(context), targetId, relative));
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictDeleteAll": {
      const targetId = String(msg.targetId || "");
      const result = await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectAllGitHubSyncConflictDeletions(githubSyncStateDirectory(context), targetId));
      vscode.window.showWarningMessage(`Prepared ${result.selected} deletion${result.selected === 1 ? "" : "s"} for GitHub. Nothing is deleted until Apply resolutions & Sync succeeds.`);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictDeleteLocal": {
      const targetId = String(msg.targetId || "");
      const relative = String(msg.path || "");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectGitHubSyncConflictLocalDeletion(githubSyncStateDirectory(context), targetId, relative));
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictDeleteLocalAll": {
      const targetId = String(msg.targetId || "");
      const result = await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        selectAllGitHubSyncConflictLocalDeletions(githubSyncStateDirectory(context), targetId));
      vscode.window.showWarningMessage(`Prepared ${result.selected} machine-local deletion${result.selected === 1 ? "" : "s"}. Nothing is deleted until Apply resolutions & Sync succeeds.`);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictValidate": {
      const targetId = String(msg.targetId || "");
      const relative = String(msg.path || "");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        validateGitHubSyncManualCandidate(githubSyncStateDirectory(context), targetId, relative));
      vscode.window.showInformationMessage(`Validated edited merge candidate: ${relative}`);
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictAgent": {
      const targetId = String(msg.targetId || "");
      const relative = String(msg.path || "");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, () =>
        prepareGitHubSyncAgentCandidates(context, targetId, relative));
      vscode.window.showInformationMessage("Agent merge candidates are ready. Review them before Accept & Push.");
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictAgentAll": {
      const targetId = String(msg.targetId || "");
      const result = await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () => await vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: "Preparing GitHub Sync Agent merges",
      }, async progress => prepareGitHubSyncAgentCandidates(context, targetId, "", (message, increment) => {
        progress.report({ message, increment });
      })));
      const remaining = result.unsupported + result.failed.length;
      vscode.window.showInformationMessage(
        `Agent prepared ${result.prepared} merge candidate${result.prepared === 1 ? "" : "s"}.`
        + (remaining ? ` ${remaining} conflict${remaining === 1 ? "" : "s"} still require GitHub, machine-local, or manual resolution.` : "")
      );
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictAccept": {
      const targetId = String(msg.targetId || "");
      const progress = (text: string) => respond({ command: "githubSyncConflictAcceptProgress", data: { targetId, text } });
      progress("Preparing conflict resolutions…");
      const result = await withGitHubSyncConflictEdit(context, { ...msg, targetId }, () =>
        withGitHubSyncApplyLock(context, () => acceptGitHubSyncConflict(context, targetId, progress)), true);
      if (result.refreshed.length) {
        vscode.window.showWarningMessage(
          `${result.refreshed.length} machine-local file${result.refreshed.length === 1 ? "" : "s"} changed after the conflict was prepared. The conflict choices were refreshed; review them again before applying.`
        );
      } else {
        vscode.window.showInformationMessage(`Accepted ${result.accepted} GitHub Sync merge candidate${result.accepted === 1 ? "" : "s"}. Push is queued.`);
      }
      respond({ command: "githubSyncConflictAccepted", data: { targetId, accepted: result.accepted, refreshed: result.refreshed } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncConflictDiscard": {
      const targetId = String(msg.targetId || "");
      await withGitHubSyncConflictEdit(context, { ...msg, targetId }, async () =>
        clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId));
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "githubSyncRestore": {
      const target = githubSyncTargetById(context, String(msg.targetId || ""));
      requireGitHubSyncManualMode(target, "restoring a snapshot");
      if (readGitHubSyncConflict(githubSyncStateDirectory(context), target.id)) {
        throw new Error(`Resolve or discard the current GitHub Sync comparison before restoring a snapshot for ${target.name}.`);
      }
      const checkoutRoot = path.join(githubSyncStateDirectory(context), "checkouts");
      const credentials = await readGitHubSyncCredentials(context, target);
      const snapshot = await withGitHubSyncTargetLock(context, target.id, () => fetchGitHubRemoteSnapshot(target, checkoutRoot, false, credentials));
      const selected = await vscode.window.showQuickPick(snapshot.files.map(file => ({ label: path.basename(file.path), description: file.path, path: file.path })), {
        canPickMany: true, matchOnDescription: true, title: `Restore from ${target.name}`, placeHolder: `Select files from ${target.branch} at ${snapshot.commit.slice(0, 10)}`,
      });
      if (!selected?.length) { respond({ command: "githubSyncRestoreCancelled", data: { targetId: target.id } }); break; }
      const selectedPaths = selected.map(item => item.path);
      const commit = snapshot.commit;
      const restore = (overwrite: boolean) => withGitHubSyncTargetLock(context, target.id, () => {
        const current = githubSyncTargetById(context, target.id);
        requireGitHubSyncManualMode(current, "restoring a snapshot");
        if (readGitHubSyncConflict(githubSyncStateDirectory(context), target.id)) {
          throw new Error(`Resolve or discard the current GitHub Sync comparison before restoring a snapshot for ${current.name}.`);
        }
        return withGitHubSyncApplyLock(context, () =>
          restoreGitHubRemoteFiles(current, checkoutRoot, getStorePath(), commit, selectedPaths, overwrite, credentials));
      });
      let result = await restore(false);
      if (result.conflicts.length) {
        const detail = result.conflicts.slice(0, 8).join("\n") + (result.conflicts.length > 8 ? `\n...and ${result.conflicts.length - 8} more` : "");
        const choice = await vscode.window.showWarningMessage(
          `${result.conflicts.length} selected file${result.conflicts.length === 1 ? "" : "s"} already exist locally. Overwrite them?`,
          { modal: true, detail },
          "Overwrite and Restore"
        );
        if (choice !== "Overwrite and Restore") {
          respond({ command: "githubSyncRestoreCancelled", data: { targetId: target.id } });
          break;
        }
        result = await restore(true);
      }
      invalidateSharedContentCatalog();
      await refreshKnowledgeInventory(context);
      _treeProvider?.refresh();
      respond({ command: "githubSyncRestored", data: { targetId: target.id, restored: result.restored } });
      respond({ command: "githubSyncState", data: await githubSyncStateData(context) });
      break;
    }

    case "recipeSubscriptionGroups": {
      respond({ command: "recipeSubscriptionGroups", data: sharedMarket?.cachedGroups("recipes") || [] });
      break;
    }

    case "knowledgeSearch": {
      const mode = ["lexical", "semantic", "dual"].includes(msg.mode) ? msg.mode as "lexical" | "semantic" | "dual" : "lexical";
      const contentType = ({ skills: "skill", notes: "note", papers: "research", scripts: "script" } as const)[msg.tab as "skills" | "notes" | "papers" | "scripts"];
      try {
        if (!contentType) throw new Error("This collection does not support indexed search.");
        if (!retrievalWorker) await refreshRetrievalIndex(context);
        if (!retrievalWorker) throw new Error("The unified retrieval worker is not ready. Check Settings → Router.");
        const result = await retrievalWorker.query({ schema: "pkm.retrieval.query/v1",
          requestId: String(msg.requestId), text: String(msg.q || ""), contentTypeFilter: [contentType],
          scope: { capabilityId: "panel.search" }, topK: 100, route: mode,
          generation: { mode: "latest-ready" }, diagnostics: "summary" });
        const groups = sharedMarket?.cachedGroups(msg.tab as SharedContentType) || [];
        const inventory = knowledgeInventory?.entries() || [];
        const hits = result.hits.map(hit => {
          try {
            const script = hit.contentType === "script" ? scriptGet(hit.sourceUri) : undefined;
            const entries = script ? [...inventory.filter(entry => entry.area !== "scripts"), {
              area: "scripts", relativePath: script.path, slug: script.path, title: script.file,
              knowledgeId: script.knowledgeId, aliases: script.aliases,
            }] : inventory;
            return { ...hit, ...panelSearchTarget(hit.sourceUri, entries, groups) };
          } catch (error) {
            const open_error = (error as Error).message;
            log.warn(`Panel search result cannot open: ${open_error}`);
            return { ...hit, open_error };
          }
        });
        respond({ command: "knowledgeSearch", requestId: msg.requestId, tab: msg.tab,
          data: { ...result, hits } });
      } catch (error) {
        respond({ command: "knowledgeSearch", requestId: msg.requestId, tab: msg.tab,
          data: { ok: false, search_mode: mode, semantic_status: "unavailable", semantic_reason: String(error), hits: [] } });
      }
      break;
    }

    case "list": {
      const latestKnowledgeListRequest = session.listRequests;
      const { tab, filter, q } = msg;
      const requestSequence = ++knowledgeListRequestSequence;
      latestKnowledgeListRequest.set(String(tab || ""), requestSequence);
      const listStartedAt = Date.now();
      const profileFields = {
        traceId: String(msg.profileRequestId || ""),
        surface: String(tab || ""),
        workspace: String(msg.profileWorkspace || "knowledge"),
      };
      const useInventory = !msg.fresh;
      const openingMessage = ({
        skills: "Opening the spellbook…",
        notes: "Opening the enchanted notebook…",
        papers: "Consulting the ancient scrolls…",
        prompts: "Preparing the incantations…",
        packages: "Unlocking the supply chest…",
        scripts: "Reading the runes…",
      } as Record<string, string>)[String(tab || "")] || "Brewing a potion…";
      if (!msg.silent) respond({ command: "loadingProgress", data: { stage: "scanning", percent: 25, message: openingMessage } });
      await new Promise(resolve => setImmediate(resolve));
      const searchOptions = { regex: !!msg.regex, caseSensitive: !!msg.caseSensitive };
      const source = searchOptions.regex ? String(q || "") : String(q || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      let listPattern: RegExp | undefined;
      try { listPattern = new RegExp(source, searchOptions.caseSensitive ? "" : "i"); } catch { /* invalid regex returns no matches */ }
      const listMatches = (value: unknown) => !!listPattern?.test(JSON.stringify(value));
      const data = loadProfiler.measure("host.list.source", profileFields, (): unknown => {
        if (tab === "skills") return q ? skillSearch(q, searchOptions) : useInventory && knowledgeInventory?.snapshot.revision && filter === "all" ? knowledgeInventory.skills() : skillList(filter === "all" ? undefined : filter);
        if (tab === "notes") {
          if (q) return noteSearch(q, searchOptions);
          if (useInventory && knowledgeInventory?.snapshot.revision) {
            return notesFromInventoryOrFallback(knowledgeInventory, () => noteList(undefined, 500));
          }
          return noteList(undefined, 500);
        }
        if (tab === "papers") return q ? paperSearch(q, searchOptions) : paperList();
        if (tab === "prompts") { const rows = promptList(); return q ? rows.filter(listMatches) : rows; }
        if (tab === "packages") { const rows = packagesWithGit(); return q ? rows.filter(listMatches) : rows; }
        if (tab === "scripts") return q ? scriptSearch(q, searchOptions) : useInventory && knowledgeInventory?.snapshot.revision ? knowledgeInventory.scripts() : scriptList();
        return [];
      });
      let projectedData = data;
      let brokerSharedFolders: Record<string, any> = {};
      loadProfiler.measure("host.list.sharing", profileFields, () => {
        if (!SHARED_CONTENT_TYPES.includes(tab as SharedContentType) || !Array.isArray(projectedData)) return;
        const type = tab as SharedContentType;
        const markers = brokerShareMarkers(type, projectedData, (sharedMarket?.snapshot as any)?.shares || []);
        brokerSharedFolders = markers.folders;
        projectedData = projectedData.map(item => ({
          ...item,
          isPrivate: isContentItemPrivate(type as PrivacyContentType, item),
          brokerShares: markers.items[sharedContentIdentity(type, item)]?.brokers || [],
        }));
      });
      const privacyTopLevels = loadProfiler.measure("host.list.privacy", profileFields,
        () => SHARED_CONTENT_TYPES.includes(tab as SharedContentType) ? privateTopLevels(tab as PrivacyContentType) : []);
      if (tab === "skills" && !msg.silent && Array.isArray(projectedData) && projectedData.length) {
        for (let count = Math.min(200, projectedData.length); ; count = Math.min(count + 200, projectedData.length)) {
          if (latestKnowledgeListRequest.get("skills") !== requestSequence) break;
          respond({ command: "listPartial", tab, q, filter, data: projectedData.slice(0, count), privateTopLevels: privacyTopLevels });
          await new Promise(resolve => setTimeout(resolve, 16));
          if (count === projectedData.length) break;
        }
      }
      if (latestKnowledgeListRequest.get(String(tab || "")) !== requestSequence) break;
      const isGroupedKnowledgeArea = tab === "skills" || tab === "notes" || tab === "papers";
      const folders = loadProfiler.measure("host.list.folders", profileFields, () =>
        isGroupedKnowledgeArea ? (tab === "notes" && useInventory && knowledgeInventory?.snapshot.revision ? knowledgeInventory.folders("notes") : folderList(tab)) : undefined);
      const knowledgeGroups = loadProfiler.measure("host.list.groups", profileFields, () => isGroupedKnowledgeArea
        ? knowledgeGroupSnapshot(tab, [
          ...(folders || []),
          ...(Array.isArray(projectedData) ? projectedData.map(item => String(item?.category || "")).filter(Boolean) : []),
        ])
        : undefined);
      const trashAreas = ["notes", "papers", "prompts", "scripts"] as KnowledgeTrashArea[];
      const knowledgeTrash = loadProfiler.measure("host.list.trash", profileFields,
        () => tab === "skills" ? skillTrashList() : trashAreas.includes(tab as KnowledgeTrashArea) ? knowledgeTrashList(tab as KnowledgeTrashArea) : []);
      const itemCount = Array.isArray(projectedData) ? projectedData.length : 0;
      const folderCount = Array.isArray(folders) ? folders.length : 0;
      if (!msg.silent) respond({ command: "loadingProgress", data: { stage: "building-tree", percent: 78, current: itemCount, total: itemCount, message: "Arranging the enchanted shelves…", detail: `${folderCount} folders` } });
      await new Promise(resolve => setImmediate(resolve));
      if (latestKnowledgeListRequest.get(String(tab || "")) !== requestSequence) break;
      loadProfiler.measure("host.list.respond", { ...profileFields, itemCount, folderCount }, () =>
        respond({ command: "list", tab, q, filter, data: projectedData, folders, knowledgeGroups, subscriptionGroups: [], knowledgeTrash, privateTopLevels: privacyTopLevels, brokerSharedFolders }));
      const localDuration = Date.now() - listStartedAt;
      if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "cattree.local_list_ms", localDuration, itemCount);
      if (localDuration > 250) log.warn(`slow local CatTree list tab=${tab} durationMs=${localDuration} items=${itemCount}`);
      if (sharedMarket && SHARED_CONTENT_TYPES.includes(tab as SharedContentType)) {
        setImmediate(() => {
          if (latestKnowledgeListRequest.get(String(tab || "")) !== requestSequence) return;
          const subscriptionStartedAt = Date.now();
          try {
            const subscriptionGroups = sharedMarket?.cachedGroups(tab as SharedContentType, String(q || "")) || [];
            if (latestKnowledgeListRequest.get(String(tab || "")) !== requestSequence) return;
            respond({ command: "listSubscriptionGroups", tab, data: subscriptionGroups });
            const subscriptionDuration = Date.now() - subscriptionStartedAt;
            if (performanceStateDir) recordPerformanceMetric(performanceStateDir, "cattree.subscriptions_ms", subscriptionDuration, subscriptionGroups.reduce((sum, group) => sum + group.items.length, 0));
            if (subscriptionDuration > 250) log.warn(`slow subscribed CatTree groups tab=${tab} durationMs=${subscriptionDuration}`);
          } catch (error) {
            log.warn(`subscribed CatTree groups failed tab=${tab}: ${(error as Error).message}`);
          }
        });
      }
      if (!firstContentRecorded && performanceStateDir && activationStartedAt) {
        firstContentRecorded = true;
        recordPerformanceMetric(performanceStateDir, "startup.first_content_ms", Date.now() - activationStartedAt, itemCount);
      }
      if (!msg.silent) respond({ command: "loadingProgress", data: { stage: "ready", percent: 100, current: itemCount, total: itemCount, message: "Ready", detail: `${folderCount} folders` } });
      break;
    }

    case "folderCreate": {
      const area = String(msg.area || "");
      if (area !== "skills" && area !== "notes" && area !== "papers") break;
      const parent = String(msg.parent || "").replace(/^\/+|\/+$/g, "");
      const name = String(msg.name || "").trim();
      if (!name) break;
      const rel = parent ? `${parent}/${name}` : name;
      if (folderCreate(area, rel)) {
        gitCommit(`add(folder): ${area}/${rel}`);
        _treeProvider?.refresh();
        vscode.window.setStatusBarMessage("$(new-folder) Folder created", 3000);
      }
      const data = area === "skills" ? skillList() : area === "notes" ? noteList(undefined, 500) : paperList();
      respond({ command: "list", tab: area, data, folders: folderList(area) });
      break;
    }

    case "knowledgeGroupCreate":
    case "knowledgeGroupRename":
    case "knowledgeGroupSetColor":
    case "knowledgeGroupDelete":
    case "knowledgeGroupAssign": {
      const area = String(msg.area || "") as KnowledgeGroupArea;
      if (area !== "skills" && area !== "notes" && area !== "papers") break;
      try {
        if (msg.command === "knowledgeGroupCreate") knowledgeGroupCreate(area, String(msg.name || ""), String(msg.color || ""));
        else if (msg.command === "knowledgeGroupRename") knowledgeGroupRename(area, String(msg.groupId || ""), String(msg.name || ""));
        else if (msg.command === "knowledgeGroupSetColor") knowledgeGroupSetColor(area, String(msg.groupId || ""), String(msg.color || ""));
        else if (msg.command === "knowledgeGroupDelete") knowledgeGroupDelete(area, String(msg.groupId || ""));
        else knowledgeGroupAssign(area, String(msg.folder || ""), String(msg.groupId || ""));
        respond({ command: "saved" });
      } catch (error) {
        vscode.window.showErrorMessage(`Knowledge Group update failed: ${(error as Error).message}`);
      }
      break;
    }

    case "paperFolderRename": {
      const oldPath = String(msg.oldPath || "");
      const newPath = String(msg.newPath || "");
      const result = folderRename("papers", oldPath, newPath);
      if (!result.ok) {
        vscode.window.showErrorMessage(`Paper folder rename failed: ${result.error || "unknown error"}`);
        break;
      }
      knowledgeGroupFolderRenamed("papers", oldPath, newPath);
      gitCommit(`rename(paper-folder): ${oldPath} -> ${newPath}`);
      _treeProvider?.refresh();
      respond({ command: "saved" });
      break;
    }

    case "paperFolderDelete": {
      const folderPath = String(msg.path || "");
      const parts = folderPath.split("/").filter(Boolean);
      if (!parts.length) break;
      const result = folderDeletePromote("papers", folderPath);
      if (!result.ok) {
        vscode.window.showErrorMessage(`Paper folder delete failed: ${result.error || "unknown error"}`);
        break;
      }
      gitCommit(`delete(paper-folder): ${folderPath} (${result.moved} promoted)`);
      _treeProvider?.refresh();
      respond({ command: "saved" });
      break;
    }

    case "createKnowledgeItem": {
      const area = String(msg.area || "");
      if (area !== "skills" && area !== "notes" && area !== "papers") break;
      const category = await selectKnowledgeFolder(area, String(msg.category || ""));
      if (category === undefined) break;
      const title = await vscode.window.showInputBox({
        prompt: area === "skills" ? "New skill name" : area === "notes" ? "New note title" : `New ${msg.kind === "idea" ? "idea" : "paper"} title`,
      });
      if (!title?.trim()) break;
      if (area === "skills") {
        if (skillGet(title.trim())) { vscode.window.showWarningMessage(`Skill already exists: ${title.trim()}`); break; }
        skillUpsert({ name: title.trim(), content: "", category });
        gitCommit(`add(skill): ${title.trim()}`);
        await openStoreMarkdown("skills", category ? `${category}/${title.trim()}` : title.trim());
      } else if (area === "notes") {
        const slug = (category ? `${category}/` : "") + title.trim();
        if (noteGet(slug)) { vscode.window.showWarningMessage(`Note already exists: ${slug}`); break; }
        const documentKind = await vscode.window.showQuickPick([
          { label: "Markdown", description: "Free-form Note; checkboxes are not managed tasks", value: "markdown" },
          { label: "Todo Board", description: "Structured Stories and tasks; managed through UI / MCP commands", value: "todo-board" },
        ], { placeHolder: "Choose document type" });
        if (!documentKind) break;
        if (documentKind.value === "todo-board") todoBoardCreate(slug, title.trim(), category);
        else noteUpsert({ slug, title: title.trim(), content: "", type: "general", tags: [], category });
        gitCommit(`add(note): ${slug}`);
        await openStoreMarkdown("notes", slug);
      } else if (area === "papers") {
        const slug = uniquePaperSlug(title.trim(), category);
        if (paperGet(slug)) { vscode.window.showWarningMessage(`Paper or idea already exists: ${slug}`); break; }
        paperUpsert({
          slug, title: title.trim(), content: "", category,
          kind: msg.kind === "idea" ? "idea" : "paper",
          topic: String(msg.topic || ""), group: String(msg.group || "Papers"),
        });
        gitCommit(`add(${msg.kind === "idea" ? "idea" : "paper"}): ${slug}`);
        await openStoreMarkdown("papers", slug);
      } else break;
      _treeProvider?.refresh();
      respond({ command: "saved" });
      break;
    }

    case "createPromptItem": {
      const project = String(msg.project || "").trim() || await vscode.window.showInputBox({ prompt: "Prompt project" });
      if (!project?.trim()) break;
      const task = String(msg.task || "").trim() || await vscode.window.showInputBox({ prompt: "Prompt task" });
      if (!task?.trim()) break;
      const version = String(msg.version || "").trim() || await vscode.window.showInputBox({ prompt: "Prompt version", value: "v1" });
      if (!version?.trim()) break;
      const file = await vscode.window.showInputBox({
        prompt: "New prompt filename", placeHolder: "prompt.md",
        validateInput: value => value?.trim() && !/[\\/]/.test(value) ? null : "Enter a filename without slashes",
      });
      if (!file?.trim()) break;
      const segments = [project, task, version, file].map(value => String(value).trim());
      if (segments.some(value => value === "." || value === "..")) break;
      const full = path.join(getStorePath(), "prompts", ...segments);
      if (fs.existsSync(full)) { vscode.window.showWarningMessage(`Prompt already exists: ${segments.join("/")}`); break; }
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, "");
      gitCommit(`add(prompt): ${segments.join("/")}`);
      _treeProvider?.refresh();
      respond({ command: "saved" });
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(full));
      await vscode.window.showTextDocument(doc, { preview: false });
      break;
    }

    case "todoBoardGrantWorker": {
      try {
        if (vscode.workspace.isTrusted === false) throw new Error("Worker access requires a trusted workspace.");
        const actorId = String(msg.actorId || ""), slug = String(msg.slug || "");
        const choice = await vscode.window.showWarningMessage(
          `Copy worker access for ${actorId} on “${slug}”? Share it only with that Agent. It can act as this worker on this Board, not as a user. This replaces any previous token for this Agent.`,
          { modal: true }, "Copy Worker Token");
        if (choice !== "Copy Worker Token") break;
        const token = todoBoardGrantWorker(slug, String(msg.expectedDigest || ""), actorId);
        await vscode.env.clipboard.writeText(token);
        vscode.window.showInformationMessage("Board-scoped worker token copied. Keep it private; pass it as worker_token to note_work_item_command. Reload the Board before the next change.");
      } catch (error) {
        vscode.window.showErrorMessage(`Worker access failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      break;
    }

    case "todoBoardConvert": {
      try {
        const { requestTodoBoardConversion } = await import("./ui/todo-board-conversion");
        await requestTodoBoardConversion(String(msg.slug || ""), async (prompt, title) => {
          if (!todoBoardConversionChat) throw new Error("PKM Chat is unavailable. Use Copy conversion prompt instead.");
          await todoBoardConversionChat(prompt, title);
        });
      } catch (error) {
        vscode.window.showErrorMessage(`Todo Board conversion failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      break;
    }

    case "noteTodoRead":
    case "noteTodoCommand": {
      const slug = typeof msg.slug === "string" ? msg.slug : "";
      try {
        if (!slug) throw new Error("Choose an existing Note.");
        if (vscode.workspace.isTrusted === false) throw new Error("Work Items require a trusted workspace.");
        const projects = currentProjectStore().list().projects.map(project => ({ projectId: project.projectId, name: project.name }));
        if (msg.command === "noteTodoCommand") {
          if (typeof msg.expectedDigest !== "string") throw new Error("Read the Note before modifying Work Items.");
          const item = msg.operation && typeof msg.operation === "object" && "item" in msg.operation ? msg.operation.item : undefined;
          if (item && typeof item === "object" && "projectId" in item && item.projectId !== undefined
            && !projects.some(project => project.projectId === item.projectId)) throw new Error("Choose an existing Project or clear the Project assignment.");
          noteWorkItemCommand(slug, msg.expectedDigest, msg.operation, { id: "user:local", role: "user" });
        }
        const snapshot = noteWorkItemsRead(slug);
        const note = noteGet(slug);
        if (!note) throw new Error("Note is no longer available. Reload the library before continuing.");
        const chats = apiChatGroupSnapshots(path.join(getStorePath(), ".pkm", "state"))
          .filter(chat => !chat.deletedAt).map(chat => ({ id: chat.hostSessionId, title: chat.title || chat.hostSessionId, chatUrl: chat.chatUrl }));
        respond({ command: "noteTodoResult", data: { slug, requestId: msg.requestId, snapshot, content: note.content, projects, chats, documentKind: note.documentKind } });
        if (msg.command === "noteTodoCommand") _treeProvider?.refresh();
      } catch (error) {
        respond({ command: "noteTodoResult", data: { slug, requestId: msg.requestId, error: error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "noteTodoProject": {
      const projectId = typeof msg.projectId === "string" ? msg.projectId : "";
      try {
        if (vscode.workspace.isTrusted === false) throw new Error("Work Items require a trusted workspace.");
        if (!currentProjectStore().list().projects.some(project => project.projectId === projectId)) throw new Error("Project not found.");
        const progress = projectWorkItemProgress(projectId);
        const chats = apiChatGroupSnapshots(path.join(getStorePath(), ".pkm", "state"))
          .filter(chat => !chat.deletedAt).map(chat => ({ id: chat.hostSessionId, title: chat.title || chat.hostSessionId }));
        const agentIds = chats.map(chat => chat.id);
        respond({ command: "noteTodoProjectResult", data: { projectId, requestId: msg.requestId, ...progress, agentIds, chats } });
      } catch (error) {
        respond({ command: "noteTodoProjectResult", data: { projectId, requestId: msg.requestId, error: error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "noteTodoInspect":
    case "noteTodoAgent": {
      try {
        if (vscode.workspace.isTrusted === false) throw new Error("Work Items require a trusted workspace.");
        const reference = msg.reference as WorkItemReference;
        const inspected = inspectWorkItem(reference);
        if (msg.command === "noteTodoInspect") {
          respond({ command: "noteTodoInspectResult", data: { requestId: msg.requestId, ...inspected } });
        } else {
          const ownerId = inspected.item.ownerId;
          const root = getStorePath();
          if (!ownerId?.startsWith("chat:")) throw new Error("No resolvable PKM Chat identity is recorded for this Work Item.");
          const chatId = ownerId.slice("chat:".length);
          const chat = apiChatGroupSnapshots(path.join(getStorePath(), ".pkm", "state"))
            .find(chat => chat.hostSessionId === chatId && !chat.deletedAt);
          if (!chat) throw new Error("The recorded Agent is unavailable. No same-name Chat was substituted.");
          const snapshots = listAgentSnapshots(root).filter(snapshot => snapshot.sourceHostKind === "pkm" && snapshot.sourceHostSessionId === chatId);
          if (typeof msg.snapshotId === "string") {
            if (!snapshots.some(snapshot => snapshot.snapshotId === msg.snapshotId)) throw new Error("Snapshot is unavailable for this Agent.");
            const contents = readAgentSnapshotContents(root, msg.snapshotId);
            respond({ command: "noteTodoAgentResult", data: { requestId: msg.requestId, ...inspected, chatId, title: chat.title, snapshots, contents } });
            break;
          }
          const snapshot = await vscode.commands.executeCommand("personalKnowledge.readChatHarness", chatId, "snapshot", {});
          if (!snapshot) throw new Error("The scoped Agent record reader is unavailable.");
          if (getStorePath() !== root || inspectWorkItem(reference).digest !== inspected.digest) throw new Error("Work Item changed while reading Agent records. Reload before inspecting.");
          respond({ command: "noteTodoAgentResult", data: { requestId: msg.requestId, ...inspected, chatId, title: chat.title, snapshot, snapshots } });
        }
      } catch (error) {
        respond({ command: msg.command === "noteTodoInspect" ? "noteTodoInspectResult" : "noteTodoAgentResult",
          data: { requestId: msg.requestId, error: error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "detail": {
      const { type, key } = msg;
      let data: unknown = null;
      if (type === "subscriptionItem") {
        data = getSharedMarket().cachedDetail(String(key || ""));
      } else if (type === "skill") {
        const r = skillGet(key);
        if (r) data = { type: "skill", ...r };
      } else if (type === "note") {
        const r = noteGet(key);
        if (r) data = { ...r, note_type: r.type, type: "note" };
      } else if (type === "paper") {
        const r = paperGet(key);
        if (r) {
          const papers = paperList() as any[];
          const resolvedCites = (r.cites || []).map((cite: any) => {
            const ref = String(cite.paper || "").toLowerCase();
            const target = papers.find(p => String(p.slug).toLowerCase() === ref || String(p.title).toLowerCase() === ref);
            return { ...cite, slug: target?.slug || "", title: target?.title || cite.paper };
          });
          const currentRefs = new Set([String(r.slug).toLowerCase(), String(r.title).toLowerCase()]);
          const citedBy = papers.flatMap(paper => (paper.cites || []).flatMap((cite: any) =>
            currentRefs.has(String(cite.paper || "").toLowerCase())
              ? [{ slug: paper.slug, title: paper.title, note: cite.note || "" }]
              : []));
          data = { type: "paper", ...r, resolvedCites, citedBy };
        }
      } else if (type === "prompt") {
        const [proj, task, ver, fname] = key.split("|");
        const r = promptGetFile(proj, task, ver, fname);
        if (r) {
          const allVers = promptGetAllVersionsOfFile(proj, task, fname);
          const promptTask = promptList().find(item => item.project === proj && item.task === task);
          const taskVersions = promptTask?.versions.map(item => item.version) || allVers.map(item => item.version);
          const identity = { project: proj, task, version: ver, file: fname };
          const analysis = cachedPromptAnalysis(identity) || {
            available: true, pending: true, format: path.extname(fname).replace(/^\./, "") || "prompt",
            syntaxValid: null, syntaxError: "", variables: [], relatedFiles: [], templateTree: [], missingTemplates: [],
            lineCount: r.content ? r.content.split(/\r?\n/).length : 0, charCount: r.content?.length || 0, chatTemplate: false,
          };
          data = { type: "prompt", ...r, allVersions: allVers, taskVersions, analysis };
          const orderedVersions = [ver, ...taskVersions.filter(version => version !== ver)];
          setImmediate(async () => {
            for (const version of orderedVersions) {
              const versionInfo = promptTask?.versions.find(item => item.version === version);
              const files = versionInfo?.files.map(item => item.name).filter(name => /\.jinja2?$/.test(name)) || [fname];
              const taskVariables = new Set<string>();
              for (const file of files) {
                const versionIdentity = { project: proj, task, version, file };
                try {
                  const result = await inspectPromptCached(context.extensionPath, versionIdentity);
                  result.variables.forEach(variable => taskVariables.add(variable));
                  if (file === fname) respond({ command: "promptVersionAnalysis", data: { ...versionIdentity, analysis: result } });
                } catch (error: any) {
                  if (file === fname) respond({ command: "promptVersionAnalysis", data: { ...versionIdentity, analysis: { available: false, pending: false, syntaxValid: false, syntaxError: error?.message || String(error), variables: [], relatedFiles: [], templateTree: [], missingTemplates: [] } } });
                }
              }
              respond({ command: "promptTaskVariables", data: { project: proj, task, version, variables: [...taskVariables].sort() } });
            }
          });
        }
      } else if (type === "promptDiff") {
        const [proj, task, fname] = key.split("|");
        const allVers = promptGetAllVersionsOfFile(proj, task, fname);
        data = { type: "promptDiff", project: proj, task, file: fname, allVersions: allVers };
      } else if (type === "package") {
        const r = packageGet(key);
        if (r) data = { type: "package", ...r };
      } else if (type === "packageFile") {
        const [pkg, ...rest] = key.split("|");
        const relPath = rest.join("|");
        const r = packageFileGet(pkg, relPath);
        if (r) data = { type: "script", ...r, pkmPath: `packages/${pkg}/${relPath}` };
      } else if (type === "script") {
        // key is the full relative path (e.g. "AdCoherence/Analysis/foo.script")
        const r = scriptGet(key);
        if (r) data = { type: "script", ...r };
      }
      if (data && typeof data === "object" && type !== "subscriptionItem") {
        if (type === "packageFile") (data as any).isPrivate = isTopLevelPrivate("packages", String(key || "").split("|")[0]);
        else if (type === "promptDiff") (data as any).isPrivate = isTopLevelPrivate("prompts", String(key || "").split("|")[0]);
        else if ((["skill", "note", "paper", "prompt", "package", "script"] as string[]).includes(type)) {
          (data as any).isPrivate = isContentItemPrivate(type === "package" ? "packages" : type === "prompt" ? "prompts" : `${type}s` as PrivacyContentType, data);
        }
      }
      const editIdentity = panelEditIdentity(type, key);
      const editRevision = panelEditRevision(panelEditValue(type, key));
      session.revisions.set(editIdentity, editRevision);
      respond({ command: "detail", data, editIdentity, editRevision, detailRequestId: msg.detailRequestId, detailTab: msg.detailTab });
      break;
    }

    case "promptRender": {
      const identity = {
        project: String(msg.project || ""), task: String(msg.task || ""),
        version: String(msg.version || ""), file: String(msg.file || ""),
      };
      try {
        const rendered = await renderPrompt(
          context.extensionPath,
          identity,
          msg.context && typeof msg.context === "object" ? msg.context : {},
          msg.mode === "chat" ? "chat" : "completion",
        );
        respond({ command: "promptRendered", data: { ...identity, ...rendered } });
      } catch (error: any) {
        respond({ command: "promptRendered", data: { ...identity, error: error?.message || String(error) } });
      }
      break;
    }

    case "promptInference": {
      const identity = {
        project: String(msg.project || ""), task: String(msg.task || ""),
        version: String(msg.version || ""), file: String(msg.file || ""),
      };
      try {
        const backends = await listAiBackends(context);
        const backend = backends.find(item => item.id === String(msg.backend || ""));
        if (!backend) throw new Error("Choose an available model before running inference.");
        if (backend.id.endsWith(":needkey")) throw new Error('API key not set. Run "Personal Knowledge Manager: Set AI API Key".');
        const rendered = await renderPrompt(
          context.extensionPath,
          identity,
          msg.context && typeof msg.context === "object" ? msg.context : {},
          msg.mode === "chat" ? "chat" : "completion",
        );
        const prompt = Array.isArray(rendered.result)
          ? rendered.result.map((message: any) => `<|im_start|>${String(message[0] || "user")}\n${String(message[1] || "")}<|im_end|>`).join("\n")
          : String(rendered.result || "");
        if (!prompt.trim()) throw new Error("The rendered Prompt is empty.");
        if (prompt.length > 200_000) throw new Error("The rendered Prompt exceeds the 200,000 character inference limit.");
        const result = await runAiPrompt(context, backend, prompt);
        respond({ command: "promptInferenceResult", data: { ...identity, result, rendered: rendered.result, mode: rendered.mode, backend: backend.label, model: backend.model } });
      } catch (error: any) {
        respond({ command: "promptInferenceResult", data: { ...identity, error: error?.message || String(error) } });
      }
      break;
    }

    case "promptSaveVersionNote": {
      const project = String(msg.project || ""), task = String(msg.task || ""), version = String(msg.version || ""), file = String(msg.file || "");
      const note = String(msg.note || "");
      const overwriteLabel = `Overwrite ${version}`;
      const newVersionLabel = "Save as New Version…";
      const choice = await vscode.window.showWarningMessage(
        `Save the Version note for ${project}/${task}/${version}/${file}?`,
        { modal: true, detail: "Overwrite updates this Prompt version. Save as New Version copies the complete version folder before applying the note." },
        overwriteLabel, newVersionLabel,
      );
      if (!choice) { respond({ command: "promptVersionNoteSaved", data: { cancelled: true } }); break; }
      let targetVersion: string | undefined;
      if (choice === newVersionLabel) {
        const match = /^v(\d+(?:\.\d+)*)$/.exec(version);
        const parts = match ? match[1].split(".").map(Number) : [1];
        parts[parts.length - 1] += 1;
        const suggested = `v${parts.join(".")}`;
        targetVersion = await vscode.window.showInputBox({
          title: "Save Prompt as New Version", prompt: `Copy the complete ${version} folder and update this Version note.`, value: suggested,
          validateInput: value => {
            if (!/^v\d+(?:\.\d+)*$/.test(value.trim())) return "Use a version such as v10 or v9.2.";
            try { return fs.existsSync(promptFilePath(project, task, value.trim())) ? `Version already exists: ${value.trim()}` : undefined; }
            catch (error: any) { return error?.message || String(error); }
          },
        });
        if (!targetVersion) { respond({ command: "promptVersionNoteSaved", data: { cancelled: true } }); break; }
        targetVersion = targetVersion.trim();
      }
      try {
        const saved = promptSaveVersionNote(project, task, version, file, note, targetVersion);
        gitCommit(`${targetVersion ? "add(prompt-version)" : "update(prompt)"}: ${project}/${task}/${saved.version}/${file} note`);
        _treeProvider?.refresh();
        respond({ command: "promptVersionNoteSaved", data: { ok: true, project, task, ...saved } });
      } catch (error: any) {
        respond({ command: "promptVersionNoteSaved", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "promptOpenTextEditor": {
      try {
        const fullPath = promptFilePath(String(msg.project || ""), String(msg.task || ""), String(msg.version || ""), String(msg.file || ""));
        if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) throw new Error("Prompt file was not found.");
        const document = await vscode.workspace.openTextDocument(vscode.Uri.file(fullPath));
        await vscode.window.showTextDocument(document, { preview: false });
      } catch (error: any) {
        vscode.window.showWarningMessage(error?.message || String(error));
      }
      break;
    }

    case "subscriptionFork": {
      const market = getSharedMarket();
      const keys = Array.isArray(msg.keys) ? msg.keys.map(String) : [];
      const source = keys.length
        ? market.forkFolderSource(keys, String(msg.path || ""))
        : market.forkSource(String(msg.key || ""));
      let forkPath: string;
      if (source.type === "recipes") {
        const recipe = JSON.parse(source.content || "null") as RecipeRecord;
        const store = currentProjectStore();
        const result = store.importRecipe(projectCommand(store, "recipe-subscription-fork", {
          sourceRecipeId: recipe?.recipeId, brokerName: source.brokerName, remotePath: source.remotePath,
        }), recipe, {
          kind: "subscription-fork", sourceKey: `${source.publisherUser}@${source.publisherHost}/${source.brokerName}/${source.remotePath}`,
          preserveIdentity: false, rejectExisting: true, brokerName: source.brokerName,
          publisherUser: source.publisherUser, publisherHost: source.publisherHost,
        });
        forkPath = `recipes/${result.entityId}`;
      } else forkPath = forkSubscriptionContent(getStorePath(), source);
      gitCommit(`fork(${source.type === "packages" ? "package" : source.type}): ${source.brokerName}/${source.remotePath}`);
      _treeProvider?.refresh();
      respond({ command: "subscriptionForked", data: { type: source.type, path: forkPath } });
      break;
    }

    case "saveNote": {
      const { title, content, type, tags, category, slug: existingSlug } = msg;
      const slug = existingSlug ?? uniqueSlug(title || content.slice(0, 60));
      noteUpsert({ slug, title: title || slug, content, type, tags, category });
      advancePanelEditBaseline("note", slug, respond);
      gitCommit(existingSlug ? `update(note): ${slug}` : `add(note): ${slug}`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Note saved", 3000);
      break;
    }

    case "saveAsset": {
      const { data, ext, reqId } = msg;
      try {
        const existing = noteGet(String(msg.slug || ""));
        if (!existing) throw new Error("Save the Note before attaching images.");
        const rel = saveNoteAsset(String(data || ""), String(ext || "png"), existing.category, String(existing.slug).split("/").pop());
        respond({ command: "assetSaved", reqId, markdown: `![](${rel})` });
      } catch (e) {
        log.error(`saveAsset failed: ${String(e)}`);
        respond({ command: "assetSaved", reqId, error: String(e) });
      }
      break;
    }

    case "markdownAssetList": {
      const area = String(msg.area || "");
      if (!["skills", "notes", "papers"].includes(area)) throw new Error("Invalid Markdown content area.");
      const documentPath = String(msg.documentPath || "");
      const full = checkedMarkdownPath(path.join(getStorePath(), area), documentPath);
      const assets = listedMarkdownAssets(getStorePath(), area as MarkdownAssetArea, documentPath, fs.readFileSync(full, "utf8"));
      respond({ command: "markdownAssetList", data: { area, documentPath, assets: assets.map(asset => ({ path: asset.path })) } });
      break;
    }

    case "manageMarkdownAssets":
    case "previewMarkdownAsset": {
      const area = String(msg.area || "");
      if (!["skills", "notes", "papers"].includes(area)) throw new Error("Invalid Markdown content area.");
      const documentPath = String(msg.documentPath || "");
      if (msg.command === "previewMarkdownAsset") {
        const full = checkedMarkdownPath(path.join(getStorePath(), area), documentPath);
        const asset = listedMarkdownAssets(getStorePath(), area as MarkdownAssetArea, documentPath, fs.readFileSync(full, "utf8")).find(asset => asset.path === msg.assetPath);
        if (!asset) throw new Error("The Markdown resource is no longer available.");
        await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(asset.fullPath));
      } else if (session.markdownDraftOpen) {
        throw new Error("Save or close inline Markdown editors before managing resources.");
      } else if (await manageMarkdownAssets(area as MarkdownAssetArea, documentPath)) {
        _treeProvider?.refresh();
        respond({ command: "reloaded", data: { changedPath: `${area}/${documentPath}` } });
      }
      break;
    }

    case "resolveNoteLink": {
      // Cross-note link: target may be a [[title]], a slug, or a relative /
      // absolute .md path. `from` is the source note's slug (for relative refs).
      const target = String(msg.target || "").trim();
      const from = String(msg.from || "").trim();
      const isWiki = !!msg.wiki;
      let r: any = null;

      // 1. Path-style links: resolve relative (./, ../, sub/x.md) against the
      //    source note's folder, or an absolute path that lives under notes/.
      if (!isWiki && target && (/\.md(\?|#|$)/i.test(target) || target.includes("/"))) {
        const slug = resolveNoteSlugFromPath(target, from);
        if (slug) r = noteGet(slug);
      }
      // 2. Direct slug (or a path relative to the notes root).
      if (!r && target) r = noteGet(target.replace(/\.md$/i, ""));
      // 3. Title / slug / basename fallback (covers [[Title]] wiki links).
      if (!r && target) {
        const needle = target.replace(/\.md$/i, "").toLowerCase();
        const base = needle.split("/").pop() || needle;
        const hit = (noteList(undefined, 10000) as any[]).find(
          n => (n.title || "").toLowerCase() === needle ||
               (n.slug || "").toLowerCase() === needle ||
               (n.slug || "").toLowerCase().endsWith("/" + base) ||
               (n.title || "").toLowerCase() === base,
        );
        if (hit) r = noteGet(hit.slug);
      }
      if (r) respond({ command: "detail", data: { ...r, note_type: r.type, type: "note" } });
      else respond({ command: "noteLinkMissing", target });
      break;
    }

    case "exportNoteHtml": {
      // Build a self-contained HTML document from the webview-rendered body and
      // either open it in the default browser or save it to a file.
      try {
        const note = msg.area === "notes" ? noteGet(String(msg.slug || "")) : undefined;
        const exported = note?.documentKind === "todo-board" ? {
          ...msg, bodyHtml: browserNoteTodo("", "", note.slug, note.title, context.extensionPath, noteWorkItemsRead(note.slug), false),
        } : msg;
        const doc = buildStandaloneNoteHtml(exported, katexCssForExport(context));
        const safe = safeFilePart(String(msg.title || msg.slug || "note")) || "note";
        if (msg.mode === "browser") {
          const opened = await openHtmlInBrowser(doc);
          if (opened) {
            vscode.window.setStatusBarMessage("$(globe) Note opened in browser", 4000);
          } else {
            // Couldn't open a browser (e.g. fully headless host) — offer to save instead.
            const out = path.join(os.tmpdir(), `pk-note-${safe}-${Date.now()}.html`);
            fs.writeFileSync(out, doc, "utf-8");
            const pick = await vscode.window.showInformationMessage(
              `Couldn't open a browser. Preview written to ${out}`, "Copy Path");
            if (pick === "Copy Path") await vscode.env.clipboard.writeText(out);
          }
        } else {
          const target = await vscode.window.showSaveDialog({
            saveLabel: "Export note as HTML",
            defaultUri: vscode.Uri.file(path.join(os.homedir(), `${safe}.html`)),
            filters: { HTML: ["html"] },
          });
          if (target) {
            fs.writeFileSync(target.fsPath, doc, "utf-8");
            const pick = await vscode.window.showInformationMessage(
              `Note exported to ${path.basename(target.fsPath)}`, "Open");
            if (pick === "Open") await vscode.env.openExternal(target);
          }
        }
      } catch (e) {
        log.error(`exportNoteHtml failed: ${String(e)}`);
        vscode.window.showErrorMessage(`Export failed: ${String(e)}`);
      }
      break;
    }

    case "collectLinkedNotes": {
      const rootSlug = String(msg.slug || "").trim();
      if (msg.exportMode === "browser") {
        const opened = await openLiveMarkdownPreview("note", rootSlug, context);
        if (opened) vscode.window.setStatusBarMessage(`$(globe) Live preview: ${notePreviewPath(rootSlug)}`, 5000);
        else vscode.window.showWarningMessage("Couldn't open the live Note preview in a browser.");
        break;
      }
      // Static Site export still renders the transitive linked-note closure in
      // the webview so diagrams can be embedded for offline use.
      const notes = collectLinkedNotes(rootSlug);
      const entry = notes.find(n => n.slug === rootSlug) || notes[0];
      respond({ command: "linkedNotes", entryFilename: entry ? entry.filename : "", notes, mode: msg.exportMode || "browser" });
      break;
    }

    case "openMarkdownPreview": {
      const kind = String(msg.kind || "") as "note" | "skill" | "paper" | "script";
      if (!(["note", "skill", "paper", "script"] as string[]).includes(kind)) break;
      const key = String(msg.key || "").trim();
      const opened = await openLiveMarkdownPreview(kind, key, context);
      if (opened) vscode.window.setStatusBarMessage(`$(globe) Live preview: ${markdownPreviewPath(kind, key)}`, 5000);
      else vscode.window.showWarningMessage("Couldn't open the Markdown preview in a browser.");
      break;
    }

    case "copyPublicContentLink": {
      const kind = String(msg.kind || "") as "note" | "skill" | "paper" | "script";
      const key = String(msg.key || "").trim();
      if (!(["note", "skill", "paper", "script"] as string[]).includes(kind) || !key) break;
      const url = navigationItemPath({ nodeType:kind === "script" ? "script-file" : kind,
        nodeData:kind === "script" ? { key } : { relPath:`${key}.md` } });
      await vscode.env.clipboard.writeText(url);
      vscode.window.setStatusBarMessage(`$(link) PKM URL copied: ${url}`, 5000);
      break;
    }

    case "writeLinkedExport": {
      // Write each webview-rendered note as a standalone HTML file with clickable
      // cross-note links. mode 'save' -> a folder the user picks (portable,
      // shareable, runs offline); otherwise -> a temp folder opened in the browser.
      try {
        const files: any[] = Array.isArray(msg.files) ? msg.files : [];
        if (!files.length) { vscode.window.setStatusBarMessage("$(info) Nothing to export", 3000); break; }
        const entry = String(msg.entryFilename || files[0].filename);
        const writeAll = (dir: string) => {
          for (const f of files) {
            const note = noteGet(String(f.slug || "")) || {};
            const doc = buildStandaloneNoteHtml({
              title: note.title || f.slug, slug: f.slug, category: note.category || "",
              tags: note.tags || "[]", noteType: note.type || "general",
              updatedAt: note.updated_at || "", bodyHtml: note.documentKind === "todo-board"
                ? browserNoteTodo("", "", note.slug, note.title, context.extensionPath, noteWorkItemsRead(note.slug), false) : f.bodyHtml || "",
            }, katexCssForExport(context));
            fs.writeFileSync(path.join(dir, String(f.filename)), doc, "utf-8");
          }
        };

        if (msg.mode === "save") {
          const picked = await vscode.window.showOpenDialog({
            canSelectFolders: true, canSelectFiles: false, canSelectMany: false,
            openLabel: "Export linked notes here",
            defaultUri: vscode.Uri.file(os.homedir()),
          });
          if (!picked || !picked.length) break;
          const entryNote = files.find(f => f.filename === entry) || files[0];
          const baseName = safeFilePart(String(entryNote.slug || "notes").split("/").pop() || "notes") || "notes";
          const outDir = path.join(picked[0].fsPath, `${baseName}-linked`);
          fs.mkdirSync(outDir, { recursive: true });
          writeAll(outDir);
          const entryPath = path.join(outDir, entry);
          const pick = await vscode.window.showInformationMessage(
            `Exported ${files.length} linked note${files.length > 1 ? "s" : ""} to ${outDir}. Open ${entry} to browse offline.`,
            "Reveal", "Open");
          if (pick === "Reveal") await vscode.commands.executeCommand("revealFileInOS", vscode.Uri.file(entryPath));
          else if (pick === "Open") await vscode.env.openExternal(vscode.Uri.file(entryPath));
          break;
        }

        const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pk-notes-"));
        writeAll(dir);
        const opened = await serveFolderInBrowser(dir, entry);
        if (opened) {
          vscode.window.setStatusBarMessage(`$(globe) Opened ${files.length} linked note${files.length > 1 ? "s" : ""} in browser`, 5000);
        } else {
          const pick = await vscode.window.showInformationMessage(
            `Couldn't open a browser. Notes written to ${dir}`, "Copy Path");
          if (pick === "Copy Path") await vscode.env.clipboard.writeText(dir);
        }
      } catch (e) {
        log.error(`writeLinkedExport failed: ${String(e)}`);
        vscode.window.showErrorMessage(`Linked export failed: ${String(e)}`);
      }
      break;
    }

    case "toast": {
      vscode.window.setStatusBarMessage(`$(info) ${String(msg.text || "")}`, 4000);
      break;
    }

    case "copyText": {
      const text = String(msg.text || "");
      if (!text) break;
      await vscode.env.clipboard.writeText(text);
      vscode.window.setStatusBarMessage(`$(copy) Copied ${text}`, 3000);
      break;
    }

    case "goToPkmPath": {
      await vscode.commands.executeCommand("personalKnowledge.goToPkmPath");
      break;
    }

    // ── Servers dashboard ────────────────────────────────────────────────────
    case "serverList": {
      respond({ command: "serverList", data: await serverListForUi(context) });
      respond({ command: "serverPrivacy", data: privateTopLevels("servers") });
      respond({ command: "serverSubscriptionGroups", data: await subscribedServerGroupsForUi() });
      await _treeProvider?.refreshServerStatus();
      break;
    }

    case "serverSubscriptionStatus": {
      respond({ command: "serverSubscriptionGroups", data: await subscribedServerGroupsForUi(String(msg.subscriptionId || ""), true) });
      break;
    }

    case "serverSubscriptionRefresh": {
      const subscriptionId = String(msg.subscriptionId || "");
      const refreshed = await getSharedMarket().refresh(subscriptionId, true);
      respond({ command: "serverSubscriptionGroups", data: await subscribedServerGroupsForUi(subscriptionId, true) });
      respond({ command: "subscriptionCompleted", data: { action: "serverContentRefreshed", name: refreshed.alias || refreshed.brokerName || refreshed.shareId, revision: refreshed.revision } });
      break;
    }
    case "serverGroupList": {
      respond({ command: "serverGroupList", data: serverGroupList() });
      break;
    }
    case "serverCreateGroup": {
      const result = serverCreateGroup(String(msg.category || ""));
      if (!result.ok) vscode.window.showErrorMessage(`Create Server group failed: ${result.error || "unknown error"}`);
      else {
        if (msg.moveSlug) serverUpdate(String(msg.moveSlug), { category: result.group || "" });
        gitCommit(`server group create: ${result.group}`);
      }
      respond({ command: "serverGroupList", data: serverGroupList() });
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverStart": {
      const r = startServer(String(msg.slug || ""));
      if (!r.ok && r.error) vscode.window.showErrorMessage(`Start failed: ${r.error}`);
      await new Promise(res => setTimeout(res, 400));
      await ensureServerForwarding(context, String(msg.slug || ""));
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverStop": {
      stopServer(String(msg.slug || ""));
      await new Promise(res => setTimeout(res, 300));
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverInspectExternal": {
      respond({ command: "serverList", data: await serverListForUi(context, String(msg.slug || "")) });
      break;
    }
    case "serverForceStopExternal": {
      const result = await forceStopExternalServer(String(msg.slug || ""), Array.isArray(msg.expectedPids) ? msg.expectedPids : []);
      if (!result.ok) vscode.window.showErrorMessage(`Force Stop failed: ${result.error || "unknown error"}`);
      else vscode.window.showInformationMessage(`Stopped external listener PID ${result.pids?.join(", ") || "unknown"}.`);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverRestart": {
      const r = await restartServer(String(msg.slug || ""));
      if (!r.ok && r.error) vscode.window.showErrorMessage(`Restart failed: ${r.error}`);
      await ensureServerForwarding(context, String(msg.slug || ""));
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverSetPort": {
      const r = await setServerPort(String(msg.slug || ""), Number(msg.port) || 0);
      if (!r.ok && r.error) vscode.window.showErrorMessage(`Change port failed: ${r.error}`);
      await ensureServerForwarding(context, String(msg.slug || ""));
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverImport": {
      const r = serverImport(String(msg.sourceDir || ""), String(msg.name || ""));
      if (r.ok) gitCommit(`server import: ${r.slug}`);
      else if (r.error) vscode.window.showErrorMessage(`Import failed: ${r.error}`);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverImportGit": {
      if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before importing Git sources.");
      const url = await vscode.window.showInputBox({ title:"Import server from Git", prompt:"Repository HTTPS/SSH URL. Checkout only: no install, build, or automatic start.", ignoreFocusOut:true });
      if (!url) break;
      const branch = await vscode.window.showInputBox({ title:"Git branch", prompt:"Explicit branch to checkout and track", value:"main", ignoreFocusOut:true });
      if (!branch) break;
      const name = await vscode.window.showInputBox({ title:"Server name", value:url.split("/").pop()?.replace(/\.git$/, "") || "Git server", ignoreFocusOut:true });
      if (!name) break;
      const command = await vscode.window.showInputBox({ title:"Start command (saved, NOT executed)", prompt:"Runs later only when you explicitly start the server; supports {port} and {python}.", ignoreFocusOut:true });
      if (!command) break;
      const slug = await vscode.window.withProgress({ location:vscode.ProgressLocation.Notification, title:"Checking out Git server (no code execution)", cancellable:false },
        () => serverImportGit(name, url, branch, command));
      vscode.window.showInformationMessage(`Imported ${slug}. Review the checkout and install dependencies yourself before starting it.`);
      invalidateSharedContentCatalog();
      respond({ command:"serverList", data:await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "packageImportGit": {
      if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before importing Git sources.");
      const url = await vscode.window.showInputBox({ title:"Import package from Git", prompt:"Repository HTTPS/SSH URL; source snapshot only, no install or execution.", ignoreFocusOut:true });
      if (!url) break;
      const branch = await vscode.window.showInputBox({ title:"Git branch", value:"main", ignoreFocusOut:true });
      if (!branch) break;
      const name = await vscode.window.showInputBox({ title:"Package name", value:url.split("/").pop()?.replace(/\.git$/, "") || "package", ignoreFocusOut:true });
      if (!name) break;
      await vscode.window.withProgress({ location:vscode.ProgressLocation.Notification, title:"Importing Git package source (no code execution)", cancellable:false },
        () => importGitPackage(path.join(getStorePath(), "packages"), path.join(context.globalStorageUri.fsPath, "git-packages"), name, url, branch));
      invalidateSharedContentCatalog();
      respond({ command:"reloaded" });
      _treeProvider?.refresh();
      break;
    }
    case "packageUpdateGit": {
      if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before updating Git sources.");
      await vscode.window.withProgress({ location:vscode.ProgressLocation.Notification, title:"Updating package source; preserving local changes", cancellable:false },
        () => updateGitPackage(path.join(getStorePath(), "packages"), path.join(context.globalStorageUri.fsPath, "git-packages"), String(msg.name || "")));
      invalidateSharedContentCatalog();
      respond({ command:"reloaded" });
      _treeProvider?.refresh();
      break;
    }
    case "serverUpdateGit": {
      if (!vscode.workspace.isTrusted) throw new Error("Trust this workspace before updating Git sources.");
      await vscode.window.withProgress({ location:vscode.ProgressLocation.Notification, title:"Fetching configured branch and fast-forwarding stopped server", cancellable:false },
        () => serverUpdateGit(String(msg.slug || "")));
      invalidateSharedContentCatalog();
      respond({ command:"serverList", data:await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverCreate": {
      const r = serverCreate(String(msg.name || ""));
      if (r.ok) gitCommit(`server create: ${r.slug}`);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverUpdate": {
      const slug = String(msg.slug || "");
      const patch = msg.patch || {};
      const requestedPort = Number(patch.port);
      const owner = patch.port !== undefined ? serverPortOwner(requestedPort, slug) : undefined;
      if (owner) vscode.window.showErrorMessage(`Port ${requestedPort} is already reserved by ${owner}. Choose a unique port.`);
      else if (!serverUpdate(slug, patch)) vscode.window.showErrorMessage("Server settings were not saved. Check that the port is between 1 and 65535 and unique.");
      else gitCommit(`server update: ${msg.slug}`);
      await ensureServerForwarding(context, slug);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverSetPinned": {
      const slug = String(msg.slug || "");
      serverUpdate(slug, { pinned: !!msg.pinned });
      gitCommit(`server ${msg.pinned ? "star" : "unstar"}: ${slug}`);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverMoveGroup": {
      const oldPrefix = String(msg.oldPrefix || "");
      const newPrefix = String(msg.newPrefix || "");
      if (privateTopLevelPromotionBlocked("servers", oldPrefix, newPrefix)) throw new Error("Set this private Server group as Public before deleting it into Ungrouped.");
      const result = serverMoveGroup(oldPrefix, newPrefix);
      if (!result.ok) vscode.window.showErrorMessage(`Move Server group failed: ${result.error || "unknown error"}`);
      else {
        preserveTopLevelPrivacy("servers", oldPrefix, newPrefix);
        gitCommit(`server group move: ${oldPrefix} -> ${newPrefix || "(root)"}`);
      }
      respond({ command: "serverList", data: await serverListForUi(context) });
      respond({ command: "serverGroupList", data: serverGroupList() });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverDelete": {
      serverDelete(String(msg.slug || ""));
      gitCommit(`server delete: ${msg.slug}`);
      respond({ command: "serverList", data: await serverListForUi(context) });
      await _treeProvider?.refreshServerStatus();
      break;
    }
    case "serverSetForward": {
      const enabled = !!msg.enabled;
      await context.globalState.update("servers.autoForward.global.v1", enabled);
      const externalUrls: Record<string, string> = {};
      if (enabled) {
        for (const server of await serverList()) {
          const externalUrl = await ensureServerForwarding(context, server.slug);
          if (externalUrl) externalUrls[server.slug] = externalUrl;
        }
      }
      else if (vscode.env.remoteName) vscode.window.showInformationMessage("Automatic forwarding disabled. Close any existing tunnel manually in VS Code's Ports view.");
      respond({ command: "serverForwardResult", data: { enabled, externalUrls, remoteName: vscode.env.remoteName || "" } });
      respond({ command: "serverList", data: await serverListForUi(context) });
      break;
    }
    case "serverLog": {
      respond({ command: "serverLog", slug: msg.slug, text: serverLog(String(msg.slug || ""), 300) });
      break;
    }
    case "serverPickFolder": {
      const picked = await vscode.window.showOpenDialog({
        canSelectFolders: true, canSelectFiles: false, canSelectMany: false,
        openLabel: "Select server folder",
      });
      respond({ command: "serverPickFolder", dir: picked && picked.length ? picked[0].fsPath : "" });
      break;
    }
    case "serverOpenUrl": {
      try {
        const url = String(msg.url || "");
        if (msg.requiresForward && vscode.env.remoteName && !msg.forwardEnabled) {
          vscode.window.showWarningMessage("Enable Port Forward for this Server Link, or use the Stable Link with a reachable network IP.");
          break;
        }
        await vscode.env.openExternal(vscode.Uri.parse(url));
      } catch (e: any) { vscode.window.showErrorMessage(`Couldn't open URL: ${e?.message}`); }
      break;
    }
    case "serverOpenFolder": {
      const dir = serverDir(String(msg.slug || ""));
      if (dir && fs.existsSync(dir)) {
        try { await vscode.commands.executeCommand("revealInExplorer", vscode.Uri.file(dir)); } catch { /* ignore */ }
        try { await vscode.commands.executeCommand("vscode.openFolder", vscode.Uri.file(dir), { forceNewWindow: true }); }
        catch (e: any) { vscode.window.showErrorMessage(`Couldn't open folder: ${e?.message}`); }
      } else {
        vscode.window.showErrorMessage("Server folder not found");
      }
      break;
    }
    case "serverCopy": {
      await vscode.env.clipboard.writeText(String(msg.text || ""));
      vscode.window.setStatusBarMessage("$(check) Copied", 2500);
      break;
    }

    // ── Python Environments ──────────────────────────────────────────────────
    case "envList": {
      if (msg.refresh) {
        const refreshErrors: string[] = [];
        for (const environment of pyenvList()) {
          const probe = await refreshEnvironmentVersion(environment.id);
          if (probe.error) refreshErrors.push(`${environment.name || environment.id}: Python version probe failed: ${probe.error}`);
          const size = await refreshEnvironmentSize(environment.id);
          if (size.error) refreshErrors.push(`${environment.name || environment.id}: disk size probe failed: ${size.error}`);
        }
        respond({ command: "envList", data: envListForUi(), refreshErrors });
        break;
      }
      respond({ command: "envList", data: envListForUi() });
      void sweepEnvVersions(respond);
      void sweepEnvSizes(respond);
      break;
    }
    case "envCondaList": {
      respond({ command: "envCondaList", data: await condaEnvs() });
      break;
    }
    case "envDetectFolder": {
      respond({ command: "envDetectFolder", data: detectFolderEnv(String(msg.dir || "")) });
      break;
    }
    case "envPickFolder": {
      const picked = await vscode.window.showOpenDialog({
        canSelectFolders: true, canSelectFiles: false, canSelectMany: false,
        openLabel: "Select environment folder",
      });
      respond({ command: "envPickFolder", dir: picked && picked.length ? picked[0].fsPath : "" });
      break;
    }
    case "envAdd": {
      pyenvAdd(msg.env || {});
      respond({ command: "envList", data: envListForUi() });
      _treeProvider?.refresh();
      vscode.window.setStatusBarMessage("$(check) Environment added", 3000);
      break;
    }
    case "envUpdate": {
      pyenvUpdate(String(msg.id || ""), msg.patch || {});
      respond({ command: "envList", data: envListForUi() });
      _treeProvider?.refresh();
      break;
    }
    case "envDelete": {
      const r = await pyenvDelete(String(msg.id || ""), !!msg.removeFiles);
      respond({ command: "envList", data: envListForUi() });
      respond({ command: "envDeleteResult", data: r });
      _treeProvider?.refresh();
      break;
    }
    case "envPackages": {
      const r = await pyenvPackages(String(msg.id || ""), !!msg.refresh);
      respond({ command: "envPackages", id: msg.id, ...r });
      break;
    }
    case "envCompare": {
      respond({ command: "envCompare", data: await pyenvCompare(String(msg.a || ""), String(msg.b || "")) });
      break;
    }
    case "envSimilarity": {
      respond({ command: "envSimilarity", data: await pyenvSimilarity() });
      break;
    }
    case "envMergeScript": {
      const r = await pyenvMergeScript(String(msg.a || ""), String(msg.b || ""));
      if (r.error || !r.script) { respond({ command: "envMergeScript", error: r.error || "no script" }); break; }
      await vscode.env.clipboard.writeText(r.script);
      vscode.window.setStatusBarMessage("$(check) Merge script copied — review and run it yourself", 4000);
      respond({ command: "envMergeScript", script: r.script, keep: r.keep, drop: r.drop });
      break;
    }
    case "envSize": {
      const r = msg.refresh ? await refreshEnvironmentSize(String(msg.id || "")) : await pyenvSize(String(msg.id || ""), false);
      respond({ command: "envSize", id: msg.id, ...r });
      break;
    }
    case "envMigrate": {
      const target = pyenvsRoot();
      const env = pyenvList().find(e => e.id === msg.id);
      const r = await vscode.window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: `Migrating “${env?.name || msg.id}” → ${target}…`, cancellable: false },
        () => pyenvMigrate(String(msg.id || ""), target),
      );
      if (r.ok) {
        respond({ command: "envList", data: envListForUi() });
        respond({ command: "envMigrated", ok: true });
        _treeProvider?.refresh();
        void sweepEnvSizes(respond);
        vscode.window.setStatusBarMessage("$(check) Environment migrated", 3000);
      } else {
        respond({ command: "envMigrated", ok: false, error: r.error, log: r.log });
      }
      break;
    }
    case "envDeleteScript": {
      const { script, error } = pyenvDeleteScript(String(msg.id || ""));
      if (error || !script) { respond({ command: "envDeleteScript", id: msg.id, error: error || "no script" }); break; }
      await vscode.env.clipboard.writeText(script);
      vscode.window.setStatusBarMessage("$(check) Delete command copied — run it yourself", 4000);
      respond({ command: "envDeleteScript", id: msg.id, script });
      break;
    }
    case "envCreate": {
      const input = msg.input || {};
      const r = await vscode.window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: `Creating ${input.manager} environment “${input.name}”…`, cancellable: false },
        () => pyenvCreate(input),
      );
      if (r.ok) {
        respond({ command: "envList", data: envListForUi() });
        respond({ command: "envCreated", ok: true });
        _treeProvider?.refresh();
        void sweepEnvSizes(respond);
        vscode.window.setStatusBarMessage("$(check) Environment created", 3000);
      } else {
        respond({ command: "envCreated", ok: false, error: r.error, log: r.log });
      }
      break;
    }
    case "envCreatePickDir": {
      const picked = await vscode.window.showOpenDialog({
        canSelectFolders: true, canSelectFiles: false, canSelectMany: false,
        openLabel: "Select parent folder for the new environment",
      });
      respond({ command: "envCreatePickDir", dir: picked && picked.length ? picked[0].fsPath : "" });
      break;
    }
    case "envActivate": {
      const { lines, display, error } = pyenvActivateCommands(String(msg.id || ""));
      if (error || !lines.length) { respond({ command: "envActivate", id: msg.id, error: error || "no activation command" }); break; }
      const env = pyenvList().find(e => e.id === msg.id);
      const term = vscode.window.createTerminal(`env: ${env?.name || msg.id}`);
      term.show();
      for (const line of lines) term.sendText(line, true); // per-line: works in PowerShell 5.1 and bash
      respond({ command: "envActivate", id: msg.id, script: display, termName: `env: ${env?.name || msg.id}` });
      break;
    }

    case "saveSkill": {
      const { name, content, category, description, tags } = msg;
      const priority = String(msg.priority || "normal") as SkillPriority;
      if (!["normal", "high", "highest"].includes(priority)) throw new Error("Skill priority must be normal, high, or highest.");
      skillUpsert({ name, content, category, description, tags, priority });
      advancePanelEditBaseline("skill", name, respond);
      gitCommit(`save(skill): ${name}`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Skill saved", 3000);
      break;
    }

    case "skillSetPriority": {
      const name = String(msg.name || "");
      const priority = String(msg.priority || "normal") as SkillPriority;
      if (!["normal", "high", "highest"].includes(priority)) throw new Error("Skill priority must be normal, high, or highest.");
      const skill = skillGet(name);
      if (!skill) throw new Error(`Skill not found: ${name}`);
      skillUpsert({ ...skill, name, priority, tags: JSON.parse(skill.tags || "[]") });
      gitCommit(`priority(skill): ${name} ${priority}`);
      scheduleRetrievalRefresh(context);
      const updated = skillGet(name);
      if (!updated) throw new Error(`Failed to reload Skill after setting priority: ${name}`);
      respond({ command: "detail", data: { type: "skill", ...updated, isPrivate: isContentItemPrivate("skills", updated) } });
      vscode.window.setStatusBarMessage(`$(settings) ${name} priority: ${priority}`, 3000);
      break;
    }

    case "skillRenameFolder": {
      const n = skillMoveCategory(String(msg.oldPrefix || ""), String(msg.newPrefix || ""));
      if (n) {
        knowledgeGroupFolderRenamed("skills", String(msg.oldPrefix || ""), String(msg.newPrefix || ""));
        gitCommit(`rename(skill-folder): ${msg.oldPrefix} -> ${msg.newPrefix} (${n})`);
      }
      _treeProvider?.refresh();
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Renamed folder (${n} skill${n === 1 ? "" : "s"})`, 3000);
      break;
    }

    case "skillMove": {
      if (skillMove(String(msg.name || ""), String(msg.category || ""))) {
        gitCommit(`move(skill): ${msg.name} -> ${msg.category || "(root)"}`);
        _treeProvider?.refresh();
      }
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Skill moved", 3000);
      break;
    }

    case "noteMove": {
      if (noteMove(String(msg.slug || ""), String(msg.category || ""))) {
        gitCommit(`move(note): ${msg.slug} -> ${msg.category || "(root)"}`);
        _treeProvider?.refresh();
      }
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Note moved", 3000);
      break;
    }

    case "noteMoveFolder": {
      const n = noteMoveFolder(String(msg.oldPrefix || ""), String(msg.newPrefix || ""));
      if (n) {
        knowledgeGroupFolderRenamed("notes", String(msg.oldPrefix || ""), String(msg.newPrefix || ""));
        gitCommit(`move(note-folder): ${msg.oldPrefix} -> ${msg.newPrefix} (${n})`);
      }
      _treeProvider?.refresh();
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Moved folder (${n} note${n === 1 ? "" : "s"})`, 3000);
      break;
    }

    case "noteSetPinned": {
      if (noteSetPinned(String(msg.slug || ""), !!msg.pinned)) {
        gitCommit(`${msg.pinned ? "pin" : "unpin"}(note): ${msg.slug}`);
        _treeProvider?.refresh();
      }
      respond({ command: "saved" });
      break;
    }

    case "skillSetPinned": {
      const name = String(msg.name || "");
      if (skillSetPinned(name, !!msg.pinned)) {
        gitCommit(`${msg.pinned ? "pin" : "unpin"}(skill): ${name}`);
        _treeProvider?.refresh();
      }
      respond({ command: "saved" });
      break;
    }

    case "noteFolderPins": {
      respond({ command: "noteFolderPins", data: noteFolderPins() });
      break;
    }

    case "noteSetFolderPinned": {
      if (noteSetFolderPinned(String(msg.prefix || ""), !!msg.pinned)) {
        gitCommit(`${msg.pinned ? "pin" : "unpin"}(note-folder): ${msg.prefix}`);
        _treeProvider?.refresh();
      }
      respond({ command: "noteFolderPins", data: noteFolderPins() });
      break;
    }

    case "savePaper": {
      const p = msg.paper || {};
      const slug = p.slug || uniquePaperSlug(p.title || "paper", p.category || "");
      paperUpsert({
        slug, title: p.title || slug, content: p.content ?? "",
        authors: p.authors ?? [], year: p.year ?? null, topic: p.topic ?? "",
        publisher: p.publisher ?? "", tags: p.tags ?? [], url: p.url ?? "",
        file: p.file ?? "", conclusions: p.conclusions ?? [], implementation: p.implementation ?? [],
        assumptions: p.assumptions ?? [], cites: p.cites ?? [],
        category: p.category ?? "", kind: p.kind ?? "paper", group: p.group ?? "Papers", pinned: !!p.pinned,
      });
      advancePanelEditBaseline("paper", slug, respond);
      gitCommit(p.slug ? `update(paper): ${slug}` : `add(paper): ${slug}`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Paper saved", 3000);
      break;
    }

    case "paperPicker": {
      respond({ command: "paperPicker", data: (paperList() as any[]).map(p => ({ slug: p.slug, title: p.title })) });
      break;
    }

    case "paperGroups": {
      respond({ command: "paperGroups", data: paperGroups() });
      break;
    }

    case "paperSetGroup": {
      if (paperSetGroup(String(msg.slug || ""), String(msg.group || "Papers"))) {
        gitCommit(`group(paper): ${msg.slug} -> ${msg.group}`);
      }
      respond({ command: "saved" });
      break;
    }

    case "paperSetGroupMany": {
      const slugs: string[] = Array.isArray(msg.slugs) ? msg.slugs : [];
      const group = String(msg.group || "Papers");
      let n = 0;
      for (const s of slugs) if (paperSetGroup(String(s), group)) n++;
      if (n) gitCommit(`group(paper x${n}): -> ${group}`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Moved ${n} to “${group}”`, 3000);
      break;
    }

    case "paperSetPinned": {
      if (paperSetPinned(String(msg.slug || ""), !!msg.pinned)) {
        gitCommit(`${msg.pinned ? "pin" : "unpin"}(paper): ${msg.slug}`);
      }
      respond({ command: "saved" });
      break;
    }

    case "paperSetTopic": {
      if (paperSetTopic(String(msg.slug || ""), String(msg.topic || ""))) {
        gitCommit(`topic(paper): ${msg.slug} -> ${msg.topic || "(none)"}`);
      }
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Topic updated", 3000);
      break;
    }

    case "openStoreFolder": {
      const area = String(msg.area || "");
      if (!["scripts", "packages", "notes", "skills", "papers", "prompts"].includes(area)) break;
      const root = path.join(getStorePath(), area);
      const full = path.join(root, String(msg.rel || ""));
      if (!path.resolve(full).startsWith(path.resolve(root))) break;
      if (!fs.existsSync(full)) { vscode.window.showWarningMessage(`Folder not found: ${msg.rel}`); break; }
      await vscode.commands.executeCommand("vscode.openFolder", vscode.Uri.file(full), { forceNewWindow: true });
      break;
    }
    case "openStoreFile": {
      const area = String(msg.area || "");
      if (!["scripts", "packages", "notes", "skills", "papers", "prompts"].includes(area)) break;
      const root = path.join(getStorePath(), area);
      const full = path.join(root, String(msg.rel || ""));
      if (!path.resolve(full).startsWith(path.resolve(root))) break;
      if (!fs.existsSync(full)) { vscode.window.showWarningMessage(`File not found: ${msg.rel}`); break; }
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(full));
      await vscode.window.showTextDocument(doc, { preview: false });
      break;
    }

    case "openKnowledgeContent": {
      const area = String(msg.area || "") as KnowledgeMarkdownArea;
      if (area !== "skills" && area !== "notes" && area !== "papers") break;
      await openStoreMarkdown(area, String(msg.key || ""));
      break;
    }

    case "editKnowledgeMetadata": {
      const area = String(msg.area || "") as KnowledgeMarkdownArea;
      if (area !== "skills" && area !== "notes" && area !== "papers") break;
      await editMarkdownMetadata(knowledgeContentUri(area, String(msg.key || "")));
      break;
    }

    case "updateKnowledgeMetadataField": {
      const area = String(msg.area || "") as KnowledgeMarkdownArea;
      const key = String(msg.key || "");
      const field = String(msg.field || "");
      const value = String(msg.value ?? "").trim();
      const rejectMetadataUpdate = (error: string): void => {
        vscode.window.showWarningMessage(error);
        respond({ command: "metadataUpdateResult", data: { ok: false, error } });
      };
      if (!(["skills", "notes", "papers"] as string[]).includes(area)
          || !["title", "tags", "description", "source_project"].includes(field)
          || (field === "source_project" && area !== "skills")) break;
      if (field === "title" && (!value || /[\\/]/.test(value))) {
        rejectMetadataUpdate("Title is required and cannot contain slashes.");
        break;
      }
      const tags = value.split(",").map(tag => tag.trim()).filter(Boolean);
      let refreshed: any;
      let newKey = key;
      if (area === "skills") {
        const listed = (skillList() as any[]).find(item => (item.category ? `${item.category}/${item.name}` : item.name) === key);
        const current = listed && skillGet(listed.name);
        if (!current) { rejectMetadataUpdate(`Skill not found: ${key}`); break; }
        const name = field === "title" ? value : current.name;
        const safeName = storeSafeName(name);
        const destinationKey = current.category ? `${current.category}/${safeName}` : safeName;
        const destinationExists = destinationKey !== key && fs.existsSync(path.join(getStorePath(), "skills", `${destinationKey}.md`));
        if ((name !== current.name && skillGet(name)) || destinationExists) { rejectMetadataUpdate(`A skill file already exists at "${destinationKey}.md". No files were changed.`); break; }
        skillUpsert({
          name, previousName: current.name, content: current.content, category: current.category,
          description: field === "description" ? value : current.description,
          tags: field === "tags" ? tags : JSON.parse(current.tags || "[]"),
          source_project: field === "source_project" ? value : current.source_project,
        });
        newKey = destinationKey;
        refreshed = { type: "skill", ...skillGet(name) };
      } else if (area === "notes") {
        const current = noteGet(key);
        if (!current) { rejectMetadataUpdate(`Note not found: ${key}`); break; }
        const title = field === "title" ? value : current.title;
        const safeTitle = storeSafeName(title);
        newKey = current.category ? `${current.category}/${safeTitle}` : safeTitle;
        if (newKey !== current.slug && noteGet(newKey)) { rejectMetadataUpdate(`A note already exists at "${newKey}.md". No files were changed.`); break; }
        noteUpsert({
          slug: current.slug, title, content: current.content, type: current.type,
          tags: field === "tags" ? tags : JSON.parse(current.tags || "[]"),
          category: current.category, pinned: current.pinned,
          description: field === "description" ? value : current.description,
        });
        const updated = noteGet(newKey);
        refreshed = updated && { ...updated, note_type: updated.type, type: "note" };
      } else {
        const current = paperGet(key);
        if (!current) { rejectMetadataUpdate(`Paper or idea not found: ${key}`); break; }
        const title = field === "title" ? value : current.title;
        const safeTitle = storeSafeName(title);
        newKey = current.category ? `${current.category}/${safeTitle}` : safeTitle;
        if (newKey !== current.slug && paperGet(newKey)) { rejectMetadataUpdate(`A paper or idea already exists at "${newKey}.md". No files were changed.`); break; }
        paperUpsert({
          ...current, slug: current.slug, title,
          tags: field === "tags" ? tags : current.tags,
          description: field === "description" ? value : current.description,
        });
        refreshed = { type: "paper", ...paperGet(newKey) };
      }
      if (!refreshed) break;
      gitCommit(`metadata(${area}): ${key} ${field}`);
      _treeProvider?.refresh();
      respond({ command: "detail", data: refreshed });
      respond({ command: "metadataUpdateResult", data: { ok: true, field, key: newKey } });
      vscode.window.setStatusBarMessage(`$(check) ${field === "source_project" ? "Source" : field} updated`, 3000);
      break;
    }

    case "packageDelete": {
      const name = String(msg.name || "").trim();
      if (!name) break;
      const dir = path.join(getStorePath(), "packages", name);
      if (!fs.existsSync(dir)) { vscode.window.showWarningMessage(`Package not found: ${name}`); break; }
      // Second confirmation (native modal) — first one happens in the webview.
      const CONFIRM = "Delete Package";
      const pick = await vscode.window.showWarningMessage(
        `Permanently delete package "${name}"? This removes the entire folder and cannot be undone.`,
        { modal: true, detail: dir },
        CONFIRM
      );
      if (pick !== CONFIRM) { respond({ command: "saved" }); break; }
      if (packageDelete(name)) {
        gitCommit(`delete(package): ${name}`);
        _treeProvider?.refresh();
        vscode.window.setStatusBarMessage("$(check) Package deleted", 3000);
        respond({ command: "list", tab: "packages", data: packagesWithGit() });
      } else {
        vscode.window.showErrorMessage(`Failed to delete package: ${name}`);
        respond({ command: "saved" });
      }
      break;
    }

    case "scriptMove": {
      if (scriptMove(String(msg.relPath || ""), String(msg.category || ""))) {
        gitCommit(`move(script): ${msg.relPath} -> ${msg.category || "(root)"}`);
        _treeProvider?.refresh();
      }
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage("$(check) Script moved", 3000);
      break;
    }

    case "scriptMoveFolder": {
      const n = scriptMoveFolder(String(msg.oldPrefix || ""), String(msg.newPrefix || ""));
      if (n) gitCommit(`move(script-folder): ${msg.oldPrefix} -> ${msg.newPrefix} (${n})`);
      _treeProvider?.refresh();
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Moved folder (${n} script${n === 1 ? "" : "s"})`, 3000);
      break;
    }

    case "createScript": {
      const rel = await createScriptAtFolder(String(msg.folder || ""));
      if (rel) respond({ command: "saved" });
      break;
    }

    case "deleteScript": {
      const relPath = String(msg.relPath || "");
      const entry = knowledgeMoveToTrash("scripts", relPath, "item", path.basename(relPath));
      if (entry) gitCommit(`trash(script): ${entry.originalPath}`);
      respond({ command: "knowledgeTrashResult", data: entry ? { ok: true, action: "moved", area: "scripts", path: entry.originalPath } : { ok: false, area: "scripts", error: "Script was not found." } });
      break;
    }

    case "paperGroupRename": {
      const n = paperGroupRename(String(msg.oldName || ""), String(msg.newName || ""));
      if (n) gitCommit(`group(rename): ${msg.oldName} -> ${msg.newName} (${n})`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Renamed group (${n} item${n === 1 ? "" : "s"})`, 3000);
      break;
    }

    case "paperGroupDelete": {
      const n = paperGroupDelete(String(msg.name || ""));
      if (n) gitCommit(`group(delete): ${msg.name} -> Papers (${n})`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Deleted group (${n} item${n === 1 ? "" : "s"} moved to Papers)`, 3000);
      break;
    }

    case "deletePaper": {
      const { slug } = msg;
      const paper = paperGet(String(slug || ""));
      const entry = knowledgeMoveToTrash("papers", `${slug}.md`, "item", paper?.title || path.basename(String(slug || "")));
      if (entry) gitCommit(`trash(paper): ${entry.originalPath}`);
      respond({ command: "knowledgeTrashResult", data: entry ? { ok: true, action: "moved", area: "papers", path: entry.originalPath } : { ok: false, area: "papers", error: "Paper was not found." } });
      break;
    }

    case "deleteAllPapers": {
      const result = paperMoveAllToTrash();
      if (result.ok && result.moved) gitCommit(`trash(papers): all (${result.moved})`);
      respond({
        command: "knowledgeTrashResult",
        data: result.ok
          ? { ok: true, action: "moved-all", area: "papers", count: result.moved }
          : { ok: false, area: "papers", error: result.error || "Could not move all Papers to Trash." },
      });
      if (result.ok) {
        vscode.window.setStatusBarMessage(`$(check) Moved ${result.moved} Paper${result.moved === 1 ? "" : "s"} to Trash`, 4000);
      }
      break;
    }

    case "paperFacets": {
      respond({ command: "paperFacets", data: paperFacets() });
      break;
    }

    case "paperGraph": {
      respond({ command: "paperGraph", data: paperGraph(msg.opts || {}) });
      break;
    }

    case "savePaperFile": {
      const { data, ext, reqId } = msg;
      try {
        const existing = paperGet(String(msg.slug || ""));
        if (!existing) throw new Error("Save the Paper or Idea before attaching a file.");
        const rel = savePaperFile(String(data || ""), String(ext || "pdf"), existing.category, String(existing.slug).split("/").pop());
        respond({ command: "paperFileSaved", reqId, file: rel });
      } catch (e) {
        log.error(`savePaperFile failed: ${String(e)}`);
        respond({ command: "paperFileSaved", reqId, error: String(e) });
      }
      break;
    }

    case "openPaperLink": {
      // Open a paper's remote URL or its local file in the OS default app.
      const url = String(msg.url || "").trim();
      const file = String(msg.file || "").trim();
      const category = String(msg.category || "").trim();
      try {
        if (url) {
          await vscode.env.openExternal(vscode.Uri.parse(url));
        } else if (file) {
          const segs = category.split("/").map(s => s.trim()).filter(Boolean);
          const full = path.join(getStorePath(), "papers", ...segs, file);
          await vscode.env.openExternal(vscode.Uri.file(full));
        }
      } catch (e) {
        vscode.window.showErrorMessage(`Couldn't open paper: ${String(e)}`);
      }
      break;
    }

    case "export": {
      const rows = skillList() as any[];
      const bundle = {
        from: process.env.USER ?? "user",
        created_at: new Date().toISOString(),
        skills: rows.map(r => ({
          name: r.name, content: skillGet(r.name)?.content ?? "",
          metadata: { description: r.description, category: r.category,
                      tags: JSON.parse(r.tags ?? "[]"), source_project: r.source_project }
        }))
      };
      respond({ command: "exported", data: attachMarkdownAssetsToSyncBundle(bundle) });
      break;
    }

    case "startSync": {
      const { selected, contentTypes, expiresMinutes, port } = msg;
      const sel = selected ?? { skills: [], notes: [], prompts: [], scripts: [], packages: [] };
      try {
        if (!_storeReady || !directoryExists(getStorePath())) throw new Error("Machine-local Knowledge Root is not ready. Configure it before starting Sync.");
        await syncServer.ensureStarted(port ?? 19878);
        const session = syncServer.createSession(sel, contentTypes ?? ["skills"], expiresMinutes ?? 30);
        respond({ command: "syncStarted", data: {
          id: session.id, magicCode: createSyncMagicCode(session), expires: session.expires.toISOString(),
          contentTypes: session.contentTypes, selected: session.selected,
          summary: syncSummary(session),
        }});
      } catch (e: any) {
        respond({ command: "syncError", data: { error: e.message } });
      }
      break;
    }

    case "getSyncSessions": {
      const sessions = syncServer.allSessions().map(s => ({
        id: s.id,
        expires: s.expires.toISOString(), enabled: s.enabled,
        skillCount: s.selected.skills.length || "all",
        summary: syncSummary(s),
        created: s.created.toISOString(),
      }));
      respond({ command: "syncSessions", data: { sessions } });
      break;
    }

    case "revokeSync": {
      syncServer.revokeSession(msg.id);
      const sessions = syncServer.allSessions().map(s => ({
        id: s.id,
        expires: s.expires.toISOString(), enabled: s.enabled,
        skillCount: s.selected.skills.length || "all",
        summary: syncSummary(s),
        created: s.created.toISOString(),
      }));
      respond({ command: "syncSessions", data: { sessions } });
      vscode.window.setStatusBarMessage("$(circle-slash) Magic Code revoked", 3000);
      break;
    }

    case "joinSync": {
      const mode = msg.mode === "group" ? "group" : "overwrite";
      try {
        if (!_storeReady || !directoryExists(getStorePath())) throw new Error("Machine-local Knowledge Root is not ready. Configure it before downloading Sync content.");
        const targetRoot = path.resolve(getStorePath());
        const confirmed = await vscode.window.showWarningMessage(
          "Download synchronized knowledge into this machine-local root?",
          { modal: true, detail: `${extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "")}\n\n${targetRoot}\n\nMode: ${mode === "group" ? "New incoming subgroup" : "Merge / overwrite matching content"}` },
          "Download Here",
        );
        if (confirmed !== "Download Here") throw new Error("Sync download cancelled before writing any files.");
        respond({ command: "syncProgress", data: { stage: "connecting", message: "Connecting to Sync host…" } });
        const { syncUrl, username, password } = parseSyncMagicCode(msg.magicCode);
        const response = await fetch(`${syncUrl}/sync/bundle`, {
          headers: { "Authorization": "Basic " + Buffer.from(`${username}:${password}`).toString("base64") },
          signal: AbortSignal.timeout(15_000),
        });
        if (!response.ok) {
          respond({ command: "syncError", data: { error: `Server returned ${response.status}: ${await response.text()}` } });
          return;
        }
        const totalBytes = Number(response.headers.get("content-length")) || 0;
        const chunks: Buffer[] = [];
        let downloadedBytes = 0;
        if (response.body) {
          const reader = response.body.getReader();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = Buffer.from(value);
            chunks.push(chunk);
            downloadedBytes += chunk.length;
            respond({ command: "syncProgress", data: { stage: "downloading", current: downloadedBytes, total: totalBytes, percent: totalBytes ? Math.min(100, Math.round(downloadedBytes * 100 / totalBytes)) : undefined, message: "Downloading knowledge bundle…" } });
          }
        } else chunks.push(Buffer.from(await response.text(), "utf8"));
        const bundle = JSON.parse(Buffer.concat(chunks).toString("utf8")) as any;
        const from = bundle?.from ?? "remote";
        // "group" mode isolates everything under <type>/_incoming/<label>/… so
        // nothing overwrites existing items; the user merges offline afterwards.
        const seg = (s: string) => String(s || "").trim().replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
        const stamp = () => { const d = new Date(), p = (n: number) => String(n).padStart(2, "0"); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`; };
        const label = mode === "group" ? (seg(msg.groupLabel) || `${seg(from)}-${stamp()}`) : "";
        const prefix = label ? `_incoming/${label}` : "";
        const pcat = (c?: string) => prefix ? (c ? `${prefix}/${c}` : prefix) : (c || "");
        const importedDocuments = markdownBundleDocuments(bundle);
        if (prefix) {
          for (const document of importedDocuments) {
            const destination = checkedMarkdownPath(path.join(getStorePath(), document.area), `${prefix}/${document.path}`);
            if (fs.existsSync(destination)) throw new Error(`Incoming document already exists: ${document.path}. Choose a new subgroup.`);
          }
          for (const skill of bundle.skills || []) {
            if (skillGet(skill.name)) throw new Error(`Skill name "${skill.name}" already exists. Group import cannot silently move or overwrite it; use distinct Skill names.`);
          }
        }
        importMarkdownAssetBundle(getStorePath(), bundle.assets, importedDocuments, prefix);
        const counts: Record<string, number> = {};
        const totalItems = ["skills", "notes", "papers", "prompts", "scripts", "packages", "recipes"]
          .reduce((count, type) => count + (Array.isArray(bundle?.[type]) ? bundle[type].length : 0), 0);
        let importedItems = 0;
        const reportImported = async (type: string): Promise<void> => {
          importedItems += 1;
          respond({ command: "syncProgress", data: { stage: "importing", current: importedItems, total: totalItems, percent: totalItems ? Math.round(importedItems * 100 / totalItems) : 100, type, message: `Importing ${type}…` } });
          if (importedItems % 20 === 0) await new Promise<void>(resolve => setImmediate(resolve));
        };
        respond({ command: "syncProgress", data: { stage: "importing", current: 0, total: totalItems, percent: 0, message: "Preparing imported content…" } });
        for (const s of bundle?.skills ?? []) {
          const m = s.metadata ?? {};
          skillUpsert({ name: s.name, content: s.content,
            description: m.description, category: pcat(m.category),
            tags: m.tags, source_project: m.source_project });
          counts.skills = (counts.skills ?? 0) + 1;
          await reportImported("skills");
        }
        if (bundle?.notes?.length) {
          const notes = prefix ? bundle.notes.map((n: any) => ({ ...n, slug: `${prefix}/${n.slug}`, category: pcat(n.category) })) : bundle.notes;
          for (const note of notes) {
            noteUpsert({ ...note, type: note.type || "general", tags: Array.isArray(note.tags) ? note.tags : JSON.parse(note.tags || "[]") });
            counts.notes = (counts.notes ?? 0) + 1;
            await reportImported("notes");
          }
        }
        const importedSlugs = new Set((bundle?.papers ?? []).map((p: any) => p.slug));
        const remap = (s: string) => (prefix && importedSlugs.has(s)) ? `${prefix}/${s}` : s;
        for (const p of bundle?.papers ?? []) {
          paperUpsert({
            slug: prefix ? `${prefix}/${p.slug}` : p.slug, title: p.title, content: p.content ?? "",
            authors: p.authors, year: p.year, topic: p.topic, publisher: p.publisher,
            tags: p.tags, url: p.url, file: p.file, conclusions: p.conclusions,
            implementation: p.implementation, assumptions: p.assumptions, cites: [],
            category: pcat(p.category), group: prefix ? label : p.group,
          });
          counts.papers = (counts.papers ?? 0) + 1;
          await reportImported("papers");
        }
        for (const p of bundle?.papers ?? []) {
          const slug = prefix ? `${prefix}/${p.slug}` : p.slug;
          const current = paperGet(slug);
          if (!current) continue;
          const cites = Array.isArray(p.cites) ? p.cites.map((cite: any) => {
            if (typeof cite === "string") return { paper: remap(cite), note: "" };
            return cite?.paper ? { paper: remap(cite.paper), note: cite.note || "" } : cite;
          }) : [];
          paperUpsert({ ...current, cites });
        }
        if (bundle?.prompts?.length) {
          const prompts = prefix ? bundle.prompts.map((x: any) => ({ ...x, project: `${prefix}/${x.project}` })) : bundle.prompts;
          for (const prompt of prompts) {
            counts.prompts = (counts.prompts ?? 0) + promptImport([prompt]);
            await reportImported("prompts");
          }
        }
        if (bundle?.scripts?.length) {
          const scripts = prefix ? bundle.scripts.map((x: any) => ({ ...x, category: pcat(x.category), identity: undefined })) : bundle.scripts;
          for (const script of scripts) {
            counts.scripts = (counts.scripts ?? 0) + scriptImport([script]);
            await reportImported("scripts");
          }
        }
        if (bundle?.packages?.length) {
          const pkgs = prefix ? bundle.packages.map((x: any) => ({ ...x, name: `${prefix}/${x.name}` })) : bundle.packages;
          for (const pkg of pkgs) {
            counts.packages = (counts.packages ?? 0) + packageImport([pkg]);
            await reportImported("packages");
          }
        }
        for (const recipe of bundle?.recipes ?? []) {
          const store = currentProjectStore();
          const result = store.importRecipe(projectCommand(store, "recipe-direct-sync", {
            sourceRecipeId: recipe?.recipeId, from, group: label || "overwrite",
          }), recipe as RecipeRecord, {
            kind: "direct-sync", sourceKey: `${from}/${label || "overwrite"}`,
            preserveIdentity: !prefix, categoryPrefix: prefix,
          });
          counts.recipes = (counts.recipes ?? 0) + (result.replayed ? 0 : 1);
          await reportImported("recipes");
        }
        const total   = Object.values(counts).reduce((a, b) => a + b, 0);
        const summary = Object.entries(counts).map(([k, v]) => `${v} ${k}`).join(", ");
        gitCommit(`sync: ${summary} from ${from}${label ? ` (group ${label})` : ""}`);
        respond({ command: "syncJoined", data: { count: total, summary, from, group: label || undefined, targetRoot } });
        respond({ command: "saved" });
        vscode.window.setStatusBarMessage(`$(cloud-download) Synced: ${summary}${label ? " → " + label : ""}`, 5000);
      } catch (e: any) {
        respond({ command: "syncError", data: { error: e.message } });
      }
      break;
    }

    case "verifySyncMagicCode": {
      try {
        parseSyncMagicCode(msg.magicCode);
        respond({ command: "syncMagicCodeVerified", data: { requestId: msg.requestId, ok: true } });
      } catch (error: any) {
        respond({ command: "syncMagicCodeVerified", data: { requestId: msg.requestId, ok: false, error: error?.message || "Magic Code is invalid." } });
      }
      break;
    }

    case "getSyncSkillList": {
      const rows = skillList() as any[];
      respond({ command: "syncSkillList", data: { skills: rows.map((r: any) => ({ name: r.name, category: r.category })) } });
      break;
    }

    case "getSyncContentList": {
      const skills   = (skillList() as any[]).map((r: any) => ({ id: r.name,  label: r.name,  cat: r.category ?? "", meta: "" }));
      const notes    = (noteList(undefined, 200) as any[]).map((r: any) => ({ id: r.slug,  label: r.title, cat: r.category ?? "", meta: r.type }));
      const papers   = (paperList() as any[]).map((p: any) => ({ id: p.slug, label: p.title, cat: p.category ?? p.topic ?? "", meta: p.year ? String(p.year) : "" }));
      const prompts  = promptList().flatMap(t => ({ id: `${t.project}/${t.task}`, label: t.task, cat: t.project, meta: "" }));
      const scripts  = (scriptList() as any[]).map((s: any) => ({ id: s.path, label: s.file, cat: s.category ?? "", meta: s.lang }));
      const packages = packageList().map((p: any) => ({ id: p.name, label: p.name, cat: "", meta: p.lang }));
      const recipes  = currentProjectStore().list().recipes.filter(recipe => !isContentItemPrivate("recipes", recipe)).map(recipe => ({ id: recipe.recipeId, label: recipe.name, cat: recipe.category ?? "", meta: recipe.scope === "project" ? "Project Recipe" : "Global Recipe" }));
      respond({ command: "syncContentList", data: { skills, notes, papers, prompts, scripts, packages, recipes } });
      break;
    }

    case "deleteNote": {
      const { slug } = msg;
      const note = noteGet(String(slug || ""));
      const entry = knowledgeMoveToTrash("notes", `${slug}.md`, "item", note?.title || path.basename(String(slug || "")));
      if (entry) gitCommit(`trash(note): ${entry.originalPath}`);
      respond({ command: "knowledgeTrashResult", data: entry ? { ok: true, action: "moved", area: "notes", path: entry.originalPath, entry } : { ok: false, area: "notes", error: "Note was not found." } });
      break;
    }

    case "deleteSkill": {
      const { name } = msg;
      const trashed = skillMoveToTrash(String(name || ""));
      if (trashed) gitCommit(`trash(skill): ${trashed.originalPath}`);
      respond({ command: "skillTrashResult", data: trashed ? { ok: true, action: "moved", path: trashed.originalPath } : { ok: false, error: "Skill was not found." } });
      break;
    }

    case "skillTrashFolder": {
      const trashed = skillFolderMoveToTrash(String(msg.path || ""));
      if (trashed) gitCommit(`trash(skill-folder): ${trashed.originalPath}`);
      respond({ command: "skillTrashResult", data: trashed ? { ok: true, action: "moved", path: trashed.originalPath } : { ok: false, error: "Skill folder was not found." } });
      break;
    }

    case "skillTrashRestore": {
      const result = skillTrashRestore(String(msg.id || ""));
      if (!result.ok) { respond({ command: "skillTrashResult", data: result }); break; }
      gitCommit(`restore(skill-trash): ${result.path}`);
      respond({ command: "skillTrashResult", data: { ok: true, action: "restored", path: result.path } });
      break;
    }

    case "skillTrashEmpty": {
      const count = skillTrashEmpty();
      if (count) gitCommit(`empty(skill-trash): ${count} entries`);
      respond({ command: "skillTrashResult", data: { ok: true, action: "emptied", count } });
      break;
    }

    case "skillTrashDelete": {
      const result = skillTrashDelete(String(msg.id || ""));
      if (result.ok) gitCommit(`delete(skill-trash): ${result.name}`);
      respond({ command: "skillTrashResult", data: result.ok ? { ok: true, action: "deleted", path: result.name } : result });
      break;
    }

    case "knowledgeTrashMove": {
      const area = String(msg.area || "") as KnowledgeTrashArea;
      if (!("notes papers prompts scripts".split(" ") as string[]).includes(area)) throw new Error("Unsupported Trash area.");
      const entry = knowledgeMoveToTrash(area, String(msg.path || ""), msg.kind === "folder" ? "folder" : "item", String(msg.name || ""));
      if (entry) gitCommit(`trash(${area}): ${entry.originalPath}`);
      respond({ command: "knowledgeTrashResult", data: entry ? { ok: true, action: "moved", area, path: entry.originalPath, entry } : { ok: false, area, error: `${area} item was not found.` } });
      break;
    }

    case "knowledgeTrashRestore": {
      const area = String(msg.area || "") as KnowledgeTrashArea;
      if (!("notes papers prompts scripts".split(" ") as string[]).includes(area)) throw new Error("Unsupported Trash area.");
      const result = knowledgeTrashRestore(area, String(msg.id || ""));
      if (result.ok) gitCommit(`restore(${area}-trash): ${result.path}`);
      respond({ command: "knowledgeTrashResult", data: { ...result, action: "restored", area } });
      break;
    }

    case "knowledgeTrashDelete": {
      const area = String(msg.area || "") as KnowledgeTrashArea;
      if (!("notes papers prompts scripts".split(" ") as string[]).includes(area)) throw new Error("Unsupported Trash area.");
      const result = knowledgeTrashDelete(area, String(msg.id || ""));
      if (result.ok) gitCommit(`delete(${area}-trash): ${result.path}`);
      respond({ command: "knowledgeTrashResult", data: { ...result, action: "deleted", area } });
      break;
    }

    case "knowledgeTrashEmpty": {
      const area = String(msg.area || "") as KnowledgeTrashArea;
      if (!("notes papers prompts scripts".split(" ") as string[]).includes(area)) throw new Error("Unsupported Trash area.");
      const result = knowledgeTrashEmpty(area);
      if (result.ok && result.count) gitCommit(`empty(${area}-trash): ${result.count} entries`);
      respond({ command: "knowledgeTrashResult", data: { ...result, action: "emptied", area } });
      break;
    }

    case "markDone": {
      const { slug } = msg;
      const row = noteGet(slug);
      if (row) {
        const newContent = row.content + `\n\n---\n✓ Done (${new Date().toISOString().slice(0, 10)})`;
        const tags = JSON.parse(row.tags ?? "[]");
        noteUpsert({ slug: row.slug, title: row.title, content: newContent, type: "done", tags, category: row.category });
        gitCommit(`done(note): ${slug}`);
        vscode.window.setStatusBarMessage("$(check) Marked as done", 3000);
      }
      respond({ command: "saved" });
      break;
    }

    case "import": {
      const { bundle } = msg;
      importMarkdownAssetBundle(getStorePath(), bundle?.assets, markdownBundleDocuments(bundle || {}));
      let count = 0;
      for (const s of bundle?.skills ?? []) {
        const m = s.metadata ?? {};
        skillUpsert({ name: s.name, content: s.content,
          description: m.description, category: m.category,
          tags: m.tags, source_project: m.source_project });
        count++;
      }
      for (const note of bundle?.notes || []) {
        noteUpsert({ ...note, type: note.type || "general", tags: Array.isArray(note.tags) ? note.tags : JSON.parse(note.tags || "[]") });
        count++;
      }
      for (const paper of bundle?.papers || []) { paperUpsert(paper); count++; }
      gitCommit(`import(knowledge): ${count} from ${bundle?.from ?? "unknown"}`);
      respond({ command: "saved" });
      vscode.window.setStatusBarMessage(`$(check) Imported ${count} knowledge item(s)`, 4000);
      break;
    }

    // ── MCP ──────────────────────────────────────────────────────────────
    case "configureNativeMcpDiscovery": {
      try {
        const completed = await configurePkmMcp(context);
        respond({ command: "mcpStatus", data: mcpPanelStatusData() });
        respond({ command: "mcpActionResult", data: { action: "configureNativeMcpDiscovery", ok: completed, cancelled: !completed, message: "PKM MCP configuration saved at the selected scope. Client discovery and tool access are not yet verified." } });
      } catch (error) {
        respond({ command: "mcpActionResult", data: { action: "configureNativeMcpDiscovery", ok: false, error: error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "registerCopilotMcp": {
      try {
        const completed = await registerCopilotMcpUserConfig();
        respond({ command: "mcpStatus", data: mcpPanelStatusData() });
        respond({ command: "mcpActionResult", data: { action: "registerCopilotMcp", ok: completed, cancelled: !completed, message: "Copilot CLI user configuration matches. Verify discovery and check_version in that client's new chat." } });
      } catch (error) {
        respond({ command: "mcpActionResult", data: { action: "registerCopilotMcp", ok: false, error: error instanceof Error ? error.message : String(error) } });
      }
      break;
    }

    case "mcpStatus": {
      mcpRuntimeStatusCache = undefined;
      respond({ command: "mcpStatus", data: mcpPanelStatusData(String(msg.profileRequestId || "")) });
      break;
    }
    case "checkMcp": {
      respond({ command: "mcpStatus", data: mcpPanelStatusData(String(msg.profileRequestId || "")) });
      await maintainPkmIntegration(context);
      respond({ command: "mcpCheckComplete", data: {
        state: integrationMaintenanceState,
        error: integrationMaintenanceError,
      } });
      break;
    }

    case "refreshMcpUsage": {
      const activeStorePath = _storeReady ? getStorePath() : "";
      const startedAt = performance.now();
      try {
        const usage = activeStorePath
          ? await mcpUsageSummary(activeStorePath)
          : { sessions: [], measurementNote: "Configure a Knowledge Root to observe MCP usage." };
        respond({
          command: "mcpUsage",
          data: { ...usage, storePath: activeStorePath },
        });
      } finally {
        loadProfiler.record("host.mcp.usage", {
          traceId: String(msg.profileRequestId || ""),
          surface: "mcp",
          durationMs: Math.round(performance.now() - startedAt),
        });
      }
      break;
    }

    case "actionToolchainsConfigure": {
      await vscode.commands.executeCommand("workbench.action.openSettings", "personalKnowledge.actions.toolchains");
      respond({ command: "actionToolchainsConfigured", data: { ok: true } });
      break;
    }

    case "openActionLibrary": {
      openActionLibrary(context);
      break;
    }

    case "mcpSetFeatureDomain": {
      const domain = String(msg.domain || "") as McpFeatureDomain;
      if (!MCP_FEATURE_DOMAINS.includes(domain)) {
        vscode.window.showErrorMessage("Unknown MCP feature domain.");
        break;
      }
      const enabled = new Set(enabledMcpFeatureDomains());
      if (msg.enabled) enabled.add(domain); else enabled.delete(domain);
      await vscode.workspace.getConfiguration("personalKnowledge").update(
        "mcpEnabledFeatureDomains",
        MCP_FEATURE_DOMAINS.filter(candidate => enabled.has(candidate)),
        vscode.ConfigurationTarget.Global,
      );
      writeMcpFeatureDomainConfig(MCP_FEATURE_DOMAINS.filter(candidate => enabled.has(candidate)));
      refreshMcpDefinitions();
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      vscode.window.setStatusBarMessage(`$(settings) ${domain} Agent tools ${msg.enabled ? "enabled" : "disabled"}`, 3500);
      break;
    }

    case "skillRouterStatus": {
      respond({ command: "skillRouterStatus", data: await skillRouterStatusData(context) });
      break;
    }

    case "runSkillRouterBenchmark": {
      if (skillRouterBenchmarkRunning) break;
      skillRouterBenchmarkRunning = true;
      skillRouterBenchmarkError = "";
      respond({ command: "skillRouterStatus", data: await skillRouterStatusData(context) });
      const stateDirectory = retrievalStateDirectory(context);
      fs.mkdirSync(stateDirectory, { recursive: true });
      const temporary = path.join(stateDirectory, `router-benchmark-${randomUUID()}.json`);
      try {
        await new Promise<void>((resolve, reject) => {
          execFile(process.execPath, [path.join(context.extensionPath, "scripts", "benchmark-retrieval.js"),
            "--tiers=1000", "--repetitions=5", `--output=${temporary}`], {
            env: { ...process.env, ELECTRON_RUN_AS_NODE: "1", PKM_RETRIEVAL_TEST_PYTHON: resolveMcpPython() },
            timeout: 180_000, maxBuffer: 1024 * 1024, windowsHide: true,
          }, error => error ? reject(error) : resolve());
        });
        if (!readSkillRouterBenchmarkReport(temporary)) throw new Error("Benchmark produced no compatible 1K lexical measurements.");
        fs.renameSync(temporary, path.join(stateDirectory, "router-benchmark.json"));
      } catch (error) {
        skillRouterBenchmarkError = error instanceof Error ? error.message : String(error);
      } finally {
        fs.rmSync(temporary, { force: true });
        skillRouterBenchmarkRunning = false;
        respond({ command: "skillRouterStatus", data: await skillRouterStatusData(context) });
      }
      break;
    }

    case "setSkillRouterSolutionEnabled": {
      const solution = String(msg.solution || "") as MatureSkillRouterSolution;
      if (!MATURE_SKILL_ROUTER_SOLUTIONS.includes(solution)) throw new Error("This Skill Router solution is not available for enablement.");
      if (solution === "copilot_default" && !msg.enabled) throw new Error("Copilot default is the required automatic fallback and cannot be disabled yet.");
      const enabled = new Set(enabledSkillRouterSolutions());
      if (msg.enabled) enabled.add(solution); else enabled.delete(solution);
      enabled.add("copilot_default");
      await vscode.workspace.getConfiguration("personalKnowledge").update(
        "skillRouterEnabledSolutions",
        MATURE_SKILL_ROUTER_SOLUTIONS.filter(candidate => enabled.has(candidate)),
        vscode.ConfigurationTarget.Global,
      );
      respond({ command: "skillRouterStatus", data: await skillRouterStatusData(context) });
      break;
    }

    case "setSkillRouterSourcePriority": {
      if (!Array.isArray(msg.sourceIds) || msg.sourceIds.some((id: unknown) => typeof id !== "string")) {
        throw new Error("Router source priority must be an ordered list of source IDs.");
      }
      const sources = skillRouterSources();
      const sourcePriority = normalizeSkillRouterSourcePriority(msg.sourceIds, sources);
      await vscode.workspace.getConfiguration("personalKnowledge").update(
        "skillRouterSourcePriority",
        sourcePriority,
        vscode.ConfigurationTarget.Global,
      );
      respond({ command: "skillRouterStatus", data: await skillRouterStatusData(context) });
      vscode.window.setStatusBarMessage("$(check) Router source priority saved", 3000);
      break;
    }

    case "dismissIntegrationGuide": {
      await context.globalState.update("pkm.integrationGuideDismissed.v1", true);
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      break;
    }

    case "setExternalLinkHost": {
      await updateExternalLinkHost(String(msg.address || "").trim());
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      respond({ command: "serverList", data: await serverListForUi(context) });
      const inviteHost = chatInviteHostOptions(context);
      respond({ command: "chatConfig", data: { inviteHosts: inviteHost.options, inviteHost: inviteHost.selected, inviteHostUnavailable: inviteHost.unavailable } });
      break;
    }

    case "setContentGatewayPort": {
      const port = Number(msg.port);
      if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("Content Gateway port must be between 1024 and 65535.");
      if (publicContentServer) await new Promise<void>(resolve => publicContentServer!.close(() => resolve()));
      publicContentActivePort = 0;
      await vscode.workspace.getConfiguration("personalKnowledge").update("contentGatewayPort", port, vscode.ConfigurationTarget.Global);
      await ensurePublicContentGateway(context);
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      break;
    }

    case "refreshMcpPathSizes": {
      mcpPathSizeGeneration += 1;
      mcpPathSizeCache.clear();
      void sendMcpPathSizes(respond, mcpPathSizeGeneration);
      break;
    }

    case "pkmSkillInject":
    case "pkmSkillInjectAll":
    case "pkmSkillBrowseCustomTarget":
    case "pkmSkillEnterCustomTarget":
    case "pkmSkillRemoveCustomTarget":
      throw new Error("Legacy Agent Skill injection is retired. Use the account-level PKM MCP registration instead.");

    case "pkmSkillRemove": {
      try {
        await disconnectPkmSkill(context, String(msg.id || ""));
        log.action("pkmSkill.remove", { target: String(msg.id || "") });
        respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      } catch (error: any) {
        respond({ command: "mcpError", data: { error: error?.message || String(error) } });
      }
      break;
    }

    case "reconfigureKnowledgeRoot": {
      const result = await vscode.commands.executeCommand<{ ok?: boolean; cancelled?: boolean; message?: string; error?: string }>("personalKnowledge.reconfigureKnowledgeRoot");
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      respond({ command: "mcpActionResult", data: { action: "reconfigureKnowledgeRoot", ...(result || { cancelled: true }) } });
      break;
    }

    case "reconfigureEnvironmentsRoot": {
      const result = await vscode.commands.executeCommand<{ ok?: boolean; cancelled?: boolean; message?: string; error?: string }>("personalKnowledge.reconfigureEnvironmentsRoot");
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      respond({ command: "mcpActionResult", data: { action: "reconfigureEnvironmentsRoot", ...(result || { cancelled: true }) } });
      break;
    }

    case "reconfigureMcpRuntimePath": {
      const result = await vscode.commands.executeCommand<{ ok?: boolean; cancelled?: boolean; message?: string; error?: string }>("personalKnowledge.reconfigureMcpRuntimePath");
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      respond({ command: "mcpActionResult", data: { action: "reconfigureMcpRuntimePath", ...(result || { cancelled: true }) } });
      break;
    }

    case "reconfigureMcpServerPath": {
      const result = await vscode.commands.executeCommand<{ ok?: boolean; cancelled?: boolean; message?: string; error?: string }>("personalKnowledge.reconfigureMcpServerPath");
      respond({ command: "mcpStatus", data: mcpPanelStatusData() });
      respond({ command: "mcpActionResult", data: { action: "reconfigureMcpServerPath", ...(result || { cancelled: true }) } });
      break;
    }

    case "pkmSkillOpenProposals": {
      const directory = path.join(getStorePath(), "_proposals", "skills");
      fs.mkdirSync(directory, { recursive: true });
      await vscode.commands.executeCommand("revealFileInOS", vscode.Uri.file(directory));
      log.action("pkmSkill.proposals.open", { directory });
      break;
    }

    case "mcpDetectPython": {
      void streamMcpPythonCandidates(respond);
      break;
    }

    case "mcpCancelPythonScan": {
      cancelMcpPythonScan();
      respond({ command: "mcpPythonScanComplete", data: { cancelled: true, text: "Scan cancelled." } });
      break;
    }

    case "mcpBrowsePython": {
      const picks = await vscode.window.showOpenDialog({
        canSelectFiles: true, canSelectFolders: false, canSelectMany: false,
        openLabel: "Select Python executable", title: "Select Python 3.10+ for PKM MCP",
      });
      if (picks?.[0]) {
        const result = validateMcpPython(picks[0].fsPath);
        respond({ command: "mcpPythonResult", data: { ...result, valid: !result.error, source: "configured" } });
      } else respond({ command: "mcpPythonBrowseCancelled", data: {} });
      break;
    }

    case "mcpSetPython": {
      const result = validateMcpPython(String(msg.path || ""));
      if (result.error) {
        requireMcpPythonSetup(context, result.error);
        respond({ command: "mcpPythonResult", data: { ...result, valid: false, source: "configured", saved: false } });
        break;
      }
      const configuration = vscode.workspace.getConfiguration("personalKnowledge");
      const previousPython = configuration.get<string>("mcpPythonPath", "");
      await configuration.update("mcpPythonPath", result.path, vscode.ConfigurationTarget.Global);
      try {
        const runtime = await ensureMcpRuntime(context);
        scheduleRetrievalRefresh(context, 0);
        refreshMcpDefinitions();
        respond({ command: "mcpPythonResult", data: { ...result, valid: true, source: "configured", saved: true, runtime } });
        _treeProvider?.refresh();
        respond({ command: "envList", data: envListForUi() });
      } catch (error: any) {
        await configuration.update("mcpPythonPath", previousPython || undefined, vscode.ConfigurationTarget.Global);
        refreshMcpDefinitions();
        respond({ command: "mcpRuntimeResult", data: { ok: false, error: error?.message || String(error), commands: mcpRuntimeManualCommands(result.path) } });
      }
      break;
    }

    case "mcpRepairRuntime": {
      const base = detectMcpPython();
      if (!base.valid) {
        requireMcpPythonSetup(context, base.error);
        respond({ command: "mcpRuntimeResult", data: { ok: false, error: base.error, commands: [] } });
        break;
      }
      try {
        const runtime = await ensureMcpRuntime(context);
        scheduleRetrievalRefresh(context, 0);
        refreshMcpDefinitions();
        respond({ command: "mcpRuntimeResult", data: { ok: true, runtime } });
        _treeProvider?.refresh();
        respond({ command: "envList", data: envListForUi() });
      } catch (error: any) {
        respond({ command: "mcpRuntimeResult", data: { ok: false, error: error?.message || String(error), commands: mcpRuntimeManualCommands(base.path) } });
      }
      break;
    }

    case "generateMcp":
    case "generateChatMcp": {
      try {
        const preview = !!msg.previewOnly;
        if (!preview && !mcpRuntimeStatus().healthy) {
          await ensureMcpRuntime(context);
          scheduleRetrievalRefresh(context, 0);
        }
        if (!preview) {
          integrationMaintenanceState = "running";
          integrationMaintenanceError = "";
          setupProgress("generating-server", "Generating current MCP server code…", true);
        }
        const info = preview
          ? { serverPath: mcpStatus().serverPath, configSnippet: combinedMcpRegistry() }
          : await generateMcpServer(context);
        if (!preview) {
          refreshMcpDefinitions();
          if (!(await mcpRuntimeStatusAsync()).healthy || !mcpStatus().current) throw new Error("Generated MCP server/runtime verification failed.");
          integrationMaintenanceState = "ready";
          setupProgress("ready", "Runtime/server verified; retrieval and client discovery must be verified separately.");
        }
        respond({ command: "mcpGenerated", data: { ...info, preview } });
        if (!preview) vscode.window.setStatusBarMessage("$(check) MCP server created", 4000);
      } catch (e: any) {
        const message = e?.message || String(e);
        if (!msg.previewOnly) {
          integrationMaintenanceState = integrationFailureState(message);
          integrationMaintenanceError = message;
          setupProgress(integrationMaintenanceState, message);
        }
        respond({ command: "mcpError", data: { error: message } });
      }
      break;
    }

    case "aiSummary": {
      try {
        const result = await aiSummarizeScript(context, msg.path, msg.backend, !!msg.cacheOnly);
        respond({ command: "aiSummary", data: result });
      } catch (e: any) {
        respond({ command: "aiSummary", data: { error: e.message } });
      }
      break;
    }

    case "listAiBackends": {
      try {
        const backends = await listAiBackends(context);
        respond({ command: "aiBackends", data: { backends } });
      } catch (e: any) {
        respond({ command: "aiBackends", data: { backends: [], error: e.message } });
      }
      break;
    }

    case "saveScript": {
      const { path: relPath, content } = msg;
      const full = path.join(getStorePath(), "scripts", relPath);
      // Guard against path traversal outside the scripts folder
      const scriptsRoot = path.join(getStorePath(), "scripts");
      if (!path.resolve(full).startsWith(path.resolve(scriptsRoot) + path.sep)) {
        respond({ command: "scriptSaved", data: { error: "Invalid script path." } });
        break;
      }
      if (!fs.existsSync(full)) {
        respond({ command: "scriptSaved", data: { error: `Script not found: ${relPath}` } });
        break;
      }
      const confirm = await vscode.window.showWarningMessage(
        `Save changes to "${relPath}"? This overwrites the file and commits it to git.`,
        { modal: true },
        "Save & Commit"
      );
      if (confirm !== "Save & Commit") {
        respond({ command: "scriptSaved", data: { cancelled: true } });
        break;
      }
      try {
        checkPanelEdit(msg);
        fs.writeFileSync(full, content);
        // Content changed → all cached AI summaries for this script are stale
        fs.rmSync(scriptCacheDir(relPath), { recursive: true, force: true });
        advancePanelEditBaseline("script", relPath, respond);
        gitCommit(`edit(script): ${relPath}`);
        log.action("script.save", { path: relPath });
        vscode.window.setStatusBarMessage("$(check) Script saved & committed", 3000);
        respond({ command: "scriptSaved", data: { ok: true, path: relPath } });
      } catch (e: any) {
        respond({ command: "scriptSaved", data: { error: e.message } });
      }
      break;
    }
  }
  } catch (e: any) {
    // Ensure the webview never hangs on a loading banner due to an unhandled error
    log.error(`handleMessage(${msg.command}) failed: ${e?.stack ?? e?.message ?? e}`);
    if (msg.command === "list") {
      respond({ command: "list", tab: String(msg.tab || ""), data: [] });
    } else if (String(msg.command || "").startsWith("skillTrash") || msg.command === "deleteSkill") {
      respond({ command: "skillTrashResult", data: { ok: false, error: e?.message || String(e) } });
    } else if (String(msg.command || "").startsWith("knowledgeTrash")
      || ["deleteNote", "deletePaper", "deleteAllPapers", "deleteScript"].includes(String(msg.command || ""))) {
      const area = msg.command === "deleteNote" ? "notes"
        : msg.command === "deletePaper" || msg.command === "deleteAllPapers" ? "papers"
        : msg.command === "deleteScript" ? "scripts" : String(msg.area || "");
      respond({ command: "knowledgeTrashResult", data: { ok: false, area, error: e?.message || String(e) } });
    } else if (["projectState", "projectCreate", "projectOverview", "projectLink", "projectLifecycle", "projectCheckpoint", "projectOpenSource", "threadCreate", "threadRename", "threadMove", "threadOpenChatroom", "ganttTaskCreate", "ganttTaskUpdate", "ganttTaskDelete", "collaborationCreate", "collaborationTransition", "recipeCreate", "recipeFolderCreate", "recipeFolderDelete", "recipeUpdate", "recipeDelete", "recipeTrash", "recipeValidateDefinition", "recipeOpenBrowser", "projectRecipesExport", "agentSessionTrash", "agentSessionStop", "agentSessionGroupDelete"].includes(String(msg.command || ""))) {
      respond({ command: "projectError", data: { action: String(msg.command || ""), code: String(e?.code || "project-error"), error: e?.message || String(e), ...(e?.details ? { details: e.details } : {}) } });
    } else if (String(msg.command || "").startsWith("subscription")) {
      respond({ command: "subscriptionError", data: { action: String(msg.command || ""), error: e?.message || String(e) } });
    } else if (String(msg.command || "").startsWith("githubSync")) {
      respond({ command: "githubSyncError", data: { action: String(msg.command || ""), targetId: msg.targetId,
        repairRequestId:msg.repairRequestId, error: e?.message || String(e) } });
    }
  }
}

async function offerMcpRuntimeSetup(context: vscode.ExtensionContext): Promise<void> {
  if (context.globalState.get<boolean>("mcpRuntimeSetupOffered.v1", false) || (await mcpRuntimeStatusAsync()).healthy) return;
  await warmMcpPythonProbes();
  await context.globalState.update("mcpRuntimeSetupOffered.v1", true);
  const base = detectMcpPython();
  const openSetup = () => { const panel = getOrCreatePanel(context); panel.reveal(vscode.ViewColumn.One); if (panelSession().ready) panel.webview.postMessage({ command: "openTab", tab: "mcp" }); else panelSession().pendingTab = "mcp"; };
  if (!base.valid) {
    const choice = await vscode.window.showWarningMessage(
      "Personal Knowledge Manager is ready, but MCP requires Python 3.10+. Install Python or specify an executable in Config. PKM features remain available.",
      "Open Config", "Later");
    if (choice === "Open Config") openSetup();
    return;
  }
  const choice = await vscode.window.showInformationMessage(
    `Python ${base.version} detected at ${base.path}. Create a dedicated runtime for the unified PKM MCP server?`,
    "Create MCP Runtime", "Choose Another Python", "Later");
  if (choice === "Choose Another Python") { openSetup(); return; }
  if (choice !== "Create MCP Runtime") return;
  try {
    await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: "Creating PKM MCP Runtime", cancellable: false }, async progress => {
      progress.report({ message: "Creating environment and installing dependencies…" });
      await ensureMcpRuntime(context);
      scheduleRetrievalRefresh(context, 0);
    });
    _treeProvider?.refresh();
    vscode.window.showInformationMessage("PKM MCP Runtime is ready and registered in Envs.", "Open Config")
      .then(result => { if (result === "Open Config") openSetup(); });
  } catch (error: any) {
    vscode.window.showErrorMessage(`MCP runtime setup failed: ${error?.message || String(error)}`, "Open Config")
      .then(result => { if (result === "Open Config") openSetup(); });
  }
}

async function offerMcpRuntimeDependencyRepair(context: vscode.ExtensionContext): Promise<void> {
  const state = mcpRuntimeStatus();
  if (!state.exists || state.healthy || !/(prompt_manager|adaptive_skill_retrieval)/.test(state.error)) return;
  const offerKey = "mcpRuntimeDependencyRepairOffered.retrieval-0.3.0";
  if (context.globalState.get<boolean>(offerKey, false)) return;
  await context.globalState.update(offerKey, true);
  const choice = await vscode.window.showWarningMessage(
    "The existing PKM MCP Runtime is missing required Prompt Manager or adaptive retrieval dependencies. Repair it now?",
    "Repair Runtime", "Open Config", "Later",
  );
  const openSetup = () => {
    const panel = getOrCreatePanel(context);
    panel.reveal(vscode.ViewColumn.One);
    if (panelSession().ready) void panel.webview.postMessage({ command: "openTab", tab: "mcp" });
    else panelSession().pendingTab = "mcp";
  };
  if (choice === "Open Config") { openSetup(); return; }
  if (choice !== "Repair Runtime") return;
  try {
    await vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: "Updating PKM MCP Runtime dependencies",
      cancellable: false,
    }, async progress => {
      progress.report({ message: "Installing managed MCP and adaptive retrieval dependencies…" });
      await ensureMcpRuntime(context);
      scheduleRetrievalRefresh(context, 0);
    });
    refreshMcpDefinitions();
    _treeProvider?.refresh();
    vscode.window.showInformationMessage("PKM MCP Runtime dependencies were updated successfully.");
  } catch (error: any) {
    vscode.window.showErrorMessage(`PKM MCP Runtime repair failed: ${error?.message || String(error)}`, "Open Config")
      .then(result => { if (result === "Open Config") openSetup(); });
  }
}

function openMcpSetup(context: vscode.ExtensionContext, highlightRegenerate = false, target?: "python" | "progress"): void {
  const mcpPanel = getOrCreatePanel(context);
  mcpPanel.reveal(vscode.ViewColumn.One);
  if (panelSession().ready) {
    void mcpPanel.webview.postMessage({ command: "openTab", tab: "mcp" });
    if (highlightRegenerate) void mcpPanel.webview.postMessage({ command: "highlightMcpRegenerate" });
    if (target) void mcpPanel.webview.postMessage({ command: "focusMcpSetup", target });
  } else {
    panelSession().pendingTab = "mcp";
    panelSession().pendingMcpRegenerateHighlight ||= highlightRegenerate;
    panelSession().pendingMcpSetupTarget = target;
  }
}

async function regenerateMcpServerCode(context: vscode.ExtensionContext): Promise<void> {
  try {
    const info = await generateMcpServer(context);
    refreshMcpDefinitions();
    _treeProvider?.refresh();
    postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
    await vscode.window.showInformationMessage(
      `PKM MCP server code regenerated at ${info.serverPath}. Restart the pkm MCP server to load it.`,
      "Open Config",
    ).then(choice => { if (choice === "Open Config") openMcpSetup(context, true); });
  } catch (error: any) {
    const choice = await vscode.window.showErrorMessage(
      `Could not regenerate PKM MCP server code: ${error?.message || String(error)}`,
      "Open Config",
    );
    if (choice === "Open Config") openMcpSetup(context, true);
  }
}

async function offerMcpServerRegeneration(context: vscode.ExtensionContext): Promise<void> {
  const status = mcpStatus();
  if (status.current || !(await mcpRuntimeStatusAsync()).healthy) return;
  const promptKey = `${status.installedVersion || "missing"}->${status.expectedVersion}`;
  if (_mcpRegenerationPromptedFor === promptKey) return;
  _mcpRegenerationPromptedFor = promptKey;
  const installed = status.installed ? `v${status.installedVersion}` : "missing";
  const choice = await vscode.window.showWarningMessage(
    `PKM MCP server code is ${installed}; v${status.expectedVersion} is required. Regenerate it now, then restart the pkm MCP server.`,
    "Regenerate Server Code", "Open Config", "Later",
  );
  if (choice === "Regenerate Server Code") await regenerateMcpServerCode(context);
  else if (choice === "Open Config") openMcpSetup(context, true);
}

let integrationMaintenance: Promise<void> | undefined;
let integrationMaintenanceErrorShown = false;
let integrationMaintenanceState: "idle" | "running" | "ready" | "action-required" | "error" = "idle";
let integrationMaintenanceError = "";
let newerPkmVersionNotice = "";
let integrationSetupProgress: McpRuntimeProgress | undefined;
let integrationSetupPostedAt = 0;
let missingPythonSetupInvited = false;

function integrationFailureState(message: string): "action-required" | "error" {
  return /action-required|close\/reconnect|newer|downgrade|Python 3\.10/i.test(message) ? "action-required" : "error";
}

function publishIntegrationProgress(progress: McpRuntimeProgress): void {
  const previousPhase = integrationSetupProgress?.phase;
  integrationSetupProgress = { ...progress };
  const now = Date.now();
  if (previousPhase === progress.phase && now - integrationSetupPostedAt < 250) return;
  integrationSetupPostedAt = now;
  // Retain the snapshot even without a panel; never create/reveal a panel during installation.
  if (!activePanel() || !panelSession().ready) return;
  postToPanel({ command: "mcpRuntimeProgress", data: integrationSetupProgress });
  postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
}

function setupProgress(phase: string, text: string, restart = false): void {
  const now = Date.now();
  publishIntegrationProgress({ phase, text, startedAt: restart ? now : integrationSetupProgress?.startedAt ?? now, updatedAt: now });
}

function requireMcpPythonSetup(context: vscode.ExtensionContext, error: string): void {
  integrationMaintenanceState = "action-required";
  integrationMaintenanceError = error || "Python 3.10+ is required for PKM MCP.";
  setupProgress("action-required", `${integrationMaintenanceError} Basic file Knowledge remains available. Open Config → MCP / Python to resume.`);
  if (missingPythonSetupInvited) return;
  missingPythonSetupInvited = true;
  void vscode.window.showInformationMessage(
    "PKM file Knowledge is available. MCP setup needs Python 3.10+: choose Python in Config → MCP to continue.",
    "Open setup", "Later",
  ).then(choice => { if (choice === "Open setup") openMcpSetup(context, false, "python"); });
}

// All existing automatic/user runtime entry points share the retained Host protocol.
async function ensureMcpRuntime(context: vscode.ExtensionContext): Promise<Awaited<ReturnType<typeof ensureMcpRuntimeWithProgress>>> {
  integrationMaintenanceState = "running";
  integrationMaintenanceError = "";
  setupProgress("checking", "Preparing managed runtime…", true);
  try {
    const runtime = await ensureMcpRuntimeWithProgress(context, progress => {
      if (progress.phase !== "ready" && progress.phase !== "error") publishIntegrationProgress(progress);
    });
    refreshMcpDefinitions();
    if (!integrationMaintenance) integrationMaintenanceState = "ready";
    setupProgress("runtime-verified", "Runtime health verified. Retrieval refresh is separate; client discovery/trust must be verified separately.");
    return runtime;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    integrationMaintenanceError = message;
    integrationMaintenanceState = integrationFailureState(message);
    setupProgress(integrationMaintenanceState, message);
    throw error;
  }
}

function maintainPkmIntegration(context: vscode.ExtensionContext): Promise<void> {
  if (integrationMaintenance) return integrationMaintenance;
  integrationMaintenanceState = "running";
  integrationMaintenanceError = "";
  setupProgress("checking", "Checking PKM integration and waiting for shared maintenance…", true);
  const producer = backgroundTaskRegistry.producer({ id: "pkm-integration-upgrade", kind: "other", label: "Preparing PKM integration" });
  producer.queued({ detail: "Waiting for shared runtime maintenance" });
  integrationMaintenance = withCrossProcessLock(path.join(managedMcpServerDirectory(), "integration-upgrade.lock"), "PKM integration upgrade", 600_000, async () => {
    producer.running({ detail: "Checking managed runtime and server compatibility" });
    await warmMcpPythonProbes();
    const server = mcpStatus();
    if (server.newerThanExpected) {
      const detected = `MCP server v${server.installedVersion}`;
      integrationMaintenanceState = "action-required";
      integrationMaintenanceError = `Newer PKM components detected: ${detected}. Reload this VS Code window to use the updated extension. No files were changed.`;
      setupProgress("action-required", integrationMaintenanceError);
      if (newerPkmVersionNotice !== detected) {
        newerPkmVersionNotice = detected;
        void vscode.window.showInformationMessage(
          `A newer PKM version is active on this machine (${detected}). Reload this VS Code window when convenient. This window will not downgrade shared PKM files.`,
          "Open Config",
        ).then(choice => { if (choice === "Open Config") openMcpSetup(context); });
      }
      return;
    }
    const python = detectMcpPython();
    if (!python.valid) {
      requireMcpPythonSetup(context, python.error);
      log.warn(`automatic PKM integration setup requires action: ${integrationMaintenanceError}`);
      return;
    }
    const runtime = mcpRuntimeStatus();
    if (!runtime.healthy) {
      log.info("automatically creating or repairing managed MCP runtime");
      await ensureMcpRuntime(context);
    } else if (!server.current) {
      setupProgress("generating-server", "Updating generated MCP server code…");
      await generateMcpServer(context);
    }
    setupProgress("health-check", "Verifying managed runtime health and current server…");
    refreshMcpDefinitions();
    if (!(await mcpRuntimeStatusAsync()).healthy || !mcpStatus().current) {
      throw new Error("PKM integration upgrade did not produce a healthy runtime and current MCP server.");
    }
    scheduleRetrievalRefresh(context, 0);
    integrationMaintenanceErrorShown = false;
    integrationMaintenanceState = "ready";
    setupProgress("ready", "PKM runtime and server verified; retrieval refresh scheduled (not yet verified). Client discovery/trust must be verified separately.");
    postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
  }, 1_800_000).catch(error => {
    const message = error instanceof Error ? error.message : String(error);
    integrationMaintenanceState = integrationFailureState(message);
    integrationMaintenanceError = message;
    setupProgress(integrationMaintenanceState, message);
    log.warn(`automatic PKM integration maintenance failed: ${message}`);
    if (!integrationMaintenanceErrorShown) {
      integrationMaintenanceErrorShown = true;
      void vscode.window.showWarningMessage(
        `PKM could not finish automatic integration setup: ${message}`,
        "Open Config",
      ).then(choice => { if (choice === "Open Config") openMcpSetup(context); });
    }
  }).finally(() => { producer.idle(); integrationMaintenance = undefined; });
  return integrationMaintenance;
}

// ── Sidebar tree provider ──────────────────────────────────────────────────
type PkNodeType =
  | 'module-knowledge' | 'module-tools' | 'module-automation' | 'module-projects' | 'module-settings'
  | 'page-user-profile' | 'page-agent-sessions' | 'page-agent-snapshots' | 'page-recipes' | 'page-action-library' | 'page-actions' | 'page-projects' | 'page-portal-connections' | 'page-skill-router' | 'page-github-sync' | 'page-background-tasks'
  | 'recipe-folder' | 'recipe'
  | 'root-skills' | 'root-notes' | 'root-papers' | 'root-prompts' | 'root-packages' | 'root-scripts' | 'root-environments' | 'root-servers' | 'root-chatroom' | 'root-subscriptions' | 'root-mcp'
  | 'environment-group' | 'environment-item'
  | 'server-group' | 'server-ungrouped-group' | 'server-item' | 'server-subscriber-group' | 'server-subscriber-item'
  | 'chat-hosted-group' | 'chat-joined-group' | 'chat-hosted-room' | 'chat-room'
  | 'subscription-brokers-group' | 'subscription-subscribers-group' | 'subscription-broker' | 'subscription-subscriber'
  | 'subscribed-content-root' | 'subscribed-content-broker' | 'subscribed-content-folder' | 'subscribed-content-item'
  | 'skill-folder' | 'skill' | 'skill-trash' | 'skill-trash-item' | 'note-folder' | 'note' | 'paper-folder' | 'paper'
  | 'knowledge-trash' | 'knowledge-trash-item' | 'markdown-assets-folder' | 'markdown-asset' | 'markdown-assets-manage'
  | 'prompt-project' | 'prompt-task' | 'prompt-version' | 'prompt-file'
  | 'package' | 'script-folder' | 'script-file';

interface PkFolder { folders: Map<string, PkFolder>; items: any[]; }

function folkNavigationLabel(value: string, root: boolean): string {
  return root && value.startsWith("_folk_") && value.length > 6 ? `${value.slice(6).replace(/--[a-f0-9]{12}$/i, "")} · folk` : value;
}

function privateNavigationLabel(type: PrivacyContentType, value: string, topLevel: boolean): string {
  const label = folkNavigationLabel(value, topLevel);
  return topLevel && isTopLevelPrivate(type, value) ? `🔒 ${label}` : label;
}

class PkTreeItem extends vscode.TreeItem {
  constructor(
    label: string,
    public readonly nodeType: PkNodeType,
    collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly nodeData: any = {}
  ) {
    super(label, collapsibleState);
    const ICONS: Partial<Record<PkNodeType, string>> = {
      "module-knowledge": "library", "module-tools": "tools", "module-automation": "run-all", "module-projects": "project", "module-settings": "settings-gear",
      "page-agent-sessions": "hubot", "page-agent-snapshots": "save", "page-recipes": "notebook", "page-projects": "project", "page-skill-router": "git-branch", "page-github-sync": "git-merge",
      "page-user-profile": "account", "page-action-library": "library", "page-actions": "tools", "page-portal-connections": "plug", "page-background-tasks": "tasklist",
      "recipe-folder": "folder", "recipe": "notebook",
      "root-skills": "book", "root-notes": "note", "root-papers": "library", "root-prompts": "comment-discussion",
      "root-packages": "package", "root-scripts": "terminal", "root-environments": "beaker", "root-servers": "server-environment", "root-chatroom": "comment-discussion", "root-subscriptions": "broadcast", "root-mcp": "server-process",
      "environment-group": "folder", "environment-item": "python",
      "chat-hosted-group": "broadcast", "chat-joined-group": "plug", "chat-hosted-room": "broadcast", "chat-room": "comment",
      "subscription-brokers-group": "folder", "subscription-subscribers-group": "folder", "subscription-broker": "radio-tower", "subscription-subscriber": "cloud",
      "subscribed-content-root": "cloud", "subscribed-content-broker": "remote", "subscribed-content-folder": "folder", "subscribed-content-item": "file",
      "skill-folder": "folder", "skill-trash": "trash", "skill-trash-item": "trash", "knowledge-trash": "trash", "knowledge-trash-item": "trash", "note-folder": "folder", "paper-folder": "folder",
      "skill": "symbol-snippet", "note": "file-text", "paper": "file-pdf",
      "markdown-assets-folder": "folder", "markdown-asset": "file-media", "markdown-assets-manage": "tools",
      "prompt-project": "folder", "prompt-task": "symbol-file",
      "prompt-version": "versions", "prompt-file": "file-code",
      "package": "package", "script-folder": "folder", "script-file": "file-code", "server-group": "folder", "server-ungrouped-group": "folder", "server-subscriber-group": "cloud", "server-subscriber-item": "link-external",
    };
    const icon = ICONS[nodeType];
    if (icon) this.iconPath = new vscode.ThemeIcon(icon);
    if (nodeData?.description) this.tooltip = nodeData.description;

    // contextValue drives right-click "New item" menus (see package.json view/item/context)
    if (nodeType === 'page-recipes') this.contextValue = 'pk-recipes-root';
    else if (nodeType === 'recipe-folder') this.contextValue = 'pk-recipes-group';
    else if (nodeType === 'recipe') this.contextValue = 'pk-recipe-item';
    else if (nodeType === 'root-skills') this.contextValue = 'pk-skills-root';
    else if (nodeType === 'skill-folder') this.contextValue = label === "(uncategorized)" ? 'pk-skills-virtual-root' : 'pk-skills-group';
    else if (nodeType === 'skill-trash') this.contextValue = 'pk-skill-trash';
    else if (nodeType === 'skill-trash-item') this.contextValue = 'pk-skill-trash-item';
    else if (nodeType === 'knowledge-trash') this.contextValue = 'pk-knowledge-trash';
    else if (nodeType === 'knowledge-trash-item') this.contextValue = 'pk-knowledge-trash-item';
    else if (nodeType === 'root-notes') this.contextValue = 'pk-notes-root';
    else if (nodeType === 'note-folder') this.contextValue = label === "(uncategorized)" ? 'pk-notes-virtual-root' : 'pk-notes-group';
    else if (nodeType === 'root-papers') this.contextValue = 'pk-papers-root';
    else if (nodeType === 'paper-folder') this.contextValue = label === "(uncategorized)" ? 'pk-papers-virtual-root' : 'pk-papers-group';
    else if (nodeType === 'root-prompts') this.contextValue = 'pk-prompts-root';
    else if (nodeType === 'prompt-project' || nodeType === 'prompt-task') this.contextValue = 'pk-prompts-group';
    else if (nodeType === 'prompt-version') this.contextValue = 'pk-prompts-terminal-group';
    else if (nodeType === 'root-scripts') this.contextValue = 'pk-scripts-root';
    else if (nodeType === 'script-folder') this.contextValue = 'pk-scripts-group';
    else if (nodeType === 'root-servers') this.contextValue = 'pk-servers-container';
    else if (nodeType.startsWith('subscribed-content-')) this.contextValue = 'pk-subscribed-content';
    else if (nodeType === 'server-group') this.contextValue = 'pk-server-group';
    // Leaf items support right-click Edit
    else if (nodeType === 'skill')       this.contextValue = 'pk-skill-item';
    else if (nodeType === 'note')        this.contextValue = 'pk-note-item';
    else if (nodeType === 'paper')       this.contextValue = 'pk-paper-item';
    else if (nodeType === 'prompt-file') this.contextValue = 'pk-prompt-item';
    else if (nodeType === 'script-file') this.contextValue = 'pk-script-item';
    if (nodeData?.privacyTopLevel) this.contextValue = `${this.contextValue || "pk-item"}-privacy-${nodeData.isPrivate ? "private" : "public"}`;
  }
}

class PkTreeProvider implements vscode.TreeDataProvider<PkTreeItem> {
  constructor(private readonly context: vscode.ExtensionContext) {}
  private _onChange = new vscode.EventEmitter<PkTreeItem | undefined | void>();
  readonly onDidChangeTreeData = this._onChange.event;
  private serverStatus: NavigationStatus = { kind: "offline", description: "checking", tooltip: "Checking managed servers." };
  private serverRows: any[] = [];
  private serverStatusRefresh: Promise<void> | undefined;
  private skillRootCache: PkFolder | undefined;
  private noteRootCache: PkFolder | undefined;
  private paperRootCache: PkFolder | undefined;
  private scriptRootCache: PkFolder | undefined;

  refresh(): void {
    this.skillRootCache = undefined;
    this.noteRootCache = undefined;
    this.paperRootCache = undefined;
    this.scriptRootCache = undefined;
    this._onChange.fire();
  }
  async refreshServerStatus(): Promise<void> {
    if (this.serverStatusRefresh) return this.serverStatusRefresh;
    this.serverStatusRefresh = (async () => {
      try { this.serverRows = await serverList(); this.serverStatus = summarizeServerNavigation(this.serverRows); }
      catch (error: any) { this.serverStatus = { kind: "attention", description: "status error", tooltip: `Could not inspect managed servers: ${error?.message || String(error)}` }; }
      this._onChange.fire();
    })();
    try { await this.serverStatusRefresh; }
    finally { this.serverStatusRefresh = undefined; }
  }
  refreshChatStatus(): void { this._onChange.fire(); }
  getTreeItem(e: PkTreeItem): vscode.TreeItem { return e; }

  private applyStatus(item: PkTreeItem, status: NavigationStatus): PkTreeItem {
    const color = status.kind === "online" ? "testing.iconPassed" : status.kind === "attention" ? "list.warningForeground" : "disabledForeground";
    item.iconPath = new vscode.ThemeIcon("circle-filled", new vscode.ThemeColor(color));
    item.description = this.localizedStatus(status.description);
    item.tooltip = status.tooltip;
    return item;
  }

  private text(key: string, params: Record<string, string | number> = {}): string {
    return localizedText(this.context.extensionPath, key, params);
  }

  private localizedStatus(description: string): string {
    const exact: Record<string, string> = { checking: "nav.checking", offline: "nav.offline", none: "nav.none", "all stopped": "nav.allStopped", "Hub running": "nav.hubRunning" };
    if (exact[description]) return this.text(exact[description]);
    const aggregate = /^(\d+) (running|connected|connecting)$/.exec(description);
    if (aggregate) {
      const key = aggregate[2] === "running" ? "nav.serversRunning" : aggregate[2] === "connected" ? "nav.roomsConnected" : "nav.roomsConnecting";
      return this.text(key, { count: aggregate[1] });
    }
    return description;
  }

  getChildren(element?: PkTreeItem): PkTreeItem[] {
    const C = vscode.TreeItemCollapsibleState.Collapsed;
    if (!element) {
      return [
        new PkTreeItem("Knowledge", "module-knowledge", C),
        new PkTreeItem("Tools", "module-tools", C),
        new PkTreeItem("Automation", "module-automation", C),
        new PkTreeItem("Projects", "module-projects", C),
        new PkTreeItem("Settings", "module-settings", C),
      ];
    }
    if (element.nodeType === "module-knowledge") {
      return [
        new PkTreeItem(this.text("tabs.skills"), "root-skills", C),
        new PkTreeItem(this.text("tabs.notes"), "root-notes", C),
        new PkTreeItem(this.text("tabs.papers"), "root-papers", C),
      ];
    }
    if (element.nodeType === "module-tools") {
      const servers = new PkTreeItem(this.text("tabs.servers"), "root-servers", C);
      servers.command = { command: "personalKnowledge.openServers", title: "Open Servers" };
      const environments = new PkTreeItem(this.text("tabs.environments"), "root-environments", C);
      environments.command = { command: "personalKnowledge.openEnvironments", title: "Open Environments" };
      return [
        new PkTreeItem(this.text("tabs.prompts"), "root-prompts", C),
        new PkTreeItem(this.text("tabs.scripts"), "root-scripts", C),
        new PkTreeItem(this.text("tabs.packages"), "root-packages", C),
        environments,
        servers,
      ];
    }
    if (element.nodeType === "module-automation") {
      const recipes = new PkTreeItem("Recipe Library", "page-recipes", C);
      recipes.command = { command: "personalKnowledge.openPanelTab", title: "Open Recipe Library", arguments: ["recipes"] };
      return [
        this._panelPage("User Profile", "page-user-profile", "userProfile"),
        this._panelPage("Agent Sessions", "page-agent-sessions", "agentSessions"),
        this._panelPage("Agent Snapshot", "page-agent-snapshots", "agentSnapshots"),
        recipes,
        this._panelPage("Action Library", "page-action-library", "actionLibrary"),
        this._panelPage("Action Workbench", "page-actions", "actions"),
      ];
    }
    if (element.nodeType === "module-projects") {
      const chatroom = new PkTreeItem("Threads", "root-chatroom", C);
      chatroom.command = { command: "personalKnowledge.openChatroom", title: "Open Threads" };
      return [
        this._panelPage("Overview", "page-projects", "projects"),
        chatroom,
        this._panelPage("Portal Connections", "page-portal-connections", "portalConnections"),
      ];
    }
    if (element.nodeType === "module-settings") {
      const mcp = new PkTreeItem("General & MCP", "root-mcp", vscode.TreeItemCollapsibleState.None);
      mcp.command = { command: "personalKnowledge.setupMcp", title: "Open General & MCP" };
      const subscriptions = new PkTreeItem("Network & Sharing", "root-subscriptions", C);
      subscriptions.command = { command: "personalKnowledge.openSubscriptions", title: "Open Network & Sharing" };
      return [
        mcp,
        this._panelPage("Router", "page-skill-router", "skillRouter"),
        subscriptions,
        this._panelPage("GitHub Sync", "page-github-sync", "githubSync"),
        this._panelPage("Background Tasks", "page-background-tasks", "backgroundTasks"),
      ];
    }
    try {
      switch (element.nodeType) {
        case 'root-skills':    return this._withSubscribedContent("skills", this._skillRootItems());
        case 'page-recipes':   return this._withSubscribedContent("recipes", this._recipeFolder([]));
        case 'recipe-folder':  return this._recipeFolder(element.nodeData.path);
        case 'skill-folder':   return this._skillFolder(element.nodeData.path);
        case 'skill-trash':    return this._skillTrashItems();
        case 'root-notes':     return this._withSubscribedContent("notes", this._withKnowledgeTrash("notes", this._noteFolder([])));
        case 'note-folder':    return this._noteFolder(element.nodeData.path);
        case 'root-papers':    return this._withSubscribedContent("papers", this._withKnowledgeTrash("papers", this._paperFolder([])));
        case 'paper-folder':   return this._paperFolder(element.nodeData.path);
        case 'skill':
        case 'note':
        case 'paper': {
          const area = element.nodeType === "skill" ? "skills" : element.nodeType === "note" ? "notes" : "papers";
          return [new PkTreeItem(path.posix.basename(markdownAssetDirectory(element.nodeData.relPath)), "markdown-assets-folder",
            vscode.TreeItemCollapsibleState.Collapsed, { area, documentPath: element.nodeData.relPath })];
        }
        case 'markdown-assets-folder': return this._markdownAssets(element.nodeData.area, element.nodeData.documentPath);
        case 'root-prompts':   return this._withSubscribedContent("prompts", this._withKnowledgeTrash("prompts", this._promptProjects()));
        case 'prompt-project': return this._promptTasks(element.nodeData.project);
        case 'prompt-task':    return this._promptVersions(element.nodeData.project, element.nodeData.task);
        case 'prompt-version': return this._promptFiles(element.nodeData);
        case 'root-packages':  return this._withSubscribedContent("packages", this._packageItems());
        case 'root-scripts':   return this._withSubscribedContent("scripts", this._withKnowledgeTrash("scripts", this._scriptFolder([])));
        case 'script-folder':  return this._scriptFolder(element.nodeData.path);
        case 'knowledge-trash': return this._knowledgeTrashItems(element.nodeData.area);
        case 'root-environments': return this._environmentItems([]);
        case 'environment-group': return this._environmentItems(element.nodeData.path);
        case 'root-servers': return this._serverRootItems();
        case 'server-group': return this._serverItems(element.nodeData.path);
        case 'server-ungrouped-group': return this._serverItems([], true);
        case 'server-subscriber-group': return this._subscribedServerItems(element.nodeData.subscriptionId);
        case 'subscribed-content-root':
        case 'subscribed-content-broker':
        case 'subscribed-content-folder': return this._subscribedContentChildren(element.nodeData.model);
        case 'root-chatroom': return this._chatGroups();
        case 'chat-hosted-group': return this._hostedRooms();
        case 'chat-joined-group': return this._chatRooms();
        case 'root-subscriptions': return this._subscriptionGroups();
        case 'subscription-brokers-group': return this._subscriptionBrokers();
        case 'subscription-subscribers-group': return this._subscriptionSubscribers();
      }
    } catch { /* DB/store not ready yet */ }
    return [];
  }

  private _panelPage(label: string, nodeType: PkNodeType, tab: string): PkTreeItem {
    const item = new PkTreeItem(label, nodeType, vscode.TreeItemCollapsibleState.None);
    item.command = { command: "personalKnowledge.openPanelTab", title: `Open ${label}`, arguments: [tab] };
    return item;
  }

  private _markdownAssets(area: MarkdownAssetArea, documentPath: string): PkTreeItem[] {
    const data = { area, documentPath };
    const manage = new PkTreeItem("Manage resources...", "markdown-assets-manage", vscode.TreeItemCollapsibleState.None, data);
    manage.command = { command: "personalKnowledge.manageMarkdownAssets", title: "Manage Markdown resources", arguments: [manage] };
    try {
      const full = checkedMarkdownPath(path.join(getStorePath(), area), documentPath);
      return [manage, ...listedMarkdownAssets(getStorePath(), area, documentPath, fs.readFileSync(full, "utf8")).map(asset => {
        const item = new PkTreeItem(asset.path.startsWith(markdownAssetDirectory(documentPath) + "/")
          ? asset.path.slice(markdownAssetDirectory(documentPath).length + 1) : asset.path + " (legacy reference)",
        "markdown-asset", vscode.TreeItemCollapsibleState.None, { ...data, assetPath: asset.path });
        item.command = { command: "vscode.open", title: "Preview resource", arguments: [vscode.Uri.file(asset.fullPath)] };
        return item;
      })];
    } catch (error) {
      log.error(`Markdown resource tree failed: ${String(error)}`);
      vscode.window.showErrorMessage(`Could not list Markdown resources: ${String(error)}`);
      return [manage];
    }
  }

  private _subscriptionGroups(): PkTreeItem[] {
    const snapshot = sharedMarket?.snapshot as any;
    const brokers = new PkTreeItem("Brokers", "subscription-brokers-group", vscode.TreeItemCollapsibleState.Collapsed);
    const subscribers = new PkTreeItem("Subscribers", "subscription-subscribers-group", vscode.TreeItemCollapsibleState.Collapsed);
    brokers.description = String(snapshot?.shares?.length || 0);
    subscribers.description = String(snapshot?.subscriptions?.length || 0);
    brokers.command = { command: "personalKnowledge.openSubscriptions", title: "Open Brokers" };
    subscribers.command = { command: "personalKnowledge.openSubscriptions", title: "Open Subscribers" };
    return [brokers, subscribers];
  }

  private _withSubscribedContent(type: SharedContentType, local: PkTreeItem[]): PkTreeItem[] {
    const model = sharedMarket && subscriptionNavigationRoot(type, sharedMarket.cachedGroups(type));
    const items = model ? [...local, this._subscribedContentItem(model)] : [...local];
    const rank = (item: PkTreeItem) => item.nodeType === "skill-trash" || item.nodeType === "knowledge-trash"
      ? 2 : item.nodeData?.isPrivate ? 1 : 0;
    return items.sort((left, right) => rank(left) - rank(right));
  }

  private _subscribedContentItem(model: SubscriptionNavigationNode): PkTreeItem {
    const nodeType: PkNodeType = model.kind === "root" ? "subscribed-content-root"
      : model.kind === "broker" ? "subscribed-content-broker"
      : model.kind === "folder" ? "subscribed-content-folder" : "subscribed-content-item";
    const state = model.kind === "item" ? vscode.TreeItemCollapsibleState.None : vscode.TreeItemCollapsibleState.Collapsed;
    const item = new PkTreeItem(model.label, nodeType, state, { model, key: model.itemKey, pkmPath: model.pkmPath });
    if (model.kind !== "item") item.description = String(model.count);
    if (model.kind === "root") item.tooltip = `Read-only ${model.contentType} from subscribed Brokers`;
    if (model.kind === "broker") item.tooltip = `Subscribed ${model.contentType} from ${model.label}`;
    if (model.kind === "item") {
      item.tooltip = model.path;
      if (model.contentType === "servers") {
        item.iconPath = new vscode.ThemeIcon("link-external");
        item.command = { command: "personalKnowledge.openSubscribedServer", title: "Open Subscribed Server", arguments: [model.itemKey] };
      } else {
        item.command = { command: "personalKnowledge.openSubscribedContent", title: "Open Subscribed Content", arguments: [model.contentType, model.itemKey] };
      }
    }
    return item;
  }

  private _subscribedContentChildren(model: SubscriptionNavigationNode): PkTreeItem[] {
    return model.children.map(child => this._subscribedContentItem(child));
  }

  private _subscriptionBrokers(): PkTreeItem[] {
    const snapshot = sharedMarket?.snapshot as any;
    return (snapshot?.shares || []).map((share: any) => {
      const item = new PkTreeItem(share.name, "subscription-broker", vscode.TreeItemCollapsibleState.None, { shareId: share.shareId });
      item.description = `r${Number(share.revision) || 0} · ${share.visibility === "public" ? "discoverable" : "unlisted"}`;
      const gatewayStarting = snapshot.gatewayStatus === "starting";
      item.iconPath = new vscode.ThemeIcon(snapshot.gatewayStatus === "running" ? "radio-tower" : gatewayStarting ? "sync~spin" : "circle-slash", new vscode.ThemeColor(snapshot.gatewayStatus === "running" ? "testing.iconPassed" : gatewayStarting ? "notificationsWarningIcon.foreground" : "disabledForeground"));
      item.command = { command: "personalKnowledge.openSubscriptions", title: "Open Broker", arguments: [share.shareId] };
      return item;
    });
  }

  private _subscriptionSubscribers(): PkTreeItem[] {
    const snapshot = sharedMarket?.snapshot as any;
    return (snapshot?.subscriptions || []).map((subscription: any) => {
      const item = new PkTreeItem(subscription.alias || subscription.publisher || subscription.shareId, "subscription-subscriber", vscode.TreeItemCollapsibleState.None, { subscriptionId: subscription.id });
      item.description = subscription.status || "new";
      item.iconPath = new vscode.ThemeIcon(subscription.status === "current" ? "cloud" : "cloud-offline", new vscode.ThemeColor(subscription.status === "current" ? "testing.iconPassed" : "disabledForeground"));
      item.command = { command: "personalKnowledge.openSubscriptions", title: "Open Subscriber" };
      return item;
    });
  }

  private _chatGroups(): PkTreeItem[] {
    const recents = chatRecents(this.context);
    const hostedRooms = getChatMgr().hostedRoomsForNavigation();
    const hosted = new PkTreeItem("Hosted Rooms", "chat-hosted-group", vscode.TreeItemCollapsibleState.Collapsed);
    const joined = new PkTreeItem("Recent Joined Rooms", "chat-joined-group", vscode.TreeItemCollapsibleState.Collapsed);
    hosted.description = String(hostedRooms.length);
    joined.description = String(recents.length);
    return [hosted, joined];
  }

  private _serverItems(groupPath: string[], ungroupedOnly = false): PkTreeItem[] {
    const prefix = groupPath.join("/");
    const childGroups = new Set<string>();
    const navigationServers = this.serverRows.filter(server => String(server.category || "").split("/")[0]?.toLowerCase() !== "hidden");
    for (const category of ungroupedOnly ? [] : serverGroupList()) {
      const parts = String(category || "").split("/").filter(Boolean);
      if (parts[0]?.toLowerCase() === "hidden" || parts.slice(0, groupPath.length).join("/") !== prefix) continue;
      if (parts.length > groupPath.length) childGroups.add(parts[groupPath.length]);
    }
    const direct = navigationServers.filter(server => {
      const parts = String(server.category || "").split("/").filter(Boolean);
      if (parts.slice(0, groupPath.length).join("/") !== prefix) return false;
      if (parts.length > groupPath.length) {
        childGroups.add(parts[groupPath.length]);
        return false;
      }
      return true;
    }).sort((left, right) => Number(!!right.pinned) - Number(!!left.pinned) || left.name.localeCompare(right.name));
    const groups = [...childGroups].sort((left, right) => left.localeCompare(right)).map(name => {
      const path = [...groupPath, name];
      const categoryPrefix = path.join("/");
      const topLevel = groupPath.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("servers", name, topLevel), "server-group", vscode.TreeItemCollapsibleState.Collapsed,
        { path, privacyTopLevel: topLevel, isPrivate: topLevel && isTopLevelPrivate("servers", name), privacyType: "servers", privacyName: name });
      item.description = String(navigationServers.filter(server => String(server.category || "") === categoryPrefix
        || String(server.category || "").startsWith(categoryPrefix + "/")).length);
      return item;
    });
    const servers = direct.map(server => {
      const status: NavigationStatus = server.status === "running"
        ? { kind: "online", description: this.text("nav.runningPort", { port: server.activePort }), tooltip: `${server.name} is running on port ${server.activePort}.` }
        : server.status === "external"
          ? { kind: "online", description: `external · :${server.port}`, tooltip: `${server.name} has a live listener on port ${server.port}, but PKM did not start it.` }
        : server.status === "starting"
          ? { kind: "attention", description: this.text("nav.startingPort", { port: server.activePort }), tooltip: `${server.name} is starting on port ${server.activePort}.` }
          : { kind: "offline", description: this.text("nav.stoppedPort", { port: server.port }), tooltip: `${server.name} is stopped; configured port ${server.port}.` };
      const inheritedPrivate = isContentItemPrivate("servers", server);
      const serverLabel = `${inheritedPrivate ? "🔒 " : ""}${server.pinned ? "★ " : ""}${server.name}`;
      const item = this.applyStatus(new PkTreeItem(serverLabel, "server-item", vscode.TreeItemCollapsibleState.None,
        { slug: server.slug, isPrivate: inheritedPrivate }), status);
      item.contextValue = server.status === "stopped" ? "pk-server-stopped" : server.status === "external" ? "pk-server-external" : "pk-server-active";
      item.command = { command: "personalKnowledge.openServers", title: "Open Servers", arguments: [server.slug] };
      return item;
    });
    if (!groupPath.length && !ungroupedOnly && servers.length) {
      const ungrouped = new PkTreeItem(this.text("servers.ungrouped"), "server-ungrouped-group", vscode.TreeItemCollapsibleState.Expanded);
      ungrouped.description = String(servers.length);
      ungrouped.tooltip = `${servers.length} Server${servers.length === 1 ? "" : "s"} without a group.`;
      return [ungrouped, ...groups];
    }
    if (ungroupedOnly) return servers;
    return [...groups, ...servers];
  }

  private _serverRootItems(): PkTreeItem[] {
    const local = this._serverItems([]);
    return this._withSubscribedContent("servers", local);
  }

  private _subscribedServerItems(subscriptionId: string): PkTreeItem[] {
    if (!sharedMarket) return [];
    const group = sharedMarket.cachedGroups("servers").find(item => item.subscriptionId === subscriptionId);
    if (!group) return [];
    return group.items.map(server => {
      const link = sharedMarket!.cachedServerLinks(server.key).links[0]?.url || "";
      const item = new PkTreeItem(server.title, "server-subscriber-item", vscode.TreeItemCollapsibleState.None, { key: server.key });
      item.description = link || "Unavailable";
      item.tooltip = link || "No Server link is available.";
      if (link) item.command = { command: "personalKnowledge.openSubscribedServer", title: "Open Subscribed Server", arguments: [server.key] };
      return item;
    });
  }

  private _environmentCategory(environment: any): string[] {
    const manager = String(environment.manager || "other");
    if (manager === "conda") {
      const environmentPath = String(environment.path || "");
      const rootPath = environmentPath.includes("/envs/") ? environmentPath.slice(0, environmentPath.indexOf("/envs/")) : environmentPath;
      return [manager, rootPath.split("/").filter(Boolean).pop() || "conda"];
    }
    const parentPath = String(environment.path || environment.python || "").replace(/\/[^/]*$/, "");
    return [manager, parentPath.split("/").filter(Boolean).pop() || "(root)"];
  }

  private _environmentItems(groupPath: string[]): PkTreeItem[] {
    const environments = envListForUi();
    const childGroups = new Set<string>();
    const direct = environments.filter(environment => {
      const category = this._environmentCategory(environment);
      if (category.slice(0, groupPath.length).join("/") !== groupPath.join("/")) return false;
      if (category.length > groupPath.length) { childGroups.add(category[groupPath.length]); return false; }
      return true;
    }).sort((left, right) => String(left.name).localeCompare(String(right.name)));
    const groups = [...childGroups].sort((left, right) => left.localeCompare(right)).map(name => {
      const itemPath = [...groupPath, name];
      const item = new PkTreeItem(name, "environment-group", vscode.TreeItemCollapsibleState.Collapsed, { path: itemPath });
      item.description = String(environments.filter(environment => {
        const category = this._environmentCategory(environment);
        return category.slice(0, itemPath.length).join("/") === itemPath.join("/");
      }).length);
      return item;
    });
    const items = direct.map(environment => {
      const item = new PkTreeItem(environment.name, "environment-item", vscode.TreeItemCollapsibleState.None, { id: environment.id });
      item.description = environment.missing ? "missing" : environment.pyVersion ? `py ${environment.pyVersion}` : environment.manager;
      item.tooltip = `${environment.name}\n${environment.python || environment.path || ""}`;
      item.iconPath = new vscode.ThemeIcon(environment.missing ? "warning" : "python", environment.missing ? new vscode.ThemeColor("list.warningForeground") : undefined);
      item.command = { command: "personalKnowledge.openEnvironments", title: "Open Environments", arguments: [environment.id] };
      return item;
    });
    return [...groups, ...items];
  }

  private _hostedRooms(): PkTreeItem[] {
    return getChatMgr().hostedRoomsForNavigation().map(room => {
      const status: NavigationStatus = room.active || room.activeElsewhere
        ? { kind: "online", description: room.activeElsewhere ? "active elsewhere" : "active", tooltip: room.activeElsewhere ? "Room is active in another VS Code window." : "Active hosted Room." }
        : room.canRehost
          ? { kind: "offline", description: "stored", tooltip: "Stored Room · click to Rehost." }
          : { kind: "attention", description: "unavailable", tooltip: room.unavailableReason || "Stored Room is unavailable." };
      const item = this.applyStatus(new PkTreeItem(room.roomName, "chat-hosted-room", vscode.TreeItemCollapsibleState.None, room), status);
      item.contextValue = room.active ? "pk-chat-hosted-room-active" : room.canForceClose ? "pk-chat-hosted-room-active-elsewhere" : "pk-chat-hosted-room-stored";
      if (!room.activeElsewhere) item.command = { command: "personalKnowledge.openHostedRoomItem", title: room.active ? "Open Room" : "Rehost Room", arguments: [room.roomId] };
      return item;
    });
  }

  private _chatRooms(): PkTreeItem[] {
    const liveRooms = new Map(((getChatMgr().state() as any).rooms || []).map((room: any) => [chatRoomIdentity(room.url, room.room, room.roomId), room]));
    return chatRecents(this.context)
      .sort((left, right) => right.lastJoined - left.lastJoined)
      .map(room => {
        const live = liveRooms.get(room.id) as any;
        const status: NavigationStatus = live?.status === "connected"
          ? { kind: "online", description: `connected · as ${room.user}`, tooltip: `Connected as ${room.user}.` }
          : live?.status === "connecting"
            ? { kind: "attention", description: `connecting · as ${room.user}`, tooltip: `Connecting as ${room.user}.` }
            : { kind: "offline", description: `offline · as ${room.user}`, tooltip: `Recent Room · reconnect as ${room.user}.` };
        const item = this.applyStatus(new PkTreeItem(room.room, "chat-room", vscode.TreeItemCollapsibleState.None, { id: room.id }), status);
        item.tooltip = `${status.tooltip}\n${room.url}/${encodeURIComponent(room.room)}`;
        item.command = { command: "personalKnowledge.openChatRoomItem", title: "Open Room", arguments: [room.id] };
        return item;
      });
  }

  // ── Generic recursive path tree ──────────────────────────────────────────
  /** Build a nested folder tree from entries {path, data}. */
  private _buildPathTree(entries: { path: string[]; data: any }[]): PkFolder {
    const root: PkFolder = { folders: new Map(), items: [] };
    for (const e of entries) {
      let node = root;
      for (const seg of e.path) {
        if (!node.folders.has(seg)) node.folders.set(seg, { folders: new Map(), items: [] });
        node = node.folders.get(seg)!;
      }
      node.items.push(e.data);
    }
    return root;
  }

  private _navigate(root: PkFolder, path: string[]): PkFolder | undefined {
    let node = root;
    for (const seg of path) {
      const next = node.folders.get(seg);
      if (!next) return undefined;
      node = next;
    }
    return node;
  }

  private _addFolderPaths(root: PkFolder, folders: string[]): PkFolder {
    for (const folder of folders) {
      let node = root;
      for (const segment of folder.split("/").filter(Boolean)) {
        if (!node.folders.has(segment)) node.folders.set(segment, { folders: new Map(), items: [] });
        node = node.folders.get(segment)!;
      }
    }
    return root;
  }

  // ── Skills (recursive by category path) ──────────────────────────────────
  private _skillRoot(): PkFolder {
    if (this.skillRootCache) return this.skillRootCache;
    const skills = knowledgeInventory?.snapshot.revision ? knowledgeInventory.skills() : skillList();
    const entries = (skills as any[]).map(s => {
      const cat = (s.category || "").trim();
      const path = cat ? cat.split("/").map((x: string) => x.trim()).filter(Boolean) : ["(uncategorized)"];
      return { path, data: s };
    });
    const folders = knowledgeInventory?.snapshot.revision ? knowledgeInventory.folders("skills") : folderList("skills");
    return this.skillRootCache = this._addFolderPaths(this._buildPathTree(entries), folders);
  }

  private _skillRootItems(): PkTreeItem[] {
    const items = this._skillFolder([]);
    const trash = skillTrashList();
    const item = new PkTreeItem("Trash", "skill-trash", vscode.TreeItemCollapsibleState.Collapsed);
    item.description = String(trash.length);
    items.push(item);
    return items;
  }

  private _withKnowledgeTrash(area: KnowledgeTrashArea, items: PkTreeItem[]): PkTreeItem[] {
    const trash = knowledgeTrashList(area);
    const item = new PkTreeItem("Trash", "knowledge-trash", vscode.TreeItemCollapsibleState.Collapsed, { area });
    item.description = String(trash.length);
    return [...items, item];
  }

  private _knowledgeTrashItems(area: KnowledgeTrashArea): PkTreeItem[] {
    return knowledgeTrashList(area).map(entry => {
      const item = new PkTreeItem(entry.name, "knowledge-trash-item", vscode.TreeItemCollapsibleState.None, { ...entry, area });
      item.description = entry.originalPath;
      item.tooltip = `${entry.kind === "folder" ? "Folder" : "Item"} moved to Trash at ${entry.deletedAt}`;
      return item;
    });
  }

  private _skillTrashItems(): PkTreeItem[] {
    return skillTrashList().map(entry => {
      const item = new PkTreeItem(entry.name, "skill-trash-item", vscode.TreeItemCollapsibleState.None, entry);
      item.description = entry.originalPath;
      item.tooltip = `${entry.kind === "folder" ? "Folder" : "Skill"} moved to Trash at ${entry.deletedAt}`;
      return item;
    });
  }

  private _skillFolder(path: string[]): PkTreeItem[] {
    const node = this._navigate(this._skillRoot(), path);
    if (!node) return [];
    const out: PkTreeItem[] = [];
    for (const name of [...node.folders.keys()].sort((a, b) =>
      a === "(uncategorized)" ? 1 : b === "(uncategorized)" ? -1 : a.localeCompare(b))) {
      const folder = node.folders.get(name)!;
      const count = this._countLeaves(folder);
      const topLevel = path.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("skills", name, topLevel), 'skill-folder', vscode.TreeItemCollapsibleState.Collapsed,
        { path: [...path, name], relPath: [...path, name].join("/"), privacyTopLevel: topLevel && name !== "(uncategorized)", isPrivate: topLevel && isTopLevelPrivate("skills", name), privacyType: "skills", privacyName: name });
      item.description = String(count);
      out.push(item);
    }
    for (const s of node.items.sort((a: any, b: any) => a.name.localeCompare(b.name))) {
      const item = new PkTreeItem(s.name, 'skill', vscode.TreeItemCollapsibleState.Collapsed,
        { key: s.category ? `${s.category}/${s.name}` : s.name, relPath: `${s.category ? `${s.category}/` : ""}${s.name}.md`, description: s.description });
      item.command = { command: 'personalKnowledge.openSkill', title: 'Open', arguments: [s.name] };
      if (s.description) item.description = s.description;
      out.push(item);
    }
    return out;
  }

  private _countLeaves(node: PkFolder): number {
    let n = node.items.length;
    for (const f of node.folders.values()) n += this._countLeaves(f);
    return n;
  }

  private _recipeFolder(path: string[]): PkTreeItem[] {
    const snapshot = currentProjectStore().list();
    const entries = snapshot.recipes
      .filter(recipe => recipe.scope === "global")
      .map(recipe => ({
        path: String(recipe.category || "").split("/").map(segment => segment.trim()).filter(Boolean),
        data: recipe,
      }));
    const node = this._navigate(this._addFolderPaths(this._buildPathTree(entries), snapshot.recipeFolders), path);
    if (!node) return [];
    const folders = [...node.folders.keys()].sort((left, right) => left.localeCompare(right)).map(name => {
      const folder = node.folders.get(name)!;
      const folderPath = [...path, name];
      const topLevel = path.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("recipes", name, topLevel), "recipe-folder", vscode.TreeItemCollapsibleState.Collapsed,
        { path: folderPath, relPath: folderPath.join("/"), privacyTopLevel: topLevel, isPrivate: topLevel && isTopLevelPrivate("recipes", name), privacyType: "recipes", privacyName: name });
      item.description = String(this._countLeaves(folder));
      return item;
    });
    const recipes = node.items.sort((left: any, right: any) => left.name.localeCompare(right.name)).map((recipe: RecipeRecord) => {
      const relPath = `${recipe.category ? `${recipe.category}/` : ""}${recipe.recipeId}.json`;
      const item = new PkTreeItem(recipe.name, "recipe", vscode.TreeItemCollapsibleState.None, { ...recipe, relPath });
      item.description = recipe.description;
      item.command = { command: "personalKnowledge.openRecipe", title: "Open Recipe", arguments: [recipe.recipeId] };
      return item;
    });
    return [...folders, ...recipes];
  }

  // ── Notes (recursive by category path; uncategorized grouped together) ───
  private _noteRoot(): PkFolder {
    if (this.noteRootCache) return this.noteRootCache;
    const notes = knowledgeInventory?.snapshot.revision ? knowledgeInventory.notes() : noteList(undefined, 500);
    const entries = (notes as any[]).map(n => {
      const cat = (n.category || "").trim();
      const path = cat ? cat.split("/").map((x: string) => x.trim()).filter(Boolean) : ["(uncategorized)"];
      return { path, data: n };
    });
    const folders = knowledgeInventory?.snapshot.revision ? knowledgeInventory.folders("notes") : folderList("notes");
    return this.noteRootCache = this._addFolderPaths(this._buildPathTree(entries), folders);
  }

  private _noteFolder(path: string[]): PkTreeItem[] {
    const node = this._navigate(this._noteRoot(), path);
    if (!node) return [];
    const out: PkTreeItem[] = [];
    for (const name of [...node.folders.keys()].sort((a, b) =>
      a === "(uncategorized)" ? 1 : b === "(uncategorized)" ? -1 : a.localeCompare(b))) {
      const folder = node.folders.get(name)!;
      const topLevel = path.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("notes", name, topLevel), 'note-folder', vscode.TreeItemCollapsibleState.Collapsed,
        { path: [...path, name], relPath: [...path, name].join("/"), privacyTopLevel: topLevel && name !== "(uncategorized)", isPrivate: topLevel && isTopLevelPrivate("notes", name), privacyType: "notes", privacyName: name });
      item.description = String(this._countLeaves(folder));
      out.push(item);
    }
    for (const n of node.items.sort((a: any, b: any) => (b.updated_at || "").localeCompare(a.updated_at || ""))) {
      const relativePath = `${n.slug}.md`;
      const item = new PkTreeItem(n.title, 'note', vscode.TreeItemCollapsibleState.Collapsed, { key: n.slug, relPath: relativePath });
      if (n.documentKind === "todo-board") item.iconPath = new vscode.ThemeIcon("project");
      item.description = relativePath.split("/").pop() || relativePath;
      item.tooltip = `${n.documentKind === "todo-board" ? "Todo Board · " : ""}${n.title}\nnotes/${relativePath}`;
      item.command = { command: 'personalKnowledge.openNote', title: 'Open', arguments: [n.slug] };
      out.push(item);
    }
    return out;
  }

  // ── Papers (category → paper) ────────────────────────────────────────────
  private _paperRoot(): PkFolder {
    if (this.paperRootCache) return this.paperRootCache;
    const entries = (paperList() as any[]).map(p => {
      const cat = (p.category || "").trim();
      const path = cat ? cat.split("/").map((x: string) => x.trim()).filter(Boolean) : ["(uncategorized)"];
      return { path, data: p };
    });
    return this.paperRootCache = this._addFolderPaths(this._buildPathTree(entries), folderList("papers"));
  }

  private _paperFolder(path: string[]): PkTreeItem[] {
    const node = this._navigate(this._paperRoot(), path);
    if (!node) return [];
    const out: PkTreeItem[] = [];
    for (const name of [...node.folders.keys()].sort((a, b) =>
      a === "(uncategorized)" ? 1 : b === "(uncategorized)" ? -1 : a.localeCompare(b))) {
      const folder = node.folders.get(name)!;
      const topLevel = path.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("papers", name, topLevel), 'paper-folder', vscode.TreeItemCollapsibleState.Collapsed,
        { path: [...path, name], relPath: [...path, name].join("/"), privacyTopLevel: topLevel && name !== "(uncategorized)", isPrivate: topLevel && isTopLevelPrivate("papers", name), privacyType: "papers", privacyName: name });
      item.description = String(this._countLeaves(folder));
      out.push(item);
    }
    // Sort papers by citation count (popularity), then year desc
    for (const p of node.items.sort((a: any, b: any) => (b.citationCount - a.citationCount) || ((b.year || 0) - (a.year || 0)))) {
      const item = new PkTreeItem(p.title, 'paper', vscode.TreeItemCollapsibleState.Collapsed, { key: p.slug, relPath: `${p.slug}.md` });
      item.description = `${p.year || ""}${p.citationCount ? "  ·  " + p.citationCount + "★" : ""}`.trim();
      item.command = { command: 'personalKnowledge.openPaper', title: 'Open', arguments: [p.slug] };
      out.push(item);
    }
    return out;
  }

  // ── Prompts (project → task → version → file) ────────────────────────────
  private _promptProjects(): PkTreeItem[] {
    const projects = [...new Set([...promptList().map(t => t.project), ...folderList("prompts").map(folder => folder.split("/")[0])])].sort();
    return projects.map(p =>
      new PkTreeItem(privateNavigationLabel("prompts", p, true), 'prompt-project', vscode.TreeItemCollapsibleState.Collapsed,
        { project: p, privacyTopLevel: true, isPrivate: isTopLevelPrivate("prompts", p), privacyType: "prompts", privacyName: p }));
  }

  private _promptTasks(project: string): PkTreeItem[] {
    const tasks = new Set(promptList().filter(t => t.project === project).map(t => t.task));
    for (const folder of folderList("prompts")) {
      const parts = folder.split("/");
      if (parts[0] === project && parts[1]) tasks.add(parts[1]);
    }
    return [...tasks].sort().map(task => new PkTreeItem(task, 'prompt-task', vscode.TreeItemCollapsibleState.Collapsed, { project, task }));
  }

  private _promptVersions(project: string, task: string): PkTreeItem[] {
    const t = promptList().find(x => x.project === project && x.task === task);
    const versions = new Map((t?.versions || []).map(version => [version.version, version.files]));
    for (const folder of folderList("prompts")) {
      const parts = folder.split("/");
      if (parts[0] === project && parts[1] === task && parts[2] && !versions.has(parts[2])) versions.set(parts[2], []);
    }
    return [...versions].sort(([left], [right]) => left.localeCompare(right)).map(([version, files]) =>
      new PkTreeItem(version, 'prompt-version', vscode.TreeItemCollapsibleState.Collapsed, { project, task, version, files }));
  }

  private _promptFiles(nd: any): PkTreeItem[] {
    return (nd.files ?? []).map((f: any) => {
      const item = new PkTreeItem(f.name, 'prompt-file', vscode.TreeItemCollapsibleState.None,
        { project: nd.project, task: nd.task, version: nd.version, file: f.name });
      const key = `${nd.project}|${nd.task}|${nd.version}|${f.name}`;
      item.command = { command: 'personalKnowledge.openPrompt', title: 'Open', arguments: [key] };
      return item;
    });
  }

  // ── Packages ─────────────────────────────────────────────────────────────
  private _packageItems(): PkTreeItem[] {
    return (packageList() as any[]).map((p: any) => {
      const item = new PkTreeItem(privateNavigationLabel("packages", p.name, true), 'package', vscode.TreeItemCollapsibleState.None,
        { key: p.name, description: p.description, privacyTopLevel: true, isPrivate: isTopLevelPrivate("packages", p.name), privacyType: "packages", privacyName: p.name });
      item.description = p.lang;
      item.command = { command: 'personalKnowledge.openPackage', title: 'Open', arguments: [p.name] };
      return item;
    });
  }

  // ── Scripts (recursive by folder path) ───────────────────────────────────
  private _scriptRoot(): PkFolder {
    if (this.scriptRootCache) return this.scriptRootCache;
    const scripts = knowledgeInventory?.snapshot.revision ? knowledgeInventory.scripts() : scriptList();
    const entries = (scripts as any[]).map(s => {
      const cat = (s.category || "").trim();
      const path = cat && cat !== "(root)" ? cat.split("/").map((x: string) => x.trim()).filter(Boolean) : [];
      return { path, data: s };
    });
    const folders = knowledgeInventory?.snapshot.revision ? knowledgeInventory.folders("scripts") : folderList("scripts");
    return this.scriptRootCache = this._addFolderPaths(this._buildPathTree(entries), folders);
  }

  private _scriptFolder(path: string[]): PkTreeItem[] {
    const node = this._navigate(this._scriptRoot(), path);
    if (!node) return [];
    const out: PkTreeItem[] = [];
    for (const name of [...node.folders.keys()].sort()) {
      const folder = node.folders.get(name)!;
      const topLevel = path.length === 0;
      const item = new PkTreeItem(privateNavigationLabel("scripts", name, topLevel), 'script-folder', vscode.TreeItemCollapsibleState.Collapsed,
        { path: [...path, name], relPath: [...path, name].join("/"), privacyTopLevel: topLevel, isPrivate: topLevel && isTopLevelPrivate("scripts", name), privacyType: "scripts", privacyName: name });
      item.description = String(this._countLeaves(folder));
      out.push(item);
    }
    for (const s of node.items.sort((a: any, b: any) => a.file.localeCompare(b.file))) {
      const item = new PkTreeItem(s.file, 'script-file', vscode.TreeItemCollapsibleState.None, { key: s.path, relPath: s.path });
      item.description = s.lang;
      item.command = { command: 'personalKnowledge.openScript', title: 'Open', arguments: [s.path] };
      out.push(item);
    }
    return out;
  }
}

type TreeMoveArea = "skills" | "notes" | "papers" | "prompts" | "scripts" | "servers";
type TreeMoveLevel = "folder" | "file" | "project" | "task" | "version";
interface TreeMoveInfo { area: TreeMoveArea; relPath: string; level: TreeMoveLevel; }

function treeMoveInfo(item: PkTreeItem, asTarget = false): TreeMoveInfo | undefined {
  const rootAreas: Partial<Record<PkNodeType, TreeMoveArea>> = {
    "root-skills": "skills", "root-notes": "notes", "root-papers": "papers", "root-prompts": "prompts", "root-scripts": "scripts", "root-servers": "servers",
  };
  const rootArea = rootAreas[item.nodeType];
  if (rootArea) return asTarget ? { area: rootArea, relPath: "", level: rootArea === "prompts" ? "project" : "folder" } : undefined;
  const areaByType: Partial<Record<PkNodeType, TreeMoveArea>> = {
    "skill-folder": "skills", skill: "skills", "note-folder": "notes", note: "notes",
    "paper-folder": "papers", paper: "papers", "script-folder": "scripts", "script-file": "scripts",
  };
  const area = areaByType[item.nodeType];
  if (area) {
    if (item.nodeType.endsWith("folder")) {
      if (item.nodeData.relPath === "(uncategorized)") return asTarget ? { area, relPath: "", level: "folder" } : undefined;
      return { area, relPath: item.nodeData.relPath, level: "folder" };
    }
    return asTarget ? undefined : { area, relPath: item.nodeData.relPath, level: "file" };
  }
  if (item.nodeType === "prompt-project") return { area: "prompts", relPath: item.nodeData.project, level: "project" };
  if (item.nodeType === "prompt-task") return { area: "prompts", relPath: `${item.nodeData.project}/${item.nodeData.task}`, level: "task" };
  if (item.nodeType === "prompt-version") return { area: "prompts", relPath: `${item.nodeData.project}/${item.nodeData.task}/${item.nodeData.version}`, level: "version" };
  if (item.nodeType === "prompt-file" && !asTarget) {
    return { area: "prompts", relPath: `${item.nodeData.project}/${item.nodeData.task}/${item.nodeData.version}/${item.nodeData.file}`, level: "file" };
  }
  if (item.nodeType === "server-group" && asTarget) return { area: "servers", relPath: item.nodeData.path.join("/"), level: "folder" };
  if (item.nodeType === "server-ungrouped-group" && asTarget) return { area: "servers", relPath: "", level: "folder" };
  if (item.nodeType === "server-item" && !asTarget) return { area: "servers", relPath: item.nodeData.slug, level: "file" };
  return undefined;
}

class PkTreeDragAndDropController implements vscode.TreeDragAndDropController<PkTreeItem> {
  constructor(private readonly context: vscode.ExtensionContext) {}
  private static readonly mime = "application/vnd.code.tree.personalKnowledge.sidebarView";
  readonly dragMimeTypes = [PkTreeDragAndDropController.mime];
  readonly dropMimeTypes = [PkTreeDragAndDropController.mime];

  handleDrag(source: readonly PkTreeItem[], dataTransfer: vscode.DataTransfer): void {
    const info = source.length === 1 ? treeMoveInfo(source[0]) : undefined;
    if (info) dataTransfer.set(PkTreeDragAndDropController.mime, new vscode.DataTransferItem(JSON.stringify(info)));
  }

  async handleDrop(target: PkTreeItem | undefined, dataTransfer: vscode.DataTransfer): Promise<void> {
    if (!target) { vscode.window.showInformationMessage("Drop onto a category root or folder."); return; }
    const raw = dataTransfer.get(PkTreeDragAndDropController.mime);
    const destination = treeMoveInfo(target, true);
    if (!raw || !destination) { vscode.window.showWarningMessage("Files can only be dropped onto folders."); return; }
    let source: TreeMoveInfo;
    try { source = JSON.parse(await raw.asString()); } catch { return; }
    if (source.area !== destination.area) { vscode.window.showWarningMessage("Items cannot be moved between knowledge areas."); return; }
    if (source.area === "servers") {
      const server = (await serverList()).find(row => row.slug === source.relPath);
      if (!server) { vscode.window.showWarningMessage("Server not found."); return; }
      if (String(server.category || "") === destination.relPath) return;
      if (!serverUpdate(source.relPath, { category: destination.relPath })) { vscode.window.showWarningMessage("Could not move Server to that group."); return; }
      gitCommit(`server move: ${source.relPath} -> ${destination.relPath || "(root)"}`);
      await _treeProvider?.refreshServerStatus();
      postToPanel({ command: "serverGroupList", data: serverGroupList() });
      postToPanel({ command: "serverList", data: await serverListForUi(this.context) });
      vscode.window.setStatusBarMessage(`$(move) Moved ${server.name} to ${destination.relPath || "Ungrouped"}`, 3000);
      return;
    }
    if (source.area === "prompts") {
      const allowedParent: Record<TreeMoveLevel, TreeMoveLevel | undefined> = { project: "project", task: "project", version: "task", file: "version", folder: undefined };
      const requiredDepth: Partial<Record<TreeMoveLevel, number>> = { project: 0, task: 1, version: 2, file: 3 };
      const destinationDepth = destination.relPath ? destination.relPath.split("/").length : 0;
      if (allowedParent[source.level] !== destination.level || destinationDepth !== requiredDepth[source.level]) {
        vscode.window.showWarningMessage("Prompts must keep the project / task / version / file hierarchy.");
        return;
      }
    }
    const result = storeEntryMove(source.area, source.relPath, destination.relPath);
    if (!result.ok) { vscode.window.showWarningMessage(result.error || "Move failed."); return; }
    gitCommit(`move(${source.area}): ${source.relPath} -> ${result.newPath}`);
    try { await refreshKnowledgeInventory(this.context, true); }
    catch (error) {
      vscode.window.showErrorMessage(`Moved to ${result.newPath}, but Navigation refresh failed. Do not repeat the move; refresh Navigation to retry: ${error instanceof Error ? error.message : String(error)}`);
      return;
    }
    _treeProvider?.refresh();
    postToPanel({ command: "reloaded" });
    vscode.window.setStatusBarMessage(`$(move) Moved to ${result.newPath}`, 3000);
  }
}

// ── First-run setup wizard ─────────────────────────────────────────────────
async function firstTimeSetup(context: vscode.ExtensionContext, reconfigure = false): Promise<string | undefined> {
  const hostDescription = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const resolved = resolvedStorePath(context);
  const currentPath = resolved?.path || "";
  const previousPath = context.globalState.get<string>("lastStorePath", "").trim();
  const reusablePath = previousPath && previousPath !== currentPath && fs.existsSync(previousPath) && fs.statSync(previousPath).isDirectory()
    ? previousPath : "";
  const reuseLabel = reusablePath ? `Reuse previous  (${reusablePath})` : undefined;
  const recommendedPath = path.join(os.homedir(), "uone-knowledge");
  const recommendedLabel = "Use Recommended Location";

  const pick = await vscode.window.showInformationMessage(
    reconfigure
      ? `Configure the Personal Knowledge root on ${hostDescription}.${currentPath ? ` Current: ${currentPath}` : ""}`
      : `Welcome to Personal Knowledge Manager. Choose where this machine stores your knowledge.`,
    { modal: true, detail: reconfigure
      ? "Changing the root switches this machine to another PKM store. Existing content is not moved."
      : `${recommendedPath}\n\nAfter this choice, PKM automatically creates or repairs its isolated runtime, generates the MCP server, builds the retrieval index, and keeps future updates current. Your Markdown files remain the source of truth.` },
    ...(!reconfigure ? [recommendedLabel] : []),
    ...(reuseLabel ? [reuseLabel] : []),
    "Choose Existing Folder…",
    "Enter Another Path…"
  );

  if (!pick) return undefined;

  let chosenPath: string | undefined;

  const usedRecommendedPath = pick === recommendedLabel;
  if (usedRecommendedPath) {
    chosenPath = recommendedPath;
  } else if (reuseLabel && pick === reuseLabel) {
    chosenPath = reusablePath;
  } else if (pick === "Choose Existing Folder…") {
    const result = await vscode.window.showOpenDialog({
      canSelectFolders: true,
      canSelectFiles: false,
      canSelectMany: false,
      openLabel: "Select knowledge store folder",
      title: "Personal Knowledge Manager — store location",
    });
    if (!result?.[0]) return undefined;
    chosenPath = result[0].fsPath;

  } else if (pick === "Enter Another Path…") {
    chosenPath = await vscode.window.showInputBox({
      prompt: "Enter the full path for your knowledge store",
      placeHolder: path.join(os.homedir(), "your-knowledge-root"),
      value: currentPath || reusablePath,
      validateInput: value => localAbsolutePathError(value),
    });
    if (!chosenPath) return undefined;
    chosenPath = chosenPath.trim();

  } else return undefined;

  chosenPath = path.resolve(chosenPath);
  const cloudStore = cloudSynchronizedPath(chosenPath);
  if (cloudStore) {
    const cloudChoice = await vscode.window.showWarningMessage(
      `${cloudStore.provider} is not recommended for the Knowledge Root.`,
      {
        modal: true,
        detail: `${chosenPath}\n\nCloud-drive clients can lock files, expose placeholders, and race PKM's atomic writes or renames, causing permission and consistency errors. GitHub Sync already provides cross-machine synchronization and version history, so a normal local folder is more reliable.`,
      },
      "Choose Another Location",
      "Use Cloud Folder Anyway",
    );
    if (cloudChoice === "Choose Another Location") return firstTimeSetup(context, reconfigure);
    if (cloudChoice !== "Use Cloud Folder Anyway") return undefined;
  }

  // Create the folder if it doesn't exist
  if (!fs.existsSync(chosenPath)) {
    if (!usedRecommendedPath) {
      const confirm = await vscode.window.showWarningMessage(
        `Folder does not exist: ${chosenPath}\n\nCreate it?`,
        { modal: true },
        "Create folder"
      );
      if (confirm !== "Create folder") return undefined;
    }
    fs.mkdirSync(chosenPath, { recursive: true });
  }

  if (!usedRecommendedPath) {
    const confirmed = await vscode.window.showInformationMessage(
      `Use this machine-local Knowledge Root?`,
      { modal: true, detail: `${hostDescription}\n\n${chosenPath}\n\nThis path stays on this extension host and is not copied by VS Code Settings Sync.` },
      "Use This Root",
    );
    if (confirmed !== "Use This Root") return undefined;
  }

  await rememberMachineStorePath(context, chosenPath, true);
  return chosenPath;
}

function displayBytes(bytes: number | undefined): string {
  if (!Number.isFinite(bytes) || Number(bytes) < 0) return "not measured";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = Number(bytes), index = 0;
  while (value >= 1024 && index < units.length - 1) { value /= 1024; index += 1; }
  return `${value.toFixed(index === 0 || value >= 100 ? 0 : 1)} ${units[index]}`;
}

async function chooseEnvironmentsRoot(context: vscode.ExtensionContext): Promise<string | undefined> {
  const current = path.resolve(managedEnvironmentsRoot());
  const defaultPath = path.resolve(os.homedir(), "pkm-envs");
  const host = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const cachedSize = mcpPathSizeCache.get(current)?.bytes;
  const choice = await vscode.window.showWarningMessage(
    "Reconfigure the machine-local Environments Root?",
    { modal: true, detail: `${host}\n\nCurrent: ${current}\nCurrent disk usage: ${displayBytes(cachedSize)}\n\nThis directory stores migrated/created conda, venv, and uv environments plus the managed pkm-mcp runtime. It can grow very large. Existing environments will not be moved automatically.` },
    `Use default (${defaultPath})`, "Browse Folder…", "Type a Path…",
  );
  if (!choice) return undefined;
  let selected: string | undefined;
  if (choice === "Browse Folder…") {
    const picked = await vscode.window.showOpenDialog({ canSelectFiles: false, canSelectFolders: true, canSelectMany: false, title: "Select machine-local Environments Root", openLabel: "Select Environments Root" });
    selected = picked?.[0]?.fsPath;
  } else if (choice === "Type a Path…") {
    selected = await vscode.window.showInputBox({ title: "Environments Root", prompt: `Absolute path on ${host}`, value: current, placeHolder: defaultPath, validateInput: value => localAbsolutePathError(value) });
  } else selected = defaultPath;
  if (!selected) return undefined;
  selected = path.resolve(selected.trim());
  if (!directoryExists(selected)) {
    const create = await vscode.window.showWarningMessage(`Create the Environments Root directory?`, { modal: true, detail: selected }, "Create Directory");
    if (create !== "Create Directory") return undefined;
    fs.mkdirSync(selected, { recursive: true });
  }
  if (selected === current) return undefined;
  const confirmed = await vscode.window.showWarningMessage(
    "Use this machine-local Environments Root?",
    { modal: true, detail: `${host}\n\nCurrent: ${current}\nNew: ${selected}\n\nExisting environments stay at their current paths. New managed environments and migrations use the new root. The managed pkm-mcp runtime must be recreated under the new root.` },
    "Use This Root",
  );
  return confirmed === "Use This Root" ? selected : undefined;
}

async function chooseMachineDirectory(label: string, current: string, defaultPath: string, impact: string): Promise<string | undefined> {
  const host = extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "");
  const choice = await vscode.window.showWarningMessage(
    `Reconfigure ${label}?`,
    { modal: true, detail: `${host}\n\nCurrent: ${current}\n\n${impact}\nThis path is machine-local and excluded from VS Code Settings Sync.` },
    `Use default (${defaultPath})`, "Browse Folder…", "Type a Path…",
  );
  if (!choice) return undefined;
  let selected: string | undefined;
  if (choice === "Browse Folder…") {
    const picked = await vscode.window.showOpenDialog({ canSelectFiles: false, canSelectFolders: true, canSelectMany: false, title: `Select ${label}`, openLabel: `Select ${label}` });
    selected = picked?.[0]?.fsPath;
  } else if (choice === "Type a Path…") {
    selected = await vscode.window.showInputBox({ title: label, prompt: `Absolute path on ${host}`, value: current, placeHolder: defaultPath, validateInput: value => localAbsolutePathError(value) });
  } else selected = defaultPath;
  if (!selected) return undefined;
  selected = path.resolve(selected.trim());
  if (selected === current) return undefined;
  if (!directoryExists(selected)) {
    const create = await vscode.window.showWarningMessage(`Create this directory?`, { modal: true, detail: selected }, "Create Directory");
    if (create !== "Create Directory") return undefined;
    fs.mkdirSync(selected, { recursive: true });
  }
  const confirmed = await vscode.window.showWarningMessage(
    `Use this ${label}?`,
    { modal: true, detail: `${host}\n\nCurrent: ${current}\nNew: ${selected}\n\n${impact}` },
    "Use This Path",
  );
  return confirmed === "Use This Path" ? selected : undefined;
}

function directoryIsEmpty(directory: string): boolean {
  try { return fs.readdirSync(directory).length === 0; }
  catch { return false; }
}

function safeMcpRuntimeTarget(directory: string): boolean {
  return !directoryExists(directory) || directoryIsEmpty(directory) || fs.existsSync(path.join(directory, ".pkm-base-python.json"));
}

function safeMcpServerTarget(directory: string): boolean {
  if (!directoryExists(directory) || directoryIsEmpty(directory)) return true;
  try { return /PKM MCP Server.*auto-generated/i.test(fs.readFileSync(path.join(directory, "server.py"), "utf8")); }
  catch { return false; }
}

// ── Activation ─────────────────────────────────────────────────────────────
function registerExtensionHostRuntime(context: vscode.ExtensionContext, isBusy: () => boolean): void {
  const build = loadedExtensionBuild;
  if (!build) { log.warn("Runtime build identity missing; coordinated reload is unavailable."); return; }
  const scope = createHash("sha256").update(`${path.dirname(context.extensionPath)}\n${context.extension.id.toLowerCase()}`).digest("hex");
  const installedBuild = () => readInstalledExtensionBuild(context.extensionPath, context.extension.id);
  const slotId = createHash("sha256").update(context.storageUri?.toString() || vscode.env.sessionId).digest("hex");
  const registry = new ExtensionHostRegistry(path.join(context.globalStorageUri.fsPath, "runtime", "extension-hosts", scope), {
    ...build, hostId: randomUUID(), slotId, scope, pid: process.pid, vscodeVersion: vscode.version,
  });
  configureManagedMcpAttribution({
    hostId: registry.identity.hostId,
    editorSessionId: vscode.env.sessionId,
    hostSlotId: registry.identity.slotId,
    extensionHostPid: process.pid,
    extensionHostLogUri: context.logUri.toString(),
    workspace: vscode.workspace.workspaceFile?.toString()
      || vscode.workspace.workspaceFolders?.map(folder => folder.uri.toString()).join(" | ") || undefined,
    machine: os.hostname(),
    remoteName: vscode.env.remoteName || undefined,
  });
  refreshMcpDefinitions();
  const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -1000);
  status.command = "personalKnowledge.hostStatus";
  let retrievalObservation: RetrievalWorkerStatus | undefined;
  let observedWorker: RetrievalWorkerManager | undefined;
  let retrievalObservedAt: string | undefined;
  let retrievalObservationError: string | undefined;
  let observing = false, disposed = false;
  const observationAbort = new AbortController();
  const indexTask = backgroundTaskRegistry.producer({ id: "retrieval-index-build", kind: "retrieval", label: "Build retrieval index" });
  const observeRetrieval = async () => {
    if (observing || disposed) return;
    observing = true;
    const worker = retrievalWorker;
    try {
      const observed = await worker?.observeStatus(observationAbort.signal);
      if (disposed || worker !== retrievalWorker) return;
      retrievalObservation = observed;
      observedWorker = worker;
      retrievalObservedAt = observed ? new Date().toISOString() : undefined;
      retrievalObservationError = undefined;
      const lifecycle = worker?.lifecycleStatus();
      if (observed && (observed.building_revision || observed.work_state && observed.work_state !== "idle")) {
        indexTask.running({ detail: lifecycle?.detail, progress: lifecycle?.progress });
      } else indexTask.idle();
    } catch (error) {
      if (disposed || worker !== retrievalWorker) return;
      const message = String(error);
      if (retrievalObservationError !== message) log.warn(`Retrieval status observation unavailable: ${message}`);
      retrievalObservationError = message;
      indexTask.idle();
    } finally { observing = false; }
  };
  const diagnostics = async () => {
    const report = {
      coverage: "Registered PKM hosts sharing this installation and profile storage only. Unregistered legacy hosts, other machines/profiles and external agent activity are not verified.",
      current: registry.identity, installed: installedBuild(), online: registry.hosts(), reload: registry.progress() ?? null,
      integration: { state: integrationMaintenanceState, error: integrationMaintenanceError },
    };
    const document = await vscode.workspace.openTextDocument({ language: "json", content: JSON.stringify(report, null, 2) });
    await vscode.window.showTextDocument(document, { preview: true });
    return report;
  };
  const dashboard = new StatusDashboard(context, async () => {
    const installed = installedBuild();
    let targets: GitHubSyncTarget[] = [];
    try {
      const parsed = JSON.parse(await fs.promises.readFile(githubSyncTargetsPath(context), "utf8"));
      if (parsed?.schema !== GITHUB_SYNC_TARGETS_SCHEMA || !Array.isArray(parsed.targets)) throw new Error("unsupported target file");
      targets = parsed.targets.map((target: unknown) => normalizeGitHubSyncTarget(target));
    } catch (error) { if (!(error && typeof error === "object" && "code" in error && error.code === "ENOENT")) throw error; }
    const currentObservation = observedWorker === retrievalWorker ? retrievalObservation : undefined;
    return {
      updatedAt: new Date().toISOString(),
      host: { version: build.version, build: build.buildId, installedVersion: installed?.version, installedBuild: installed?.buildId,
        pid: process.pid, node: process.version, vscode: vscode.version, hosts: registry.hosts().length,
        busy: isBusy(), integration: integrationMaintenanceState, error: integrationMaintenanceError },
      retrieval: { lifecycle: currentObservation && retrievalWorker ? retrievalWorker.lifecycleStatus() : { state: "idle" as const, detail: "No running retrieval worker observed." },
        observedAt: currentObservation ? retrievalObservedAt : undefined,
        status: currentObservation ? { ready: currentObservation.ready, ready_generation: currentObservation.ready_generation,
          building_generation: currentObservation.building_generation, document_count: currentObservation.document_count, error: currentObservation.error } : undefined,
        error: retrievalObservationError },
      sync: dashboardSyncTargets(targets, githubSyncScheduler?.snapshot() || {}),
      tasks: backgroundTaskRegistry.snapshot(),
    };
  }, diagnostics);
  const tick = () => {
    try {
      const installed = installedBuild();
      const migration = !getStorePath() || integrationMaintenanceState === "ready" ? "ready"
        : integrationMaintenanceState === "error" ? "failed"
        : integrationMaintenanceState === "action-required" ? "action-required" : "pending";
      registry.heartbeat(isBusy(), "ready", migration);
      const lifecycle = retrievalWorker?.lifecycleStatus();
      const percent = indexBuildPercent(lifecycle?.progress);
      const indexSummary = retrievalObservationError ? "Index unavailable" : retrievalObservation && lifecycle?.state === "working"
        ? `Index ${percent === undefined ? "building" : `${percent}%`}`
        : retrievalObservation?.error ? "Index error" : retrievalObservation?.ready ? "Index ready" : "Index pending";
      const syncStates = Object.values(githubSyncScheduler?.snapshot() || {});
      const syncSummary = syncStates.some(state => ["error", "needs-attention", "blocked", "partial"].includes(state.status))
        ? "Sync needs attention" : syncStates.some(state => state.status === "syncing") ? "Sync running"
        : syncStates.some(state => state.status === "queued") ? "Sync queued"
        : syncStates.some(state => state.status === "scheduled") ? "Sync scheduled" : "Sync inactive";
      status.text = "PKM Status";
      status.tooltip = `Loaded: ${build.version} / ${build.buildId}\nInstalled: ${installed?.version ?? "unknown"} / ${installed?.buildId ?? "unknown"}\nVS Code: ${vscode.version}; Node: ${process.version}; PID: ${process.pid}\nIntegration: ${migration}\n${indexSummary}; ${syncSummary}\nRegistered online hosts: ${registry.hosts().length}\nOpen PKM Status Dashboard, Host log and diagnostics.`;
      void observeRetrieval();
      if (registry.poll(installed?.buildId, isBusy())) {
        log.info(`coordinated reload requested pid=${process.pid} target=${installed?.buildId}`);
        void vscode.commands.executeCommand("workbench.action.reloadWindow").then(undefined, error => {
          registry.heartbeat(isBusy(), "failed");
          log.error(`coordinated reload failed: ${String(error)}`);
        });
      }
    } catch (error) { log.warn(`Host runtime registry unavailable: ${String(error)}`); }
  };
  tick(); status.show();
  const timer = setInterval(tick, 2_000); timer.unref();
  context.subscriptions.push(status, dashboard, { dispose: () => {
    disposed = true; observationAbort.abort(); clearInterval(timer); indexTask.idle();
    try { registry.dispose(); } catch {}
  } },
    vscode.commands.registerCommand("personalKnowledge.hostStatus", async () => {
      await dashboard.open();
      // Callers (startup tests, automation) still need the verified host report, not just the opened dashboard.
      return { coverage: "Registered PKM hosts sharing this installation and profile storage only. Unregistered legacy hosts, other machines/profiles and external agent activity are not verified.",
        current: registry.identity, installed: installedBuild(), online: registry.hosts(), reload: registry.progress() ?? null,
        integration: { state: integrationMaintenanceState, error: integrationMaintenanceError } };
    }),
    vscode.commands.registerCommand("personalKnowledge.reloadAllHosts", async () => {
      const installed = installedBuild();
      if (!installed) { await vscode.window.showErrorMessage("Installed PKM build identity is missing. Install a verified package first."); return; }
      const hosts = registry.hosts();
      const answer = await vscode.window.showWarningMessage(`Reload ${hosts.length} registered PKM windows to ${installed.version} / ${installed.buildId.slice(0, 12)}?`, {
        modal: true, detail: "All extensions in these windows restart. Busy PKM Chat/background work will defer reload for up to five minutes. External agent activity is not tracked: stop it before continuing. Legacy unregistered hosts and other machines require separate reloads. Sending this request is not proof of completion; check Host Status for verified successor hosts.",
      }, "Reload registered windows");
      if (answer !== "Reload registered windows") return;
      try {
        const request = registry.requestReload(installed.buildId);
        log.info(`coordinated reload broadcast id=${request.id} hosts=${request.targets.length} target=${installed.buildId}`);
      } catch (error) { await vscode.window.showErrorMessage(String(error)); }
    }));
}

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  retrievalSolutionDisposed = false;
  activationStartedAt = Date.now();
  firstContentRecorded = false;
  performanceStateDir = path.join(context.globalStorageUri.fsPath, "performance");
  configureCopilotSdk({ storageDir: context.globalStorageUri.fsPath });
  log.init(context);
  let apiChat: ReturnType<typeof registerApiChatShell> | undefined;
  setChatStartupTrace(message => log.startup(`${message} (activation+${Date.now() - activationStartedAt}ms)`));
  try {
    apiChat = registerApiChatShell(context, async signal => {
      const { registerApiChat } = await import("./chat/api-chat-view");
      if (signal.aborted) throw new Error("PKM Chat backend loading was cancelled.");
      return registerApiChat(context, createChatKnowledgeRetriever(() => retrievalWorker, currentRetrievalSnapshot), false, async () => {
        await maintainPkmIntegration(context);
        if (integrationMaintenanceState !== "ready") {
          throw new Error(`PKM MCP preparation ${integrationMaintenanceState}: ${integrationMaintenanceError}`);
        }
      });
    });
    portalChatContext = (chatId, label) => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.portalContext(chatId, label);
    };
    portalInteraction = (chatId, interaction, current) => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.requestPortalInteraction(chatId, interaction, current);
    };
    portalChooseContext = () => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.choosePortalContext();
    };
    todoBoardConversionChat = (prompt, title) => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.runNoteBoardConversion(prompt, title);
    };
    portalChatBindingsReader = () => apiChat!.portalChatBindings();
    remoteChatExecutor = (prompt, signal, requestId, chatId, observer, source, profileSnapshot) => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.executeRemoteTask(prompt, signal, requestId, chatId, observer, source, profileSnapshot);
    };
    remoteTaskAttemptsReader = (chatId, requestId, replyId) => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.readPortalTaskAttempts(chatId, requestId, replyId);
    };
    portalProfileReview = chatId => {
      if (!apiChat) throw new Error("PKM Chat is unavailable.");
      return apiChat.reviewPortalProfiles(chatId);
    };
    portalReviewReceiver = (chatId, review) => apiChat!.receivePortalReview(chatId, review);
    portalCommandRecorder = (chatId, activity) => apiChat!.recordPortalCommand(chatId, activity);
    portalMutationGuard = chatId => apiChat!.assertPortalMutationAllowed(chatId);
    portalMutationPolicy = chatId => apiChat!.preparePortalMutationPolicy(chatId);
    portalTransferRecorder = (chatId, status, peerName) => apiChat!.recordPortalTransfer(chatId, status, peerName);
  } catch (error) {
    log.error(`PKM Chat initialization failed: ${error instanceof Error ? error.stack || error.message : String(error)}`);
    void vscode.window.showErrorMessage("PKM Chat could not initialize. Other PKM features remain available. See the Personal Knowledge Manager log for details.");
  }
  githubSyncDiagnostics.init(context);
  loadProfiler.init(context);
  loadProfiler.record("host.activation.started");
  let activationPhaseStartedAt = activationStartedAt;
  const activationPhases: Record<string, number> = {};
  const recordActivationPhase = (stage: string) => {
    const now = Date.now();
    const durationMs = now - activationPhaseStartedAt;
    activationPhases[stage] = durationMs;
    loadProfiler.record("host.activation.phase", { stage, durationMs, elapsedMs: now - activationStartedAt });
    activationPhaseStartedAt = now;
  };
  recordActivationPhase("shell");
  log.info(`activating extension v${context.extension?.packageJSON?.version ?? "?"}`);
  context.subscriptions.push(backgroundTaskRegistry.subscribe(snapshot => {
    if (panels.instances.size) void postToPanel({ command: "backgroundTasks", data: snapshot });
  }));
  context.subscriptions.push(new ActionBackgroundTasks(backgroundTaskRegistry, getStorePath, {
    enabled: () => _storeReady && vscode.workspace.isTrusted && configuredMcpFeatureDomains().includes("automation") && mcpRuntimeStatus().healthy,
    scan: () => actionRequest(context, "safety_scan", {}),
    report: error => log.warn(`Action safety scan failed: ${(error as Error).message || String(error)}`),
  }));
  initializeActionCommands(context);
  const userPortConfiguration = vscode.workspace.getConfiguration("personalKnowledge");
  const missingUserPorts = (["serversProxyPort", "contentGatewayPort", "chatHubPort"] as const)
    .filter(setting => userPortConfiguration.inspect<number>(setting)?.globalValue === undefined);
  await Promise.all(missingUserPorts.map(setting =>
    userPortConfiguration.update(setting, stableUserPort(setting), vscode.ConfigurationTarget.Global)));
  recordActivationPhase("ports");
  chatCtx = context;
  configurePortalRuntime({
    state: id => getChatMgr().portalStateForChat(id),
    permission: (id, tool, resource) => getChatMgr().portalToolAllowed(id, tool, resource),
    invalidate: id => getChatMgr().invalidatePortal(id),
    chatRemoved: id => getChatMgr().portalChatRemoved(id),
  });
  await migrateChatRecents(context);
  recordActivationPhase("chat-recents");
  const applyChatArchiveCfg = () => {
    const c = vscode.workspace.getConfiguration("personalKnowledge");
    const mb = Math.max(0, c.get<number>("chatHistoryLimitMB") ?? 10);
    const dir = path.join(context.globalStorageUri.fsPath, "chat-history");
    getChatMgr().configureArchive(dir, Math.round(mb * 1024 * 1024));
    const store = _storeReady ? getStorePath() : "";
    if (store) getChatMgr().configurePersistence(path.join(store, "chatrooms"), getChatInstallationId(context), context.secrets);
    getChatMgr().configurePortalJournal(context.globalState);
    getChatMgr().configurePersistentPortals(context);
  };
  applyChatArchiveCfg();
  void getChatMgr().cleanupPortalPersistence(context).catch(error => {
    log.error(`Portal legacy cleanup failed: ${String(error)}`);
    void vscode.window.showErrorMessage(`PKM Portal legacy cleanup failed: ${error instanceof Error ? error.message : String(error)}`);
  });
  recipeDraftFileSystem = new RecipeDraftFileSystem();
  context.subscriptions.push(
    vscode.commands.registerCommand("personalKnowledge.openActionRunProject", async (runId: string) => {
      if (!_storeReady || !vscode.workspace.isTrusted || !configuredMcpFeatureDomains().includes("automation")) throw new Error("Opening Action Run Projects requires a configured, trusted automation workspace.");
      const store = currentProjectStore();
      const projectId = await actionRunProject(store, getStorePath(), runId,
        async options => vscode.window.showQuickPick(options, { title: "Open Action Run in Project", placeHolder: "Choose its Project; execution state is not changed." }),
        (operation, input) => projectCommand(store, operation, input));
      if (projectId) openProjectCockpit(context, projectId);
      return projectId;
    }),
    vscode.commands.registerCommand("personalKnowledge.promoteChatToProject", async (source: { chatId: string; sessionId?: string; title?: string }) => {
      if (!_storeReady) throw new Error("Configure a Knowledge Root before promoting Chat.");
      const store = currentProjectStore();
      const projectId = await promoteChatProject(store, source,
        async () => vscode.window.showInputBox({ title: "Promote Chat to Project", prompt: "Create a Project linked to this Chat. Ordinary Chat remains unchanged; all other fields are optional.", value: source.title || "Chat Project", validateInput: value => value.trim() ? undefined : "Enter a Project name." }),
        (operation, input) => projectCommand(store, operation, input));
      if (projectId) openProjectCockpit(context, projectId);
      return projectId;
    }),
    vscode.commands.registerCommand("personalKnowledge.duplicatePanel", () => {
      const source = getOrCreatePanel(context);
      if (!panels.instances.get(source)?.ready) { createPanelInstance(context, panels.duplicate(source)); return; }
      // A live snapshot request includes keystrokes/scroll not yet delivered by the periodic sync.
      void source.webview.postMessage({ command: "duplicatePanelSnapshot" });
    }),
    vscode.commands.registerCommand("personalKnowledge.openEmbeddedActionLibrary", () => {
      const instance = getOrCreatePanel(context);
      const session = panels.instances.get(instance)!;
      session.snapshot.tab = "actionLibrary";
      session.snapshot.workspace = "automation";
      if (session.ready) void instance.webview.postMessage({ command: "openEmbeddedActionLibrary" });
      else session.pendingTab = "actionLibrary";
    }),
    vscode.commands.registerCommand("personalKnowledge.openEmbeddedActions", (target = {}) => {
      const instance = getOrCreatePanel(context);
      const session = panels.instances.get(instance)!;
      const current = session.snapshot.actions || {};
      const next = { ...current };
      if (target.runId) { next.currentRun = target.runId; next.lastRun = target.runId; delete next.targetAction; next.libraryOpen = false; }
      else if (target.actionId) { next.targetAction = target.actionId; next.currentRun = null; next.lastRun = null; next.libraryOpen = false; }
      else if (target.library) next.libraryOpen = true;
      session.snapshot.actions = next;
      if (session.ready) void instance.webview.postMessage({ command: "openEmbeddedActions", state: session.snapshot.actions });
      else session.pendingActions = next;
    }),
    vscode.commands.registerCommand("personalKnowledge.openActions", () => openActionWorkbench(context)),
    vscode.commands.registerCommand("personalKnowledge.openActionLibrary", () => openActionLibrary(context)),
    vscode.commands.registerCommand("personalKnowledge.portalControl", async (args: Record<string, unknown>, external = false) => getChatMgr().portalControl(context, args, external)),
    vscode.commands.registerCommand("personalKnowledge.portalPermissions", async (id: string) => getChatMgr().authorizePortalForChat(id)),
    vscode.commands.registerCommand("personalKnowledge.portalDiagnostics", async () => {
      const report = JSON.stringify(getChatMgr().portalDiagnostics(), null, 2);
      log.info(`Portal diagnostics:\n${report}`);
      await vscode.window.showTextDocument(await vscode.workspace.openTextDocument({ language: "json", content: report }), { preview: false });
    }),
    vscode.commands.registerCommand("personalKnowledge.portalPendingLink", async (id: string, action: "copy" | "void") => getChatMgr().portalPendingLink(id, action)),
    vscode.commands.registerCommand("personalKnowledge.peerCollaboration", async (owner?: { id: string; label: string }) => {
      try {
        const resolved = owner && portalChatContext ? await portalChatContext(owner.id) : await apiChat?.choosePortalContext();
        if (resolved) await getChatMgr().managePeer(context, resolved);
      }
      catch (error) { log.error(`peer collaboration: ${String(error)}`); await vscode.window.showErrorMessage(error instanceof Error ? error.message : String(error)); }
    }),
    vscode.commands.registerCommand("personalKnowledge.openActionsInBrowser", () => openActionWorkbenchInBrowser(context)),
    vscode.commands.registerCommand("personalKnowledge.configureActionWorkspace", async () => {
      const platformKey = process.platform === "win32" ? "windows" : process.platform === "darwin" ? "macos" : "linux";
      const configuration = vscode.workspace.getConfiguration("personalKnowledge");
      const roots = configuration.get<Record<string, string>>("actions.workspaceRoots", {});
      const selected = await vscode.window.showOpenDialog({ canSelectFiles: false, canSelectFolders: true, canSelectMany: false,
        title: "Select Action Working Directory", defaultUri: roots[platformKey] ? vscode.Uri.file(roots[platformKey]) : undefined });
      if (!selected?.[0]) return;
      await configuration.update("actions.workspaceRoots", { ...roots, [platformKey]: selected[0].fsPath }, vscode.ConfigurationTarget.Global);
      writeActionWorkspaceConfig();
      return selected[0].fsPath;
    }),
    vscode.workspace.registerFileSystemProvider("pkm-content", new KnowledgeContentFileSystem(), { isCaseSensitive: true }),
    vscode.workspace.registerFileSystemProvider("pkm-recipe-draft", recipeDraftFileSystem, { isCaseSensitive: true }),
    vscode.languages.registerCodeLensProvider([{ language: "markdown", scheme: "file" }, { language: "markdown", scheme: "pkm-content" }], new KnowledgeMetadataCodeLensProvider()),
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration("personalKnowledge.actions.workspaceRoots") || e.affectsConfiguration("personalKnowledge.actions.toolchains")) writeActionWorkspaceConfig();
      if (e.affectsConfiguration("personalKnowledge.logLevel")) log.refreshLevel();
      if (e.affectsConfiguration("personalKnowledge.loadProfilingEnabled")) loadProfiler.refresh();
      if (e.affectsConfiguration("personalKnowledge.chatHistoryLimitMB")) applyChatArchiveCfg();
      if (e.affectsConfiguration("personalKnowledge.externalLinkHost")) {
        const selected = externalLinkHostOptions();
        if (!selected.unavailable && chatCtx) getChatMgr().setAdvertisedHost(selected.resolved);
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
      }
      if (e.affectsConfiguration("personalKnowledge.contentGatewayPort")) {
        publicContentServer?.close();
        publicContentServer = undefined;
        publicContentActivePort = 0;
        void ensurePublicContentGateway(context).catch(error => log.warn(`public content gateway: ${(error as Error).message}`));
      }
      if (e.affectsConfiguration("personalKnowledge.skillRouterEnabledSolutions")
          || e.affectsConfiguration("personalKnowledge.skillRouterSourcePriority")) {
        writeSkillRouterRuntimeConfig(context);
        void skillRouterStatusData(context).then(data => postToPanel({ command: "skillRouterStatus", data }));
      }
      if (e.affectsConfiguration("personalKnowledge.mcpEnabledFeatureDomains") && getStorePath()) {
        try {
          writeMcpFeatureDomainConfig();
          refreshMcpDefinitions();
          postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        } catch (error) {
          log.error(`MCP feature domain update failed: ${(error as Error).message}`);
          void vscode.window.showErrorMessage(`MCP feature domain update failed: ${(error as Error).message}`);
        }
      }
      if (e.affectsConfiguration("personalKnowledge.agentSessionArchiveKeepLatestK") && _storeReady) {
        void agentSessionProjectStateData()
          .then(data => postToPanel({ command: "projectState", data }))
          .catch(error => {
            log.warn(`Agent Session archive retention configuration refresh failed: ${(error as Error).message}`);
            void vscode.window.showErrorMessage(`Agent Session archive retention failed: ${(error as Error).message}`);
          });
      }
      if (e.affectsConfiguration("personalKnowledge.storePath") || e.affectsConfiguration("personalKnowledge.environmentsPath") || e.affectsConfiguration("personalKnowledge.mcpPythonPath") || e.affectsConfiguration("personalKnowledge.mcpRuntimePath") || e.affectsConfiguration("personalKnowledge.mcpServerPath")) refreshMcpDefinitions();
    })
  );

  const cfg = vscode.workspace.getConfiguration("personalKnowledge");
  const initialResolution = resolvedStorePath(context);
  let configuredPath = initialResolution?.path || "";
  let firstConfiguration = false;
  log.debug(`machineStorePath="${configuredPath}" source=${initialResolution?.source || "none"}`);
  if (initialResolution) await rememberMachineStorePath(context, initialResolution.path);
  recordActivationPhase("store-path");

  // First-time setup: ask user where to store their knowledge base
  if (!configuredPath) {
    panelSession().pendingTab = "mcp";
    const chosen = await firstTimeSetup(context, false);
    if (!chosen) {
      vscode.window.showErrorMessage(
        "Personal Knowledge Manager: setup not completed. Click the sidebar icon or open the panel to configure.",
        "Configure now"
      ).then(v => { if (v) ensureSetup(context); });
    }
    configuredPath = chosen ?? "";
    firstConfiguration = !!chosen;
    if (firstConfiguration) {
      await context.globalState.update(ONBOARDING_PENDING_KEY, true);
      await context.globalState.update(ONBOARDING_COMPLETED_KEY, false);
    }
  }

  if (configuredPath) {
    fsSetStorePath(configuredPath);
    storageSetStorePath(configuredPath);
    setPrivacyStoreRoot(configuredPath);
    setKnowledgeGroupStoreRoot(configuredPath);
    knowledgeInventory = new KnowledgeInventoryManager(
      configuredPath,
      path.join(context.globalStorageUri.fsPath, "inventory"),
      path.join(__dirname, "knowledge-inventory-worker.js"),
    );
    publicContentTimer = setInterval(() => { void ensurePublicContentGateway(context).catch(() => {}); }, 5_000);
    publicContentTimer.unref?.();
    context.subscriptions.push({ dispose: () => {
      if (publicContentTimer) clearInterval(publicContentTimer);
      publicContentTimer = undefined;
      publicContentServer?.close();
      publicContentServer = undefined;
      publicContentActivePort = 0;
    } });
  }
  applyChatArchiveCfg();
  context.subscriptions.push(vscode.window.registerWebviewPanelSerializer("personalKnowledge", {
    async deserializeWebviewPanel(webviewPanel, state) {
      initializePanel(webviewPanel, context, true, state);
      if (!configuredPath) panels.instances.get(webviewPanel)!.pendingTab = "mcp";
    },
  }));
  const openPanelOnStartup = !!configuredPath && (firstConfiguration || cfg.get<boolean>("openOnStartup"));
  if (openPanelOnStartup) {
    getOrCreatePanel(context);
    activePanel()?.webview.postMessage({ command: "loadingProgress", data: { stage: "framework", percent: 3, message: "The library doors are opening…", detail: "Preparing each collection in turn…" } });
  }
  if (configuredPath) {
    const chatroomsRoot = path.join(getStorePath(), "chatrooms");
    const chatroomWatcher = createKnowledgeFileWatcher([chatroomsRoot]);
    let chatroomRefreshTimer: NodeJS.Timeout | undefined;
    const scheduleChatroomRefresh = () => {
      if (chatroomRefreshTimer) clearTimeout(chatroomRefreshTimer);
      chatroomRefreshTimer = setTimeout(() => {
        chatroomRefreshTimer = undefined;
        void getChatMgr().refreshStoredRooms().catch(error => log.warn(`chat: cross-window refresh failed: ${(error as Error).message}`));
      }, 200);
      chatroomRefreshTimer.unref?.();
    };
    chatroomWatcher.onDidCreate(scheduleChatroomRefresh);
    chatroomWatcher.onDidChange(scheduleChatroomRefresh);
    chatroomWatcher.onDidDelete(scheduleChatroomRefresh);
    context.subscriptions.push(chatroomWatcher, { dispose: () => { if (chatroomRefreshTimer) clearTimeout(chatroomRefreshTimer); } });
  }

  // Servers + Python Environments subsystems (machine-local runtime state).
  let initializeServers = () => {};
  try {
    const stateBase = context.globalStorageUri.fsPath;
    initPyenvs(path.join(stateBase, "environments"), m => log.info(`[env] ${m}`));
    if (configuredPath) {
      const pport = vscode.workspace.getConfiguration("personalKnowledge").get<number>("serversProxyPort", 39501);
      initializeServers = () => initServers(path.join(getStorePath(), "servers"), path.join(stateBase, "servers"), pport, m => log.info(`[servers] ${m}`));
    }
  } catch (e: any) { log.warn(`servers/env init failed: ${e?.message}`); }

  try {
    sharedMarket = new SharedMarketManager(
      path.join(context.globalStorageUri.fsPath, "subscriptions"),
      path.join(context.extensionPath, "dist", "subscription-gateway.js"),
      `${os.userInfo().username || "user"} / ${os.hostname()}`,
      {
        onChanged: () => {
          invalidatePendingSubscriptionGroupLists();
          postToPanel({ command: "subscriptionChanged" });
          writeSkillRouterRuntimeConfig(context);
          void skillRouterStatusData(context).then(data => postToPanel({ command: "skillRouterStatus", data }));
          _treeProvider?.refresh();
          scheduleRetrievalRefresh(context);
        },
        onWarning: message => { void vscode.window.showWarningMessage(message, "Open Subscription").then(choice => {
          if (choice !== "Open Subscription") return;
          if (activePanel()) { activePanel()!.reveal(vscode.ViewColumn.One); void activePanel()!.webview.postMessage({ command: "openTab", tab: "subscriptions" }); }
          else { panelSession().pendingTab = "subscriptions"; getOrCreatePanel(context); }
        }); },
        onDiagnostic: event => log.info(`subscription diagnostic ${JSON.stringify(event)}`),
      },
      context.secrets,
      { user: os.userInfo().username || "user", host: os.hostname(), version: String(context.extension.packageJSON.version || "unknown") },
    );
    const externalHost = externalLinkHostOptions().resolved;
    const marketState = sharedMarket.snapshot as any;
    if (externalHost && marketState.advertisedHost !== externalHost) {
      void sharedMarket.configure({ enabled: marketState.enabled, port: marketState.port, advertisedHost: externalHost, displayName: marketState.displayName })
        .then(() => sharedMarket?.startBackground())
        .catch(error => log.warn(`Subscription host update failed: ${(error as Error).message}`));
    } else sharedMarket.startBackground();
  } catch (error: any) { log.warn(`subscription init failed: ${error?.message || error}`); }
  registerNativeMcpProvider(context);
  context.subscriptions.push(
    vscode.commands.registerCommand("personalKnowledge.configureNativeMcpDiscovery", () => configurePkmMcp(context)),
    vscode.commands.registerCommand("personalKnowledge.offerPkmMcpConfiguration", (reason: string) => offerPkmMcpConfiguration(context, reason)),
    vscode.commands.registerCommand("personalKnowledge.registerCopilotMcp", () => registerCopilotMcpUserConfig()),
  );

  // Register sidebar tree view + commands FIRST so they're always available
  const treeProvider = new PkTreeProvider(context);
  _treeProvider = treeProvider;
  const treeView = vscode.window.createTreeView("personalKnowledge.sidebarView", {
    treeDataProvider: treeProvider,
    dragAndDropController: new PkTreeDragAndDropController(context),
    showCollapseAll: true,
  });
  const openMainPanel = async () => {
    log.action("command.open");
    if (!(await ensureSetup(context))) return;
    getOrCreatePanel(context);
  };
  context.subscriptions.push(vscode.commands.registerCommand("personalKnowledge.open", openMainPanel));
  context.subscriptions.push(vscode.commands.registerCommand("personalKnowledge.openHelp", (requested: unknown) => {
    const sections = ["start", "tools", "retrieval", "agents", "tasks", "workers", "memory", "recipes", "projects", "sharing", "snapshots", "setup", "troubleshooting"];
    const section = typeof requested === "string" && sections.includes(requested) ? requested : "troubleshooting";
    const target = getOrCreatePanel(context);
    target.reveal(vscode.ViewColumn.One);
    if (panelSession().ready) target.webview.postMessage({ command: "openTab", tab: "help", helpSection: section });
    else {
      panelSession().pendingTab = "help";
      panelSession().pendingHelpSection = section;
    }
  }));
  context.subscriptions.push(vscode.commands.registerCommand("_personalKnowledge.testNavigationPath", (area: string, segments: string[]) => {
    const rootType = `root-${area}`;
    let children = treeProvider.getChildren();
    const moduleType = ["skills", "notes", "papers"].includes(area) ? "module-knowledge"
      : ["prompts", "scripts", "packages", "environments", "servers"].includes(area) ? "module-tools"
      : undefined;
    if (moduleType) {
      const module = children.find(item => item.nodeType === moduleType);
      if (!module) return { found: false, missing: moduleType, children: children.map(item => item.label) };
      children = treeProvider.getChildren(module);
    }
    let current = children.find(item => item.nodeType === rootType);
    if (!current) return { found: false, missing: rootType, children: children.map(item => item.label) };
    for (const segment of segments || []) {
      children = treeProvider.getChildren(current);
      const next = children.find(item => Array.isArray(item.nodeData?.path) && item.nodeData.path[item.nodeData.path.length - 1] === segment);
      if (!next) return { found: false, missing: segment, children: children.map(item => ({ label: item.label, description: item.description, relPath: item.nodeData?.relPath })) };
      current = next;
    }
    children = treeProvider.getChildren(current);
    return { found: true, children: children.map(item => ({ label: item.label, description: item.description, relPath: item.nodeData?.relPath, key: item.nodeData?.key })) };
  }));
  context.subscriptions.push(vscode.commands.registerCommand("_personalKnowledge.testRecipeIntentDraft", async () => {
    const recipeId = "recipe_test_intent";
    const nodeId = "validate-guidance";
    const initial = "Brief: initial test intent.";
    const refreshed = "Brief: latest unsaved webview intent.";
    const edited = "Brief: edited through a real VS Code document save.";
    const storeBefore = canonicalJson(currentProjectStore().list());
    const uri = vscode.Uri.from({ scheme: "pkm-recipe-draft", authority: recipeId, path: `/${nodeId}.md` });
    recipeDraftFileSystem?.seed(uri, initial);
    const document = await vscode.workspace.openTextDocument(uri);
    recipeDraftFileSystem?.seed(uri, refreshed);
    const refreshDeadline = Date.now() + 3000;
    while (document.getText() !== refreshed && Date.now() < refreshDeadline) {
      await new Promise(resolve => setTimeout(resolve, 25));
    }
    const refreshedFromWebview = document.getText() === refreshed;
    const edit = new vscode.WorkspaceEdit();
    edit.replace(uri, new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length)), edited);
    const applied = await vscode.workspace.applyEdit(edit);
    const saved = applied && await document.save();
    const persistedDraft = Buffer.from(recipeDraftFileSystem?.readFile(uri) || []).toString("utf8");
    return {
      applied,
      saved,
      refreshedFromWebview,
      persistedDraft,
      projectStoreUnchanged: storeBefore === canonicalJson(currentProjectStore().list())
    };
  }));
  // Clicking the Activity Bar icon: ensure setup then open main panel
  const openVisibleSidebar = async () => {
    log.action("sidebar.open");
    await openMainPanel();
  };
  treeView.onDidChangeVisibility(e => {
    if (e.visible) {
      void openVisibleSidebar();
    }
  });
  context.subscriptions.push(treeView);
  if (treeView.visible) void openVisibleSidebar();

  context.subscriptions.push(
    vscode.commands.registerCommand("personalKnowledge.goToPkmPath", async (locator?: string) => {
      log.action("command.goToPkmPath");
      await goToPkmPath(context, locator);
    }),

    vscode.commands.registerCommand("personalKnowledge.openPanelTab", async (tab: string) => {
      if (!(await ensureSetup(context))) return;
      openPanelTab(context, String(tab || ""));
    }),
    vscode.commands.registerCommand("personalKnowledge.openNativeHarness", async (sessionId: string) => {
      nativeHarnessAccess(sessionId);
      openPanelTab(context, "agentSessions");
      if (panelSession().ready) void activePanel()?.webview.postMessage({ command:"openNativeHarness", sessionId });
      else panelSession().pendingNativeSessionId = sessionId;
    }),
    vscode.commands.registerCommand("personalKnowledge.readNativeHarness", (method: string, params: Record<string, unknown>) => nativeHarnessRequest(method, params)),

    vscode.commands.registerCommand("personalKnowledge.openRecipe", async (value: string | PkTreeItem) => {
      const recipeId = typeof value === "string" ? value : String(value?.nodeData?.recipeId || "");
      const opened = await openRecipeEditorInBrowser(recipeId);
      if (!opened) vscode.window.showErrorMessage("Could not open the Recipe editor in your browser.");
    }),

    vscode.commands.registerCommand("personalKnowledge.openSubscriptions", async (shareId?: string) => {
      log.action("command.openSubscriptions");
      if (!(await ensureSetup(context))) return;
      openSubscriptionPanel(context, String(shareId || ""));
    }),

    vscode.commands.registerCommand("personalKnowledge.openSubscribedServer", async (key: string) => {
      try {
        const server = getSharedMarket().cachedServerLinks(String(key || ""));
        const link = server.links[0]?.url;
        if (!link) throw new Error("No Server link is available.");
        await vscode.env.openExternal(vscode.Uri.parse(link));
      } catch (error: any) {
        vscode.window.showErrorMessage(`Open subscribed Server failed: ${error?.message || String(error)}`);
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.openSubscribedContent", async (type: SharedContentType, key: string) => {
      if (!SHARED_CONTENT_TYPES.includes(type) || type === "servers") return;
      openInPanel(context, "subscriptionItem", String(key || ""), false, type);
    }),

    vscode.commands.registerCommand("personalKnowledge.refreshTree", async () => {
      log.action("command.refreshTree");
      try {
        await refreshKnowledgeInventory(context, true);
        treeProvider.refresh();
        postToPanel({ command: "reloaded" });
      } catch (error) {
        vscode.window.showErrorMessage(`Navigation refresh failed: ${error instanceof Error ? error.message : String(error)}`);
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.classifyAssets", reviewAssetClassification),
    vscode.commands.registerCommand("personalKnowledge.rollbackAssetClassification", reviewAssetClassificationRollback),
    vscode.commands.registerCommand("personalKnowledge.editMarkdownMetadata", editMarkdownMetadata),
    vscode.commands.registerCommand("personalKnowledge.manageMarkdownAssets", async (item?: PkTreeItem) => {
      const area = item?.nodeData?.area || (item?.nodeType === "skill" ? "skills" : item?.nodeType === "note" ? "notes" : item?.nodeType === "paper" ? "papers" : "");
      const documentPath = item?.nodeData?.documentPath || item?.nodeData?.relPath;
      if (!["skills", "notes", "papers"].includes(area) || !documentPath) return;
      try {
        if ([...panels.instances.values()].some(session => session.markdownDraftOpen)) throw new Error("Save or close inline Markdown editors before managing resources.");
        if (await manageMarkdownAssets(area, documentPath)) {
          treeProvider.refresh();
          postToPanel({ command: "reloaded", data: { changedPath: `${area}/${documentPath}` } });
        }
      } catch (error) {
        log.error(`Markdown resource operation failed: ${String(error)}`);
        vscode.window.showErrorMessage(`Markdown resource operation failed: ${String(error)}`);
      }
    }),
    vscode.commands.registerCommand("personalKnowledge.editMarkdownContent", async (area: KnowledgeMarkdownArea, key: string) => {
      await openStoreMarkdown(area, key);
    }),

    vscode.commands.registerCommand("personalKnowledge.copyNavigationPath", async (item?: PkTreeItem) => {
      if (!item) return;
      const locator = navigationItemPath(item);
      await vscode.env.clipboard.writeText(locator);
      vscode.window.setStatusBarMessage(`$(copy) Copied PKM path: ${locator}`, 4000);
    }),

    vscode.commands.registerCommand("personalKnowledge.setFolderPrivate", async (item?: PkTreeItem) => {
      if (!item?.nodeData?.privacyTopLevel) return;
      const type = item.nodeData.privacyType as PrivacyContentType;
      const name = String(item.nodeData.privacyName || "");
      setTopLevelPrivacy(type, name, true);
      gitCommit(`privacy(${type}): ${name} private`);
      const changed = await sharedMarket?.refreshPublishedShares() || 0;
      treeProvider.refresh();
      if (activePanel()) await handleMessage({ command: "subscriptionState" }, message => postToPanel(message), context);
      vscode.window.setStatusBarMessage(`$(lock) ${name} is private${changed ? `; refreshed ${changed} Broker${changed === 1 ? "" : "s"}` : ""}`, 5000);
    }),

    vscode.commands.registerCommand("personalKnowledge.setFolderPublic", async (item?: PkTreeItem) => {
      if (!item?.nodeData?.privacyTopLevel) return;
      const type = item.nodeData.privacyType as PrivacyContentType;
      const name = String(item.nodeData.privacyName || "");
      setTopLevelPrivacy(type, name, false);
      gitCommit(`privacy(${type}): ${name} public`);
      const changed = await sharedMarket?.refreshPublishedShares() || 0;
      treeProvider.refresh();
      if (activePanel()) await handleMessage({ command: "subscriptionState" }, message => postToPanel(message), context);
      vscode.window.setStatusBarMessage(`$(unlock) ${name} is public${changed ? `; refreshed ${changed} Broker${changed === 1 ? "" : "s"}` : ""}`, 5000);
    }),

    vscode.commands.registerCommand("personalKnowledge.newSubgroup", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const group = navigationGroupInfo(item);
      if (!group) { vscode.window.showWarningMessage("Select a real group or category root."); return; }
      const value = await vscode.window.showInputBox({
        title: `New ${group.area} Subgroup`, prompt: `Create inside ${group.path || "Root"}; slash-separated paths create multiple levels`, placeHolder: "e.g. Research/Vision/Models",
        validateInput: input => normalizedSubgroupPath(input) ? undefined : "Enter one or more valid subgroup names separated by slashes",
      });
      if (!value) return;
      const suffix = normalizedSubgroupPath(value);
      if (!suffix) return;
      const destination = [group.path, suffix].filter(Boolean).join("/");
      if (group.maxDepth && destination.split("/").length > group.maxDepth) {
        vscode.window.showWarningMessage("Prompts support three group levels: Project / Task / Version. The next level is a Prompt file.");
        return;
      }
      if (folderList(group.area).includes(destination)) { vscode.window.showWarningMessage(`Group already exists: ${destination}`); return; }
      if (!folderCreate(group.area, destination)) { vscode.window.showErrorMessage(`Could not create subgroup: ${destination}`); return; }
      gitCommit(`add(subgroup): ${group.area}/${destination}`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(new-folder) Created ${group.area} subgroup ${destination}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.renameSubgroup", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const group = navigationGroupInfo(item);
      if (!group?.path) { vscode.window.showWarningMessage("Category roots cannot be renamed."); return; }
      const parts = group.path.split("/");
      const currentName = parts.pop()!;
      const parent = parts.join("/");
      const nextName = await vscode.window.showInputBox({
        title: `Rename ${group.area} Subgroup`, value: currentName, prompt: parent ? `Name within ${parent}` : "Subgroup name",
        validateInput: input => normalizedSubgroupPath(input) === input.trim() && !/[\\/]/.test(input) ? undefined : "Enter one valid subgroup name without slashes",
      });
      if (!nextName || nextName.trim() === currentName) return;
      const destination = [parent, nextName.trim()].filter(Boolean).join("/");
      const result = folderRename(group.area, group.path, destination);
      if (!result.ok) { vscode.window.showErrorMessage(`Rename subgroup failed: ${result.error || "unknown error"}`); return; }
      preserveTopLevelPrivacy(group.area as PrivacyContentType, group.path, destination);
      gitCommit(`rename(group): ${group.area}/${group.path} -> ${destination}`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(edit) Renamed ${group.area} group to ${destination}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteSubgroup", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const group = navigationGroupInfo(item);
      if (!group?.path) { vscode.window.showWarningMessage("Category roots cannot be deleted."); return; }
      if ((["skills", "notes", "papers", "prompts", "scripts"] as string[]).includes(group.area)) {
        const area = group.area as KnowledgeTrashArea | "skills";
        const choice = await vscode.window.showWarningMessage(
          `Move ${area} folder “${group.path}” and all its contents to Trash?`,
          { modal: true }, "Move to Trash",
        );
        if (choice !== "Move to Trash") return;
        try {
          await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification, title: `Moving ${area} folder to Trash: ${group.path}`, cancellable: false,
          }, async () => {
            await new Promise(resolve => setTimeout(resolve, 16));
            const trashed = area === "skills" ? skillFolderMoveToTrash(group.path)
              : knowledgeMoveToTrash(area, group.path, "folder", path.basename(group.path));
            if (!trashed) throw new Error(`Folder was not found: ${group.path}`);
            gitCommit(`trash(${area}-folder): ${trashed.originalPath}`);
            refreshKnowledgeGroups();
            vscode.window.setStatusBarMessage(`$(trash) Moved ${area} folder to Trash: ${group.path}`, 3000);
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          log.error(`Move ${area} folder to Trash failed: ${message}`);
          vscode.window.showErrorMessage(`Could not move ${area} folder to Trash: ${message}`);
        }
        return;
      }
      const full = path.join(getStorePath(), group.area, ...group.path.split("/"));
      const contents = fs.readdirSync(full).filter(name => name !== ".gitkeep");
      const parentPath = group.path.includes("/") ? group.path.slice(0, group.path.lastIndexOf("/")) : "";
      const currentName = group.path.split("/").pop() || "";
      const fallback = group.area === "prompts" && contents.length ? (currentName === "Ungrouped" ? "Recovered" : "Ungrouped") : "";
      const destination = [parentPath, fallback].filter(Boolean).join("/") || "Root";
      const choice = await vscode.window.showWarningMessage(
        contents.length ? `Delete ${group.area} subgroup “${group.path}”? Its contents will move to ${destination}. No files will be deleted.` : `Delete empty ${group.area} subgroup “${group.path}”?`,
        { modal: true }, "Delete Subgroup",
      );
      if (choice !== "Delete Subgroup") return;
      const result = folderDeletePromote(group.area, group.path, fallback);
      if (!result.ok) { vscode.window.showErrorMessage(`Delete subgroup failed: ${result.error || "unknown error"}`); return; }
      gitCommit(`delete(group): ${group.area}/${group.path} (${result.moved} promoted)`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(trash) Deleted ${group.area} group ${group.path}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.restoreSkillTrash", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || item?.nodeType !== "skill-trash-item") return;
      const result = skillTrashRestore(String(item.nodeData.id || ""));
      if (!result.ok) { vscode.window.showErrorMessage(`Restore from Skills Trash failed: ${result.error || "unknown error"}`); return; }
      gitCommit(`restore(skill-trash): ${result.path}`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(history) Restored ${result.path}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.emptySkillTrash", async () => {
      if (!(await ensureSetup(context))) return;
      const count = skillTrashList().length;
      if (!count) return;
      const choice = await vscode.window.showWarningMessage(
        `Permanently delete all ${count} entries in Skills Trash? This cannot be undone.`,
        { modal: true }, "Empty Trash",
      );
      if (choice !== "Empty Trash") return;
      skillTrashEmpty();
      gitCommit(`empty(skill-trash): ${count} entries`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(trash) Emptied Skills Trash`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteSkillTrashEntry", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || item?.nodeType !== "skill-trash-item") return;
      const choice = await vscode.window.showWarningMessage(
        `Permanently delete ${item.nodeData.kind} “${item.nodeData.name}” from Skills Trash? This cannot be undone.`,
        { modal: true }, "Delete Permanently",
      );
      if (choice !== "Delete Permanently") return;
      const result = skillTrashDelete(String(item.nodeData.id || ""));
      if (!result.ok) { vscode.window.showErrorMessage(`Permanent deletion failed: ${result.error || "unknown error"}`); return; }
      gitCommit(`delete(skill-trash): ${result.name}`);
      refreshKnowledgeGroups();
      vscode.window.setStatusBarMessage(`$(trash) Permanently deleted ${result.name}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.trashKnowledgeItem", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item) return;
      let area: KnowledgeTrashArea | undefined;
      let relativePath = "";
      if (item.nodeType === "note") { area = "notes"; relativePath = `${item.nodeData.key}.md`; }
      else if (item.nodeType === "paper") { area = "papers"; relativePath = `${item.nodeData.key}.md`; }
      else if (item.nodeType === "prompt-file") { area = "prompts"; relativePath = [item.nodeData.project, item.nodeData.task, item.nodeData.version, item.nodeData.file].join("/"); }
      else if (item.nodeType === "script-file") { area = "scripts"; relativePath = item.nodeData.key; }
      if (!area || !relativePath) return;
      const name = typeof item.label === "string" ? item.label : path.basename(relativePath);
      const choice = await vscode.window.showWarningMessage(`Move “${name}” to ${area} Trash?`, { modal: true }, "Move to Trash");
      if (choice !== "Move to Trash") return;
      const entry = knowledgeMoveToTrash(area, relativePath, "item", name);
      if (!entry) { vscode.window.showErrorMessage(`Could not move item to ${area} Trash.`); return; }
      gitCommit(`trash(${area}): ${entry.originalPath}`);
      refreshKnowledgeGroups();
    }),

    vscode.commands.registerCommand("personalKnowledge.restoreKnowledgeTrash", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || item?.nodeType !== "knowledge-trash-item") return;
      const area = item.nodeData.area as KnowledgeTrashArea;
      const result = knowledgeTrashRestore(area, String(item.nodeData.id || ""));
      if (!result.ok) { vscode.window.showErrorMessage(`Restore from ${area} Trash failed: ${result.error}`); return; }
      gitCommit(`restore(${area}-trash): ${result.path}`);
      refreshKnowledgeGroups();
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteKnowledgeTrashEntry", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || item?.nodeType !== "knowledge-trash-item") return;
      const area = item.nodeData.area as KnowledgeTrashArea;
      const choice = await vscode.window.showWarningMessage(`Permanently delete “${item.nodeData.name}” from ${area} Trash? This cannot be undone.`, { modal: true }, "Delete Permanently");
      if (choice !== "Delete Permanently") return;
      const result = knowledgeTrashDelete(area, String(item.nodeData.id || ""));
      if (!result.ok) { vscode.window.showErrorMessage(`Permanent deletion failed: ${result.error}`); return; }
      gitCommit(`delete(${area}-trash): ${result.path}`);
      refreshKnowledgeGroups();
    }),

    vscode.commands.registerCommand("personalKnowledge.emptyKnowledgeTrash", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || item?.nodeType !== "knowledge-trash") return;
      const area = item.nodeData.area as KnowledgeTrashArea;
      const count = knowledgeTrashList(area).length;
      if (!count) return;
      const choice = await vscode.window.showWarningMessage(`Permanently delete all ${count} entries in ${area} Trash? This cannot be undone.`, { modal: true }, "Empty Trash");
      if (choice !== "Empty Trash") return;
      const result = knowledgeTrashEmpty(area);
      if (!result.ok) {
        vscode.window.showErrorMessage(`Empty ${area} Trash failed after deleting ${result.count} of ${count} entries: ${result.error}`);
        refreshKnowledgeGroups();
        return;
      }
      gitCommit(`empty(${area}-trash): ${result.count} entries`);
      refreshKnowledgeGroups();
    }),

    // ── Add new item at a folder (right-click on container) ────────────────
    vscode.commands.registerCommand("personalKnowledge.addRecipeHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const category = item?.nodeType === "recipe-folder" ? String(item.nodeData.relPath || "") : "";
      const name = await vscode.window.showInputBox({ prompt: "New Recipe name", placeHolder: "e.g. Publish release" });
      if (!name?.trim()) return;
      const store = currentProjectStore();
      const input = { scope: "global", name: name.trim(), category };
      const result = store.createRecipe(projectCommand(store, "recipe-create", input), { kind: "global" }, input.name, category);
      gitCommit(`add(recipe): ${category ? `${category}/` : ""}${input.name}`);
      treeProvider.refresh();
      await openRecipeEditorInBrowser(result.entityId || "");
    }),

    vscode.commands.registerCommand("personalKnowledge.newRecipeSubfolder", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const parent = item?.nodeType === "recipe-folder" ? String(item.nodeData.relPath || "") : "";
      const value = await vscode.window.showInputBox({
        title: "New Recipe Subfolder",
        prompt: `Create inside ${parent || "Recipe Library"}; slash-separated paths create multiple levels`,
        placeHolder: "e.g. Release/Validation",
        validateInput: input => normalizedSubgroupPath(input) && !input.split("/").some(segment => segment.trim() === "(uncategorized)")
          ? undefined : "Enter one or more valid folder names separated by slashes",
      });
      if (!value) return;
      const name = normalizedSubgroupPath(value);
      if (!name) return;
      const store = currentProjectStore();
      const input = { parent, name };
      const result = store.createRecipeFolder(projectCommand(store, "recipe-folder-create", input), parent, name);
      gitCommit(`add(recipe-folder): ${result.entityId}`);
      treeProvider.refresh();
      if (activePanel()) postToPanel({ command: "projectState", data: await agentSessionProjectStateData() });
      vscode.window.setStatusBarMessage(`$(new-folder) Created Recipe folder ${result.entityId}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteRecipeFolder", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const folder = item?.nodeType === "recipe-folder" ? String(item.nodeData.relPath || "") : "";
      if (!folder) { vscode.window.showWarningMessage("Select a Recipe folder to delete."); return; }
      const parent = folder.includes("/") ? folder.slice(0, folder.lastIndexOf("/")) : "Recipe Library root";
      const choice = await vscode.window.showWarningMessage(
        `Delete Recipe folder “${folder}”? Its Recipes and subfolders will move to ${parent}; no Recipes will be deleted.`,
        { modal: true }, "Delete Folder",
      );
      if (choice !== "Delete Folder") return;
      const store = currentProjectStore();
      store.deleteRecipeFolder(projectCommand(store, "recipe-folder-delete", { folder }), folder);
      if (!folder.includes("/") && isTopLevelPrivate("recipes", folder)) setTopLevelPrivacy("recipes", folder, false);
      gitCommit(`delete(recipe-folder): ${folder}`);
      treeProvider.refresh();
      if (activePanel()) postToPanel({ command: "projectState", data: await agentSessionProjectStateData() });
      vscode.window.setStatusBarMessage(`$(trash) Deleted Recipe folder ${folder}; contents moved to ${parent}`, 4000);
    }),

    vscode.commands.registerCommand("personalKnowledge.addSkillHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const cat = await selectKnowledgeFolder("skills", categoryFromTreeItem(item));
      if (cat === undefined) return;
      const name = await vscode.window.showInputBox({ prompt: "New skill name", placeHolder: "e.g. my-new-skill" });
      if (!name?.trim()) return;
      if (skillGet(name.trim())) { vscode.window.showWarningMessage(`Skill already exists: ${name.trim()}`); return; }
      skillUpsert({ name: name.trim(), content: "", category: cat || undefined });
      gitCommit(`add(skill): ${name.trim()}`);
      treeProvider.refresh();
      await openStoreMarkdown("skills", cat ? `${cat}/${name.trim()}` : name.trim());
    }),

    vscode.commands.registerCommand("personalKnowledge.addNoteHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const cat = await selectKnowledgeFolder("notes", categoryFromTreeItem(item));
      if (cat === undefined) return;
      const title = await vscode.window.showInputBox({ prompt: "New note title", placeHolder: "e.g. Investigation findings" });
      if (!title?.trim()) return;
      const key = (cat ? cat + "/" : "") + title.trim();
      if (noteGet(key)) { vscode.window.showWarningMessage(`Note already exists: ${key}`); return; }
      const documentKind = await vscode.window.showQuickPick(["Markdown", "Todo Board"], { placeHolder: "Choose document type" });
      if (!documentKind) return;
      if (documentKind === "Todo Board") todoBoardCreate(key, title.trim(), cat);
      else noteUpsert({ slug: key, title: title.trim(), content: "", type: "general", tags: [], category: cat });
      gitCommit(`add(note): ${title.trim()}`);
      treeProvider.refresh();
      await openStoreMarkdown("notes", key);
    }),

    vscode.commands.registerCommand("personalKnowledge.addPaperHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const category = await selectKnowledgeFolder("papers", categoryFromTreeItem(item));
      if (category === undefined) return;
      const title = await vscode.window.showInputBox({ prompt: "New paper title", placeHolder: "e.g. Attention Is All You Need" });
      if (!title?.trim()) return;
      const slug = uniquePaperSlug(title.trim(), category);
      if (paperGet(slug)) { vscode.window.showWarningMessage(`Paper or idea already exists: ${slug}`); return; }
      paperUpsert({ slug, title: title.trim(), content: "", category, kind: "paper" });
      gitCommit(`add(paper): ${slug}`);
      treeProvider.refresh();
      await openStoreMarkdown("papers", slug);
    }),

    vscode.commands.registerCommand("personalKnowledge.addIdeaHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const category = await selectKnowledgeFolder("papers", categoryFromTreeItem(item));
      if (category === undefined) return;
      const title = await vscode.window.showInputBox({ prompt: "New idea title", placeHolder: "e.g. Retrieval with adaptive memory" });
      if (!title?.trim()) return;
      const slug = uniquePaperSlug(title.trim(), category);
      if (paperGet(slug)) { vscode.window.showWarningMessage(`Paper or idea already exists: ${slug}`); return; }
      paperUpsert({ slug, title: title.trim(), content: "", category, kind: "idea" });
      gitCommit(`add(idea): ${slug}`);
      treeProvider.refresh();
      await openStoreMarkdown("papers", slug);
    }),

    vscode.commands.registerCommand("personalKnowledge.addPromptHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const data = item?.nodeData ?? {};
      const project = data.project || await vscode.window.showInputBox({ prompt: "Prompt project" });
      if (!project?.trim()) return;
      const task = data.task || await vscode.window.showInputBox({ prompt: "Prompt task" });
      if (!task?.trim()) return;
      const version = data.version || await vscode.window.showInputBox({ prompt: "Prompt version", value: "v1" });
      if (!version?.trim()) return;
      const file = await vscode.window.showInputBox({
        prompt: "New prompt filename",
        placeHolder: "prompt.md",
        validateInput: value => value?.trim() && !/[\\/]/.test(value) ? null : "Enter a filename without slashes",
      });
      if (!file?.trim()) return;
      const segments = [project, task, version, file].map(value => String(value).trim());
      if (segments.some(value => value === "." || value === "..")) return;
      const full = path.join(getStorePath(), "prompts", ...segments);
      if (fs.existsSync(full)) { vscode.window.showWarningMessage(`Prompt already exists: ${segments.join("/")}`); return; }
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, "");
      gitCommit(`add(prompt): ${segments.join("/")}`);
      treeProvider.refresh();
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(full));
      await vscode.window.showTextDocument(doc, { preview: false });
    }),

    vscode.commands.registerCommand("personalKnowledge.addScriptHere", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context))) return;
      const folder = (item?.nodeData?.path ?? []).join("/");
      await createScriptAtFolder(folder);
    }),

    // ── Edit item (right-click on a leaf) ─────────────────────────────────
    vscode.commands.registerCommand("personalKnowledge.editSkill", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item?.nodeData?.key) return;
      await openStoreMarkdown("skills", item.nodeData.key);
    }),
    vscode.commands.registerCommand("personalKnowledge.editNote", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item?.nodeData?.key) return;
      await openStoreMarkdown("notes", item.nodeData.key);
    }),
    vscode.commands.registerCommand("personalKnowledge.editPaper", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item?.nodeData?.key) return;
      await openStoreMarkdown("papers", item.nodeData.key);
    }),
    vscode.commands.registerCommand("personalKnowledge.editScript", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item?.nodeData?.key) return;
      const full = path.join(getStorePath(), "scripts", item.nodeData.key);
      const document = await vscode.workspace.openTextDocument(vscode.Uri.file(full));
      await vscode.window.showTextDocument(document, { preview: false });
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteScript", async (item?: PkTreeItem) => {
      if (!(await ensureSetup(context)) || !item?.nodeData?.key) return;
      const relativePath = String(item.nodeData.key);
      const choice = await vscode.window.showWarningMessage(`Move Script “${relativePath}” to Trash?`, { modal: true }, "Move to Trash");
      if (choice !== "Move to Trash") return;
      const entry = knowledgeMoveToTrash("scripts", relativePath, "item", path.basename(relativePath));
      if (!entry) { vscode.window.showErrorMessage(`Could not move Script to Trash: ${relativePath}`); return; }
      gitCommit(`trash(script): ${entry.originalPath}`);
      refreshKnowledgeGroups();
    }),

    vscode.commands.registerCommand("personalKnowledge.openSkill", async (name: string) => {
      log.action("command.openSkill", { name });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "skill", name);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openNote", async (slug: string) => {
      log.action("command.openNote", { slug });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "note", slug);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openPaper", async (slug: string) => {
      log.action("command.openPaper", { slug });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "paper", slug);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openPrompt", async (key: string) => {
      log.action("command.openPrompt", { key });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "prompt", key);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openPackage", async (name: string) => {
      log.action("command.openPackage", { name });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "package", name);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openScript", async (key: string) => {
      log.action("command.openScript", { key });
      if (!(await ensureSetup(context))) return;
      openInPanel(context, "script", key);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.addNote", async () => {
      if (!(await ensureSetup(context))) return;
      openPanelTab(context, "notes");
      void vscode.commands.executeCommand("personalKnowledge.addNoteHere");
    }),

    vscode.commands.registerCommand("personalKnowledge.saveSkill", async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;
      const selection = editor.document.getText(editor.selection);
      if (!selection) { vscode.window.showInformationMessage("Select text first to save as a skill."); return; }

      const name = await vscode.window.showInputBox({
        prompt: "Skill name (slug)", placeHolder: "e.g. my-workflow-tip",
        validateInput: v => v?.trim() ? null : "Name required",
      });
      if (!name) return;
      const category = await vscode.window.showInputBox({ prompt: "Category (optional)", placeHolder: "e.g. dlis" });
      skillUpsert({ name: name.trim(), content: selection, category: category?.trim() });
      gitCommit(`save(skill): ${name.trim()}`);
      vscode.window.setStatusBarMessage("$(check) Skill saved to knowledge store", 3000);
      postToPanel({ command: "saved" });
      treeProvider.refresh();
    }),

    vscode.commands.registerCommand("personalKnowledge.setupMcp", async () => {
      log.action("command.setupMcp");
      const p = getOrCreatePanel(context);
      p.reveal(vscode.ViewColumn.One);
      if (panelSession().ready) p.webview.postMessage({ command: "openTab", tab: "mcp" });
      else panelSession().pendingTab = "mcp";
    }),

    vscode.commands.registerCommand("personalKnowledge.removeLegacyAgentInjection", async () => {
      const answer = await vscode.window.showWarningMessage(
        "Remove legacy PKM-generated Agent Router files? Private backups will be saved. Canonical Skills and user-authored files will not be removed.",
        { modal: true }, "Back Up and Remove",
      );
      if (answer !== "Back Up and Remove") return;
      try {
        const backupDirectory = path.join(context.globalStorageUri.fsPath, "retired-agent-injection");
        const result = await retirePkmSkillProjections(context, backupDirectory);
        log.action("pkmSkill.retire", { removed: result.removed, preserved: result.preserved, backupDirectory });
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        await vscode.window.showInformationMessage(
          `Removed ${result.removed.length} generated Router file(s); preserved ${result.preserved.length} unowned or unsafe file(s). Backups: ${backupDirectory}`,
        );
        return result;
      } catch (error) {
        log.warn(`legacy Agent injection removal failed: ${(error as Error).message}`);
        await vscode.window.showErrorMessage(`Legacy Agent injection removal failed: ${(error as Error).message}`);
        throw error;
      }
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.reconfigureKnowledgeRoot", async () => {
      const previousRoot = _storeReady ? getStorePath() : "";
      const chosen = await firstTimeSetup(context, true);
      if (!chosen || chosen === previousRoot) return { cancelled: true };
      await chatMgr?.dispose();
      chatMgr = undefined;
      disposeServers();
      const proxyPort = vscode.workspace.getConfiguration("personalKnowledge").get<number>("serversProxyPort", 39501);
      try {
        _storeReady = false;
        await initStore(context, chosen);
        applyChatArchiveCfg();
        ensureGitRepo();
        startFileWatcher(context);
        const resetTargetIds = await mutateGitHubSyncTargets(context, "Knowledge Root change", targets => {
          for (const target of targets) {
            delete target.lastSync;
            delete target.lastFailure;
          }
          return { targets, result: targets.map(target => target.id) };
        });
        for (const targetId of resetTargetIds) clearGitHubSyncConflict(githubSyncStateDirectory(context), targetId);
        configureGitHubSyncScheduler(context);
        initServers(path.join(chosen, "servers"), path.join(context.globalStorageUri.fsPath, "servers"), proxyPort, message => log.info(`[servers] ${message}`));
        mcpPathSizeGeneration += 1;
        mcpPathSizeCache.clear();
        refreshMcpDefinitions();
        treeProvider.refresh();
        postToPanel({ command: "reloaded" });
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        vscode.window.showInformationMessage(`Knowledge Root changed on ${extensionHostDescription(process.platform, os.hostname(), vscode.env.remoteName || "")}: ${chosen}. Chatroom history now uses ${path.join(chosen, "chatrooms")}; existing Rooms were not moved.`);
        void maintainPkmIntegration(context);
        return { ok: true, message: `Knowledge Root changed to ${chosen}.` };
      } catch (error: any) {
        if (previousRoot && directoryExists(previousRoot)) {
          await rememberMachineStorePath(context, previousRoot, true);
          _storeReady = false;
          await initStore(context, previousRoot);
          applyChatArchiveCfg();
          startFileWatcher(context);
          configureGitHubSyncScheduler(context);
          initServers(path.join(previousRoot, "servers"), path.join(context.globalStorageUri.fsPath, "servers"), proxyPort, message => log.info(`[servers] ${message}`));
        }
        refreshMcpDefinitions();
        treeProvider.refresh();
        postToPanel({ command: "reloaded" });
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        vscode.window.showErrorMessage(`Knowledge Root change failed and the previous root was restored: ${error?.message || String(error)}`);
        return { ok: false, error: `Knowledge Root change failed and the previous root was restored: ${error?.message || String(error)}` };
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.reconfigureEnvironmentsRoot", async () => {
      const chosen = await chooseEnvironmentsRoot(context);
      if (!chosen) return { cancelled: true };
      const configuration = vscode.workspace.getConfiguration("personalKnowledge");
      const previous = configuration.get<string>("environmentsPath", "");
      const runtimeIsDerived = !configuration.get<string>("mcpRuntimePath", "").trim();
      const derivedRuntime = path.join(chosen, "pkm-mcp");
      if (runtimeIsDerived && !safeMcpRuntimeTarget(derivedRuntime)) {
        vscode.window.showErrorMessage(`Cannot use this Environments Root: ${derivedRuntime} is not an empty or PKM-managed runtime directory.`);
        return { ok: false, error: `Cannot use this Environments Root: ${derivedRuntime} is not an empty or PKM-managed runtime directory.` };
      }
      await configuration.update("environmentsPath", chosen, vscode.ConfigurationTarget.Global);
      try {
        refreshMcpDefinitions();
        if (runtimeIsDerived) {
          await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: "Rebuilding PKM MCP Runtime in the new Environments Root", cancellable: false }, () => ensureMcpRuntime(context));
        }
      } catch (error: any) {
        await configuration.update("environmentsPath", previous || undefined, vscode.ConfigurationTarget.Global);
        refreshMcpDefinitions();
        mcpPathSizeGeneration += 1;
        mcpPathSizeCache.clear();
        treeProvider.refresh();
        postToPanel({ command: "envList", data: envListForUi() });
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        vscode.window.showErrorMessage(`Environments Root was restored because reconfiguration failed: ${error?.message || String(error)}`);
        return { ok: false, error: `Environments Root was restored because reconfiguration failed: ${error?.message || String(error)}` };
      }
      mcpPathSizeGeneration += 1;
      mcpPathSizeCache.clear();
      treeProvider.refresh();
      postToPanel({ command: "envList", data: envListForUi() });
      postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
      vscode.window.showInformationMessage(`Environments Root changed to ${chosen}. Existing environments were not moved.`);
      return { ok: true, message: `Environments Root changed to ${chosen}. Managed runtime status was refreshed.` };
    }),

    vscode.commands.registerCommand("personalKnowledge.reconfigureMcpRuntimePath", async () => {
      const current = managedMcpRuntimePath();
      const defaultPath = path.join(managedEnvironmentsRoot(), "pkm-mcp");
      const chosen = await chooseMachineDirectory("Managed MCP Runtime Path", current, defaultPath, "The runtime will be created or rebuilt at the new path. The previous runtime directory is not deleted automatically.");
      if (!chosen) return { cancelled: true };
      if (!safeMcpRuntimeTarget(chosen)) {
        vscode.window.showErrorMessage(`Refusing to replace non-PKM directory: ${chosen}. Choose an empty directory or an existing PKM-managed runtime.`);
        return { ok: false, error: `Refusing to replace non-PKM directory: ${chosen}. Choose an empty directory or an existing PKM-managed runtime.` };
      }
      const configuration = vscode.workspace.getConfiguration("personalKnowledge");
      const previous = configuration.get<string>("mcpRuntimePath", "");
      await configuration.update("mcpRuntimePath", chosen, vscode.ConfigurationTarget.Global);
      try {
        refreshMcpDefinitions();
        await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: "Rebuilding PKM MCP Runtime", cancellable: false }, () => ensureMcpRuntime(context));
      } catch (error: any) {
        await configuration.update("mcpRuntimePath", previous || undefined, vscode.ConfigurationTarget.Global);
        refreshMcpDefinitions();
        mcpPathSizeGeneration += 1;
        mcpPathSizeCache.clear();
        treeProvider.refresh();
        postToPanel({ command: "envList", data: envListForUi() });
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        vscode.window.showErrorMessage(`Managed MCP Runtime path was restored because rebuilding failed: ${error?.message || String(error)}`);
        return { ok: false, error: `Managed MCP Runtime path was restored because rebuilding failed: ${error?.message || String(error)}` };
      }
      mcpPathSizeGeneration += 1;
      mcpPathSizeCache.clear();
      treeProvider.refresh();
      postToPanel({ command: "envList", data: envListForUi() });
      postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
      vscode.window.showInformationMessage(`Managed MCP Runtime is ready at ${chosen}.`);
      return { ok: true, message: `Managed MCP Runtime is healthy and ready at ${chosen}.` };
    }),

    vscode.commands.registerCommand("personalKnowledge.reconfigureMcpServerPath", async () => {
      const current = managedMcpServerDirectory();
      const defaultPath = path.join(getStorePath(), "mcp-server");
      const chosen = await chooseMachineDirectory("MCP Server Directory", current, defaultPath, "Generated server.py, chat_server.py, and requirements.txt will be regenerated at the new path. The previous directory is not deleted automatically.");
      if (!chosen) return { cancelled: true };
      if (!safeMcpServerTarget(chosen)) {
        vscode.window.showErrorMessage(`Refusing to overwrite non-PKM directory: ${chosen}. Choose an empty directory or an existing PKM-generated server directory.`);
        return { ok: false, error: `Refusing to overwrite non-PKM directory: ${chosen}. Choose an empty directory or an existing PKM-generated server directory.` };
      }
      const configuration = vscode.workspace.getConfiguration("personalKnowledge");
      const previous = configuration.get<string>("mcpServerPath", "");
      await configuration.update("mcpServerPath", chosen, vscode.ConfigurationTarget.Global);
      try {
        await generateMcpServer(context);
      } catch (error: any) {
        await configuration.update("mcpServerPath", previous || undefined, vscode.ConfigurationTarget.Global);
        refreshMcpDefinitions();
        mcpPathSizeGeneration += 1;
        mcpPathSizeCache.clear();
        postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
        vscode.window.showErrorMessage(`MCP Server Directory was restored because generation failed: ${error?.message || String(error)}`);
        return { ok: false, error: `MCP Server Directory was restored because generation failed: ${error?.message || String(error)}` };
      }
      mcpPathSizeGeneration += 1;
      mcpPathSizeCache.clear();
      refreshMcpDefinitions();
      postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
      vscode.window.showInformationMessage(`PKM MCP server code regenerated at ${chosen}. Restart pkm in each MCP client.`);
      return { ok: true, message: `PKM MCP server code was regenerated at ${chosen}. Restart pkm in each MCP client.` };
    }),

    vscode.commands.registerCommand("personalKnowledge.openChatroom", async () => {
      log.action("command.openChatroom");
      openChatroomPanel(context);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openServers", async (slug?: string) => {
      log.action("command.openServers");
      openServerPanel(context, String(slug || ""));
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.openServerLink", async (item?: PkTreeItem) => {
      const slug = String(item?.nodeData?.slug || "");
      const server = (await serverListForUi(context)).find(row => row.slug === slug);
      const link = server?.networkLinks?.find((candidate: any) => candidate.kind === "hostname") || server?.networkLinks?.[0];
      if (!link?.url) { vscode.window.showWarningMessage(`No network link is available for ${server?.name || slug}.`); return; }
      await vscode.env.openExternal(vscode.Uri.parse(link.url));
    }),

    vscode.commands.registerCommand("personalKnowledge.openEnvironments", async (environmentId?: string) => {
      log.action("command.openEnvironments");
      openEnvironmentPanel(context, String(environmentId || ""));
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.startServerItem", async (item: PkTreeItem) => {
      const slug = String(item?.nodeData?.slug || "");
      if (!slug) return;
      const result = startServer(slug);
      if (!result.ok) vscode.window.showErrorMessage(`Start failed: ${result.error || "unknown error"}`);
      else await ensureServerForwarding(context, slug);
      await treeProvider.refreshServerStatus();
    }),

    vscode.commands.registerCommand("personalKnowledge.stopServerItem", async (item: PkTreeItem) => {
      const slug = String(item?.nodeData?.slug || "");
      if (!slug) return;
      stopServer(slug);
      await treeProvider.refreshServerStatus();
    }),

    vscode.commands.registerCommand("personalKnowledge.restartServerItem", async (item: PkTreeItem) => {
      const slug = String(item?.nodeData?.slug || "");
      if (!slug) return;
      const result = await restartServer(slug);
      if (!result.ok) vscode.window.showErrorMessage(`Restart failed: ${result.error || "unknown error"}`);
      else await ensureServerForwarding(context, slug);
      await treeProvider.refreshServerStatus();
    }),

    vscode.commands.registerCommand("personalKnowledge.moveServerToGroup", async (item: PkTreeItem) => {
      const slug = String(item?.nodeData?.slug || "");
      if (!slug) return;
      const server = (await serverList()).find(row => row.slug === slug);
      if (!server) { vscode.window.showErrorMessage("Server not found."); return; }
      type GroupPick = vscode.QuickPickItem & { category?: string; create?: boolean };
      const groups = serverGroupList();
      const picks: GroupPick[] = [
        { label: "Ungrouped", description: server.category ? "" : "Current group", category: "" },
        { label: "Existing groups", kind: vscode.QuickPickItemKind.Separator },
        ...groups.map(category => ({ label: category === "Hidden" ? "$(eye-closed) Hidden" : `$(folder) ${category}`, description: server.category === category ? "Current group" : category === "Hidden" ? "Excluded from Navigation" : "", category })),
        { label: "Create", kind: vscode.QuickPickItemKind.Separator },
        { label: "$(add) New subgroup…", description: "Create a subgroup and move this Server", create: true },
      ];
      const picked = await vscode.window.showQuickPick(picks, { title: `Move “${server.name}” to Group`, placeHolder: "Choose an existing group or create a new one" });
      if (!picked) return;
      let category = picked.category;
      if (picked.create) {
        const value = await vscode.window.showInputBox({ title: "New Server Subgroup", prompt: "Slash-separated subgroup path", placeHolder: "e.g. Research/Vision", validateInput: input => input.trim() ? undefined : "Subgroup path is required" });
        if (!value) return;
        const created = serverCreateGroup(value);
        if (!created.ok) { vscode.window.showErrorMessage(`Create Server group failed: ${created.error || "unknown error"}`); return; }
        category = created.group || "";
      }
      if (category === undefined || category === server.category) return;
      if (!serverUpdate(slug, { category })) { vscode.window.showErrorMessage("Could not move Server to the selected group."); return; }
      gitCommit(`server move: ${slug} -> ${category || "(root)"}`);
      await treeProvider.refreshServerStatus();
      postToPanel({ command: "serverGroupList", data: serverGroupList() });
      postToPanel({ command: "serverList", data: await serverListForUi(context) });
    }),

    vscode.commands.registerCommand("personalKnowledge.createServerGroupFromNavigation", async (item?: PkTreeItem) => {
      const parent = item?.nodeType === "server-group" ? (item.nodeData.path || []).join("/") : "";
      const value = await vscode.window.showInputBox({
        title: "New Server Subgroup", prompt: `Create inside ${parent || "Servers"}; slash-separated paths create multiple levels`, placeHolder: "e.g. Research/Vision",
        validateInput: input => input.trim() ? undefined : "Subgroup path is required",
      });
      if (!value) return;
      const suffix = normalizedSubgroupPath(value);
      if (!suffix) { vscode.window.showWarningMessage("Enter one or more valid subgroup names separated by slashes."); return; }
      const destination = [parent, suffix].filter(Boolean).join("/");
      const result = serverCreateGroup(destination);
      if (!result.ok) { vscode.window.showErrorMessage(`Create Server group failed: ${result.error || "unknown error"}`); return; }
      gitCommit(`server group create: ${result.group}`);
      await treeProvider.refreshServerStatus();
      postToPanel({ command: "serverGroupList", data: serverGroupList() });
      vscode.window.setStatusBarMessage(`$(new-folder) Created Server subgroup ${result.group}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.renameServerGroupFromNavigation", async () => {
      const groups = serverGroupList().filter(group => group !== "Hidden");
      if (!groups.length) { vscode.window.showInformationMessage("No renameable Server subgroups."); return; }
      const picked = await vscode.window.showQuickPick(groups.map(group => ({ label: `$(folder) ${group}`, group })), {
        title: "Rename Server Subgroup", placeHolder: "Choose a subgroup to rename",
      });
      if (!picked) return;
      const parts = picked.group.split("/");
      const currentName = parts.pop() || picked.group;
      const parent = parts.join("/");
      const nextName = await vscode.window.showInputBox({
        title: `Rename Server Subgroup “${picked.group}”`, value: currentName, prompt: parent ? `Name within ${parent}` : "Subgroup name",
        validateInput: value => value.trim() && !/[\\/]/.test(value) ? undefined : "Enter one subgroup name without slashes",
      });
      if (!nextName || nextName.trim() === currentName) return;
      const newPrefix = [parent, nextName.trim()].filter(Boolean).join("/");
      const result = serverMoveGroup(picked.group, newPrefix);
      if (!result.ok) { vscode.window.showErrorMessage(`Rename Server group failed: ${result.error || "unknown error"}`); return; }
      preserveTopLevelPrivacy("servers", picked.group, newPrefix);
      gitCommit(`server group move: ${picked.group} -> ${newPrefix}`);
      await treeProvider.refreshServerStatus();
      postToPanel({ command: "serverGroupList", data: serverGroupList() });
      postToPanel({ command: "serverList", data: await serverListForUi(context) });
      vscode.window.setStatusBarMessage(`$(edit) Renamed Server subgroup to ${newPrefix}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteServerGroupFromNavigation", async () => {
      const groups = serverGroupList().filter(group => group !== "Hidden");
      if (!groups.length) { vscode.window.showInformationMessage("No deletable Server subgroups."); return; }
      const rows = await serverList();
      const picked = await vscode.window.showQuickPick(groups.map(group => ({
        label: `$(folder) ${group}`,
        description: `${rows.filter(server => server.category === group || String(server.category || "").startsWith(group + "/")).length} Server(s)`,
        group,
      })), { title: "Delete Server Subgroup", placeHolder: "Choose a subgroup; no Server files will be deleted" });
      if (!picked) return;
      const parts = picked.group.split("/");
      const name = parts.pop() || picked.group;
      const parent = parts.join("/");
      if (privateTopLevelPromotionBlocked("servers", picked.group, parent)) {
        vscode.window.showWarningMessage(`Set private Server group “${picked.group}” as Public before deleting it into Ungrouped.`);
        return;
      }
      const choice = await vscode.window.showWarningMessage(
        `Delete Server subgroup “${picked.group}”? Its Servers and nested subgroups will move to ${parent ? `“${parent}”` : "Ungrouped"}. No Server files will be deleted.`,
        { modal: true }, "Delete Subgroup",
      );
      if (choice !== "Delete Subgroup") return;
      const result = serverMoveGroup(picked.group, parent);
      if (!result.ok) { vscode.window.showErrorMessage(`Delete Server group failed: ${result.error || "unknown error"}`); return; }
      gitCommit(`server group delete: ${picked.group}`);
      await treeProvider.refreshServerStatus();
      postToPanel({ command: "serverGroupList", data: serverGroupList() });
      postToPanel({ command: "serverList", data: await serverListForUi(context) });
      vscode.window.setStatusBarMessage(`$(trash) Deleted Server subgroup ${name}`, 3000);
    }),

    vscode.commands.registerCommand("personalKnowledge.renameServerGroup", async (item: PkTreeItem) => {
      const parts = [...(item?.nodeData?.path || [])];
      const currentName = String(parts.pop() || "");
      if (!currentName) return;
      const nextName = await vscode.window.showInputBox({
        title: "Rename Server Subgroup", value: currentName, prompt: "Subgroup name",
        validateInput: value => value.trim() && !/[\\/]/.test(value) ? undefined : "Enter one subgroup name without slashes",
      });
      if (!nextName || nextName.trim() === currentName) return;
      const oldPrefix = [...parts, currentName].join("/");
      const newPrefix = [...parts, nextName.trim()].join("/");
      const result = serverMoveGroup(oldPrefix, newPrefix);
      if (!result.ok) vscode.window.showErrorMessage(`Rename Server group failed: ${result.error || "unknown error"}`);
      else {
        preserveTopLevelPrivacy("servers", oldPrefix, newPrefix);
        gitCommit(`server group move: ${oldPrefix} -> ${newPrefix}`); await treeProvider.refreshServerStatus();
        postToPanel({ command: "serverGroupList", data: serverGroupList() });
        postToPanel({ command: "serverList", data: await serverListForUi(context) });
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteServerGroup", async (item: PkTreeItem) => {
      const parts = [...(item?.nodeData?.path || [])];
      const name = String(parts.pop() || "");
      if (!name) return;
      const parent = parts.join("/");
      const oldPrefix = [...parts, name].join("/");
      if (privateTopLevelPromotionBlocked("servers", oldPrefix, parent)) {
        vscode.window.showWarningMessage(`Set private Server group “${oldPrefix}” as Public before deleting it into Ungrouped.`);
        return;
      }
      const choice = await vscode.window.showWarningMessage(
        `Delete Server subgroup “${name}”? Its Servers and nested subgroups will move to ${parent ? `“${parent}”` : "Ungrouped"}. No Server files will be deleted.`,
        { modal: true }, "Delete Subgroup",
      );
      if (choice !== "Delete Subgroup") return;
      const result = serverMoveGroup(oldPrefix, parent);
      if (!result.ok) vscode.window.showErrorMessage(`Delete Server group failed: ${result.error || "unknown error"}`);
      else {
        gitCommit(`server group delete: ${oldPrefix}`); await treeProvider.refreshServerStatus();
        postToPanel({ command: "serverGroupList", data: serverGroupList() });
        postToPanel({ command: "serverList", data: await serverListForUi(context) });
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.openHostedRoomItem", async (itemOrRoomId: PkTreeItem | string) => {
      const roomId = typeof itemOrRoomId === "string" ? itemOrRoomId : String(itemOrRoomId?.nodeData?.roomId || "");
      if (!roomId) return;
      try { await openHostedRoom(context, roomId); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't open Hosted Room: ${error?.message || error}`); }
    }),

    vscode.commands.registerCommand("personalKnowledge.renameHostedRoom", async (item: PkTreeItem) => {
      const room = item?.nodeData as HostedRoomNavigationItem;
      if (!room?.roomId) return;
      try { await promptRenameHostedRoom(room); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't rename Room: ${error?.message || error}`); }
    }),

    vscode.commands.registerCommand("personalKnowledge.repairStoredRoom", async (item: PkTreeItem) => {
      const room = item?.nodeData as HostedRoomNavigationItem;
      if (!room?.roomId || room.active) return;
      try {
        const repaired = await getChatMgr().repairStoredRoom(room.roomId);
        const orphanDetail = repaired.closedOrphans
          ? ` Closed ${repaired.closedOrphans} inactive local Room instance${repaired.closedOrphans === 1 ? "" : "s"}.`
          : "";
        vscode.window.showInformationMessage(`Repaired "${repaired.roomName}". Preserved ${repaired.messageCount} message${repaired.messageCount === 1 ? "" : "s"}.${orphanDetail}`);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't repair Stored Room: ${error?.message || error}`);
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.forceCloseHostedRoom", async (item: PkTreeItem) => {
      const room = item?.nodeData as HostedRoomNavigationItem;
      if (!room?.roomId || !room.canForceClose) { vscode.window.showErrorMessage("Force Close is available only for your own Room hosted elsewhere with a verified Host credential."); return; }
      const choice = await vscode.window.showWarningMessage(
        `Force the active Host to close “${room.roomName}”? Connected participants will be disconnected. History and credentials are preserved for Rehost.`,
        { modal: true, detail: `Active endpoint: ${room.activeUrl || "unavailable"}` },
        "Force Close Host",
      );
      if (choice !== "Force Close Host") return;
      try {
        await getChatMgr().forceCloseHostedRoom(room.roomId);
        treeProvider.refreshChatStatus();
        vscode.window.showInformationMessage(`Closed the active Host for “${room.roomName}”. You can now Rehost it.`);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Couldn't force-close the active Host: ${error?.message || error}`);
      }
    }),

    vscode.commands.registerCommand("personalKnowledge.closeHostedRoom", async (item: PkTreeItem) => {
      const room = item?.nodeData as HostedRoomNavigationItem;
      if (!room?.roomId || !room.active) return;
      try { await getChatMgr().closeHostedRoomById(room.roomId); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't close Room: ${error?.message || error}`); }
    }),

    vscode.commands.registerCommand("personalKnowledge.deleteHostedRoom", async (item: PkTreeItem) => {
      const room = item?.nodeData as HostedRoomNavigationItem;
      if (!room?.roomId || room.active) return;
      try { await confirmAndDeleteStoredRoom(context, room.roomId, room.roomName); }
      catch (error: any) { vscode.window.showErrorMessage(`Couldn't delete Room: ${error?.message || error}`); }
    }),

    vscode.commands.registerCommand("personalKnowledge.openChatRoomItem", async (id: string) => {
      const entry = chatRecents(context).find(room => room.id === id);
      const recentSecret = entry ? await chatRecentSecret(context, entry.id) : "";
      if (!entry || (!entry.host && !recentSecret)) {
        vscode.window.showWarningMessage("This room has no saved key. Join it again using a fresh Magic Link.");
        return;
      }
      const manager = getChatMgr();
      if (manager.activateRoom(entry.url, entry.room, entry.roomId)) {
      } else if (entry.host) {
        const reachable = await probeChatRoomActive(entry.url, entry.room, entry.roomId);
        if (reachable) {
          const secret = manager.getRoomKey(entry.room);
          if (!secret) { vscode.window.showWarningMessage("This Room is hosted by another Extension instance."); return; }
          manager.joinRoom({ url: entry.url, room: entry.room, roomId: entry.roomId, user: entry.user, token: secret, cid: getChatCid(context) });
        } else {
          const result = await manager.startHub(entry.port);
          if (!result.ok) { vscode.window.showErrorMessage(`Couldn't Rehost Room: ${result.error}`); return; }
          try {
            const hosted = entry.roomId
              ? await manager.rehostRoom(entry.roomId)
              : await manager.createHostedRoom(entry.room, recentSecret || undefined);
            const url = `ws://127.0.0.1:${manager.hubPort}`;
            manager.joinRoom({ url, room: hosted.room, roomId: hosted.roomId, user: entry.user, token: hosted.secret, cid: getChatCid(context), hostToken: hosted.hostToken });
            await saveChatRecent(context, { url, room: hosted.room, roomId: hosted.roomId, user: entry.user, host: true });
          } catch (error: any) {
            vscode.window.showErrorMessage(`Couldn't Rehost Room: ${error?.message || error}`);
            return;
          }
        }
      } else {
        manager.joinRoom({ url: entry.url, room: entry.room, roomId: entry.roomId, user: entry.user, token: recentSecret, cid: getChatCid(context) });
        await saveChatRecent(context, entry);
      }
      openChatroomPanel(context);
      await closeNavigationSidebar();
    }),

    vscode.commands.registerCommand("personalKnowledge.showLogs", () => log.show()),

    vscode.commands.registerCommand("personalKnowledge.setAiKey", async () => {
      const key = await vscode.window.showInputBox({
        prompt: "Enter your AI API key (stored securely in VS Code SecretStorage)",
        password: true,
        ignoreFocusOut: true,
        placeHolder: "sk-… or Azure key",
      });
      if (key === undefined) return; // cancelled
      if (key.trim()) {
        await context.secrets.store("personalKnowledge.aiApiKey", key.trim());
        vscode.window.showInformationMessage("Personal Knowledge Manager: AI API key saved.");
      } else {
        await context.secrets.delete("personalKnowledge.aiApiKey");
        vscode.window.showInformationMessage("Personal Knowledge Manager: AI API key cleared.");
      }
    })
  );

  // Initialize the file store (runs the one-time DB→files migration) if configured
  recordActivationPhase("registration");
  if (configuredPath) {
    try {
      await initStore(context, configuredPath);
      applyChatArchiveCfg();
      log.info(`file store ready at ${getStorePath()}`);
      recordActivationPhase("store");
      startFileWatcher(context);
      recordActivationPhase("watchers");
      if (githubSyncStartupTimer) clearTimeout(githubSyncStartupTimer);
      githubSyncStartupTimer = setTimeout(() => {
        githubSyncStartupTimer = undefined;
        configureGitHubSyncScheduler(context);
      }, 10_000);
      githubSyncStartupTimer.unref?.();
      treeProvider.refresh();
      postToPanel({ command: "saved" }); // re-fetch if panel already open
      setImmediate(() => {
        activePanel()?.webview.postMessage({ command: "loadingProgress", data: { stage: "background", percent: 82, message: "Setting the library wards…" } });
        if (!fs.existsSync(path.join(getStorePath(), ".git"))) ensureGitRepo();
        schedulePublishedShareRefresh(context, 10_000);
        if (firstConfiguration) void maybeSeedExamples(context).catch(error => log.warn(`example seed failed: ${(error as Error).message}`));
        scheduleRetrievalRefresh(context, 10_000);
        void refreshKnowledgeInventory(context);
        void maintainPkmIntegration(context);
      });
    } catch (e: any) {
      log.error(`store init failed: ${e?.stack ?? e?.message}`);
      vscode.window.showErrorMessage(`Personal Knowledge Manager: failed to initialize store — ${e.message}`);
    }
  }

  const activationDuration = Date.now() - activationStartedAt;
  recordPerformanceMetrics(performanceStateDir, {
    "startup.activation_ms": { value: activationDuration },
    ...Object.fromEntries(Object.entries(activationPhases).map(([stage, value]) => [`startup.phase.${stage}_ms`, { value }])),
  });
  loadProfiler.record("host.activation.completed", { durationMs: activationDuration });
  log.info(`activation complete durationMs=${activationDuration}`);
  try {
    registerExtensionHostRuntime(context, () => apiChat?.isBusy === true || backgroundTaskRegistry.snapshot().tasks.some(task => task.status === "running"));
  } catch (error) { log.warn(`Host coordination unavailable: ${String(error)}`); }
  setImmediate(() => {
    activePanel()?.webview.postMessage({ command: "loadingProgress", data: { stage: "servers", percent: 12, message: "Preparing the Muggle gateway…" } });
    try { initializeServers(); }
    catch (error) { log.warn(`deferred Servers initialization failed: ${(error as Error).message}`); }
    void treeProvider.refreshServerStatus();
  });
}

// ── File watcher: auto-refresh when notes/skills change on disk ─────────────
function createKnowledgeFileWatcher(roots: string[], accept?: (filename: string) => boolean, descend?: (directory: string) => boolean) {
  return createBoundedFileWatcher(roots, {
    toEvent: filename => vscode.Uri.file(filename),
    onError: error => log.warn(`PKM file watcher: ${error.message}`),
    accept,
    descend,
  });
}

let _watcher: ReturnType<typeof createKnowledgeFileWatcher> | undefined;
let _privacyWatcher: ReturnType<typeof createKnowledgeFileWatcher> | undefined;
let _projectStateWatcher: ReturnType<typeof createKnowledgeFileWatcher> | undefined;
let _projectContentWatcher: ReturnType<typeof createKnowledgeFileWatcher> | undefined;
let _recipeContentWatcher: ReturnType<typeof createKnowledgeFileWatcher> | undefined;
let _watcherRefreshTimer: NodeJS.Timeout | undefined;
let _projectStateRefreshTimer: NodeJS.Timeout | undefined;
let _watcherFallbackTimer: NodeJS.Timeout | undefined;
let _watcherSignatureController: AbortController | undefined;
let _knowledgeTreeSignature = "";
let _watcherSkillProjectionChanged = false;

async function knowledgeTreeSignature(root = getStorePath(), signal?: AbortSignal): Promise<string> {
  const entries: string[] = [];
  let visited = 0;
  const checkCancelled = () => { if (signal?.aborted) throw new Error("Knowledge signature scan cancelled."); };
  checkCancelled();
  await assertPkmWatchRootAllowed(root);
  const visit = async (relative: string): Promise<void> => {
    checkCancelled();
    let names: string[];
    try { names = await fs.promises.readdir(path.join(root, relative)); } catch { return; }
    for (const name of names) {
      checkCancelled();
      if (name.startsWith(".") || name === "_assets" || !isPkmWatchDirectory(name)) continue;
      const child = relative ? path.join(relative, name) : name;
      if (githubSyncIgnoredPath(child)) continue;
      try {
        const stat = await fs.promises.lstat(path.join(root, child));
        if (stat.isSymbolicLink()) continue;
        if (stat.isDirectory()) await visit(child);
        else entries.push(`${child.replace(/\\/g, "/")}:${stat.mtimeMs}:${stat.size}`);
      } catch { /* file changed while scanning; the next pass will observe it */ }
      if (++visited % 64 === 0) await new Promise<void>(resolve => setImmediate(resolve));
    }
  };
  for (const area of ["notes", "skills", "papers", "prompts", "scripts", "packages", "servers", "recipes", "actions", "action-module-sets", "profiles"]) {
    checkCancelled();
    const startedAt = Date.now();
    const previousCount = entries.length;
    await assertPkmWatchRootAllowed(path.join(root, area));
    await visit(area);
    loadProfiler.record("knowledge.signature.area", { area, durationMs: Date.now() - startedAt, files: entries.length - previousCount });
    await new Promise<void>(resolve => setImmediate(resolve));
  }
  checkCancelled();
  return entries.sort().join("\n");
}

function startFileWatcher(context: vscode.ExtensionContext): void {
  _watcher?.dispose();
  _privacyWatcher?.dispose();
  _projectStateWatcher?.dispose();
  _projectContentWatcher?.dispose();
  _recipeContentWatcher?.dispose();
  if (_watcherRefreshTimer) clearTimeout(_watcherRefreshTimer);
  if (_projectStateRefreshTimer) clearTimeout(_projectStateRefreshTimer);
  if (_watcherFallbackTimer) clearInterval(_watcherFallbackTimer);
  _watcherSignatureController?.abort();
  const signatureController = new AbortController();
  _watcherSignatureController = signatureController;
  _watcherRefreshTimer = undefined;
  _projectStateRefreshTimer = undefined;
  _watcherFallbackTimer = undefined;
  contentCheckTask.idle();
  _watcherSkillProjectionChanged = false;
  _knowledgeTreeSignature = "";
  let signatureInitialized = false;
  let signatureCheck: Promise<void> | undefined;
  let signatureDirty = false;
  let fallbackRequested = false;
  const signatureRoot = getStorePath();
  const checkContents = (fallback = false): void => {
    if (signatureController.signal.aborted) return;
    signatureDirty = true;
    fallbackRequested ||= fallback;
    if (signatureCheck) return;
    signatureCheck = (async () => {
      contentCheckTask.running({ detail: "Checking local content in background" });
      do {
        signatureDirty = false;
        const compare = fallbackRequested;
        fallbackRequested = false;
        const signature = await knowledgeTreeSignature(signatureRoot, signatureController.signal);
        if (signatureController.signal.aborted) return;
        const changed = !signatureInitialized || signature !== _knowledgeTreeSignature;
        _knowledgeTreeSignature = signature;
        signatureInitialized = true;
        if (compare && changed) {
          invalidateSharedContentCatalog();
          _treeProvider?.refresh();
          if (panels.instances.size) void postToPanel({ command: "reloaded", data: { fallback: true } });
          scheduleRetrievalRefresh(context);
          githubSyncScheduler?.notifyContentChanged();
          log.info("file watcher fallback detected a knowledge tree change");
        }
      } while (signatureDirty && !signatureController.signal.aborted);
    })().catch(error => {
      if (!signatureController.signal.aborted) log.warn(`knowledge signature check failed: ${String(error)}`);
    }).finally(() => {
      signatureCheck = undefined;
      if (!signatureController.signal.aborted) queueNextContentCheck();
    });
  };
  const projectScopes = new Set<string>();
  const projectPaths = new Set<string>();
  const knowledgePaths = new Set<string>();
  const queueProjectRefresh = (scope: string, uri: vscode.Uri) => {
    projectScopes.add(scope);
    projectPaths.add(path.relative(getStorePath(), uri.fsPath).replace(/\\/g, "/"));
    if (_projectStateRefreshTimer) clearTimeout(_projectStateRefreshTimer);
    _projectStateRefreshTimer = setTimeout(() => {
      _projectStateRefreshTimer = undefined;
      const scopes = [...projectScopes].sort();
      const changedPaths = [...projectPaths].sort();
      projectScopes.clear();
      projectPaths.clear();
      for (const entry of nativeHarnessServers.values()) entry.server?.changed();
      if (![...panels.instances.values()].some(session => session.ready && session.panel?.visible)) return;
      void postToPanel({ command: "projectStateChanged", data: {
        scope: scopes.length === 1 ? scopes[0] : "all", scopes, changedPaths,
        ...(changedPaths.length === 1 ? { changedPath: changedPaths[0] } : {}),
      } });
    }, 250);
    _projectStateRefreshTimer.unref?.();
  };
  _watcher = createKnowledgeFileWatcher(
    ["notes", "skills", "papers", "prompts", "scripts", "packages", "servers", "actions", "action-module-sets", "profiles"].map(area => path.join(signatureRoot, area)),
  );
  const onChange = (uri: vscode.Uri) => {
    const relativePath = path.relative(getStorePath(), uri.fsPath).replace(/\\/g, "/");
    if (githubSyncIgnoredPath(relativePath)) return;
    knowledgePaths.add(relativePath);
    if (uri.fsPath === path.join(getStorePath(), "skills", "System", "PKM", "PKM Skills.md")) {
      _watcherSkillProjectionChanged = true;
    }
    if (_watcherRefreshTimer) return;
    _watcherRefreshTimer = setTimeout(() => {
      _watcherRefreshTimer = undefined;
      const changedPaths = [...knowledgePaths].sort();
      knowledgePaths.clear();
      void (async () => {
        const ignored = await githubSyncExcludedPaths(signatureRoot,
          changedPaths.filter(relative => relative !== ".pkm/content-privacy.json"));
        const relevantPaths = changedPaths.filter(relative => !ignored.has(relative));
        if (signatureController.signal.aborted || !relevantPaths.length) return;
        invalidateSharedContentCatalog();
        checkContents();
        _treeProvider?.refresh();
        postToPanel({ command: "reloaded", data: {
          changedPaths: relevantPaths, ...(relevantPaths.length === 1 ? { changedPath: relevantPaths[0] } : {}),
        } });
        schedulePublishedShareRefresh(context);
        scheduleRetrievalRefresh(context);
        void refreshKnowledgeInventory(context);
        const targets = readGitHubSyncTargets(context);
        if (targets.some(target => target.automation.enabled && target.automation.syncOnChange
          && relevantPaths.some(relative => {
            const type = GITHUB_SYNC_CONTENT_TYPES.find(area => area === relative.split("/")[0]);
            if (!type) return true;
            return [target.selection.public[type], target.selection.private[type]]
              .some(selection => selection.items.length > 0 || selection.folders.length > 0);
          }))) githubSyncScheduler?.notifyContentChanged();
        if (_watcherSkillProjectionChanged) {
          _watcherSkillProjectionChanged = false;
          postToPanel({ command: "mcpStatus", data: mcpPanelStatusData() });
          void maintainPkmIntegration(context);
        }
      })().catch(error => log.warn(`knowledge watcher refresh failed: ${String(error)}`));
    }, 250);
    _watcherRefreshTimer.unref?.();
  };
  _watcher.onDidCreate(onChange);
  _watcher.onDidChange(onChange);
  _watcher.onDidDelete(onChange);
  _privacyWatcher = createKnowledgeFileWatcher([path.join(signatureRoot, ".pkm", "content-privacy.json")]);
  _privacyWatcher.onDidCreate(onChange);
  _privacyWatcher.onDidChange(onChange);
  _privacyWatcher.onDidDelete(onChange);
  const stateRoot = path.join(signatureRoot, ".pkm", "state");
  _projectStateWatcher = createKnowledgeFileWatcher(
    ["projects.json", "project-store.json", "agent-groups", "api-chats", "agent-sessions", "agent-sessions-trash", "recipe-runs", "actions/runs", "mcp-usage/todos"]
      .map(area => path.join(stateRoot, area)),
    filename => filename.endsWith(".json"),
    directory => {
      const chatRelative = path.relative(path.join(stateRoot, "api-chats"), directory).replace(/\\/g, "/");
      if (chatRelative === "" || /^[a-f0-9]{16}$/.test(chatRelative)) return true;
      if (chatRelative !== ".." && !chatRelative.startsWith("../")) return false;
      const relative = path.relative(path.join(stateRoot, "actions", "runs"), directory).replace(/\\/g, "/");
      if (relative === ".." || relative.startsWith("../")) return true;
      return relative === "" || /^action_run_[a-f0-9]{32}(?:\/(?:steps|step-events))?$/.test(relative);
    },
  );
  const onProjectStateChange = (uri: vscode.Uri) => {
    agentSessionJsonCache.invalidate(uri.fsPath);
    const relativeStatePath = path.relative(path.join(getStorePath(), ".pkm", "state"), uri.fsPath).replace(/\\/g, "/");
    const scope = relativeStatePath === "projects.json" || relativeStatePath === "project-store.json" ? "projects"
      : relativeStatePath.startsWith("recipe-runs/") ? "recipeRuns" : "agentSessions";
    if (scope === "projects") {
      invalidateSharedContentCatalog();
      githubSyncScheduler?.notifyContentChanged();
      schedulePublishedShareRefresh(context);
    }
    queueProjectRefresh(scope, uri);
  };
  _projectStateWatcher.onDidCreate(onProjectStateChange);
  _projectStateWatcher.onDidChange(onProjectStateChange);
  _projectStateWatcher.onDidDelete(onProjectStateChange);
  _projectContentWatcher = createKnowledgeFileWatcher([path.join(signatureRoot, "project")]);
  const onProjectContentChange = (uri: vscode.Uri) => {
    invalidateSharedContentCatalog();
    githubSyncScheduler?.notifyContentChanged();
    schedulePublishedShareRefresh(context);
    queueProjectRefresh("projects", uri);
  };
  _projectContentWatcher.onDidCreate(onProjectContentChange);
  _projectContentWatcher.onDidChange(onProjectContentChange);
  _projectContentWatcher.onDidDelete(onProjectContentChange);
  _recipeContentWatcher = createKnowledgeFileWatcher([path.join(signatureRoot, "recipes")]);
  const onRecipeContentChange = (uri: vscode.Uri) => {
    invalidateSharedContentCatalog();
    githubSyncScheduler?.notifyContentChanged();
    schedulePublishedShareRefresh(context);
    scheduleRetrievalRefresh(context);
    queueProjectRefresh("recipes", uri);
  };
  _recipeContentWatcher.onDidCreate(onRecipeContentChange);
  _recipeContentWatcher.onDidChange(onRecipeContentChange);
  _recipeContentWatcher.onDidDelete(onRecipeContentChange);
  const fallbackIntervalMs = 5 * 60_000;
  const queueNextContentCheck = () => contentCheckTask.queued({
    detail: "Periodic filesystem safety check",
    nextRunAt: new Date(Date.now() + fallbackIntervalMs).toISOString(),
  });
  queueNextContentCheck();
  setImmediate(() => checkContents());
  _watcherFallbackTimer = setInterval(() => checkContents(true), fallbackIntervalMs);
  _watcherFallbackTimer.unref?.();
  context.subscriptions.push(_watcher, _privacyWatcher, _projectStateWatcher, _projectContentWatcher, _recipeContentWatcher);
}

export async function deactivate(): Promise<void> {
  retrievalSolutionDisposed = true;
  void disposeCopilotSdk();
  if (retrievalSolutionTimer) clearTimeout(retrievalSolutionTimer);
  _watcherSignatureController?.abort();
  _watcherSignatureController = undefined;
  githubSyncScheduler?.dispose();
  githubSyncScheduler = undefined;
  githubSyncCoordinatorStatePath = undefined;
  _watcher?.dispose();
  _privacyWatcher?.dispose();
  _projectStateWatcher?.dispose();
  _projectContentWatcher?.dispose();
  _recipeContentWatcher?.dispose();
  if (_watcherRefreshTimer) clearTimeout(_watcherRefreshTimer);
  if (_projectStateRefreshTimer) clearTimeout(_projectStateRefreshTimer);
  if (_watcherFallbackTimer) clearInterval(_watcherFallbackTimer);
  if (retrievalRefreshTimer) clearTimeout(retrievalRefreshTimer);
  if (publishedShareRefreshTimer) clearTimeout(publishedShareRefreshTimer);
  if (githubSyncStartupTimer) clearTimeout(githubSyncStartupTimer);
  _watcherRefreshTimer = undefined;
  _projectStateRefreshTimer = undefined;
  _watcherFallbackTimer = undefined;
  retrievalRefreshTimer = undefined;
  publishedShareRefreshTimer = undefined;
  githubSyncStartupTimer = undefined;
  backgroundTaskRegistry.clear();
  githubSyncTasks.clear();
  disposeServers();
  await chatMgr?.dispose();
  sharedMarket?.dispose();
  sharedMarket = undefined;
  liveNoteServer?.close();
  liveNoteServer = undefined;
  liveNoteBaseUrl = undefined;
  try { await githubSyncDiagnostics.flush(); }
  catch (error) { log.warn(`GitHub Sync diagnostic flush failed: ${error instanceof Error ? error.message : String(error)}`); }
  log.info("deactivated");
}
