import { execFile, spawn } from "child_process";
import { createHash, randomUUID } from "crypto";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { promisify } from "util";
import { normalizeTextNewlines } from "../knowledge/text-format";
import { canonicalJson, compileWorkflowDefinitionV1 } from "../workflows/workflow-contracts";
import { compareVersionOrder } from "../runtime/version-order";
import { knowledgeSyncDeletionRecords, parseStoreFrontmatter } from "../knowledge/filestore";
import { legacyKnowledgeAlias, readKnowledgeIdentity } from "../knowledge/knowledge-contracts";
import { alignSyncScriptIdentities, mergeSyncScriptIdentities, readSyncScriptIdentity, syncHistoricalScriptTrash, syncScriptAliasPath, syncScriptSidecarPath, SyncHistoricalTrashEvidence } from "./github-sync-script-identity";
import { sameKnowledgeRoot } from "./github-sync-coordinator";
import { GitHubSyncContentIssue, GitHubSyncContentRepairError, inspectConflictMarkers } from "./github-sync-content-repair";
import { GitHubSyncBaseEvidence, verifyGitHubSyncBaseDigest } from "./github-sync-base-integrity";
import { planGitHubSyncPublication } from "./github-sync-publication-plan";
import { isMarkdownAssetDirectory } from "../knowledge/markdown-assets";
import { GitHubSyncDeferredError } from "./github-sync-scheduler";
import { validatePersona, portablePersonaPath, withPersonaRepositoryMutation, validatePortablePersonaChanges } from "../chat/persona-profiles";
import { githubSyncProfilesAuthorized, githubSyncProfilesSelected } from "./github-sync-profiles";

const execFileAsync = promisify(execFile);

export const GITHUB_SYNC_CONTENT_TYPES = [
  "skills", "notes", "papers", "prompts", "scripts", "packages", "servers", "recipes", "agentSnapshots", "actions", "action-module-sets", "profiles"
] as const;

export type GitHubSyncContentType = typeof GITHUB_SYNC_CONTENT_TYPES[number];
export type GitHubSyncPrivacy = "public" | "private";
export type GitHubSyncShield = "outline" | "yellow" | "green";
export type GitHubSyncFolderFingerprints = Record<GitHubSyncContentType, Record<string, string>>;
export type GitHubSyncFolderShields = Record<GitHubSyncContentType, Record<string, GitHubSyncShield>>;
export type GitHubSyncResolutionRule =
  | "authoritative-migration"
  | "force-local-authority"
  | "built-in-authority"
  | "identical-convergence"
  | "initial-remote-authority"
  | "move-edit"
  | "deterministic-three-way"
  | "newer-remote-operation"
  | "newer-local-operation"
  | "remote-only"
  | "local-only"
  | "unchanged"
  | "human-required";

export interface GitHubSyncResolutionReport {
  totalFiles: number;
  assessedEntities?: number;
  pendingApplyMembers?: number;
  concurrentChangeBlockers?: number;
  localFiles?: number;
  remoteFiles?: number;
  rules: Partial<Record<GitHubSyncResolutionRule, number>>;
  generatedAt: string;
}
export type GitHubSyncAuthentication =
  | { method: "ssh"; identityFile: string; expectedLogin: string }
  | { method: "https"; expectedLogin: string }
  | { method: "vscode"; expectedLogin: string; accountId?: string };

export interface GitHubSyncCredentials {
  accessToken: string;
}

export class GitHubSyncExtensionCompatibilityError extends Error {
  constructor(
    readonly requiredVersion: string,
    readonly installedVersion: string,
  ) {
    super(
      `This Knowledge repository requires Personal Knowledge Manager ${requiredVersion} or newer. `
      + `Installed version: ${installedVersion}. Upgrade the extension before syncing; no local content was changed.`,
    );
    this.name = "GitHubSyncExtensionCompatibilityError";
  }
}

export function githubSyncAuthenticationSessionOptions(selectAccount = false): {
  createIfNone: true;
  clearSessionPreference?: true;
} {
  return selectAccount ? { createIfNone: true, clearSessionPreference: true } : { createIfNone: true };
}

export interface GitHubSyncTypeSelection {
  items: string[];
  folders: string[];
}

export type GitHubSyncSelectionScope = Record<GitHubSyncContentType, GitHubSyncTypeSelection>;

export interface GitHubSyncTarget {
  schema: 1;
  id: string;
  name: string;
  repository: string;
  branch: string;
  authentication?: GitHubSyncAuthentication;
  automation: {
    enabled: boolean;
    intervalMinutes: number;
    syncOnChange: boolean;
    initialSyncCompleted: boolean;
  };
  conflictResolution: "manual" | "agent";
  profileSyncConsent?: { root:string; scope:string; authorizedAt:string };
  selection: Record<GitHubSyncPrivacy, GitHubSyncSelectionScope>;
  pausedItems?: Array<{ type: GitHubSyncContentType; itemId: string }>;
  lastSync?: {
    at: string;
    commit: string;
    fingerprints: Partial<Record<GitHubSyncContentType, string>>;
    localChangeFingerprint?: string;
    repository?: string;
    branch?: string;
    storeRoot?: string;
    /** Only unresolved entities retain an older Base; "" means no prior Base. */
    entityBases?: Record<string, string>;
  };
  lastFailure?: {
    at: string;
    error: string;
    reason: string;
    attempts?: number;
    errorCode?: string;
    phase?: string;
    retryable?: boolean;
  };
  lastResolutionReport?: GitHubSyncResolutionReport;
  pendingDeletions?: GitHubSyncDeletionEvidence[];
  publication?: {
    requiredCapability: "stable-entity-identity";
    sourceCommit: string;
    sourceDigest: string;
    manualVerificationCompleted: boolean;
  };
}

export interface GitHubSyncDeletionEvidence {
  type: GitHubSyncContentType;
  itemId: string;
  deletedAt: string;
  category?: string;
  privacy?: GitHubSyncPrivacy;
}

export interface GitHubSyncFingerprintEntry {
  path: string;
  digest: string;
}

export function githubSyncManagedContent(type: GitHubSyncContentType, content: Buffer): Buffer {
  if (type !== "recipes") return content;
  if (content.includes(0) || !Buffer.from(content.toString("utf8"), "utf8").equals(content)) {
    throw new Error("Recipe content is not valid UTF-8 text.");
  }

  const recipe = JSON.parse(content.toString("utf8")) as Record<string, unknown>;
  delete recipe.editorLayout;
  return Buffer.from(`${JSON.stringify(recipe, null, 2)}\n`, "utf8");
}

/** Logical comparison only. Never use this representation as a disk write guard. */
export function githubSyncComparisonContent(type: GitHubSyncContentType, raw: Buffer, relative: string): Buffer {
  const managed = githubSyncManagedContent(type, raw);
  return normalizeTextNewlines(relative, managed);
}

export function githubSyncLocalSnapshotMatches(
  original: Buffer | undefined, planned: Buffer | undefined, current: Buffer | undefined,
): boolean {
  return current === undefined ? original === undefined || planned === undefined
    : !!(planned?.equals(current) || original?.equals(current));
}

export interface GitHubSyncCatalogItem {
  id: string;
  label: string;
  cat: string;
  meta?: string;
  isPrivate: boolean;
  source?: string;
  destination: string;
  content?: string;
  dependencies?: Array<{ source: string; destination: string }>;
  sourceLocator?: GitHubSyncContentIssue["sourceLocator"];
  identityAliases?: string[];
  legacyIds?: string[];
}

export type GitHubSyncCatalog = Record<GitHubSyncContentType, GitHubSyncCatalogItem[]>;

export interface GitHubSyncResult {
  transactionId: string;
  commit: string;
  changed: boolean;
  fingerprints: Record<GitHubSyncContentType, string>;
  pulled: string[];
  deletedLocal: string[];
  privateTopLevels: Partial<Record<GitHubSyncContentType, string[]>>;
  recipePulls: GitHubSyncRecipePull[];
  recipeDeletes: GitHubSyncRecipeDelete[];
  acknowledgedDeletions: GitHubSyncDeletionEvidence[];
  resolutionReport: GitHubSyncResolutionReport;
  entityBases?: Record<string, string>;
  deferredEntities?: string[];
}

export function githubSyncResultIsNoChange(result: GitHubSyncResult): boolean {
  return !result.changed && result.pulled.length === 0 && result.deletedLocal.length === 0
    && result.recipePulls.length === 0 && result.recipeDeletes.length === 0
    && !result.deferredEntities?.length
    && !Object.values(result.privateTopLevels).some(topLevels => topLevels.length > 0);
}

export interface GitHubSyncTransactionReceipt {
  schema: 1;
  transactionId: string;
  targetId: string;
  repository: string;
  branch: string;
  baseCommit: string;
  pushedCommit: string;
  pushedAt: string;
  operation: "sync" | "force-local-authority";
  actor?: string;
  comment?: string;
  state: "prepared" | "pushed" | "recorded";
  recordedAt?: string;
  entityBases?: Record<string, string>;
  outbox?: Array<{ entity: string; snapshot: string }>;
  preparedCommit?: string;
}

export interface GitHubSyncRecipePull {
  path: string;
  itemId: string;
  content: Buffer;
  expectedLocal?: Buffer;
}

export interface GitHubSyncRecipeDelete {
  itemId: string;
  path: string;
  expectedLocal?: Buffer;
}

export interface GitHubSyncConflict {
  path: string;
  type: GitHubSyncContentType;
  itemId: string;
  category: string;
  privacy: GitHubSyncPrivacy;
  member?: string;
  basePath?: string;
  localPath?: string;
  remotePath?: string;
  entityDeletion?: boolean;
  base?: Buffer;
  local?: Buffer;
  remote?: Buffer;
  reason?: "unrecorded-local-absence" | "concurrent-local-change" | "pending-apply" | "content-conflict" | "move-conflict" | "remote-deletion" | "dependency-conflict" | "path-collision";
  expectedLocal?: Buffer;
  plannedContent?: Buffer;
  plannedOperation?: "write" | "delete";
  baseCommit?: string;
  deletionEvidence?: GitHubSyncDeletionEvidence;
  absenceEvidence?: {
    selected: boolean; excludedPaths: string[]; historicalPaths: string[]; localDeletionRecorded: boolean;
    historicalTrash?: SyncHistoricalTrashEvidence[];
  };
}

export class GitHubSyncConflictError extends Error {
  partialResult?: GitHubSyncResult;
  constructor(
    public readonly remoteCommit: string,
    public readonly conflicts: GitHubSyncConflict[],
    public readonly pulled: string[] = [],
    public readonly deletedLocal: string[] = [],
    public readonly privateTopLevels: Partial<Record<GitHubSyncContentType, string[]>> = {},
    public readonly recipePulls: GitHubSyncRecipePull[] = [],
    public readonly recipeDeletes: GitHubSyncRecipeDelete[] = [],
    public readonly resolutionReport: GitHubSyncResolutionReport = { totalFiles: conflicts.length, rules: { "human-required": conflicts.length }, generatedAt: new Date().toISOString() },
  ) {
    const paths = conflicts.map(conflict => conflict.path);
    super(`GitHub Sync has ${paths.length} workspace member${paths.length === 1 ? "" : "s"} awaiting review or approval: ${paths.slice(0, 5).join(", ")}${paths.length > 5 ? `, and ${paths.length - 5} more` : ""}. These entities stay isolated while independent content continues syncing.`);
    this.name = "GitHubSyncConflictError";
  }
}

export interface GitHubSyncAuthenticationResult {
  host: string;
  login: string;
  fingerprint: string;
}

export interface GitHubSyncCreatedIdentity {
  identityFile: string;
  publicKey: string;
}

export interface GitHubSyncAuthenticationOptions {
  accounts: string[];
  identities: string[];
}

export function githubSyncAuthenticationFailureGuidance(target: GitHubSyncTarget | undefined, detail: string): string {
  if (!target?.authentication || !/(?:authentication failed|repository not found)/i.test(detail)) return "";
  if (target.authentication.method === "https") {
    return `Credential Manager did not authenticate as ${target.authentication.expectedLogin}. Reconnect that exact account or switch this target to VS Code GitHub Authentication.`;
  }
  if (target.authentication.method === "vscode") {
    return `Reconnect the VS Code GitHub account ${target.authentication.expectedLogin} for this target.`;
  }
  return "";
}

export interface GitHubSyncRemoteFile {
  path: string;
  type: GitHubSyncContentType;
  size: number;
}

export interface GitHubSyncRemoteValidation {
  repositoryFiles: number;
  importableFiles: number;
  ignoredFiles: number;
  invalidFiles: number;
  invalidExamples: string[];
  importableBytes: number;
  largestFileBytes: number;
  filesOverPreviewLimit: number;
}

export interface GitHubSyncRemoteSnapshot {
  targetId: string;
  commit: string;
  files: GitHubSyncRemoteFile[];
  validation: GitHubSyncRemoteValidation;
}

export interface GitHubSyncInitialPreview {
  remoteCommit: string;
  remoteSchema: 1 | 2 | 3;
  differences: GitHubSyncConflict[];
  same: number;
  remoteOnly: number;
  localOnly: number;
  modified: number;
}

export interface GitHubSyncRestoreResult {
  restored: string[];
  conflicts: string[];
}

export interface GitHubSyncRemoteAuthorityPlan {
  targetId: string;
  commit: string;
  storeRoot: string;
  targetDigest: string;
  projectionDigest: string;
  localSnapshotDigest: string;
  itemKeys: string[];
  digest: string;
  writes: GitHubSyncLocalWrite[];
  deletes: Array<{ file: GitHubSyncManagedFile; expectedLocal?: Buffer }>;
}

function remoteAuthorityTargetDigest(target: GitHubSyncTarget): string {
  return fileDigest(Buffer.from(JSON.stringify({
    id: target.id, repository: target.repository, branch: target.branch, selection: target.selection,
    pausedItems: target.pausedItems || [],
    authentication: target.authentication, pendingDeletions: target.pendingDeletions,
  })));
}

function remoteAuthorityPlanDigest(plan: Omit<GitHubSyncRemoteAuthorityPlan, "digest">): string {
  return fileDigest(Buffer.from(JSON.stringify({
    target: plan.targetDigest, root: plan.storeRoot, commit: plan.commit, projection: plan.projectionDigest,
    local: plan.localSnapshotDigest, items: plan.itemKeys,
    writes: plan.writes.map(item => [item.file.path, item.file.type, item.file.itemId, item.file.member,
      item.file.privacy, item.file.category, item.file.digest, fileDigest(item.content),
      item.expectedLocal === undefined ? null : fileDigest(item.expectedLocal)]),
    deletes: plan.deletes.map(item => [item.file.path, item.file.type, item.file.itemId, item.file.member,
      item.file.privacy, item.file.category, item.file.digest,
      item.expectedLocal === undefined ? null : fileDigest(item.expectedLocal)]),
  })));
}

function remoteAuthorityLocalSnapshot(target: GitHubSyncTarget, catalog: GitHubSyncCatalog, local: GitHubSyncManagedFile[]): string {
  return fileDigest(Buffer.from(JSON.stringify({
    local: local.map(file => [file.path, file.type, file.itemId, fileDigest(file.rawSnapshot || file.content!)]),
    recipes: catalog.recipes.filter(item => selectedItem(target, "recipes", item)).map(item => [item.id, item.content]),
  })));
}

export async function previewGitHubRemoteAuthority(
  target: GitHubSyncTarget, catalog: GitHubSyncCatalog, checkoutRoot: string, storeRoot: string,
  credentials?: GitHubSyncCredentials,
): Promise<GitHubSyncRemoteAuthorityPlan> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  if (target.automation.enabled || normalized.automation.enabled) throw new Error("Pause Auto Sync before using Force use Remote.");
  const targetDigest = remoteAuthorityTargetDigest(normalized);
  const readOnlyRoot = path.join(checkoutRoot, "remote-authority-cache");
  const snapshot = await fetchGitHubRemoteSnapshot(normalized, readOnlyRoot, false, credentials);
  const checkout = githubSyncCheckoutPath(normalized, readOnlyRoot);
  const manifest = await manifestAtCommit(normalized, readOnlyRoot, checkout, snapshot.commit, true);
  const local = selectedFiles(normalized, catalog).files;
  const localSnapshotDigest = remoteAuthorityLocalSnapshot(normalized, catalog, local);
  const originalLocalIdentity = new Map(local.map(file => [file.path, { itemId: file.itemId, privacy: file.privacy }]));
  const excluded = await githubSyncExcludedPaths(storeRoot, [...local.map(file => file.path), ...manifest.files.map(file => file.path)]);
  const originalRemoteSelection = new Set(manifest.files.filter(file =>
    selectionMatches(normalized, file.type, file.privacy, file.itemId, file.category, file.path)).map(file => file.path));
  const scriptLocators = alignSyncScriptIdentities([local, manifest.files]);
  for (const privacy of ["public", "private"] as const) {
    const items = normalized.selection[privacy].scripts.items;
    normalized.selection[privacy].scripts.items = [...new Set([...items, ...items.flatMap(id => {
      const canonical = scriptLocators.get(id);
      return canonical ? [canonical] : [];
    })])];
  }
  for (const deletion of manifest.deletions) {
    const itemId = deletion.type === "scripts" ? scriptLocators.get(deletion.itemId) || deletion.itemId : deletion.itemId;
    if (manifest.files.some(file => file.type === deletion.type && file.itemId === itemId)) {
      throw new Error("Remote tombstone conflicts with a validated live entity.");
    }
  }
  const localByPath = new Map(local.map(file => [file.path, file]));
  const selectedLocalIds = new Set(local.map(file => entityKey(file.type, file.itemId)));
  const protectedIds = new Set([...local, ...manifest.files].filter(file =>
    excluded.has(file.path) || githubSyncIgnoredPath(file.path) || isSystemManagedFile(file))
    .map(file => entityKey(file.type, file.itemId)));
  const remoteGroups = groupManagedFiles(manifest.files);
  const remote: GitHubSyncManagedFile[] = [];
  for (const [key, files] of remoteGroups) {
    if (protectedIds.has(key)) continue;
    const matches = files.map(file => originalRemoteSelection.has(file.path)
      || selectionMatches(normalized, file.type, file.privacy, file.itemId, file.category, file.path)
      || selectedLocalIds.has(key) && local.some(candidate => {
        const identity = originalLocalIdentity.get(candidate.path)!;
        return entityKey(candidate.type, candidate.itemId) === key && identity.privacy === file.privacy
          && selectionMatches(normalized, file.type, file.privacy, identity.itemId, file.category, file.path);
      }));
    if (matches.some(Boolean) && !matches.every(Boolean)) {
      throw new Error(`Remote entity has members outside the selected scope: ${files[0].path}. Review target selection first.`);
    }
    if (matches.every(Boolean)) remote.push(...files);
    else if (selectedLocalIds.has(key)) throw new Error(`Remote entity moved outside the selected scope: ${files[0].path}. Review target selection first.`);
  }
  const selectedLocal = local.filter(file => !protectedIds.has(entityKey(file.type, file.itemId)));
  const remotePaths = new Set(remote.map(file => file.path));
  const writes: GitHubSyncLocalWrite[] = [];
  for (const file of remote) {
    const unselectedOwner = catalog[file.type].find(item => !selectedItem(normalized, file.type, item)
      && (item.destination === file.path || item.dependencies?.some(dependency => dependency.destination === file.path)));
    if (unselectedOwner) throw new Error(`Remote replacement overlaps unselected Local content: ${file.path}.`);
    const content = normalizeTextNewlines(file.path, file.content!);
    validateManagedContent({ ...file, digest: fileDigest(content) }, content);
    const localRecipe = file.type === "recipes" ? local.find(candidate => candidate.type === "recipes" && candidate.itemId === file.itemId) : undefined;
    const current = file.type === "recipes" ? localRecipe?.rawSnapshot || localRecipe?.content
      : fs.existsSync(syncLocalPath(storeRoot, file.path)) ? fs.readFileSync(syncLocalPath(storeRoot, file.path)) : undefined;
    if (current && !localByPath.has(file.path) && !localRecipe) throw new Error(`Remote replacement overlaps uncatalogued Local content: ${file.path}.`);
    if (!current?.equals(content)) writes.push({ file, content, expectedLocal: current });
  }
  const remoteIds = new Set(remote.map(file => entityKey(file.type, file.itemId)));
  const deletes = selectedLocal.filter(file => !remotePaths.has(file.path)
    && !(file.type === "recipes" && remoteIds.has(entityKey(file.type, file.itemId))))
    .map(file => ({ file, expectedLocal: file.rawSnapshot || file.content }));
  const plan = {
    targetId: normalized.id, commit: snapshot.commit, storeRoot: path.resolve(storeRoot),
    targetDigest, localSnapshotDigest, writes, deletes,
    itemKeys: [...new Set([
      ...[...selectedLocal, ...remote].map(file => entityKey(file.type, file.itemId)),
      ...selectedLocal.map(file => entityKey(file.type, originalLocalIdentity.get(file.path)!.itemId)),
      ...(normalized.pendingDeletions || []).filter(item =>
        !protectedIds.has(entityKey(item.type, item.itemId))
        && selectionMatches(normalized, item.type, item.privacy || "public", item.itemId, item.category || ""))
        .map(item => entityKey(item.type, item.itemId)),
    ])].sort(),
    projectionDigest: fileDigest(Buffer.from(JSON.stringify({
      local: local.map(file => [file.path, file.itemId, fileDigest(file.rawSnapshot || file.content!)]),
      recipes: catalog.recipes.filter(item => selectedItem(normalized, "recipes", item)).map(item => [item.id, item.content]),
      excluded: [...excluded].sort(), protected: [...protectedIds].sort(),
    }))),
  };
  return { ...plan, digest: remoteAuthorityPlanDigest(plan) };
}

export async function applyGitHubRemoteAuthority(
  target: GitHubSyncTarget, catalog: GitHubSyncCatalog, checkoutRoot: string, storeRoot: string,
  approved: GitHubSyncRemoteAuthorityPlan, actor: string, comment: string,
  applyRecipes: (pulls: GitHubSyncRecipePull[], deletes: GitHubSyncRecipeDelete[], privateTopLevels: GitHubSyncResult["privateTopLevels"]) => void,
  credentials?: GitHubSyncCredentials,
  validateBeforeApply?: () => void,
  refreshCatalog?: () => Promise<GitHubSyncCatalog>,
): Promise<{ commit: string; backupDirectory: string; restored: string[]; deleted: string[] }> {
  if (!actor.trim() || !comment.trim()) throw new Error("Force use Remote requires an actor and an audit reason.");
  if (!sameKnowledgeRoot(approved.storeRoot, storeRoot) || approved.targetId !== target.id
    || approved.targetDigest !== remoteAuthorityTargetDigest(normalizeGitHubSyncTarget(target, () => target.id))
    || approved.digest !== remoteAuthorityPlanDigest(approved)) {
    throw new Error("Force use Remote preview changed. Generate a new preview.");
  }
  const current = await previewGitHubRemoteAuthority(target, catalog, checkoutRoot, storeRoot, credentials);
  if (current.digest !== approved.digest) throw new Error("Remote, Local content, selection or ignore rules changed. Generate a new Force use Remote preview.");
  const backupDirectory = path.join(checkoutRoot, "remote-authority-backups", target.id, randomUUID());
  const relativeBackup = path.relative(path.resolve(storeRoot), path.resolve(backupDirectory));
  if (!relativeBackup.startsWith(`..${path.sep}`) && relativeBackup !== ".." && !path.isAbsolute(relativeBackup)) {
    throw new Error("Recovery backups must be outside the Knowledge Root.");
  }
  fs.mkdirSync(backupDirectory, { recursive: true, mode: 0o700 });
  const backupItems = [...approved.writes, ...approved.deletes].map(item => {
    const recipe = item.file.type === "recipes" ? catalog.recipes.find(recipe => recipe.id === item.file.itemId) : undefined;
    return { item, original: recipe?.content !== undefined ? Buffer.from(recipe.content) : item.expectedLocal };
  });
  const originals = backupItems.map(({ item, original }) => ({
    path: item.file.path, type: item.file.type, itemId: item.file.itemId,
    exists: item.expectedLocal !== undefined,
    digest: original === undefined ? null : fileDigest(original),
  }));
  const audit = { schema: 1, operation: "force-remote-authority", commit: approved.commit, planDigest: approved.digest,
    targetId: target.id, repository: target.repository, branch: target.branch, storeRoot: approved.storeRoot, itemKeys: approved.itemKeys,
    actor, comment, at: new Date().toISOString(), originals, state: "prepared" };
  for (const { item, original } of backupItems) {
    if (original !== undefined) {
      const destination = managedPath(path.join(backupDirectory, "originals"), item.file.path);
      fs.mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
      fs.writeFileSync(destination, original, { mode: 0o600, flag: "wx" });
    }
  }
  writeAtomic(path.join(backupDirectory, "audit.json"), Buffer.from(JSON.stringify(audit, null, 2)));
  try {
    const checkout = githubSyncCheckoutPath(target, path.join(checkoutRoot, "remote-authority-cache"));
    const remoteHead = (await git(checkout, ["ls-remote", "origin", `refs/heads/${target.branch}`], target, false, credentials)).split(/\s+/)[0];
    if (remoteHead !== approved.commit) throw new Error("GitHub advanced after preview. Generate a new Force use Remote preview.");
    const latestCatalog = refreshCatalog ? await refreshCatalog() : catalog;
    validateBeforeApply?.();
    const normalized = normalizeGitHubSyncTarget(target, () => target.id);
    if (remoteAuthorityLocalSnapshot(normalized, latestCatalog, selectedFiles(normalized, latestCatalog).files) !== approved.localSnapshotDigest) {
      throw new Error("Local projection changed during Remote validation. Generate a new Force use Remote preview.");
    }
    const applied = applyLocalChanges(storeRoot, approved.writes, approved.deletes);
    applyRecipes(applied.recipePulls, applied.recipeDeletes, applied.privateTopLevels);
    writeAtomic(path.join(backupDirectory, "audit.json"), Buffer.from(JSON.stringify({ ...audit, state: "local-applied",
      appliedAt: new Date().toISOString() }, null, 2)));
    return { commit: approved.commit, backupDirectory,
      restored: approved.writes.map(item => item.file.path), deleted: approved.deletes.map(item => item.file.path) };
  } catch (error) {
    writeAtomic(path.join(backupDirectory, "audit.json"), Buffer.from(JSON.stringify({ ...audit, state: "needs-review",
      error: error instanceof Error ? error.message : String(error) }, null, 2)));
    throw new Error(`Force use Remote did not complete. Original content is backed up at ${backupDirectory}. ${
      error instanceof Error ? error.message : String(error)}`);
  }
}

export function completeGitHubRemoteAuthorityBackup(backupDirectory: string): void {
  const auditPath = path.join(backupDirectory, "audit.json");
  const audit = JSON.parse(fs.readFileSync(auditPath, "utf8"));
  if (audit.operation !== "force-remote-authority" || audit.state !== "local-applied") {
    throw new Error("Remote recovery audit is not ready for baseline finalization.");
  }
  writeAtomic(auditPath, Buffer.from(JSON.stringify({ ...audit, state: "completed", completedAt: new Date().toISOString() }, null, 2)));
}

function emptyScope(includeAll: boolean): GitHubSyncSelectionScope {
  const scope = {} as GitHubSyncSelectionScope;
  for (const type of GITHUB_SYNC_CONTENT_TYPES) {
    const selectedByDefault = !["packages", "servers", "agentSnapshots", "actions", "action-module-sets", "profiles"].includes(type);
    scope[type] = { items: [], folders: includeAll && selectedByDefault ? [""] : [] };
  }
  return scope;
}

export function defaultGitHubSyncSelection(): GitHubSyncTarget["selection"] {
  return { public: emptyScope(true), private: emptyScope(false) };
}

function normalizeValues(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map(value => String(value).trim().replace(/\\/g, "/")).filter(value => value === "" || (!value.startsWith("/") && !value.split("/").includes(".."))))]
    .sort((left, right) => left.localeCompare(right));
}

function normalizeScope(value: any): GitHubSyncSelectionScope {
  return Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, {
    items: normalizeValues(value?.[type]?.items),
    folders: normalizeValues(value?.[type]?.folders)
  }])) as GitHubSyncSelectionScope;
}

export function normalizeGitHubSyncTarget(value: any, createId: () => string = randomUUID): GitHubSyncTarget {
  const name = String(value?.name || "").trim();
  const repository = String(value?.repository || "").trim();
  const branch = String(value?.branch || "main").trim();
  if (!name) throw new Error("Target name is required.");
  if (!repository || /[\0\r\n]/.test(repository)) throw new Error("Repository is required.");
  if (!branch || branch.startsWith("-") || branch.endsWith(".") || branch.includes("..") || /[\s~^:?*[\\\x00-\x1f\x7f]/.test(branch)) {
    throw new Error("Branch is not a valid Git branch name.");
  }
  const selection = value?.selection
    ? { public: normalizeScope(value.selection.public), private: normalizeScope(value.selection.private) }
    : defaultGitHubSyncSelection();
  const id = String(value?.id || createId()).trim();
  if (!/^[A-Za-z0-9._-]+$/.test(id)) throw new Error("Target ID is invalid.");
  const configuredInterval = value?.automation?.intervalMinutes;
  const intervalMinutes = configuredInterval === undefined ? 5 : Number(configuredInterval);
  if (!Number.isInteger(intervalMinutes) || intervalMinutes < 1 || intervalMinutes > 1440) {
    throw new Error("Automatic sync interval must be between 1 and 1440 minutes.");
  }
  const hasAutomation = !!value?.automation;
  const initialSyncCompleted = value?.automation?.initialSyncCompleted === true
    || (value?.automation?.initialSyncCompleted === undefined && !!value?.lastSync?.at);
  const requestedAutomation = hasAutomation ? value.automation.enabled !== false : false;
  const target: GitHubSyncTarget = {
    schema: 1,
    id,
    name,
    repository,
    branch,
    automation: {
      enabled: requestedAutomation && initialSyncCompleted,
      intervalMinutes,
      syncOnChange: value?.automation?.syncOnChange !== false,
      initialSyncCompleted,
    },
    conflictResolution: value?.conflictResolution === "agent" ? "agent" : "manual",
    selection
  };
  if (value?.profileSyncConsent !== undefined) {
    const consent = value.profileSyncConsent;
    if (typeof consent?.root !== "string" || !path.isAbsolute(consent.root) || !/^[a-f0-9]{64}$/.test(consent.scope)
      || typeof consent.authorizedAt !== "string" || !Number.isFinite(Date.parse(consent.authorizedAt))) throw new Error("Invalid Profile Sync consent.");
    target.profileSyncConsent = {root:consent.root,scope:consent.scope,authorizedAt:consent.authorizedAt};
  }
  if (value?.pausedItems !== undefined) {
    if (!Array.isArray(value.pausedItems) || value.pausedItems.length > 10000) throw new Error("Invalid paused Sync items.");
    const paused = new Map<string, { type: GitHubSyncContentType; itemId: string }>();
    for (const item of value.pausedItems) {
      if (!item || !GITHUB_SYNC_CONTENT_TYPES.includes(item.type) || typeof item.itemId !== "string"
        || !item.itemId.trim() || /[\0\r\n]/.test(item.itemId)) throw new Error("Invalid paused Sync item identity.");
      paused.set(entityKey(item.type, item.itemId), { type: item.type, itemId: item.itemId });
    }
    target.pausedItems = [...paused.values()];
  }
  if (value?.authentication) {
    const method = value.authentication.method === "https" ? "https" : value.authentication.method === "vscode" ? "vscode" : "ssh";
    const identityFile = String(value.authentication.identityFile || "").trim().replace(/^~(?=$|[\\/])/, os.homedir());
    const expectedLogin = String(value.authentication.expectedLogin || "").trim();
    if (!/^[A-Za-z0-9-]+(?:_[A-Za-z0-9-]+)*$/.test(expectedLogin)) throw new Error("Expected GitHub login is required.");
    if (method === "https" || method === "vscode") {
      githubSyncRepositoryHttpsHost(repository);
      target.authentication = method === "vscode"
        ? { method, expectedLogin, ...(value.authentication.accountId ? { accountId: String(value.authentication.accountId) } : {}) }
        : { method, expectedLogin };
    } else {
      if (!identityFile || /[\0\r\n]/.test(identityFile)) throw new Error("SSH identity file is required.");
      githubSyncRepositorySshHost(repository);
      target.authentication = { method, identityFile, expectedLogin };
    }
  }
  if (value?.lastSync) {
    const fingerprints = Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES
      .filter(type => typeof value.lastSync.fingerprints?.[type] === "string")
      .map(type => [type, value.lastSync.fingerprints[type]]));
    target.lastSync = {
      at: String(value.lastSync.at || ""),
      commit: String(value.lastSync.commit || ""),
      fingerprints,
      ...(typeof value.lastSync.localChangeFingerprint === "string" ? { localChangeFingerprint: value.lastSync.localChangeFingerprint } : {}),
      ...(value.lastSync.repository ? { repository: String(value.lastSync.repository) } : {}),
      ...(value.lastSync.branch ? { branch: String(value.lastSync.branch) } : {}),
      ...(value.lastSync.storeRoot ? { storeRoot: path.resolve(String(value.lastSync.storeRoot)) } : {}),
    };
    if (value.lastSync.entityBases !== undefined) {
      if (!value.lastSync.entityBases || typeof value.lastSync.entityBases !== "object" || Array.isArray(value.lastSync.entityBases)
        || Object.keys(value.lastSync.entityBases).length > 10000) throw new Error("Invalid per-entity Sync bases.");
      const bases: Record<string, string> = {};
      for (const [key, commit] of Object.entries(value.lastSync.entityBases)) {
        if (!GITHUB_SYNC_CONTENT_TYPES.some(type => key.startsWith(`${type}\0`) && key.length > type.length + 1)
          || typeof commit !== "string" || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})?$/.test(commit)) {
          throw new Error("Invalid per-entity Sync base identity or commit.");
        }
        bases[key] = commit;
      }
      target.lastSync.entityBases = bases;
    }
  }
  if (value?.lastResolutionReport && typeof value.lastResolutionReport === "object") {
    const rules = Object.fromEntries(Object.entries(value.lastResolutionReport.rules || {})
      .filter(([, count]) => Number.isInteger(count) && Number(count) >= 0)
      .map(([rule, count]) => [rule, Number(count)])) as GitHubSyncResolutionReport["rules"];
    target.lastResolutionReport = {
      totalFiles: Math.max(0, Number(value.lastResolutionReport.totalFiles) || 0),
      ...(Number.isInteger(value.lastResolutionReport.localFiles) && value.lastResolutionReport.localFiles >= 0
        ? { localFiles: value.lastResolutionReport.localFiles } : {}),
      ...(Number.isInteger(value.lastResolutionReport.remoteFiles) && value.lastResolutionReport.remoteFiles >= 0
        ? { remoteFiles: value.lastResolutionReport.remoteFiles } : {}),
      rules,
      generatedAt: String(value.lastResolutionReport.generatedAt || ""),
    };
    for (const key of ["assessedEntities", "pendingApplyMembers", "concurrentChangeBlockers"] as const) {
      if (Number.isInteger(value.lastResolutionReport[key]) && value.lastResolutionReport[key] >= 0) {
        target.lastResolutionReport[key] = value.lastResolutionReport[key];
      }
    }
  }
  if (value?.lastFailure?.at && value?.lastFailure?.error) {
    target.lastFailure = {
      at: String(value.lastFailure.at),
      error: String(value.lastFailure.error),
      reason: String(value.lastFailure.reason || "automatic"),
      ...(Number.isInteger(value.lastFailure.attempts) && value.lastFailure.attempts > 0 ? { attempts: value.lastFailure.attempts } : {}),
      ...(typeof value.lastFailure.errorCode === "string" ? { errorCode: value.lastFailure.errorCode } : {}),
      ...(typeof value.lastFailure.phase === "string" ? { phase: value.lastFailure.phase } : {}),
      ...(value.lastFailure.retryable === false ? { retryable: false } : {}),
    };
  }
  if (Array.isArray(value?.pendingDeletions)) {
    target.pendingDeletions = value.pendingDeletions.map((entry: any): GitHubSyncDeletionEvidence => {
      const type = String(entry?.type || "") as GitHubSyncContentType;
      const itemId = String(entry?.itemId || "");
      const deletedAt = String(entry?.deletedAt || "");
      if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(type) || !itemId || !Number.isFinite(Date.parse(deletedAt))) {
        throw new Error("GitHub Sync pending deletion evidence is invalid.");
      }
      return {
        type,
        itemId,
        deletedAt,
        ...(entry.category === undefined ? {} : { category: String(entry.category) }),
        ...(entry.privacy === "private" ? { privacy: "private" as const } : entry.privacy === "public" ? { privacy: "public" as const } : {}),
      };
    });
  }
  if (value?.publication) {
    if (value.publication.requiredCapability !== "stable-entity-identity"
      || !/^[0-9a-f]{40,64}$/i.test(String(value.publication.sourceCommit || ""))
      || !/^[0-9a-f]{64}$/i.test(String(value.publication.sourceDigest || ""))) {
      throw new Error("GitHub publication capability state is invalid.");
    }
    target.publication = {
      requiredCapability: "stable-entity-identity",
      sourceCommit: String(value.publication.sourceCommit),
      sourceDigest: String(value.publication.sourceDigest),
      manualVerificationCompleted: value.publication.manualVerificationCompleted === true,
    };
  }
  return target;
}

export function githubSyncRepositorySshHost(repository: string): string {
  const value = String(repository || "").trim();
  try {
    const parsed = new URL(value);
    if (parsed.protocol === "ssh:" && parsed.hostname) return parsed.hostname;
  } catch { /* handled below */ }
  if (value.includes("://")) throw new Error("SSH account selection requires an SSH repository URL such as git@github.com:owner/repository.git.");
  const scp = /^(?:[^@/:\s]+@)?([^/:\s]+):[^\s]+$/.exec(value);
  if (scp) return scp[1];
  throw new Error("SSH account selection requires an SSH repository URL such as git@github.com:owner/repository.git.");
}

export function githubSyncRepositoryHttpsHost(repository: string): string {
  try {
    const parsed = new URL(String(repository || "").trim());
    if (parsed.protocol === "https:" && parsed.hostname && !parsed.username && !parsed.password) return parsed.hostname;
  } catch { /* handled below */ }
  throw new Error("Credential Manager authentication requires an HTTPS repository URL such as https://github.com/owner/repository.git.");
}

function shellArgument(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

export function githubSyncSshCommand(identityFile: string): string {
  return `ssh -o BatchMode=yes -o IdentitiesOnly=yes -o ConnectTimeout=10 -i ${shellArgument(identityFile)}`;
}

export function parseGitHubSshLogin(output: string): string {
  return /Hi\s+([^!\s]+)!\s+You've successfully authenticated/i.exec(String(output || ""))?.[1] || "";
}

const GITHUB_LOGIN_PATTERN = /^[A-Za-z0-9-]+(?:_[A-Za-z0-9-]+)*$/;

export function parseGitHubCredentialManagerAccounts(output: string): string[] {
  const accounts = new Set<string>();
  for (const line of String(output || "").split(/\r?\n/)) {
    const cleaned = line.replace(/\x1b\[[0-9;]*m/g, "").trim().replace(/^[-*]\s*/, "");
    if (!cleaned || /^(?:https?:\/\/)?[^\s:]+:\s*$/.test(cleaned)) continue;
    const candidate = cleaned.split(/\s+/).pop()!.replace(/^['"]|['"]$/g, "");
    if (GITHUB_LOGIN_PATTERN.test(candidate)) accounts.add(candidate);
  }
  return [...accounts].sort((left, right) => left.localeCompare(right));
}

export async function discoverGitHubCredentialManagerAccounts(): Promise<string[]> {
  try {
    const result = await execFileAsync("git", ["credential-manager", "github", "list", "--url", "https://github.com", "--no-ui"], {
      encoding: "utf8", maxBuffer: 1024 * 1024, timeout: 5000, windowsHide: process.platform === "win32",
    });
    return parseGitHubCredentialManagerAccounts(String(result.stdout || ""));
  } catch { return []; }
}

function expandedIdentityPath(value: string, sshDirectory: string): string | undefined {
  const unquoted = value.trim().replace(/^['"]|['"]$/g, "").replace(/%d/g, os.homedir());
  if (!unquoted || /%[A-Za-z%]/.test(unquoted)) return undefined;
  if (unquoted === "~") return os.homedir();
  if (unquoted.startsWith(`~${path.sep}`) || unquoted.startsWith("~/") || unquoted.startsWith("~\\")) return path.join(os.homedir(), unquoted.slice(2));
  return path.isAbsolute(unquoted) ? path.normalize(unquoted) : path.resolve(sshDirectory, unquoted);
}

export function discoverGitHubSshIdentities(sshDirectory = path.join(os.homedir(), ".ssh")): string[] {
  const identities = new Set<string>();
  const addIfPrivateKey = (candidate: string): void => {
    try {
      if (!fs.statSync(candidate).isFile()) return;
      const header = fs.readFileSync(candidate, { encoding: "utf8", flag: "r" }).slice(0, 256);
      if (/-----BEGIN (?:OPENSSH |RSA |DSA |EC )?PRIVATE KEY-----/.test(header)) identities.add(path.resolve(candidate));
    } catch { /* inaccessible files are not selectable */ }
  };
  try {
    for (const entry of fs.readdirSync(sshDirectory, { withFileTypes: true })) {
      if (entry.isFile() && !entry.name.endsWith(".pub")) addIfPrivateKey(path.join(sshDirectory, entry.name));
    }
    const configPath = path.join(sshDirectory, "config");
    if (fs.existsSync(configPath)) {
      for (const line of fs.readFileSync(configPath, "utf8").split(/\r?\n/)) {
        const match = /^\s*IdentityFile\s+(.+?)\s*(?:#.*)?$/i.exec(line);
        const candidate = match && expandedIdentityPath(match[1], sshDirectory);
        if (candidate) addIfPrivateKey(candidate);
      }
    }
  } catch { /* missing or inaccessible SSH directory */ }
  return [...identities].sort((left, right) => left.localeCompare(right));
}

export async function createGitHubSyncIdentity(expectedLogin: string, sshDirectory: string): Promise<GitHubSyncCreatedIdentity> {
  const login = String(expectedLogin || "").trim();
  if (!/^[A-Za-z0-9-]+(?:_[A-Za-z0-9-]+)*$/.test(login)) throw new Error("Enter the GitHub account before creating an SSH key.");
  fs.mkdirSync(sshDirectory, { recursive: true, mode: 0o700 });
  const identityFile = path.join(sshDirectory, `pkm_github_${login}_${randomUUID().slice(0, 8)}`);
  try {
    await execFileAsync("ssh-keygen", ["-q", "-t", "ed25519", "-N", "", "-C", `pkm:${login}`, "-f", identityFile], { encoding: "utf8", maxBuffer: 1024 * 1024, windowsHide: process.platform === "win32" });
    return { identityFile, publicKey: fs.readFileSync(`${identityFile}.pub`, "utf8").trim() };
  } catch (error) {
    fs.rmSync(identityFile, { force: true });
    fs.rmSync(`${identityFile}.pub`, { force: true });
    throw error;
  }
}

const VSCODE_GITHUB_CREDENTIAL_HELPER = "!f() { if [ \"$1\" = get ]; then printf '%s\\n' 'username=x-access-token' \"password=$PKM_GITHUB_SYNC_TOKEN\"; fi; }; f";

function gitEnvironment(target?: GitHubSyncTarget, credentials?: GitHubSyncCredentials): NodeJS.ProcessEnv {
  return target?.authentication?.method === "ssh"
    ? { ...process.env, GIT_SSH_COMMAND: githubSyncSshCommand(target.authentication.identityFile), GIT_SSH_VARIANT: "ssh" }
    : target?.authentication?.method === "https"
      ? { ...process.env, GIT_TERMINAL_PROMPT: "0" }
      : target?.authentication?.method === "vscode"
        ? { ...process.env, GIT_TERMINAL_PROMPT: "0", PKM_GITHUB_SYNC_TOKEN: credentials?.accessToken || "" }
      : process.env;
}

export function githubSyncGitArguments(args: string[], target?: GitHubSyncTarget): string[] {
  const platformSafety = ["-c", "core.longpaths=true"];
  return target?.authentication?.method === "https"
    ? [...platformSafety, "-c", "credential.gitHubAccountFiltering=true", "-c", `credential.username=${target.authentication.expectedLogin}`, ...args]
    : target?.authentication?.method === "vscode"
      ? [...platformSafety, "-c", "credential.helper=", "-c", `credential.helper=${VSCODE_GITHUB_CREDENTIAL_HELPER}`, "-c", "credential.username=x-access-token", ...args]
      : [...platformSafety, ...args];
}

export async function probeGitHubSyncAuthentication(repository: string, selectedIdentityFile: string, expectedLogin = ""): Promise<GitHubSyncAuthenticationResult> {
  const identityFile = String(selectedIdentityFile || "").trim().replace(/^~(?=$|[\\/])/, os.homedir());
  if (!identityFile) throw new Error("Select an SSH identity first.");
  if (!fs.existsSync(identityFile) || !fs.statSync(identityFile).isFile()) throw new Error(`SSH identity file does not exist: ${identityFile}`);
  const host = githubSyncRepositorySshHost(repository);
  let output = "";
  try {
    const result = await execFileAsync("ssh", ["-T", "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes", "-o", "ConnectTimeout=10", "-i", identityFile, `git@${host}`], { encoding: "utf8", maxBuffer: 1024 * 1024, windowsHide: process.platform === "win32" });
    output = `${result.stdout || ""}\n${result.stderr || ""}`;
  } catch (error: any) {
    output = `${error?.stdout || ""}\n${error?.stderr || ""}`;
  }
  const login = parseGitHubSshLogin(output);
  if (!login) throw new Error(`SSH authentication failed for ${host}. Select a key registered with GitHub.`);
  if (expectedLogin && login.toLowerCase() !== expectedLogin.toLowerCase()) {
    throw new Error(`SSH key authenticates as ${login}, not ${expectedLogin}. Select the correct account key.`);
  }
  const fingerprint = await execFileAsync("ssh-keygen", ["-lf", identityFile], { encoding: "utf8", maxBuffer: 1024 * 1024, windowsHide: process.platform === "win32" });
  return { host, login, fingerprint: String(fingerprint.stdout || "").trim() };
}

export async function probeGitHubSyncHttpsAuthentication(repository: string, expectedLogin: string): Promise<GitHubSyncAuthenticationResult> {
  const target = normalizeGitHubSyncTarget({
    id: "authentication-test",
    name: "Authentication test",
    repository,
    branch: "main",
    authentication: { method: "https", expectedLogin }
  });
  const host = githubSyncRepositoryHttpsHost(repository);
  try {
    await execFileAsync("git", githubSyncGitArguments(["ls-remote", repository], target), {
      encoding: "utf8",
      maxBuffer: 1024 * 1024,
      windowsHide: process.platform === "win32",
      env: gitEnvironment(target)
    });
  } catch (error: any) {
    const detail = String(error?.stderr || error?.stdout || error?.message || error).trim();
    throw new Error(`The configured credential helper could not access this repository as ${expectedLogin}${detail ? `: ${detail}` : "."}`);
  }
  return { host, login: expectedLogin, fingerprint: "HTTPS credential helper · repository access verified" };
}

export async function probeGitHubSyncVscodeAuthentication(repository: string, expectedLogin: string, credentials: GitHubSyncCredentials): Promise<GitHubSyncAuthenticationResult> {
  const target = normalizeGitHubSyncTarget({
    id: "authentication-test",
    name: "Authentication test",
    repository,
    branch: "main",
    authentication: { method: "vscode", expectedLogin }
  });
  const host = githubSyncRepositoryHttpsHost(repository);
  try {
    await execFileAsync("git", githubSyncGitArguments(["ls-remote", repository], target), {
      encoding: "utf8",
      maxBuffer: 1024 * 1024,
      windowsHide: process.platform === "win32",
      env: gitEnvironment(target, credentials)
    });
  } catch (error: any) {
    const detail = String(error?.stderr || error?.stdout || error?.message || error).trim();
    throw new Error(`The VS Code GitHub account could not access this repository as ${expectedLogin}${detail ? `: ${detail}` : "."}`);
  }
  return { host, login: expectedLogin, fingerprint: "VS Code GitHub Authentication · repository access verified" };
}

export async function testGitHubSyncAuthentication(target: GitHubSyncTarget, credentials?: GitHubSyncCredentials): Promise<GitHubSyncAuthenticationResult> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  if (!normalized.authentication) throw new Error("Choose an authentication method and GitHub account first.");
  return normalized.authentication.method === "https"
    ? probeGitHubSyncHttpsAuthentication(normalized.repository, normalized.authentication.expectedLogin)
    : normalized.authentication.method === "vscode"
      ? probeGitHubSyncVscodeAuthentication(normalized.repository, normalized.authentication.expectedLogin, credentials || { accessToken: "" })
      : probeGitHubSyncAuthentication(normalized.repository, normalized.authentication.identityFile, normalized.authentication.expectedLogin);
}

export function selectionIncludesType(target: GitHubSyncTarget, type: GitHubSyncContentType): boolean {
  return (["public", "private"] as const).some(privacy => {
    const selection = target.selection[privacy][type];
    return selection.items.length > 0 || selection.folders.length > 0;
  });
}

export function fingerprintGitHubSyncEntries(entries: GitHubSyncFingerprintEntry[]): string {
  const hash = createHash("sha256");
  for (const entry of [...entries].sort((left, right) => left.path.localeCompare(right.path))) {
    hash.update(entry.path.replace(/\\/g, "/"));
    hash.update("\0");
    hash.update(entry.digest);
    hash.update("\0");
  }
  return hash.digest("hex");
}

export function githubSyncShield(
  targets: GitHubSyncTarget[],
  type: GitHubSyncContentType,
  currentFingerprints: Readonly<Record<string, Partial<Record<GitHubSyncContentType, string>>>>,
  baseFileFingerprints: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>> = {},
): GitHubSyncShield {
  const covering = targets.filter(target => selectionIncludesType(target, type));
  if (!covering.length) return "outline";
  return covering.every(target => {
    const baseFiles = baseFileFingerprints[target.id]?.[type];
    const previous = baseFiles === undefined ? target.lastSync?.fingerprints[type]
      : fingerprintGitHubSyncEntries(Object.entries(baseFiles).map(([path, digest]) => ({ path, digest })));
    const current = currentFingerprints[target.id]?.[type];
    return !!previous && !!current && previous === current;
  }) ? "green" : "yellow";
}

export function githubSyncEntryShields(
  targets: GitHubSyncTarget[],
  currentFingerprints: Readonly<Record<string, Partial<Record<GitHubSyncContentType, string>>>>,
  currentFolders: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
  baseFolders: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
): GitHubSyncFolderShields {
  const result = Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, {}])) as GitHubSyncFolderShields;
  for (const type of GITHUB_SYNC_CONTENT_TYPES) {
    const folders = new Set<string>();
    for (const target of targets) {
      for (const folder of Object.keys(currentFolders[target.id]?.[type] || {})) folders.add(folder);
      for (const folder of Object.keys(baseFolders[target.id]?.[type] || {})) folders.add(folder);
    }
    for (const folder of folders) {
      const covering = targets.filter(target => (
        currentFolders[target.id]?.[type]?.[folder] !== undefined
        || baseFolders[target.id]?.[type]?.[folder] !== undefined));
      if (!covering.length) continue;
      result[type][folder] = covering.every(target => {
        const current = currentFolders[target.id]?.[type]?.[folder];
        const base = baseFolders[target.id]?.[type]?.[folder];
        if (current !== undefined && base !== undefined) return current === base;
        if (baseFolders[target.id]) return false;
        return !!target.lastSync?.fingerprints[type]
          && target.lastSync.fingerprints[type] === currentFingerprints[target.id]?.[type];
      }) ? "green" : "yellow";
    }
  }
  return result;
}

export function githubSyncShieldReasons(
  targets: GitHubSyncTarget[], type: GitHubSyncContentType,
  currentFiles: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
  baseFiles: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
  catalog: GitHubSyncCatalog,
): string[] {
  return targets.filter(target => selectionIncludesType(target, type)).flatMap(target => {
    const current = currentFiles[target.id]?.[type], base = baseFiles[target.id]?.[type];
    if (!current || !base) return [`${target.name}: file baseline unavailable; content equality is unverified.`];
    const added = Object.keys(current).filter(file => base[file] === undefined);
    const changed = Object.keys(current).filter(file => base[file] !== undefined && current[file] !== base[file]);
    const baselineOnly = Object.keys(base).filter(file => current[file] === undefined);
    if (!added.length && !changed.length && !baselineOnly.length) return [];
    const outsideScope = baselineOnly.filter(file => catalog[type].some(item =>
      item.destination === file && !selectedItem(target, type, item)));
    const examples = [...added, ...changed, ...baselineOnly].slice(0, 3);
    return [`${target.name}: ${added.length} local-only, ${changed.length} changed, ${baselineOnly.length} baseline-only file(s).`
      + (outsideScope.length ? ` ${outsideScope.length} baseline-only file(s) are now outside the selected scope (including privacy changes); retained remote copies are not automatically deleted.` : "")
      + (examples.length ? ` Examples: ${examples.join("; ")}.` : "")];
  });
}

export function githubSyncFolderShields(
  targets: GitHubSyncTarget[],
  currentFingerprints: Readonly<Record<string, Partial<Record<GitHubSyncContentType, string>>>>,
  currentFolders: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
  baseFolders: Readonly<Record<string, Partial<GitHubSyncFolderFingerprints>>>,
): GitHubSyncFolderShields {
  return githubSyncEntryShields(targets, currentFingerprints, currentFolders, baseFolders);
}

export function githubSyncIsSystemContent(type: GitHubSyncContentType, category: string, itemId = "", destination = ""): boolean {
  if (type === "actions" || type === "action-module-sets") {
    return [category, itemId, destination.replace(new RegExp(`^${type}/`), "")].some(value => /^(?:core|system)(?:[./]|$)/i.test(value));
  }
  if (!["prompts", "notes", "skills", "recipes"].includes(type)) return false;
  const first = (value: string): string => path.posix.normalize(String(value || "").replace(/\\/g, "/")).split("/")[0].toLowerCase();
  const relative = destination.replace(/\\/g, "/").replace(new RegExp(`^${type}/`, "i"), "");
  return [category, itemId, relative].some(value => first(value) === "system");
}

export function githubSyncIsSystemItem(type: GitHubSyncContentType, item: GitHubSyncCatalogItem): boolean {
  if (githubSyncIsSystemContent(type, item.cat, item.id, item.destination)) return true;
  if (type === "recipes" && item.content) {
    try { return JSON.parse(item.content.toString())?.systemKind === "built-in"; } catch { return false; }
  }
  return false;
}

function selectionMatches(
  target: GitHubSyncTarget,
  type: GitHubSyncContentType,
  privacy: GitHubSyncPrivacy,
  itemId: string,
  category: string,
  destination = ""
): boolean {
  if (type === "profiles" && (privacy !== "private" || !githubSyncProfilesAuthorized(target))) return false;
  if (target.pausedItems?.some(item => item.type === type && item.itemId === itemId)) return false;
  if (githubSyncIsSystemContent(type, category, itemId, destination) || destination && githubSyncIgnoredPath(destination)) return false;
  const selection = target.selection[privacy][type];
  return selection.items.includes(itemId) || selection.folders.some(folder =>
    folder === "" || category === folder || category.startsWith(folder + "/")
  );
}

function selectedItem(target: GitHubSyncTarget, type: GitHubSyncContentType, item: GitHubSyncCatalogItem): boolean {
  if (target.pausedItems?.some(paused => paused.type === type
    && [item.id, ...(item.legacyIds || [])].includes(paused.itemId))) return false;
  return !githubSyncIsSystemItem(type, item)
    && [item.id, ...(item.legacyIds || []), ...(type === "scripts" ? (item.identityAliases || [])
      .map(syncScriptAliasPath).filter((value): value is string => !!value).map(value => value.slice("scripts/".length)) : [])]
      .some(id => selectionMatches(target, type, item.isPrivate ? "private" : "public", id, item.cat, item.destination));
}

export function githubSyncSafeRelativePath(value: string): string {
  const normalized = value.replace(/\\/g, "/").replace(/^\/+/, "");
  const segments = normalized.split("/");
  const windowsReserved = /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/i;
  if (!normalized || /^[A-Za-z]:/.test(normalized) || segments.some(segment =>
    !segment || segment === ".." || segment === "." || /[\x00-\x1f<>:"|?*]/.test(segment) || /[. ]$/.test(segment) || windowsReserved.test(segment)
  ) || normalized === ".git" || normalized.startsWith(".git/")) {
    throw new Error(`Managed destination is invalid: ${value}`);
  }
  return normalized;
}

function managedPath(root: string, relative: string): string {
  const safe = githubSyncSafeRelativePath(relative);
  const segments = safe.split("/");
  let current = path.resolve(root);
  for (const segment of segments) {
    current = path.join(current, segment);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) {
      throw new Error(`Managed destination crosses a symbolic link: ${relative}`);
    }
  }
  return current;
}

export function githubSyncIgnoredPath(relative: string): boolean {
  const parts = relative.replace(/\\/g, "/").split("/");
  const directories = new Set([".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".hypothesis", ".ipynb_checkpoints", ".tox", ".nox", ".venv", "node_modules"]);
  const name = parts[parts.length - 1];
  return parts.some(part => directories.has(part)) || /(?:\.py[co]|\.DS_Store|Thumbs\.db)$/i.test(name)
    || /^(?:\.#|~\$)/.test(name) || /^#.*#$/.test(name)
    || /^\..+\.(?:[a-f0-9-]{32,36}|[0-9]{8,})\.tmp$/i.test(name)
    || /\.[0-9]+\.[a-f0-9]{10}\.tmp$/i.test(name)
    || /^\..+\.sw[pon]$/.test(name);
}

export class GitHubSyncSnapshotChangedError extends Error {
  constructor(readonly source: string) {
    super(`Sync snapshot changed while reading ${source}; this entity is deferred, not deleted. Retry after the writer settles.`);
    this.name = "GitHubSyncSnapshotChangedError";
  }
}

function stableSyncRead(source: string): Buffer {
  const before = fs.lstatSync(source);
  if (before.isSymbolicLink() || !before.isFile()) throw new Error(`Sync source is not a regular file: ${source}`);
  const content = fs.readFileSync(source);
  const after = fs.lstatSync(source);
  if (before.ino !== after.ino || before.size !== after.size || before.mtimeMs !== after.mtimeMs
    || before.ctimeMs !== after.ctimeMs || content.length !== after.size) throw new GitHubSyncSnapshotChangedError(source);
  return content;
}

function collectItemFiles(item: GitHubSyncCatalogItem,
  onError?: (error: unknown, destination: string, source: string) => void): Array<{ destination: string; member: string; content: Buffer; sourcePath?: string }> {
  const destination = githubSyncSafeRelativePath(item.destination);
  if (githubSyncIgnoredPath(destination)) return [];
  if (item.content !== undefined) return [{ destination, member: "", content: Buffer.from(item.content, "utf8") }];
  if (!item.source) throw new Error(`Catalog item ${item.id} has no source.`);
  const source = path.resolve(item.source);
  const stat = fs.lstatSync(source);
  if (stat.isSymbolicLink()) throw new Error(`Symbolic links cannot be synchronized: ${item.source}`);
  if (stat.isFile()) {
    const files = [{ destination, member: "", content: stableSyncRead(source), sourcePath: source }];
    for (const dependency of item.dependencies || []) {
      if (githubSyncIgnoredPath(dependency.destination)) continue;
      try {
        const dependencySource = path.resolve(dependency.source);
        const dependencyStat = fs.lstatSync(dependencySource);
        if (dependencyStat.isSymbolicLink() || !dependencyStat.isFile()) throw new Error(`Markdown asset dependency is invalid: ${dependency.source}`);
        files.push({
          destination: githubSyncSafeRelativePath(dependency.destination),
          member: item.destination.startsWith("scripts/") && dependency.destination === syncScriptSidecarPath(item.destination)
            ? "identity-sidecar" : githubSyncSafeRelativePath(dependency.destination),
          content: stableSyncRead(dependencySource),
          sourcePath: dependencySource,
        });
      } catch (error) {
        if (!onError) throw error;
        onError(error, dependency.destination, dependency.source);
      }
    }
    return files;
  }
  if (!stat.isDirectory()) throw new Error(`Unsupported catalog source: ${item.source}`);
  const files: Array<{ destination: string; member: string; content: Buffer; sourcePath?: string }> = [];
  const walk = (directory: string, relative: string): void => {
    const snapshot = fs.lstatSync(directory);
    let names: string[];
    try { names = fs.readdirSync(directory).sort((left, right) => left.localeCompare(right)); }
    catch (error) {
      if (!onError) throw error;
      onError(error, relative ? `${destination}/${relative}` : destination, directory);
      return;
    }
    for (const name of names) {
      const child = path.join(directory, name);
      const childRelative = relative ? `${relative}/${name}` : name;
      if (githubSyncIgnoredPath(childRelative)) continue;
      try {
        const childStat = fs.lstatSync(child);
        if (childStat.isSymbolicLink()) throw new Error(`Symbolic links cannot be synchronized: ${child}`);
        if (childStat.isDirectory()) walk(child, childRelative);
        else if (childStat.isFile()) files.push({ destination: `${destination}/${childRelative}`, member: childRelative, content: stableSyncRead(child), sourcePath: child });
      } catch (error) {
        if (!onError) throw error;
        onError(error, `${destination}/${childRelative}`, child);
      }
      const current = fs.lstatSync(directory);
      if (snapshot.ino !== current.ino || snapshot.mtimeMs !== current.mtimeMs || snapshot.ctimeMs !== current.ctimeMs) {
        throw new GitHubSyncSnapshotChangedError(directory);
      }
    }
  };
  walk(source, "");
  return files;
}

interface GitHubSyncManagedFile {
  path: string;
  type: GitHubSyncContentType;
  itemId: string;
  member: string;
  category: string;
  privacy: GitHubSyncPrivacy;
  digest: string;
  content?: Buffer;
  baseIntegrityEvidence?: GitHubSyncBaseEvidence;
  sourceDigest?: string;
  rawSnapshot?: Buffer;
  sourceLocator?: GitHubSyncContentIssue["sourceLocator"];
}

interface GitHubSyncManifest {
  schema: 1 | 2 | 3;
  minimumExtensionVersion?: string;
  files: GitHubSyncManagedFile[];
  deletions: GitHubSyncDeletionEvidence[];
}

const GITHUB_SYNC_MANIFEST_SCHEMA = 3;
const GITHUB_SYNC_EXTENSION_VERSION = String(require("../../package.json").version || "");
const GITHUB_SYNC_REQUIRED_CAPABILITIES = ["explicit-deletions", "stable-entity-identity"] as const;
const GITHUB_SYNC_SUPPORTED_CAPABILITIES = new Set<string>([...GITHUB_SYNC_REQUIRED_CAPABILITIES, "entity-partial-progress", "action-library-assets", "profile-cards"]);

function legacyManifestMetadata(filePath: string, type: GitHubSyncContentType): Pick<GitHubSyncManagedFile, "itemId" | "category" | "privacy"> {
  const relative = filePath.slice(type.length + 1);
  const segments = relative.split("/");
  const filename = segments[segments.length - 1];
  const withoutExtension = filename.replace(/\.[^.]+$/, "");
  const category = segments.slice(0, -1).join("/");
  let itemId: string;
  switch (type) {
    case "skills":
      itemId = withoutExtension;
      break;
    case "notes":
    case "papers":
    case "scripts":
      itemId = [...segments.slice(0, -1), withoutExtension].join("/");
      break;
    case "prompts":
      itemId = segments.slice(0, Math.min(2, segments.length)).join("/");
      break;
    case "packages":
    case "servers":
      itemId = segments[0];
      break;
    case "recipes":
      itemId = /\.([^.]+)\.json$/i.exec(filename)?.[1] || withoutExtension;
      break;
    case "agentSnapshots":
    case "actions":
      itemId = withoutExtension;
      break;
    case "action-module-sets":
      itemId = segments.slice(0, 2).join("/");
      break;
    case "profiles":
      throw new Error("Profile cards require a current identity-bearing manifest.");
  }
  if (!itemId) throw new Error(`Cannot infer legacy manifest identity for ${filePath}.`);
  return { itemId, category, privacy: "public" };
}

function selectedFiles(target: GitHubSyncTarget, catalog: GitHubSyncCatalog, excluded: ReadonlySet<string> = new Set(),
  issues?: GitHubSyncContentIssue[], deferTransient = false): {
  files: GitHubSyncManagedFile[];
  fingerprints: Record<GitHubSyncContentType, string>;
  folderFingerprints: GitHubSyncFolderFingerprints;
  deferredEntities: Set<string>;
} {
  const deferredEntities = new Set<string>();
  const files: GitHubSyncManagedFile[] = [];
  const fingerprints = {} as Record<GitHubSyncContentType, string>;
  const folderFingerprints = Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, {}])) as GitHubSyncFolderFingerprints;
  const destinations = new Set<string>();
  const portableDestinations = new Set<string>();
  for (const type of GITHUB_SYNC_CONTENT_TYPES) {
    const entries: GitHubSyncFingerprintEntry[] = [];
    const folderEntries = new Map<string, GitHubSyncFingerprintEntry[]>();
    for (const item of (catalog[type] || []).filter(candidate => selectedItem(target, type, candidate))) {
      const blocked = (error: unknown, destination = item.destination, source = item.source): void => {
        if (!issues) throw error;
        issues.push({ path: destination, type, itemId: item.id, source: "local", reason: "materialization",
          lines: [], digest: "", content: "", error: error instanceof Error ? error.message : String(error),
          ...(source ? { sourcePath: source, sourceLocator: { kind: "file", path: source } } : {}) });
      };
      const folders = githubSyncCategoryFolders(item.cat);
      for (const folder of folders) if (!folderEntries.has(folder)) folderEntries.set(folder, []);
      let collected: ReturnType<typeof collectItemFiles>;
      try { collected = collectItemFiles(item); }
      catch (error) {
        if (error instanceof GitHubSyncSnapshotChangedError || (error instanceof Error && "code" in error && error.code === "ENOENT")) {
          if (!issues && !deferTransient) throw new GitHubSyncSnapshotChangedError(item.source || item.destination);
          deferredEntities.add(entityKey(type, item.id));
          continue;
        }
        blocked(error); continue;
      }
      for (const file of collected) {
        if (excluded.has(file.destination)) continue;
        if (githubSyncIsSystemContent(type, item.cat, item.id, file.destination)) continue;
        let managed: Buffer;
        try { managed = githubSyncManagedContent(type, file.content); }
        catch (error) {
          if (!issues) throw error;
          // Preserve invalid JSON for the validator's source-specific diagnostics.
          managed = file.content;
        }
        const content = githubSyncComparisonContent(type === "recipes" ? "notes" : type, managed, file.destination);
        const digest = createHash("sha256").update(content).digest("hex");
        if (destinations.has(file.destination)) {
          const existing = files.find(candidate => candidate.path === file.destination);
          if (!existing || existing.digest !== digest) {
            blocked(new Error(`Multiple items map different content to ${file.destination}.`), file.destination);
            continue;
          }
          if (existing.privacy === "private" && !item.isPrivate) {
            existing.itemId = item.id;
            existing.member = file.member;
            existing.category = item.cat;
            existing.privacy = "public";
          }
          continue;
        }
        const portableDestination = file.destination.toLocaleLowerCase("en-US");
        if (portableDestinations.has(portableDestination)) {
          blocked(new Error(`Managed destinations differ only by case: ${file.destination}.`), file.destination);
          continue;
        }
        destinations.add(file.destination);
        portableDestinations.add(portableDestination);
        files.push({
          path: file.destination,
          type,
          itemId: item.id,
          member: file.member,
          category: item.cat,
          privacy: item.isPrivate ? "private" : "public",
          digest,
          content,
          sourceDigest: fileDigest(file.content),
          rawSnapshot: type === "recipes" ? managed : file.content,
          sourceLocator: file.sourcePath ? { kind: "file", path: file.sourcePath } : item.sourceLocator,
        });
        entries.push({ path: file.destination, digest });
        for (const folder of folders) folderEntries.get(folder)!.push({ path: file.destination, digest });
      }
    }
    fingerprints[type] = fingerprintGitHubSyncEntries(entries);
    folderFingerprints[type] = Object.fromEntries(
      [...folderEntries].map(([folder, folderFiles]) => [folder, fingerprintGitHubSyncEntries(folderFiles)]),
    );
  }
  alignSyncScriptIdentities([files]);
  return { files, fingerprints, folderFingerprints, deferredEntities };
}

function githubSyncCategoryFolders(category: string): string[] {
  const parts = String(category || "").replace(/\\/g, "/").split("/").filter(Boolean);
  return parts.length ? parts.map((_part, index) => parts.slice(0, index + 1).join("/")) : [""];
}

export function githubSyncLocalFingerprints(
  target: GitHubSyncTarget, catalog: GitHubSyncCatalog, excluded: ReadonlySet<string>,
): Record<GitHubSyncContentType, string> {
  return selectedFiles(target, catalog, excluded).fingerprints;
}

export function manifestJson(files: GitHubSyncManagedFile[], deletions: GitHubSyncDeletionEvidence[] = []): string {
  const ordered = [...files].sort((left, right) => left.path.localeCompare(right.path));
  const paths = new Set<string>();
  const members = new Set<string>();
  for (const file of ordered) {
    const portable = file.path.toLocaleLowerCase("en-US");
    if (paths.has(portable)) throw new Error(`Managed destinations differ only by case: ${file.path}.`);
    paths.add(portable);
    const member = `${file.type}\0${file.itemId}\0${file.member}`;
    if (members.has(member)) throw new Error(`Managed content repeats stable member identity for ${file.itemId}.`);
    members.add(member);
  }
  return JSON.stringify({
    schema: GITHUB_SYNC_MANIFEST_SCHEMA,
    minimumExtensionVersion: GITHUB_SYNC_EXTENSION_VERSION,
    capabilities: {
      required: [...GITHUB_SYNC_SUPPORTED_CAPABILITIES].filter(capability =>
        (capability !== "action-library-assets" || [...ordered, ...deletions].some(file => file.type === "actions" || file.type === "action-module-sets"))
        && (capability !== "profile-cards" || [...ordered, ...deletions].some(file => file.type === "profiles"))),
      storage: "pkm.github.publication/v1",
    },
    // Review-only evidence is machine-local, never publication metadata.
    files: ordered.map(({ content, sourceDigest, rawSnapshot, sourceLocator, baseIntegrityEvidence, ...file }) => file),
    deletions: [...deletions].sort((left, right) =>
      `${left.type}\0${left.itemId}`.localeCompare(`${right.type}\0${right.itemId}`))
      .map(({ type, itemId, deletedAt, category, privacy }) => ({ type, itemId, deletedAt, category, privacy })),
  }, null, 2) + "\n";
}

function inferLegacyMembers(files: GitHubSyncManagedFile[]): void {
  const groups = new Map<string, GitHubSyncManagedFile[]>();
  for (const file of files) {
    const key = `${file.type}\0${file.itemId}`;
    const group = groups.get(key) || [];
    group.push(file);
    groups.set(key, group);
  }
  for (const group of groups.values()) {
    if (group.length === 1) {
      group[0].member = "";
      continue;
    }
    const segments = group.map(file => file.path.split("/"));
    let common = 0;
    while (segments.every(parts => parts[common] && parts[common] === segments[0][common])) common += 1;
    for (const file of group) file.member = file.path.split("/").slice(common).join("/");
  }
}

export function parseManagedManifest(raw: string): GitHubSyncManifest {
  let manifest: any;
  try { manifest = JSON.parse(raw); } catch { throw new Error("Remote PKM manifest is not valid JSON."); }
  if (!Array.isArray(manifest?.files) || ![1, 2, 3].includes(manifest.schema)) {
    throw new Error("Remote repository does not contain a supported PKM manifest.");
  }
  if (manifest.schema === 3) {
    const minimumExtensionVersion = String(manifest.minimumExtensionVersion || "").trim();
    if (minimumExtensionVersion) {
      const order = compareVersionOrder(GITHUB_SYNC_EXTENSION_VERSION, minimumExtensionVersion);
      if (order === undefined) throw new Error("Remote PKM manifest has an invalid minimum extension version.");
      if (order < 0) {
        throw new GitHubSyncExtensionCompatibilityError(minimumExtensionVersion, GITHUB_SYNC_EXTENSION_VERSION);
      }
    }
    const required = manifest?.capabilities?.required;
    if (!Array.isArray(required) || manifest?.capabilities?.storage !== "pkm.github.publication/v1") {
      throw new Error("Remote PKM manifest capabilities are invalid.");
    }
    const unsupported = required.map(String).filter((capability: string) => !GITHUB_SYNC_SUPPORTED_CAPABILITIES.has(capability));
    if (unsupported.length) throw new Error(`Remote PKM manifest requires an unsupported required capability: ${unsupported.join(", ")}.`);
    for (const capability of GITHUB_SYNC_REQUIRED_CAPABILITIES) {
      if (!required.includes(capability)) throw new Error(`Remote PKM manifest is missing required capability ${capability}.`);
    }
  }
  if (manifest.files.length > 10000) throw new Error("Remote PKM manifest contains too many files.");
  const seen = new Set<string>();
  const files: GitHubSyncManagedFile[] = manifest.files.map((value: any): GitHubSyncManagedFile => {
    const filePath = githubSyncSafeRelativePath(String(manifest.schema >= 2 ? value?.path : value));
    const portable = filePath.toLocaleLowerCase("en-US");
    if (seen.has(portable)) throw new Error(`Remote manifest paths differ only by case: ${filePath}.`);
    seen.add(portable);
    const pathType = filePath.split("/", 1)[0] as GitHubSyncContentType;
    if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(pathType)) {
      throw new Error(`Remote manifest contains an unsupported content path: ${filePath}.`);
    }
    if (pathType === "recipes" && filePath.split("/").includes(".trash")) {
      throw new Error(`Remote manifest cannot contain local Recipe Trash: ${filePath}.`);
    }
    if (manifest.schema === 1) {
      return { path: filePath, type: pathType, ...legacyManifestMetadata(filePath, pathType), member: "", digest: "" };
    }
    const type = String(value?.type || "") as GitHubSyncContentType;
    const privacy = value?.privacy as GitHubSyncPrivacy;
    const itemId = String(value?.itemId || "");
    const member = manifest.schema === 3 ? String(value?.member ?? "") : "";
    const category = String(value?.category || "").replace(/\\/g, "/");
    const digest = String(value?.digest || "");
    if (type !== pathType || !itemId || (privacy !== "public" && privacy !== "private") || !/^[0-9a-f]{64}$/.test(digest)
      || (member && githubSyncSafeRelativePath(member) !== member)) {
      throw new Error(`Remote manifest metadata is invalid for ${filePath}.`);
    }
    if (type === "profiles" && (privacy !== "private" || !/^profiles\/(user|agent)\/[a-f0-9-]{36}\.json$/.test(filePath)
      || category !== filePath.split("/")[1] || `${category}/${path.posix.basename(filePath, ".json")}` !== itemId || member)) throw new Error("Invalid private Profile manifest identity.");
    return { path: filePath, type, itemId, member, category, privacy, digest };
  });
  if (manifest.schema < 3) inferLegacyMembers(files);
  if (files.some(file => file.type === "profiles") && (manifest.schema !== 3 || !manifest.capabilities.required.includes("profile-cards"))) {
    throw new Error("Profile cards require the profile-cards manifest capability.");
  }
  const deletionValues = manifest.schema === 3 ? manifest.deletions : [];
  if (!Array.isArray(deletionValues) || deletionValues.length > 10000) throw new Error("Remote PKM manifest deletion evidence is invalid.");
  const deletions = deletionValues.map((value: any): GitHubSyncDeletionEvidence => {
    const type = String(value?.type || "") as GitHubSyncContentType;
    const itemId = String(value?.itemId || "");
    const deletedAt = String(value?.deletedAt || "");
    const privacy = value?.privacy;
    if (type === "profiles" && (manifest.schema !== 3 || !manifest.capabilities.required.includes("profile-cards")
      || privacy !== "private" || !/^(user|agent)\/[a-f0-9-]{36}$/.test(itemId)
      || value.category !== itemId.split("/")[0])) throw new Error("Invalid private Profile deletion identity or capability.");
    if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(type) || !itemId || !Number.isFinite(Date.parse(deletedAt))
      || (privacy !== undefined && privacy !== "public" && privacy !== "private")) {
      throw new Error("Remote PKM manifest deletion evidence is invalid.");
    }
    return { type, itemId, deletedAt, category: value?.category === undefined ? undefined : String(value.category), privacy };
  });
  const identityMembers = new Set<string>();
  for (const file of files) {
    const identityMember = `${file.type}\0${file.itemId}\0${file.member}`;
    if (identityMembers.has(identityMember)) throw new Error(`Remote manifest repeats stable member identity for ${file.itemId}.`);
    identityMembers.add(identityMember);
  }
  const deletionKeys = new Set<string>();
  for (const deletion of deletions) {
    const key = entityKey(deletion.type, deletion.itemId);
    if (deletionKeys.has(key) || files.some((file: GitHubSyncManagedFile) => entityKey(file.type, file.itemId) === key)) {
      throw new Error("Remote PKM manifest has duplicate deletion evidence or a live entity with a tombstone.");
    }
    deletionKeys.add(key);
  }
  return {
    schema: manifest.schema,
    ...(manifest.minimumExtensionVersion ? { minimumExtensionVersion: String(manifest.minimumExtensionVersion) } : {}),
    files,
    deletions,
  };
}

export function githubSyncTargetFingerprints(
  target: GitHubSyncTarget,
  catalog: GitHubSyncCatalog
): Record<GitHubSyncContentType, string> {
  return selectedFiles(target, catalog).fingerprints;
}

export function githubSyncTargetFingerprintState(
  target: GitHubSyncTarget,
  catalog: GitHubSyncCatalog,
  excluded: ReadonlySet<string> = new Set(),
): { fingerprints: Record<GitHubSyncContentType, string>; folders: GitHubSyncFolderFingerprints; files: GitHubSyncFolderFingerprints; localChangeFingerprint: string; deferredEntities: string[] } {
  const selected = selectedFiles(target, catalog, excluded, undefined, true);
  const files = Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type,
    Object.fromEntries(selected.files.filter(file => file.type === type).map(file => [file.path, file.digest])),
  ])) as GitHubSyncFolderFingerprints;
  const localChangeFingerprint = createHash("sha256").update(JSON.stringify(selected.files
    .map(file => [file.path, file.digest, file.type, file.itemId, file.privacy])
    .sort((a, b) => a[0].localeCompare(b[0])))).digest("hex");
  return { fingerprints: selected.fingerprints, folders: selected.folderFingerprints, files, localChangeFingerprint, deferredEntities: [...selected.deferredEntities] };
}

export function githubSyncManifestFileFingerprints(target: GitHubSyncTarget, rawManifest: string, excluded: ReadonlySet<string> = new Set(),
  builtInRecipeIds: ReadonlySet<string> = new Set()): GitHubSyncFolderFingerprints {
  const manifest = parseManagedManifest(rawManifest);
  return Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type,
    Object.fromEntries(manifest.files.filter(file => !excluded.has(file.path) && file.type === type
      && !(file.type === "recipes" && builtInRecipeIds.has(file.itemId))
      && selectionMatches(target, file.type, file.privacy, file.itemId, file.category, file.path))
      .map(file => [file.path, file.digest])),
  ])) as GitHubSyncFolderFingerprints;
}

export function githubSyncManifestFolderFingerprints(
  target: GitHubSyncTarget,
  rawManifest: string,
  excluded: ReadonlySet<string> = new Set(),
  builtInRecipeIds: ReadonlySet<string> = new Set(),
): GitHubSyncFolderFingerprints {
  const manifest = parseManagedManifest(rawManifest);
  const entries = Object.fromEntries(
    GITHUB_SYNC_CONTENT_TYPES.map(type => [type, new Map<string, GitHubSyncFingerprintEntry[]>()]),
  ) as Record<GitHubSyncContentType, Map<string, GitHubSyncFingerprintEntry[]>>;
  for (const file of manifest.files) {
    if (excluded.has(file.path)) continue;
    if (file.type === "recipes" && builtInRecipeIds.has(file.itemId)) continue;
    if (!selectionMatches(target, file.type, file.privacy, file.itemId, file.category, file.path)) continue;
    for (const folder of githubSyncCategoryFolders(file.category)) {
      const folderEntries = entries[file.type].get(folder) || [];
      folderEntries.push({ path: file.path, digest: file.digest });
      entries[file.type].set(folder, folderEntries);
    }
  }
  return Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [
    type,
    Object.fromEntries([...entries[type]].map(([folder, files]) => [folder, fingerprintGitHubSyncEntries(files)])),
  ])) as GitHubSyncFolderFingerprints;
}

export async function readGitHubCachedManifest(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
): Promise<string | undefined> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const checkout = githubSyncCheckoutPath(normalized, checkoutRoot);
  if (!fs.existsSync(path.join(checkout, ".git"))) return undefined;
  try {
    return (await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${MANIFEST_PATH}`], undefined, 16 * 1024 * 1024)).toString("utf8");
  } catch {
    return undefined;
  }
}

export function githubSyncGitDependencyGuidance(error: { code?: string; path?: string }, workingDirectoryExists = true): string | undefined {
  if (error.code !== "ENOENT" || error.path !== "git") return undefined;
  return workingDirectoryExists
    ? "Git is required for GitHub Sync but is unavailable on this extension host's PATH. Install Git yourself on the machine running the extension (the remote machine for SSH/WSL/containers), configure PATH, and restart the extension host. PKM does not install Git automatically."
    : "The managed Git working directory is missing. Refresh the target and check its checkout path; no synchronization was completed.";
}

export function githubSyncReadNetworkUnavailable(command: string, detail: string): boolean {
  return ["fetch", "clone"].includes(command)
    && /could not resolve (?:host|hostname|proxy)|failed to connect|network is unreachable|no route to host|connection (?:timed out|refused|reset)|couldn't connect to server|temporary failure in name resolution/i.test(detail);
}

async function git(cwd: string, args: string[], target?: GitHubSyncTarget, allowFailure = false, credentials?: GitHubSyncCredentials): Promise<string> {
  try {
    const result = await execFileAsync("git", githubSyncGitArguments(args, target), { cwd, encoding: "utf8", maxBuffer: 4 * 1024 * 1024, timeout: 120_000, env: gitEnvironment(target, credentials), windowsHide: process.platform === "win32" });
    return String(result.stdout || "").trim();
  } catch (error: any) {
    const dependency = githubSyncGitDependencyGuidance(error, fs.existsSync(cwd));
    if (dependency) throw new Error(dependency);
    if (allowFailure) return "";
    const detail = String(error?.stderr || error?.stdout || error?.message || error).trim();
    const guidance = githubSyncAuthenticationFailureGuidance(target, detail);
    const message = `git ${args[0]} failed${detail ? `: ${detail}` : "."}${guidance ? ` ${guidance}` : ""}`;
    if (githubSyncReadNetworkUnavailable(args[0], detail)) throw new GitHubSyncDeferredError(message);
    throw new Error(message);
  }
}

async function localGitRoot(storeRoot: string): Promise<string | undefined> {
  let directory = path.resolve(storeRoot);
  for (;;) {
    if (fs.existsSync(path.join(directory, ".git"))) {
      await git(directory, ["rev-parse", "--show-toplevel"]);
      // Git resolves root symlinks; relative catalog paths must retain the caller's namespace.
      return directory;
    }
    const parent = path.dirname(directory);
    if (parent === directory) return undefined;
    directory = parent;
  }
}

export async function githubSyncExcludedPaths(storeRoot: string | undefined, relatives: Iterable<string>): Promise<Set<string>> {
  const paths = [...new Set(relatives)];
  const excluded = new Set(paths.filter(githubSyncIgnoredPath));
  if (!storeRoot || !paths.length) return excluded;
  const repository = await localGitRoot(storeRoot);
  const temporary = repository ? undefined : fs.mkdtempSync(path.join(os.tmpdir(), "pkm-sync-ignore-"));
  try {
    if (temporary) await git(temporary, ["init", "--bare", "."]);
    let root = repository || path.resolve(storeRoot);
    while (!fs.existsSync(root)) root = path.dirname(root);
    const argumentsPrefix = temporary
      ? ["-c", "core.bare=false", `--git-dir=${temporary}`, `--work-tree=${root}`] : [];
    const localPaths = new Map(paths.map(relative => [
      path.relative(root, syncLocalPath(storeRoot, relative)).split(path.sep).join("/"), relative,
    ]));
    const output = await new Promise<string>((resolve, reject) => {
      const child = execFile("git", [...argumentsPrefix, "check-ignore", "--no-index", "-z", "--stdin"], {
        cwd: root, encoding: "utf8", maxBuffer: 16 * 1024 * 1024, timeout: 120_000,
        env: gitEnvironment(), windowsHide: process.platform === "win32",
      }, (error, stdout, stderr) => {
        if (error && error.code !== 1) {
          reject(new Error(`GitHub Sync cannot evaluate local ignore rules: ${stderr || error.message}`));
        } else resolve(stdout);
      });
      child.stdin!.on("error", reject);
      child.stdin!.end([...localPaths.keys()].join("\0") + "\0");
    });
    for (const ignored of output.split("\0").filter(Boolean)) {
      const relative = localPaths.get(ignored);
      if (relative) excluded.add(relative);
    }
    return excluded;
  } finally {
    if (temporary) fs.rmSync(temporary, { recursive: true, force: true });
  }
}

async function githubSyncGitDeletionRecords(
  storeRoot: string | undefined, baseline: Iterable<GitHubSyncManagedFile>,
): Promise<Map<string, { deletedAt: string }>> {
  const deletions = new Map<string, { deletedAt: string }>();
  if (!storeRoot) return deletions;
  const candidates = [...baseline].filter(file => file.type !== "recipes" && !isSystemManagedFile(file)
    && !fs.existsSync(syncLocalPath(storeRoot, file.path)));
  if (!candidates.length) return deletions;
  const root = await localGitRoot(storeRoot);
  if (!root || !await hasRef(root, "HEAD")) return deletions;
  const head = new Map<string, string>();
  for (const entry of (await gitBuffer(root, ["ls-tree", "-r", "-z", "HEAD"], undefined, 16 * 1024 * 1024)).toString("utf8").split("\0")) {
    const match = /^(100644|100755) blob ([0-9a-f]+)\t([\s\S]+)$/.exec(entry);
    if (match) head.set(match[3], match[2]);
  }
  const index = new Map<string, string>();
  const unmerged = new Set<string>();
  const sparse = new Set<string>();
  for (const entry of (await gitBuffer(root, ["ls-files", "-v", "-z"], undefined, 16 * 1024 * 1024)).toString("utf8").split("\0")) {
    if (entry.startsWith("S ") || /^[a-z] /.test(entry)) sparse.add(entry.slice(2));
  }
  for (const entry of (await gitBuffer(root, ["ls-files", "--stage", "-z"], undefined, 16 * 1024 * 1024)).toString("utf8").split("\0")) {
    const match = /^(\d+) ([0-9a-f]+) (\d)\t([\s\S]+)$/.exec(entry);
    if (!match) continue;
    if (match[3] !== "0" || !/^100(?:644|755)$/.test(match[1])) unmerged.add(match[4]);
    else index.set(match[4], match[2]);
  }
  const deletedAt = new Date().toISOString();
  for (const file of candidates) {
    const relative = path.relative(root, syncLocalPath(storeRoot, file.path)).split(path.sep).join("/");
    if (unmerged.has(relative) || sparse.has(relative)) continue;
    let object = head.get(relative);
    if (object) {
      if (index.has(relative) && index.get(relative) !== object) continue;
    } else {
      if (index.has(relative)) continue;
      const deletionCommit = await git(root, ["log", "-1", "--format=%H", "--diff-filter=D", "--no-renames", "--", relative]);
      if (!deletionCommit) continue;
      const tree = await git(root, ["ls-tree", `${deletionCommit}^`, "--", relative]);
      const match = /^(100644|100755) blob ([0-9a-f]+)\t/.exec(tree);
      if (!match) continue;
      object = match[2];
    }
    const content = await gitBuffer(root, ["cat-file", "blob", object], undefined, 64 * 1024 * 1024);
    const managed = githubSyncManagedContent(file.type, content);
    const normalized = normalizeTextNewlines(file.path, managed);
    if (fileDigest(normalized) === file.digest) deletions.set(file.path, { deletedAt });
  }
  return deletions;
}

async function gitBuffer(cwd: string, args: string[], target?: GitHubSyncTarget, maximumBytes = 8 * 1024 * 1024): Promise<Buffer> {
  try {
    const result = await execFileAsync("git", githubSyncGitArguments(args, target), { cwd, encoding: "buffer", maxBuffer: maximumBytes + 64 * 1024, timeout: 120_000, env: gitEnvironment(target), windowsHide: process.platform === "win32" });
    return Buffer.from(result.stdout);
  } catch (error: any) {
    const dependency = githubSyncGitDependencyGuidance(error, fs.existsSync(cwd));
    if (dependency) throw new Error(dependency);
    const detail = String(error?.stderr || error?.stdout || error?.message || error).trim();
    throw new Error(`git ${args[0]} failed${detail ? `: ${detail}` : "."}`);
  }
}

async function hasRef(cwd: string, ref: string): Promise<boolean> {
  try {
    await execFileAsync("git", ["show-ref", "--verify", "--quiet", ref], { cwd, windowsHide: process.platform === "win32" });
    return true;
  } catch { return false; }
}

async function isAncestor(cwd: string, ancestor: string, descendant: string): Promise<boolean> {
  try {
    await execFileAsync("git", ["merge-base", "--is-ancestor", ancestor, descendant], { cwd, windowsHide: process.platform === "win32" });
    return true;
  } catch { return false; }
}

function githubSyncCheckoutPath(target: GitHubSyncTarget, checkoutRoot: string): string {
  return path.join(checkoutRoot, target.id, "repository");
}

export type GitHubRemoteSnapshotStage = "cloning" | "fetching" | "inventory" | "validating";

async function fetchRemoteBranch(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  credentials?: GitHubSyncCredentials,
  onProgress?: (stage: GitHubRemoteSnapshotStage) => void
): Promise<{ checkout: string; commit: string }> {
  const checkout = githubSyncCheckoutPath(target, checkoutRoot);
  if (!fs.existsSync(path.join(checkout, ".git"))) {
    fs.mkdirSync(path.dirname(checkout), { recursive: true });
    onProgress?.("cloning");
    await git(path.dirname(checkout), ["clone", "--no-checkout", "--origin", "origin", target.repository, checkout], target, false, credentials);
  }
  const remote = await git(checkout, ["remote", "get-url", "origin"]);
  if (remote !== target.repository) throw new Error("Managed checkout points to a different repository. Delete the target and create it again.");
  await git(checkout, ["config", "--local", "core.longpaths", "true"]);
  onProgress?.("fetching");
  await git(checkout, ["fetch", "origin", "--prune"], target, false, credentials);
  const remoteRef = `refs/remotes/origin/${target.branch}`;
  if (!(await hasRef(checkout, remoteRef))) throw new Error(`Remote branch ${target.branch} does not exist.`);
  return { checkout, commit: await git(checkout, ["rev-parse", remoteRef]) };
}

function remoteManifestFiles(raw: string, repositoryFiles: Map<string, number>): GitHubSyncRemoteFile[] {
  return parseManagedManifest(raw).files.map(entry => {
    const file = entry.path;
    if (!repositoryFiles.has(file)) throw new Error(`Remote manifest references a missing file: ${file}.`);
    return { path: file, type: entry.type, size: repositoryFiles.get(file) || 0 };
  }).sort((left: GitHubSyncRemoteFile, right: GitHubSyncRemoteFile) => left.path.localeCompare(right.path));
}

export async function fetchGitHubRemoteSnapshot(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  allowRepositoryTree = false,
  credentials?: GitHubSyncCredentials,
  onProgress?: (stage: GitHubRemoteSnapshotStage) => void
): Promise<GitHubSyncRemoteSnapshot> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const { checkout, commit } = await fetchRemoteBranch(normalized, checkoutRoot, credentials, onProgress);
  onProgress?.("inventory");
  const repositoryFiles = new Map<string, number>();
  for (const entry of (await git(checkout, ["ls-tree", "-r", "-l", "-z", commit])).split("\0").filter(Boolean)) {
    const separator = entry.indexOf("\t");
    if (separator < 0) continue;
    const metadata = entry.slice(0, separator).trim().split(/\s+/);
    const size = Number(metadata[3]);
    repositoryFiles.set(entry.slice(separator + 1), Number.isSafeInteger(size) && size >= 0 ? size : 0);
  }
  const snapshot = (files: GitHubSyncRemoteFile[], invalidPaths: string[] = []): GitHubSyncRemoteSnapshot => ({
    targetId: normalized.id,
    commit,
    files,
    validation: {
      repositoryFiles: repositoryFiles.size,
      importableFiles: files.length,
      ignoredFiles: Math.max(0, repositoryFiles.size - files.length - invalidPaths.length),
      invalidFiles: invalidPaths.length,
      invalidExamples: invalidPaths.slice(0, 5),
      importableBytes: files.reduce((sum, file) => sum + file.size, 0),
      largestFileBytes: files.reduce((largest, file) => Math.max(largest, file.size), 0),
      filesOverPreviewLimit: files.filter(file => file.size > 1024 * 1024).length,
    },
  });
  let manifest: string;
  onProgress?.("validating");
  try {
    manifest = (await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${MANIFEST_PATH}`], undefined, 16 * 1024 * 1024)).toString("utf8");
  } catch {
    if (allowRepositoryTree) {
      const files: GitHubSyncRemoteFile[] = [];
      const invalidPaths: string[] = [];
      for (const [file, size] of repositoryFiles) {
        const type = file.split("/", 1)[0];
        if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(type) || file.split("/").length <= 1) continue;
        try {
          files.push({ path: githubSyncSafeRelativePath(file), type: type as GitHubSyncContentType, size });
        } catch {
          invalidPaths.push(file);
        }
      }
      files.sort((left, right) => left.path.localeCompare(right.path));
      if (files.length > 10000) throw new Error("Remote repository contains too many subscribable files.");
      return snapshot(files, invalidPaths);
    }
    throw new Error("Remote repository has no PKM sync manifest yet.");
  }
  return snapshot(remoteManifestFiles(manifest, repositoryFiles));
}

export async function previewGitHubSyncTarget(
  target: GitHubSyncTarget,
  catalog: GitHubSyncCatalog,
  checkoutRoot: string,
  credentials?: GitHubSyncCredentials,
  storeRoot?: string,
): Promise<GitHubSyncInitialPreview> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const localMaterialized = selectedFiles(normalized, catalog);
  const localFiles = new Map(localMaterialized.files.map(file => [file.path, file]));
  const checkout = githubSyncCheckoutPath(normalized, checkoutRoot);
  await prepareCheckout(normalized, checkout, credentials);
  const commit = await git(checkout, ["rev-parse", "HEAD"]);
  const raw = (await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${MANIFEST_PATH}`], undefined, 16 * 1024 * 1024)).toString("utf8");
  const manifest = parseManagedManifest(raw);
  const excluded = await githubSyncExcludedPaths(storeRoot || normalized.lastSync?.storeRoot,
    [...localFiles.keys(), ...manifest.files.map(file => file.path)]);
  for (const relative of excluded) localFiles.delete(relative);
  for (const file of localFiles.values()) validateManagedContent(file, file.content!);
  const remoteFiles = new Map<string, GitHubSyncManagedFile>();
  for (const file of manifest.files) {
    if (excluded.has(file.path)) continue;
    const content = await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${file.path}`], undefined, 64 * 1024 * 1024);
    if (!file.digest) file.digest = fileDigest(content);
    validateManagedContent(file, content, true);
    remoteFiles.set(file.path, { ...file, content });
  }
  const differences: GitHubSyncConflict[] = [];
  let same = 0;
  let remoteOnly = 0;
  let localOnly = 0;
  let modified = 0;
  const paths = new Set([...localFiles.keys(), ...remoteFiles.keys()]);
  for (const relative of [...paths].sort((left, right) => left.localeCompare(right))) {
    const local = localFiles.get(relative);
    const remote = remoteFiles.get(relative);
    if (local && remote && (managedContentsEquivalent(local, remote) || frontmatterMigrationEquivalent(local, remote))) {
      same++;
      continue;
    }
    if (!local) remoteOnly++;
    else if (!remote) localOnly++;
    else modified++;
    const metadata = local || remote!;
    differences.push({
      path: relative,
      type: metadata.type,
      itemId: metadata.itemId,
      category: metadata.category,
      privacy: metadata.privacy,
      local: local?.content,
      remote: remote?.content,
    });
  }
  return { remoteCommit: commit, remoteSchema: manifest.schema, differences, same, remoteOnly, localOnly, modified };
}

async function assertRemoteCommit(target: GitHubSyncTarget, checkoutRoot: string, commit: string): Promise<string> {
  if (!/^[0-9a-f]{40,64}$/i.test(commit)) throw new Error("Remote snapshot commit is invalid.");
  const checkout = githubSyncCheckoutPath(target, checkoutRoot);
  const current = await git(checkout, ["rev-parse", `refs/remotes/origin/${target.branch}`]);
  if (current !== commit) throw new Error("Remote content changed. Refresh the remote browser before continuing.");
  return checkout;
}

export async function readGitHubRemoteFile(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
  relative: string,
  maximumBytes = 1024 * 1024
): Promise<Buffer> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const safe = githubSyncSafeRelativePath(relative);
  const checkout = await assertRemoteCommit(normalized, checkoutRoot, commit);
  const size = Number(await git(checkout, ["cat-file", "-s", `${commit}:${safe}`]));
  if (!Number.isSafeInteger(size) || size < 0 || size > maximumBytes) throw new Error(`Remote file exceeds the ${maximumBytes}-byte preview limit.`);
  return gitBuffer(checkout, ["cat-file", "blob", `${commit}:${safe}`], undefined, maximumBytes);
}

export async function readGitHubRemoteManifest(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
): Promise<string> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const checkout = await assertRemoteCommit(normalized, checkoutRoot, commit);
  return (await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${MANIFEST_PATH}`], undefined, 16 * 1024 * 1024)).toString("utf8");
}

export async function readGitHubRemoteFileForSubscription(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
  relative: string,
  maximumBytes: number
): Promise<Buffer> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const safe = githubSyncSafeRelativePath(relative);
  const checkout = await assertRemoteCommit(normalized, checkoutRoot, commit);
  const size = Number(await git(checkout, ["cat-file", "-s", `${commit}:${safe}`]));
  if (!Number.isSafeInteger(size) || size < 0 || size > maximumBytes) throw new Error(`Remote file exceeds the ${maximumBytes}-byte subscription cache limit.`);
  return gitBuffer(checkout, ["cat-file", "blob", `${commit}:${safe}`], undefined, maximumBytes);
}

export async function readGitHubRemoteFilesForSubscription(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  commit: string,
  files: { path: string; size: number }[],
  maximumBytes: number
): Promise<Map<string, Buffer>> {
  if (!/^[0-9a-f]{40,64}$/i.test(commit)) throw new Error("Remote snapshot commit is invalid.");
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const checkout = githubSyncCheckoutPath(normalized, checkoutRoot);
  const requested = files.map(file => {
    const safe = githubSyncSafeRelativePath(file.path);
    const size = Number(file.size);
    if (!Number.isSafeInteger(size) || size < 0 || size > maximumBytes) {
      throw new Error(`Remote file exceeds the ${maximumBytes}-byte subscription cache limit.`);
    }
    return { path: safe, size };
  });
  const totalBytes = requested.reduce((sum, file) => sum + file.size, 0);
  if (totalBytes > maximumBytes) throw new Error(`Remote files exceed the ${maximumBytes}-byte subscription cache limit.`);
  if (!requested.length) return new Map();

  const output = await new Promise<Buffer>((resolve, reject) => {
    const child = spawn("git", githubSyncGitArguments(["cat-file", "--batch"], normalized), {
      cwd: checkout,
      env: gitEnvironment(normalized),
      windowsHide: process.platform === "win32",
      stdio: ["pipe", "pipe", "pipe"],
    });
    const stdout: Buffer[] = [];
    const stderr: Buffer[] = [];
    const maximumOutputBytes = totalBytes + requested.length * 256 + 1024;
    let outputBytes = 0;
    let settled = false;
    const finish = (error?: Error, result?: Buffer) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (error) reject(error);
      else resolve(result || Buffer.alloc(0));
    };
    const timeout = setTimeout(() => {
      child.kill();
      finish(new Error("git cat-file batch timed out."));
    }, 120_000);
    child.on("error", error => finish(new Error(`git cat-file failed: ${error.message}`)));
    child.stdout.on("data", (chunk: Buffer) => {
      outputBytes += chunk.length;
      if (outputBytes > maximumOutputBytes) {
        child.kill();
        finish(new Error("git cat-file batch exceeded the expected output size."));
        return;
      }
      stdout.push(Buffer.from(chunk));
    });
    child.stderr.on("data", (chunk: Buffer) => stderr.push(Buffer.from(chunk)));
    child.on("close", code => {
      if (code !== 0) {
        const detail = Buffer.concat(stderr).toString("utf8").trim();
        finish(new Error(`git cat-file failed${detail ? `: ${detail}` : "."}`));
        return;
      }
      finish(undefined, Buffer.concat(stdout));
    });
    child.stdin.on("error", error => finish(new Error(`git cat-file failed: ${error.message}`)));
    child.stdin.end(requested.map(file => `${commit}:${file.path}\n`).join(""));
  });

  const result = new Map<string, Buffer>();
  let offset = 0;
  for (const file of requested) {
    const headerEnd = output.indexOf(0x0a, offset);
    if (headerEnd < 0) throw new Error(`git cat-file returned an incomplete header for ${file.path}.`);
    const header = output.subarray(offset, headerEnd).toString("utf8");
    const match = /^([0-9a-f]+) blob ([0-9]+)$/i.exec(header);
    if (!match) throw new Error(`git cat-file could not read ${file.path}: ${header}`);
    const size = Number(match[2]);
    if (!Number.isSafeInteger(size) || size !== file.size) throw new Error(`Remote file size changed for ${file.path}. Test the repository again.`);
    const contentStart = headerEnd + 1;
    const contentEnd = contentStart + size;
    if (contentEnd >= output.length || output[contentEnd] !== 0x0a) throw new Error(`git cat-file returned incomplete content for ${file.path}.`);
    result.set(file.path, Buffer.from(output.subarray(contentStart, contentEnd)));
    offset = contentEnd + 1;
  }
  if (offset !== output.length) throw new Error("git cat-file returned unexpected trailing output.");
  return result;
}

export async function verifyGitHubStagedFiles(
  target: GitHubSyncTarget, checkoutRoot: string, files: GitHubSyncManagedFile[],
  onVerified?: (count: number) => void,
): Promise<void> {
  const checkout = githubSyncCheckoutPath(target, checkoutRoot);
  const tree = await git(checkout, ["write-tree"]);
  const sizes = new Map<string, number>();
  for (const entry of (await git(checkout, ["ls-tree", "-r", "-l", "-z", tree])).split("\0").filter(Boolean)) {
    const separator = entry.indexOf("\t");
    if (separator >= 0) sizes.set(entry.slice(separator + 1), Number(entry.slice(0, separator).trim().split(/\s+/)[3]));
  }
  let batch: GitHubSyncManagedFile[] = [];
  let bytes = 0;
  let verified = 0;
  const flush = async (): Promise<void> => {
    if (!batch.length) return;
    const contents = await readGitHubRemoteFilesForSubscription(target, checkoutRoot, tree,
      batch.map(file => ({ path:file.path, size:sizes.get(file.path)! })), 64 * 1024 * 1024);
    for (const file of batch) {
      const content = contents.get(file.path)!;
      if (file.content && !content.equals(file.content)) {
        throw new Error(`Staged content differs from the validated Sync plan: ${file.path}`);
      }
      validateManagedContent({ ...file, digest: fileDigest(content) }, content, true);
      file.digest = fileDigest(content);
      file.content = content;
    }
    verified += batch.length;
    onVerified?.(verified);
    batch = [];
    bytes = 0;
  };
  for (const file of files) {
    const size = sizes.get(file.path);
    if (size === undefined) throw new Error(`Staged manifest references a missing file: ${file.path}.`);
    if (batch.length && (batch.length >= 1024 || bytes + size > 32 * 1024 * 1024)) await flush();
    batch.push(file);
    bytes += size;
  }
  await flush();
}

export async function restoreGitHubRemoteFiles(
  target: GitHubSyncTarget,
  checkoutRoot: string,
  storeRoot: string,
  commit: string,
  selectedPaths: string[],
  overwrite: boolean,
  credentials?: GitHubSyncCredentials
): Promise<GitHubSyncRestoreResult> {
  const snapshot = await fetchGitHubRemoteSnapshot(target, checkoutRoot, false, credentials);
  if (snapshot.commit !== commit) throw new Error("Remote content changed. Refresh the remote browser before restoring.");
  const available = new Set(snapshot.files.map(file => file.path));
  const selected = [...new Set(selectedPaths.map(githubSyncSafeRelativePath))].sort((left, right) => left.localeCompare(right));
  if (!selected.length) throw new Error("Select at least one remote file to restore.");
  for (const file of selected) if (!available.has(file)) throw new Error(`Remote file is not in the PKM manifest: ${file}`);
  for (const file of selected) {
    if (githubSyncIsSystemContent(file.split("/")[0] as GitHubSyncContentType, "", "", file)) {
      throw new Error(`System content is excluded from GitHub Sync restore: ${file}`);
    }
  }
  const scriptPaths = new Set(snapshot.files.filter(file => file.type === "scripts").map(file => file.path));
  const restorePaths = [...new Set(selected.flatMap(file => {
    if (!scriptPaths.has(file) || path.posix.basename(file).startsWith(".")) return [file];
    const sidecar = path.posix.join(path.posix.dirname(file), `.${path.posix.basename(file)}.pkm.json`);
    return scriptPaths.has(sidecar) ? [file, sidecar] : [file];
  }))].sort((left, right) => left.localeCompare(right));
  const excluded = await githubSyncExcludedPaths(storeRoot, restorePaths);
  if (excluded.size) throw new Error(`Local ignore rules exclude these files from restore: ${[...excluded].join(", ")}. Change the ignore rules before restoring them.`);
  const destinations = restorePaths.map(file => ({
    file,
    destination: file.startsWith("agentSnapshots/")
      ? managedPath(path.join(storeRoot, ".pkm", "state"), `agent-snapshots/${file.slice("agentSnapshots/".length)}`)
      : managedPath(storeRoot, file),
  }));
  const conflicts = destinations.filter(item => fs.existsSync(item.destination)).map(item => item.file);
  if (conflicts.length && !overwrite) return { restored: [], conflicts };
  const contents = await Promise.all(destinations.map(async item => ({
    ...item,
    content: await readGitHubRemoteFile(target, checkoutRoot, commit, item.file, 8 * 1024 * 1024)
  })));
  for (const item of contents) {
    if (githubSyncIsSystemItem(item.file.split("/")[0] as GitHubSyncContentType, {
      id: "", label: "", cat: "", isPrivate: false, destination: item.file, content: item.content.toString("utf8"),
    })) throw new Error(`System content is excluded from GitHub Sync restore: ${item.file}`);
  }
  replaceGitHubSyncFilesAtomically(contents.map(item => ({ destination: item.destination, content: item.content })), "GitHub Sync restore", storeRoot);
  return { restored: restorePaths, conflicts };
}

async function prepareCheckout(target: GitHubSyncTarget, checkout: string, credentials?: GitHubSyncCredentials): Promise<void> {
  if (!fs.existsSync(path.join(checkout, ".git"))) {
    fs.mkdirSync(path.dirname(checkout), { recursive: true });
    await git(path.dirname(checkout), ["clone", "--origin", "origin", target.repository, checkout], target, false, credentials);
  }
  const remote = await git(checkout, ["remote", "get-url", "origin"]);
  if (remote !== target.repository) throw new Error("Managed checkout points to a different repository. Delete the target and create it again.");
  await git(checkout, ["config", "--local", "core.longpaths", "true"]);
  if (await git(checkout, ["status", "--porcelain"])) throw new Error("Managed checkout has uncommitted changes; synchronization stopped.");
  await git(checkout, ["fetch", "origin", "--prune"], target, false, credentials);
  const localRef = `refs/heads/${target.branch}`;
  const remoteRef = `refs/remotes/origin/${target.branch}`;
  const localExists = await hasRef(checkout, localRef);
  const remoteExists = await hasRef(checkout, remoteRef);
  if (localExists) await git(checkout, ["checkout", target.branch]);
  else if (remoteExists) await git(checkout, ["checkout", "--track", "-b", target.branch, `origin/${target.branch}`]);
  else {
    await git(checkout, ["checkout", "--orphan", target.branch]);
    await git(checkout, ["rm", "-rf", "--ignore-unmatch", "--", "."]);
    await git(checkout, ["clean", "-fdx"]);
  }
  const hasHead = await hasRef(checkout, "HEAD");
  if (remoteExists && hasHead) {
    if (await isAncestor(checkout, "HEAD", `origin/${target.branch}`)) {
      await git(checkout, ["merge", "--ff-only", `origin/${target.branch}`]);
      return;
    }
    await git(checkout, ["reset", "--hard", `origin/${target.branch}`]);
    await git(checkout, ["clean", "-fd"]);
  }
}

const MANIFEST_PATH = ".pkm-github-sync.json";

function fileDigest(content: Buffer): string {
  return createHash("sha256").update(content).digest("hex");
}

const PKM_MANAGED_FRONTMATTER_FIELDS = new Set(["schema", "knowledgeId", "revision", "aliases"]);

function markdownFrontmatterParts(file: GitHubSyncManagedFile): { fields: Map<string, string>; body: string } | undefined {
  if (!file.path.toLocaleLowerCase("en-US").endsWith(".md") || !file.content) return undefined;
  const text = file.content.toString("utf8");
  if (!Buffer.from(text, "utf8").equals(file.content)) return undefined;
  const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text);
  if (!match) return undefined;
  const fields = new Map<string, string>();
  let key = "";
  let value: string[] = [];
  const commit = (): void => {
    if (key) fields.set(key, value.join("\n").trim());
  };
  for (const line of match[1].replace(/\r\n/g, "\n").split("\n")) {
    const field = /^([A-Za-z][A-Za-z0-9_-]*):(?:\s*(.*))?$/.exec(line);
    if (field) {
      commit();
      key = field[1];
      value = [field[2] || ""];
    } else if (key) {
      value.push(line);
    }
  }
  commit();
  return { fields, body: match[2].replace(/\r\n/g, "\n") };
}

function normalizedTags(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;
  const inline = value.trim();
  let tags: string[];
  if (inline.startsWith("[") && inline.endsWith("]")) {
    try {
      const parsed = JSON.parse(inline);
      if (!Array.isArray(parsed)) return undefined;
      tags = parsed.map(tag => String(tag));
    } catch {
      tags = inline.slice(1, -1).split(",").map(tag => tag.trim().replace(/^["']|["']$/g, "")).filter(Boolean);
    }
  } else {
    tags = inline.split("\n").map(line => /^\s*-\s*(.*?)\s*$/.exec(line)?.[1] || "")
      .map(tag => tag.replace(/^["']|["']$/g, "")).filter(Boolean);
  }
  return JSON.stringify([...new Set(tags)].sort((left, right) => left.localeCompare(right)));
}

function frontmatterMigrationEquivalent(local: GitHubSyncManagedFile, remote: GitHubSyncManagedFile): boolean {
  const localParts = markdownFrontmatterParts(local);
  const remoteParts = markdownFrontmatterParts(remote);
  if (!localParts || !remoteParts || localParts.body !== remoteParts.body) return false;
  const hasManagedMigration = [...PKM_MANAGED_FRONTMATTER_FIELDS]
    .some(key => localParts.fields.get(key) !== remoteParts.fields.get(key));
  if (!hasManagedMigration && local.digest !== remote.digest) return false;
  const keys = new Set([...localParts.fields.keys(), ...remoteParts.fields.keys()]);
  for (const key of keys) {
    if (PKM_MANAGED_FRONTMATTER_FIELDS.has(key)) continue;
    if (key === "tags") {
      if (normalizedTags(localParts.fields.get(key)) !== normalizedTags(remoteParts.fields.get(key))) return false;
      continue;
    }
    if (localParts.fields.get(key) !== remoteParts.fields.get(key)) return false;
  }
  return true;
}

function isBuiltInRecipe(file: GitHubSyncManagedFile | undefined): boolean {
  if (file?.type !== "recipes" || !file.content) return false;
  try {
    return JSON.parse(file.content.toString("utf8"))?.systemKind === "built-in";
  } catch {
    return false;
  }
}

function isSystemManagedFile(file: GitHubSyncManagedFile): boolean {
  return githubSyncIsSystemContent(file.type, file.category, file.itemId, file.path) || isBuiltInRecipe(file);
}

async function manifestAtCommit(target: GitHubSyncTarget, checkoutRoot: string, checkout: string, commit: string,
  strictCurrentRemote = false): Promise<GitHubSyncManifest> {
  const raw = (await gitBuffer(checkout, ["cat-file", "blob", `${commit}:${MANIFEST_PATH}`], undefined, 16 * 1024 * 1024)).toString("utf8");
  const manifest = parseManagedManifest(raw);
  const sizes = new Map<string, number>();
  for (const entry of (await git(checkout, ["ls-tree", "-r", "-l", "-z", commit])).split("\0").filter(Boolean)) {
    const separator = entry.indexOf("\t");
    if (separator < 0) continue;
    sizes.set(entry.slice(separator + 1), Number(entry.slice(0, separator).trim().split(/\s+/)[3]));
  }
  let batch: Array<{ path: string; size: number }> = [];
  let batchBytes = 0;
  const loadBatch = async (): Promise<void> => {
    if (!batch.length) return;
    const contents = await readGitHubRemoteFilesForSubscription(target, checkoutRoot, commit, batch, 64 * 1024 * 1024);
    for (const file of manifest.files.filter(file => contents.has(file.path))) {
      file.content = contents.get(file.path)!;
      if (strictCurrentRemote) {
        validateManagedContent(file, file.content, true);
        continue;
      }
      const verified = verifyGitHubSyncBaseDigest(commit, file.path, file.digest, file.content);
      file.digest = verified.digest;
      if (verified.evidence) file.baseIntegrityEvidence = verified.evidence;
    }
    batch = [];
    batchBytes = 0;
  };
  for (const file of manifest.files) {
    const size = sizes.get(file.path);
    if (size === undefined) throw new Error(`${strictCurrentRemote ? "Remote" : "Base"} manifest references a missing file: ${file.path}.`);
    if (batch.length && batchBytes + size > 32 * 1024 * 1024) await loadBatch();
    batch.push({ path: file.path, size });
    batchBytes += size;
  }
  await loadBatch();
  if (strictCurrentRemote) {
    const managedPaths = new Set(manifest.files.map(file => file.path.toLocaleLowerCase("en-US")));
    const omitted = [...sizes.keys()].find(file => GITHUB_SYNC_CONTENT_TYPES.includes(file.split("/", 1)[0] as GitHubSyncContentType)
      && !managedPaths.has(file.toLocaleLowerCase("en-US")));
    if (omitted) throw new Error(`Remote managed file is missing from the manifest: ${omitted}`);
  }
  const evidence = manifest.files.flatMap(file => file.baseIntegrityEvidence ? [{ path: file.path, ...file.baseIntegrityEvidence }] : []);
  if (evidence.length) {
    // Keep the original manifest/blob hashes and commit identity outside managed content.
    const directory = path.join(checkoutRoot, target.id, "base-integrity");
    fs.mkdirSync(directory, { recursive: true });
    writeAtomic(path.join(directory, `${createHash("sha256").update(commit).digest("hex")}.json`),
      Buffer.from(JSON.stringify({ schema: 1, commit, files: evidence }, null, 2), "utf8"));
  }
  return manifest;
}

function managedComparisonDigest(file: GitHubSyncManagedFile): string {
  if (!file.content) return file.digest;
  return fileDigest(githubSyncComparisonContent(file.type, file.content, file.path));
}

function managedContentsEquivalent(local: GitHubSyncManagedFile, remote: GitHubSyncManagedFile): boolean {
  return local.digest === remote.digest
    || local.type === remote.type && managedComparisonDigest(local) === managedComparisonDigest(remote);
}

function enrichLegacyFiles(files: GitHubSyncManagedFile[], known: Map<string, GitHubSyncManagedFile>): void {
  for (const file of files) {
    if (file.itemId) continue;
    const metadata = known.get(file.path);
    if (!metadata) continue;
    file.type = metadata.type;
    file.itemId = metadata.itemId;
    file.category = metadata.category;
    file.privacy = metadata.privacy;
  }
}

function syncLocalPath(storeRoot: string, relative: string): string {
  return relative.startsWith("agentSnapshots/")
    ? managedPath(path.join(storeRoot, ".pkm", "state"), `agent-snapshots/${relative.slice("agentSnapshots/".length)}`)
    : managedPath(storeRoot, relative);
}

function validateManagedContent(file: GitHubSyncManagedFile, content: Buffer, existingRemote = false): void {
  if (fileDigest(content) !== file.digest) throw new Error(`GitHub Sync content digest does not match the manifest: ${file.path}`);
  const text = content.toString("utf8");
  if (file.type === "profiles") {
    if (content.length > 32_000 || !Buffer.from(text, "utf8").equals(content)) throw new Error("Profile is not bounded UTF-8 JSON.");
    const record: unknown = JSON.parse(text);
    validatePersona(record);
    if (file.path !== portablePersonaPath(record) || file.privacy !== "private"
      || file.itemId !== `${record.kind}/${record.id}` && file.itemId !== file.path) throw new Error("Profile path or privacy mismatch.");
    return;
  }
  if (!existingRemote && githubSyncIsTextContent(file.path, content)
    && /^(?:<<<<<<<(?: .*)?|>>>>>>>(?: .*)?)\r?$/m.test(text)) {
    throw new Error(`GitHub Sync content still contains merge conflict markers: ${file.path}`);
  }
  if (file.type === "skills" && (file.path.split("/").slice(0, -1).some(isMarkdownAssetDirectory)
    || file.member && path.posix.basename(file.member).toLowerCase() !== "skill.md")) return;
  if (file.type === "actions") {
    const value = JSON.parse(text);
    if (value?.schema !== "pkm.action.definition/v1" || !/^[a-z][a-z0-9_.-]{2,100}$/.test(value.action_id)
      || file.path !== `actions/${value.action_id}.json` || !Number.isInteger(value.version) || value.version < 1
      || !Array.isArray(value.implementations) || !value.implementations.length
      || !value.input_schema || !value.output_schema || !Array.isArray(value.effects)) throw new Error(`Invalid portable Action definition: ${file.path}`);
    if (githubSyncIsSystemContent("actions", "", value.action_id)) throw new Error(`System Actions cannot be synchronized: ${file.path}`);
    return;
  }
  if (file.type === "action-module-sets") {
    const member = file.path.split("/").slice(3).join("/");
    if (member !== "manifest.json" && !/^(?:definitions|assets)\//.test(member)) throw new Error(`Only ModuleSet manifests, definitions and assets may be synchronized: ${file.path}`);
    if (member === "manifest.json") {
      const value = JSON.parse(text);
      if (!value || value.schema !== "pkm.action.module-set/v1" || `${value.module_set_id}/${value.version}` !== file.path.split("/").slice(1, 3).join("/")
        || typeof value.files !== "object" || !value.files || Array.isArray(value.files)
        || Object.entries(value.files).some(([name, hash]) => !/^(?:definitions|assets)\//.test(name)
          || githubSyncSafeRelativePath(name) !== name || typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash))) throw new Error(`Invalid ModuleSet file manifest: ${file.path}`);
    }
    return;
  }
  if (file.type !== "skills" && file.type !== "recipes") return;
  if (!Buffer.from(text, "utf8").equals(content) || text.includes("\0")) throw new Error(`GitHub Sync content is not valid UTF-8 text: ${file.path}`);
  if (file.type === "recipes") {
    let parsed: any;
    try { parsed = JSON.parse(text); }
    catch { throw new Error(`Recipe is not valid JSON: ${file.path}`); }
    if (!parsed || typeof parsed !== "object" || typeof parsed.recipeId !== "string" || typeof parsed.name !== "string" || !parsed.definition) {
      throw new Error(`Recipe is missing recipeId, name, or definition: ${file.path}`);
    }
    const compiled = compileWorkflowDefinitionV1(parsed.definition);
    if (!compiled.ok) throw Object.assign(new Error(`Recipe definition is invalid: ${file.path}`),
      { reason: "recipe-definition", diagnostics: compiled.diagnostics, recipeId: parsed.recipeId });
    if (compiled.executableDigest !== parsed.executableDigest) throw Object.assign(new Error(`Recipe executable digest is invalid: ${file.path}`),
      { reason: "recipe-digest", recipeId: parsed.recipeId, diagnostics: [
        { storedDigest: parsed.executableDigest, compiledDigest: compiled.executableDigest },
      ] });
    const segments = file.path.split("/");
    const filename = segments.pop() || "";
    const category = segments.slice(1).join("/") === "Uncategorized" ? "" : segments.slice(1).join("/");
    if (!filename.endsWith(`.${parsed.recipeId}.json`)) throw new Error(`Recipe path identity is invalid: ${file.path}`);
    if (String(parsed.category || "") !== category) throw new Error(`Recipe path category is invalid: ${file.path}`);
    return;
  }
  if (!existingRemote && /^(?:<<<<<<<|=======|>>>>>>>)/m.test(text)) throw new Error(`Skill still contains merge conflict markers: ${file.path}`);
  const frontmatter = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text);
  if (!frontmatter) throw new Error(`Skill has invalid or missing frontmatter: ${file.path}`);
  const name = /^name:\s*(.+?)\s*$/m.exec(frontmatter[1])?.[1]?.trim().replace(/^["']|["']$/g, "");
  if (!name || !frontmatter[2].trim()) throw new Error(`Skill must have a name and non-empty body: ${file.path}`);
}

export function githubSyncIsTextContent(relative: string, content: Buffer): boolean {
  return !/\.(?:png|jpe?g|gif|webp|ico|pdf|zip|gz|7z|woff2?|ttf|wasm|exe|dll|so|mp[34]|wav)$/i.test(relative)
    && !content.includes(0) && Buffer.from(content.toString("utf8"), "utf8").equals(content);
}

export function validateGitHubSyncCandidate(relative: string, content: Buffer, member = ""): void {
  const safe = githubSyncSafeRelativePath(relative);
  const type = safe.split("/", 1)[0] as GitHubSyncContentType;
  if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(type)) throw new Error(`Unsupported GitHub Sync content path: ${safe}`);
  if (type === "recipes" && safe.split("/").includes(".trash")) throw new Error(`Recipe Trash is local-only: ${safe}`);
  validateManagedContent({
    path: safe,
    type,
    itemId: safe,
    member,
    category: "",
    privacy: type === "profiles" ? "private" : "public",
    digest: fileDigest(content),
  }, content);
}

/** Collect blockers without treating any failed validation as successful content. */
export async function inspectGitHubSyncLocalContent(target: GitHubSyncTarget, catalog: GitHubSyncCatalog, storeRoot?: string) {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  if (normalized.selection.public.profiles.items.length || normalized.selection.public.profiles.folders.length
    || githubSyncProfilesSelected(normalized) && (!githubSyncProfilesAuthorized(normalized)
      || !storeRoot || !sameKnowledgeRoot(normalized.profileSyncConsent!.root, storeRoot))) {
    throw new Error("Profile Sync requires separate approval for this Knowledge Root, repository, branch and selection. Save the target to review it.");
  }
  const issues: GitHubSyncContentIssue[] = [];
  const materialized = selectedFiles(normalized, catalog, new Set(), issues);
  const scopeSnapshot = [...materialized.files];
  const excluded = await githubSyncExcludedPaths(storeRoot, [...materialized.files.map(file => file.path), ...issues.map(issue => issue.path)]);
  materialized.files = materialized.files.filter(file => !excluded.has(file.path));
  for (let index = issues.length - 1; index >= 0; index--) if (excluded.has(issues[index].path)) issues.splice(index, 1);
  issues.push(...collectGitHubSyncLocalContentIssues(materialized.files, catalog));
  return { issues, materialized, scopeSnapshot, excluded };
}

export function collectGitHubSyncLocalContentIssues(files: GitHubSyncManagedFile[], catalog: GitHubSyncCatalog): GitHubSyncContentIssue[] {
  const issues: GitHubSyncContentIssue[] = [];
  for (const file of files) {
    const content = file.content!;
    const inspection = githubSyncIsTextContent(file.path, content) ? inspectConflictMarkers(content.toString("utf8")) : { lines: [] };
    const item = catalog[file.type].find(candidate => candidate.id === file.itemId
      || file.type === "scripts" && (candidate.destination === file.path || candidate.dependencies?.some(dependency => dependency.destination === file.path)));
    const sourcePath = item?.content === undefined && item?.source
      ? file.member
        ? item.dependencies?.find(dependency => dependency.destination === file.path)?.source
          || path.join(item.source, ...file.member.split("/"))
        : item.source
      : file.sourceLocator?.kind === "file" ? file.sourceLocator.path : undefined;
    const common = {
      path: file.path, type: file.type, itemId: file.itemId, source: "local" as const,
      digest: file.digest, content: content.toString("utf8"),
      ...(sourcePath && file.sourceDigest ? { sourceDigest: file.sourceDigest } : {}),
      ...(sourcePath ? { sourcePath, sourceLocator: { kind: "file" as const, path: sourcePath } } : {}),
      ...(file.type === "recipes" ? { recipeId: file.itemId,
        sourceLocator: item?.sourceLocator || { kind: "recipe-store" as const, recipeId: file.itemId } } : {}),
    };
    if (inspection.lines.length) {
      issues.push({ ...common, reason: "merge-conflict-markers", lines: inspection.lines,
        ...(inspection.candidate !== undefined ? { candidate: inspection.candidate } : {}) });
    }
    try {
      // Markers are separately blocked above; still inspect the other contracts.
      validateManagedContent(file, content, inspection.lines.length > 0);
    } catch (error) {
      const detail = error as Error & { reason?: GitHubSyncContentIssue["reason"]; diagnostics?: unknown[]; recipeId?: string };
      issues.push({ ...common, reason: detail.reason || "content-validation", lines: [],
        error: detail.message || String(error), ...(detail.diagnostics ? { diagnostics: detail.diagnostics } : {}),
        ...(detail.recipeId ? { recipeId: detail.recipeId,
          sourceLocator: item?.sourceLocator || { kind: "recipe-store", recipeId: detail.recipeId } } : {}) });
    }
  }
  return issues;
}

export function cleanupGitHubSyncTemporary(temporary: string, primary?: unknown): void {
  try { fs.rmSync(temporary, { force: true, maxRetries: 4, retryDelay: 20 }); }
  catch (cleanupError) {
    const detail = cleanupError instanceof Error ? cleanupError.message : String(cleanupError);
    if (primary) throw new Error(`${primary instanceof Error ? primary.message : String(primary)}. Temporary cleanup also failed: ${detail}`);
    throw cleanupError;
  }
}

function writeAtomic(destination: string, content: Buffer, mode?: number): void {
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  const temporary = `${destination}.pkm-sync-${process.pid}-${randomUUID()}.tmp`;
  let primary: unknown;
  try {
    fs.writeFileSync(temporary, content, { flag: "wx", mode });
    const descriptor = fs.openSync(temporary, "r+");
    try { fs.fsyncSync(descriptor); } finally { fs.closeSync(descriptor); }
    const waitArray = new Int32Array(new SharedArrayBuffer(4));
    for (let attempt = 0; ; attempt++) {
      try {
        fs.renameSync(temporary, destination);
        break;
      } catch (error: any) {
        if (!["EPERM", "EBUSY", "EACCES"].includes(error?.code) || attempt >= 7) throw error;
        Atomics.wait(waitArray, 0, 0, 15 * (attempt + 1));
      }
    }
  } catch (error) {
    primary = error;
    throw error;
  } finally {
    cleanupGitHubSyncTemporary(temporary, primary);
  }
}

function rollbackGitHubSyncMutation(destination: string, original: Buffer | undefined, written: Buffer | undefined): void {
  const current = fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
  if (current === undefined ? written !== undefined : !written?.equals(current)) {
    const backup = fs.mkdtempSync(path.join(os.tmpdir(), "pkm-sync-rollback-"));
    if (original !== undefined) writeAtomic(path.join(backup, "original"), original, 0o600);
    if (written !== undefined) writeAtomic(path.join(backup, "applied"), written, 0o600);
    writeAtomic(path.join(backup, "receipt.json"), Buffer.from(JSON.stringify({
      destination, originalExists: original !== undefined, appliedExists: written !== undefined,
      at: new Date().toISOString(),
    })), 0o600);
    throw new Error(`Concurrent edit preserved; rollback refused because current content differs from the applied value. Recovery evidence: ${backup}`);
  }
  if (original !== undefined) writeAtomic(destination, original);
  else fs.rmSync(destination, { force: true });
}

function withActionSyncMutation<T>(storeRoot:string | undefined, destinations:string[], apply:() => T):T {
  const action = () => withActionSyncMutationUnlocked(storeRoot, destinations, apply);
  return storeRoot && destinations.some(destination => /^profiles\//.test(path.relative(storeRoot, destination).replace(/\\/g, "/")))
    ? withPersonaRepositoryMutation(storeRoot, action) : action();
}

function withActionSyncMutationUnlocked<T>(storeRoot:string | undefined, destinations:string[], apply:() => T):T {
  const affected = storeRoot ? destinations.map(destination => path.relative(storeRoot, destination).replace(/\\/g, "/"))
    .filter(relative => /^(?:actions|action-module-sets)\//.test(relative)) : [];
  if (!storeRoot || !affected.length) return apply();
  const root = managedPath(storeRoot, ".pkm/state/actions");
  fs.mkdirSync(root, { recursive:true });
  const lock = path.join(root, "mutation.lock");
  let descriptor:number;
  try { descriptor = fs.openSync(lock, "wx", 0o600); }
  catch (error) {
    if (error instanceof Error && "code" in error && error.code === "EEXIST") throw new Error("Action state is busy or requires lock recovery. Retry the original Sync after resolving it.");
    throw error;
  }
  try {
    fs.writeSync(descriptor, JSON.stringify({ pid:process.pid, started_at:new Date().toISOString() }));
    fs.fsyncSync(descriptor);
    const runs = path.join(root, "runs");
    if (fs.existsSync(runs)) for (const name of fs.readdirSync(runs)) {
      const record = managedPath(root, `runs/${name}/run.json`);
      if (!fs.existsSync(record)) continue;
      const run = JSON.parse(fs.readFileSync(record, "utf8"));
      if (["running", "waiting", "outcome_unknown"].includes(run.state)) throw new Error("Resolve active/waiting/uncertain Action Runs before synchronizing Action sources.");
    }
    const queuePath = managedPath(root, "validation-queue.json");
    if (fs.existsSync(queuePath)) {
      const queue = JSON.parse(fs.readFileSync(queuePath, "utf8"));
      if (Object.values(queue.jobs || {}).some(job => !!job && typeof job === "object" && "state" in job
        && ["queued", "running"].includes(String(job.state)))) throw new Error("Cancel or finish queued/running Action qualification before synchronizing Action sources.");
    }
    const settingsPath = managedPath(root, "settings.json");
    const settings = fs.existsSync(settingsPath) ? JSON.parse(fs.readFileSync(settingsPath, "utf8")) : {};
    if (affected.some(relative => {
      const [area, id, version] = relative.split("/");
      return area === "action-module-sets" && settings.enabled_module_sets?.[id] === Number(version);
    })) throw new Error("Unload the affected ModuleSet before synchronizing its installed source version.");
    return apply();
  } finally { fs.closeSync(descriptor); fs.unlinkSync(lock); }
}

export function replaceGitHubSyncFilesAtomically(
  replacements: Array<{ destination: string; content: Buffer | undefined; guard?: { original: Buffer | undefined } }>,
  operation = "GitHub Sync",
  actionStoreRoot?:string
): void {
  withActionSyncMutation(actionStoreRoot, replacements.map(item => item.destination), () => {
    if (actionStoreRoot) validatePortablePersonaChanges(actionStoreRoot, replacements.map(item => ({
      relative:path.relative(actionStoreRoot, item.destination).replace(/\\/g, "/"), content:item.content,
    })));
    replaceGitHubSyncFilesUnlocked(replacements, operation);
  });
}

function replaceGitHubSyncFilesUnlocked(
  replacements: Array<{ destination: string; content: Buffer | undefined; guard?: { original: Buffer | undefined } }>,
  operation = "GitHub Sync"
): void {
  const originals = replacements.map(item => ({
    destination: item.destination,
    content: fs.existsSync(item.destination) ? fs.readFileSync(item.destination) : undefined,
  }));
  const completed: number[] = [];
  try {
    for (let index = 0; index < replacements.length; index++) {
      const replacement = replacements[index];
      if (replacement.guard) {
        const current = fs.existsSync(replacement.destination) ? fs.readFileSync(replacement.destination) : undefined;
        if (!githubSyncLocalSnapshotMatches(replacement.guard.original, replacement.content, current)) {
          throw new Error(`Local content changed at the mutation boundary: ${replacement.destination}`);
        }
      }
      if (replacement.content) writeAtomic(replacement.destination, replacement.content);
      else fs.rmSync(replacement.destination, { force: true });
      completed.push(index);
    }
  } catch (error) {
    const rollbackErrors: string[] = [];
    for (const index of completed.reverse()) {
      const original = originals[index];
      try {
        rollbackGitHubSyncMutation(original.destination, original.content, replacements[index].content);
      } catch (rollbackError) {
        rollbackErrors.push(`${original.destination}: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);
      }
    }
    const primary = error instanceof Error ? error.message : String(error);
    if (rollbackErrors.length) throw new Error(`${operation} failed: ${primary}. Rollback also failed for ${rollbackErrors.join("; ")}`);
    throw error;
  }
}

interface GitHubSyncLocalWrite {
  file: GitHubSyncManagedFile;
  content: Buffer;
  expectedLocal?: Buffer;
}

class GitHubSyncLocalChangeError extends Error {
  constructor(
    public readonly file: GitHubSyncManagedFile,
    public readonly expectedLocal: Buffer | undefined,
    public readonly currentLocal: Buffer | undefined,
    public readonly remote: Buffer | undefined,
  ) {
    super(`Local content changed during synchronization: ${file.path}`);
  }
}

function applyLocalChanges(...args:Parameters<typeof applyLocalChangesUnlocked>):ReturnType<typeof applyLocalChangesUnlocked> {
  const [storeRoot, writes, deletes] = args;
  return withActionSyncMutation(storeRoot, storeRoot ? [...writes, ...deletes].map(item => syncLocalPath(storeRoot, item.file.path)) : [],
    () => applyLocalChangesUnlocked(...args));
}

function applyLocalChangesUnlocked(
  storeRoot: string | undefined,
  localWrites: GitHubSyncLocalWrite[],
  localDeletes: Array<{ file: GitHubSyncManagedFile; expectedLocal?: Buffer }>
): { pulled: string[]; deletedLocal: string[]; privateTopLevels: Partial<Record<GitHubSyncContentType, string[]>>; recipePulls: GitHubSyncRecipePull[]; recipeDeletes: GitHubSyncRecipeDelete[] } {
  const pulled: string[] = [];
  const deletedLocal: string[] = [];
  if ([...localWrites, ...localDeletes].some(item => isSystemManagedFile(item.file))) {
    throw new Error("System content cannot be changed by GitHub Sync.");
  }
  const recipePulls = localWrites
    .filter(item => item.file.type === "recipes")
    .map(item => ({ path: item.file.path, itemId: item.file.itemId, content: item.content, expectedLocal: item.expectedLocal }));
  const recipeDeletes = [...new Map(localDeletes
    .filter(item => item.file.type === "recipes")
    .map(item => [item.file.itemId, { itemId: item.file.itemId, path: item.file.path, expectedLocal: item.expectedLocal }])).values()];
  const privateTopLevels = new Map<GitHubSyncContentType, Set<string>>();
  if (!storeRoot) return { pulled, deletedLocal, privateTopLevels: {}, recipePulls: [], recipeDeletes: [] };
  validatePortablePersonaChanges(storeRoot, [
    ...localWrites.map(item => ({relative:item.file.path,content:item.content})),
    ...localDeletes.map(item => ({relative:item.file.path,content:undefined})),
  ]);
  const replacements = localWrites.filter(item => item.file.type !== "recipes").map(item => ({
    item,
    destination: syncLocalPath(storeRoot, item.file.path),
  }));
  for (const { item, destination } of replacements) {
    const current = fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
    if (item.file.type === "action-module-sets" && current && !current.equals(item.content)) {
      throw new Error(`Immutable ModuleSet member differs: ${item.file.path}. Publish a new version, or use explicit recovery for damaged files.`);
    }
    if (!githubSyncLocalSnapshotMatches(item.expectedLocal, item.content, current)) {
      throw new GitHubSyncLocalChangeError(item.file, item.expectedLocal, current, item.content);
    }
  }
  const deletions = localDeletes.filter(item => item.file.type !== "recipes").map(item => ({
    item,
    destination: syncLocalPath(storeRoot, item.file.path),
  }));
  for (const { item, destination } of deletions) {
    const current = fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
    if (current && !(item.expectedLocal?.equals(current))) {
      throw new GitHubSyncLocalChangeError(item.file, item.expectedLocal, current, undefined);
    }
  }
  const mutations = [
    ...replacements.map(({ item, destination }) => ({ destination, content: item.content, expected: item.expectedLocal, file: item.file })),
    ...deletions.map(({ item, destination }) => ({ destination, content: undefined, expected: item.expectedLocal, file: item.file })),
  ];
  const originals = mutations.map(item => ({
    destination: item.destination,
    content: fs.existsSync(item.destination) ? fs.readFileSync(item.destination) : undefined,
  }));
  const completed: number[] = [];
  try {
    for (let index = 0; index < mutations.length; index++) {
      const mutation = mutations[index];
      const current = fs.existsSync(mutation.destination) ? fs.readFileSync(mutation.destination) : undefined;
      if (!githubSyncLocalSnapshotMatches(mutation.expected, mutation.content, current)) {
        throw new GitHubSyncLocalChangeError(mutation.file, mutation.expected, current, mutation.content);
      }
      if (mutation.content) writeAtomic(mutation.destination, mutation.content);
      else fs.rmSync(mutation.destination, { force: true });
      completed.push(index);
    }
  } catch (error) {
    const rollbackErrors: string[] = [];
    for (const index of completed.reverse()) {
      try {
        const original = originals[index];
        rollbackGitHubSyncMutation(original.destination, original.content, mutations[index].content);
      } catch (rollbackError) {
        rollbackErrors.push(`${originals[index].destination}: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);
      }
    }
    if (rollbackErrors.length) {
      throw new Error(`GitHub Sync local update failed: ${error instanceof Error ? error.message : String(error)}. Rollback also failed for ${rollbackErrors.join("; ")}`);
    }
    throw error;
  }
  for (const item of localWrites) {
    pulled.push(item.file.path);
    if (item.file.privacy === "private" && item.file.type !== "agentSnapshots" && item.file.type !== "profiles") {
      const topLevel = item.file.type === "actions" ? item.file.itemId : item.file.category.split("/").filter(Boolean)[0];
      if (topLevel) {
        const values = privateTopLevels.get(item.file.type) || new Set<string>();
        values.add(topLevel);
        privateTopLevels.set(item.file.type, values);
      }
    }
  }
  for (const { file } of localDeletes) if (file.type !== "recipes") deletedLocal.push(file.path);
  return {
    pulled,
    deletedLocal,
    privateTopLevels: Object.fromEntries([...privateTopLevels].map(([type, values]) => [type, [...values].sort()])),
    recipePulls,
    recipeDeletes,
  };
}

type GitHubSyncEntityMap = Map<string, GitHubSyncManagedFile[]>;

function entityKey(type: GitHubSyncContentType, itemId: string): string {
  return `${type}\0${itemId}`;
}

function groupManagedFiles(files: Iterable<GitHubSyncManagedFile>): GitHubSyncEntityMap {
  const groups: GitHubSyncEntityMap = new Map();
  for (const file of files) {
    const key = entityKey(file.type, file.itemId);
    const group = groups.get(key) || [];
    group.push(file);
    groups.set(key, group);
  }
  for (const group of groups.values()) group.sort((left, right) => left.member.localeCompare(right.member));
  return groups;
}

function isScriptSidecarEntity(files: GitHubSyncManagedFile[]): boolean {
  if (files.length !== 2 || files[0].type !== "scripts") return false;
  const source = files.find(file => file.member === "");
  const sidecar = files.find(file => file.member !== "");
  return !!source && !!sidecar
    && sidecar.path === path.posix.join(path.posix.dirname(source.path), `.${path.posix.basename(source.path)}.pkm.json`);
}

function migrateBaseManifestToCanonicalSchema(
  base: GitHubSyncManifest,
  remote: GitHubSyncManifest,
): GitHubSyncManifest {
  const remoteByPath = new Map(remote.files.map(file => [file.path, file]));
  const remoteByContent = new Map<string, GitHubSyncManagedFile[]>();
  for (const file of remote.files) {
    const key = `${file.type}\0${managedComparisonDigest(file)}`;
    const matches = remoteByContent.get(key) || [];
    matches.push(file);
    remoteByContent.set(key, matches);
  }
  return {
    schema: GITHUB_SYNC_MANIFEST_SCHEMA,
    minimumExtensionVersion: remote.minimumExtensionVersion,
    files: base.files.map(file => {
      // Script ancestry needs validated identity/path lineage, not a unique content hash.
      if (file.type === "scripts") return file;
      const exact = remoteByPath.get(file.path);
      const contentMatches = remoteByContent.get(`${file.type}\0${managedComparisonDigest(file)}`) || [];
      const canonical = exact || (contentMatches.length === 1 ? contentMatches[0] : undefined);
      return canonical
        ? {
          ...file,
          type: canonical.type,
          itemId: canonical.itemId,
          member: canonical.member,
          category: canonical.category,
          privacy: canonical.privacy,
        }
        : file;
    }),
    deletions: [],
  };
}

export function githubSyncUnrecordedAbsenceNeedsReview(
  base: boolean, local: boolean, remote: boolean, localDeletion: boolean, remoteDeletion: boolean,
): boolean {
  return base && ((!local && remote && !localDeletion) || (local && !remote && !remoteDeletion));
}

export function githubSyncDurableEntityDeletion(
  files: GitHubSyncManagedFile[], localPresent: boolean, deletions: ReadonlyMap<string, { deletedAt: string }>,
): GitHubSyncDeletionEvidence | undefined {
  if (localPresent || !files.length || files.some(isSystemManagedFile)) return undefined;
  const deleted = files.find(file => file.member === "" && deletions.has(file.path))
    || (files.every(file => deletions.has(file.path)) ? files[0] : undefined);
  if (!deleted) return undefined;
  return {
    type: deleted.type, itemId: deleted.itemId, category: deleted.category, privacy: deleted.privacy,
    deletedAt: deletions.get(deleted.path)!.deletedAt,
  };
}

function entityState(files: GitHubSyncManagedFile[] | undefined): string | undefined {
  if (!files) return undefined;
  return JSON.stringify(files.map(file => ({
    member: file.member,
    path: file.path,
    digest: managedComparisonDigest(file),
    category: file.category,
    privacy: file.privacy,
  })));
}

function scriptDeletionMetadataEquivalent(base: GitHubSyncManagedFile[] | undefined, remote: GitHubSyncManagedFile[] | undefined): boolean {
  if (base?.length !== 1 || remote?.length !== 2 || base[0].type !== "scripts" || !isScriptSidecarEntity(remote)) return false;
  const body = remote.find(file => file.member === "")!;
  const sidecar = remote.find(file => file.member === "identity-sidecar");
  if (!sidecar?.content || base[0].member !== "" || base[0].path !== body.path
    || base[0].privacy !== body.privacy || base[0].category !== body.category
    || managedComparisonDigest(base[0]) !== managedComparisonDigest(body)) return false;
  return readSyncScriptIdentity(sidecar.content).knowledgeId === body.itemId
    && sidecar.itemId === body.itemId && sidecar.privacy === body.privacy && sidecar.category === body.category;
}

function entityContentState(files: GitHubSyncManagedFile[] | undefined): string | undefined {
  if (!files) return undefined;
  return JSON.stringify(files.map(file => ({ member: file.member, digest: managedComparisonDigest(file) })));
}

function entityPathState(files: GitHubSyncManagedFile[] | undefined): string | undefined {
  if (!files) return undefined;
  return JSON.stringify(files.filter(file => file.type !== "scripts" || file.member === "")
    .map(file => ({ member: file.member, path: file.path })));
}

function entityPathContentState(files: GitHubSyncManagedFile[] | undefined): string | undefined {
  if (!files) return undefined;
  return JSON.stringify(files.map(file => ({
    type: file.type,
    member: file.member,
    path: file.path,
    digest: managedComparisonDigest(file),
  })));
}

function entityPathLayoutState(files: GitHubSyncManagedFile[] | undefined): string | undefined {
  if (!files) return undefined;
  return JSON.stringify(files.map(file => ({
    type: file.type,
    member: file.member,
    path: file.path,
  })));
}

function reconcileMigratedEntityIdentities(
  authorityEntities: GitHubSyncEntityMap,
  entities: GitHubSyncEntityMap,
  finalRemote?: Map<string, GitHubSyncManagedFile>,
): number {
  const authorityByPathContent = new Map<string, Array<{ key: string; files: GitHubSyncManagedFile[] }>>();
  const authorityByPathLayout = new Map<string, Array<{ key: string; files: GitHubSyncManagedFile[] }>>();
  const resourceOwnersByAlias = new Map<string, Array<{ key: string; files: GitHubSyncManagedFile[] }>>();
  for (const [key, files] of authorityEntities) {
    const contentSignature = entityPathContentState(files)!;
    const matches = authorityByPathContent.get(contentSignature) || [];
    matches.push({ key, files });
    authorityByPathContent.set(contentSignature, matches);
    const layoutSignature = entityPathLayoutState(files)!;
    const layoutMatches = authorityByPathLayout.get(layoutSignature) || [];
    layoutMatches.push({ key, files });
    authorityByPathLayout.set(layoutSignature, layoutMatches);
    const document = files.find(file => file.member === "" && file.content
      && ["notes", "skills", "papers"].includes(file.type) && /\.md$/i.test(file.path));
    if (document?.content) {
      const kind = document.type === "notes" ? "note" : document.type === "skills" ? "skill" : "research";
      const identity = readKnowledgeIdentity(parseStoreFrontmatter(document.content.toString("utf8")).fm, kind, document.itemId);
      if (identity.knowledgeId) for (const alias of identity.aliases) {
        const owners = resourceOwnersByAlias.get(alias) || [];
        owners.push({ key, files });
        resourceOwnersByAlias.set(alias, owners);
      }
    }
  }
  let reconciled = 0;
  for (const [legacyKey, files] of [...entities]) {
    if (authorityEntities.has(legacyKey)) continue;
    if (files[0]?.type === "scripts" && files.some(file => /^script_[a-f0-9]{24}$/.test(file.itemId) || file.member === "identity-sidecar")) continue;
    if (files.length && files.every(file => file.member && ["notes", "skills", "papers"].includes(file.type))) {
      const first = files[0];
      const kind = first.type === "notes" ? "note" : first.type === "skills" ? "skill" : "research";
      const owners = resourceOwnersByAlias.get(legacyKnowledgeAlias(kind, first.itemId)) || [];
      const owner = owners.length === 1 ? owners[0] : undefined;
      if (owner && owner.key !== legacyKey && files.every(file => {
          const resource = owner.files.find(candidate => candidate.path === file.path && candidate.type === file.type
            && candidate.member === file.member);
          const existing = entities.get(owner.key)?.find(candidate => candidate.path === file.path);
          return file.content && resource?.content && file.content.equals(resource.content)
            && (!existing || (existing.content && existing.content.equals(file.content)));
        })) {
        const reassigned = files.map(file => {
          const resource = owner.files.find(candidate => candidate.path === file.path)!;
          return { ...file, itemId: resource.itemId, category: resource.category, privacy: resource.privacy, member: resource.member };
        });
        entities.delete(legacyKey);
        const combined = new Map((entities.get(owner.key) || []).map(file => [file.path, file]));
        for (const file of reassigned) {
          combined.set(file.path, file);
          finalRemote?.set(file.path, file);
        }
        entities.set(owner.key, [...combined.values()].sort((left, right) => left.member.localeCompare(right.member)));
        reconciled++;
        continue;
      }
    }
    let matches = authorityByPathContent.get(entityPathContentState(files)!) || [];
    if (matches.length !== 1) matches = authorityByPathLayout.get(entityPathLayoutState(files)!) || [];
    if (matches.length !== 1 || entities.has(matches[0].key)) continue;
    const canonical = matches[0];
    if (files[0]?.type === "scripts" && canonical.files.some(file => /^script_[a-f0-9]{24}$/.test(file.itemId) || file.member === "identity-sidecar")) continue;
    const authorityByMember = new Map(canonical.files.map(file => [file.member || "", file]));
    const canonicalized = files.map(file => {
      const authority = authorityByMember.get(file.member || "")
        || canonical.files.find(candidate => candidate.path === file.path);
      if (!authority) return file;
      return {
        ...file,
        itemId: authority.itemId,
        category: authority.category,
        privacy: authority.privacy,
        member: authority.member,
      };
    });
    entities.delete(legacyKey);
    entities.set(canonical.key, canonicalized);
    if (finalRemote) {
      for (const file of canonicalized) finalRemote.set(file.path, file);
    }
    reconciled++;
  }
  return reconciled;
}

function entityFileByMember(files: GitHubSyncManagedFile[] | undefined, member: string): GitHubSyncManagedFile | undefined {
  return files?.find(file => file.member === member);
}

function nonEmptyOutput(value: unknown): string {
  if (Buffer.isBuffer(value)) return value.toString("utf8").trim();
  return String(value ?? "").trim();
}

function compactDiagnostic(value: string, maxLength = 500): string {
  const compact = value.replace(/\s+/g, " ").trim();
  return compact.length <= maxLength ? compact : `${compact.slice(0, maxLength)}…`;
}

export function formatGitMergeFileFailure(error: any, managedFilePath: string): string {
  const numericExitCode = Number(error?.code);
  const exitCode = Number.isInteger(numericExitCode)
    ? String(numericExitCode)
    : nonEmptyOutput(error?.code) || "unknown";
  const stderr = nonEmptyOutput(error?.stderr);
  const stdout = nonEmptyOutput(error?.stdout);
  const message = nonEmptyOutput(error?.message);
  const detail = stderr
    ? compactDiagnostic(stderr)
    : stdout
      ? `git produced ${Buffer.byteLength(stdout, "utf8")} bytes of stdout`
      : compactDiagnostic(message);
  return `git merge-file failed for ${managedFilePath} (exit code ${exitCode})${detail ? `: ${detail}` : "."}`;
}

export async function deterministicTextMerge(
  base: Buffer,
  local: Buffer,
  remote: Buffer,
  managedFilePath: string,
): Promise<Buffer | undefined> {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "pkm-github-merge-"));
  const localPath = path.join(directory, "local");
  const basePath = path.join(directory, "base");
  const remotePath = path.join(directory, "remote");
  try {
    fs.writeFileSync(localPath, local);
    fs.writeFileSync(basePath, base);
    fs.writeFileSync(remotePath, remote);
    try {
      const result = await execFileAsync("git", ["merge-file", "-p", localPath, basePath, remotePath], {
        encoding: "buffer",
        maxBuffer: 64 * 1024 * 1024,
        windowsHide: process.platform === "win32",
      });
      return Buffer.from(result.stdout);
    } catch (error: any) {
      const exitCode = Number(error?.code);
      if (Number.isInteger(exitCode) && exitCode >= 1 && exitCode <= 127) return undefined;
      throw new Error(formatGitMergeFileFailure(error, managedFilePath));
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
}

const JSON_MERGE_CONFLICT = Symbol("json-merge-conflict");
const JSON_MISSING = Symbol("json-missing");

function sameJson(left: unknown, right: unknown): boolean {
  return left === right || (left !== JSON_MISSING && right !== JSON_MISSING
    && canonicalJson(left) === canonicalJson(right));
}

function jsonObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function mergeJsonValue(base: unknown, local: unknown, remote: unknown, recipe = false, route: string[] = []): unknown {
  if (sameJson(local, remote)) return local;
  if (sameJson(local, base)) return remote;
  if (sameJson(remote, base)) return local;
  if (jsonObject(base) && jsonObject(local) && jsonObject(remote)) {
    const merged: Record<string, unknown> = Object.create(null);
    for (const key of new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(remote)])) {
      const value = mergeJsonValue(
        Object.prototype.hasOwnProperty.call(base, key) ? base[key] : JSON_MISSING,
        Object.prototype.hasOwnProperty.call(local, key) ? local[key] : JSON_MISSING,
        Object.prototype.hasOwnProperty.call(remote, key) ? remote[key] : JSON_MISSING,
        recipe, [...route, key],
      );
      if (value === JSON_MERGE_CONFLICT) return JSON_MERGE_CONFLICT;
      if (value !== JSON_MISSING) merged[key] = value;
    }
    return merged;
  }
  if (Array.isArray(base) && Array.isArray(local) && Array.isArray(remote)) {
    if (!recipe || route.length !== 3 || route[0] !== "definition" || route[1] !== "spec" || route[2] !== "nodes") {
      return JSON_MERGE_CONFLICT;
    }
    const keyed = (items: unknown[]): Map<string, unknown> | undefined => {
      if (!items.every(item => jsonObject(item) && typeof item.nodeId === "string")) return undefined;
      const entries = items.map(item => [(item as Record<string, unknown>).nodeId as string, item] as const);
      const result = new Map(entries);
      return result.size === items.length ? result : undefined;
    };
    const baseNodes = keyed(base), localNodes = keyed(local), remoteNodes = keyed(remote);
    if (!baseNodes || !localNodes || !remoteNodes) return JSON_MERGE_CONFLICT;
    const merged: unknown[] = [];
    for (const id of new Set([...baseNodes.keys(), ...localNodes.keys(), ...remoteNodes.keys()])) {
      const value = mergeJsonValue(
        baseNodes.has(id) ? baseNodes.get(id) : JSON_MISSING,
        localNodes.has(id) ? localNodes.get(id) : JSON_MISSING,
        remoteNodes.has(id) ? remoteNodes.get(id) : JSON_MISSING,
        recipe, [...route, id],
      );
      if (value === JSON_MERGE_CONFLICT) return JSON_MERGE_CONFLICT;
      if (value !== JSON_MISSING) merged.push(value);
    }
    return merged;
  }
  return JSON_MERGE_CONFLICT;
}

export function deterministicJsonMerge(base: Buffer, local: Buffer, remote: Buffer, recipe = false): Buffer | undefined {
  const texts = [base, local, remote].map(content => content.toString("utf8"));
  if ([base, local, remote].some((content, index) => !Buffer.from(texts[index], "utf8").equals(content))) return undefined;
  let values: unknown[];
  try { values = texts.map(text => JSON.parse(text)); }
  catch { return undefined; }
  let revisions: number[] = [];
  if (recipe) {
    if (!values.every(jsonObject)) return undefined;
    revisions = values.map(value => Number((value as Record<string, unknown>).revision));
    if (revisions.some(revision => !Number.isSafeInteger(revision) || revision < 1)) return undefined;
    for (const value of values) {
      const record = value as Record<string, unknown>;
      delete record.executableDigest;
      delete record.revision;
      delete record.editorLayout;
    }
  }
  const merged = mergeJsonValue(values[0], values[1], values[2], recipe);
  if (merged === JSON_MERGE_CONFLICT || merged === JSON_MISSING) return undefined;
  if (recipe) {
    if (!jsonObject(merged)) return undefined;
    const compiled = compileWorkflowDefinitionV1(merged.definition);
    if (!compiled.ok) return undefined;
    merged.executableDigest = compiled.executableDigest;
    merged.revision = Math.max(...revisions) + 1;
  }
  return Buffer.from(`${JSON.stringify(merged, null, 2)}\n`, "utf8");
}

async function mergeManagedContent(file: GitHubSyncManagedFile, base: Buffer, local: Buffer, remote: Buffer): Promise<Buffer | undefined> {
  if (file.type === "actions" || file.type === "action-module-sets" || file.type === "profiles") return undefined;
  if ([base, local, remote].some(content => !githubSyncIsTextContent(file.path, content))) return undefined;
  const merged = file.type === "recipes" || (file.path.endsWith(".json") && file.type !== "agentSnapshots")
    ? deterministicJsonMerge(base, local, remote, file.type === "recipes")
    : await deterministicTextMerge(base, local, remote, file.path);
  if (!merged) return undefined;
  // Invalid combined graphs and document schemas remain human decisions.
  try { validateManagedContent({ ...file, digest: fileDigest(merged) }, merged); }
  catch { return undefined; }
  return merged;
}

async function recoverManagedCheckout(checkout: string, remoteCommit: string): Promise<void> {
  if (!remoteCommit) {
    fs.rmSync(path.dirname(checkout), { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
    return;
  }
  await git(checkout, ["reset", "--hard", remoteCommit]);
  await git(checkout, ["clean", "-fd"]);
}

function fingerprintsForManifest(target: GitHubSyncTarget, files: GitHubSyncManagedFile[]): Record<GitHubSyncContentType, string> {
  const byType = {} as Record<GitHubSyncContentType, GitHubSyncFingerprintEntry[]>;
  for (const type of GITHUB_SYNC_CONTENT_TYPES) byType[type] = [];
  for (const file of files) {
    if (file.itemId && selectionMatches(target, file.type, file.privacy, file.itemId, file.category, file.path)) {
      byType[file.type].push({ path: file.path, digest: file.digest });
    }
  }
  return Object.fromEntries(GITHUB_SYNC_CONTENT_TYPES.map(type => [type, fingerprintGitHubSyncEntries(byType[type])])) as Record<GitHubSyncContentType, string>;
}

function transactionReceiptPath(checkoutRoot: string, targetId: string): string {
  return path.join(checkoutRoot, targetId, "transactions", "latest.json");
}

function writeTransactionReceipt(checkoutRoot: string, receipt: GitHubSyncTransactionReceipt): void {
  const destination = transactionReceiptPath(checkoutRoot, receipt.targetId);
  writeAtomic(destination, Buffer.from(`${JSON.stringify(receipt, null, 2)}\n`, "utf8"), 0o600);
}

export function validateGitHubSyncTransaction(
  checkoutRoot: string, targetId: string, transactionId: string,
  expected?: { repository: string; branch: string; commit: string },
): GitHubSyncTransactionReceipt {
  const destination = transactionReceiptPath(checkoutRoot, targetId);
  const receipt = JSON.parse(fs.readFileSync(destination, "utf8")) as GitHubSyncTransactionReceipt;
  if (receipt.schema !== 1 || receipt.targetId !== targetId || receipt.transactionId !== transactionId) {
    throw new Error("GitHub Sync transaction receipt does not match the completed synchronization.");
  }
  if (!["pushed", "recorded"].includes(receipt.state) || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/i.test(receipt.pushedCommit)) {
    throw new Error("GitHub Sync cannot acknowledge an outbox that has not been pushed.");
  }
  if (expected && (receipt.repository !== expected.repository || receipt.branch !== expected.branch || receipt.pushedCommit !== expected.commit)) {
    throw new Error("GitHub Sync transaction receipt no longer matches the result's repository, branch or commit. Preserve the recovery record; no result was applied.");
  }
  return receipt;
}

export function completeGitHubSyncTransaction(checkoutRoot: string, targetId: string, transactionId: string): void {
  const receipt = validateGitHubSyncTransaction(checkoutRoot, targetId, transactionId);
  receipt.state = "recorded";
  receipt.recordedAt = new Date().toISOString();
  writeTransactionReceipt(checkoutRoot, receipt);
}

async function syncGitHubTargetAttempt(
  target: GitHubSyncTarget,
  catalog: GitHubSyncCatalog,
  checkoutRoot: string,
  credentials?: GitHubSyncCredentials,
  storeRoot?: string,
  onProgress?: (phase: "fetch" | "resolve-conflicts" | "commit" | "push", detail: string) => void,
  options?: GitHubSyncExecutionOptions,
): Promise<GitHubSyncResult> {
  const normalized = normalizeGitHubSyncTarget(target, () => target.id);
  const fetchStartedAt = Date.now();
  const reportFetch = (detail: string): void => onProgress?.("fetch", `${detail} (${Math.round((Date.now() - fetchStartedAt) / 1000)}s elapsed)`);
  reportFetch("Local content preflight; Remote has not been fetched");
  if (normalized.lastSync?.repository && normalized.lastSync.repository !== normalized.repository) {
    throw new Error("GitHub Sync repository changed after the last synchronization. Save the target again to start from a new reconciliation base.");
  }
  if (normalized.lastSync?.branch && normalized.lastSync.branch !== normalized.branch) {
    throw new Error("GitHub Sync branch changed after the last synchronization. Save the target again to start from a new reconciliation base.");
  }
  if (storeRoot && normalized.lastSync?.storeRoot && !sameKnowledgeRoot(normalized.lastSync.storeRoot, storeRoot)) {
    throw new Error("Knowledge Root changed after the last synchronization. Re-save the target to reconcile this root as a new machine.");
  }
  const checkout = path.join(checkoutRoot, normalized.id, "repository");
  const { issues, materialized: localMaterialized, scopeSnapshot: localScopeSnapshot,
    excluded: localExcluded } = await inspectGitHubSyncLocalContent(normalized, catalog, storeRoot);
  if (issues.length) throw new GitHubSyncContentRepairError(normalized.id, issues);
  const localFiles = new Map(localMaterialized.files.map(file => [file.path, file]));
  reportFetch(`Loaded ${localFiles.size} Local files; fetching origin/${normalized.branch}`);
  await prepareCheckout(normalized, checkout, credentials);
  reportFetch(`Fetched origin/${normalized.branch}; validating Remote files`);
  const remoteCommit = await hasRef(checkout, "HEAD") ? await git(checkout, ["rev-parse", "HEAD"]) : "";
  const authoritativeMigrationCutover = normalized.publication?.manualVerificationCompleted === false;
  const forceLocalAuthority = options?.mode === "force-local-authority";
  const forceActor = options?.actor?.trim().replace(/[\r\n]+/g, " ") || "local-user";
  const forceComment = options?.comment?.trim().replace(/[\r\n]+/g, " ") || "";
  if (authoritativeMigrationCutover && !forceLocalAuthority && normalized.publication?.sourceCommit !== remoteCommit) {
    throw new Error("GitHub changed after migration cutover. Run Preview, Stage, Verify, and Cutover again before the authoritative migration sync.");
  }
  let remoteManifest: GitHubSyncManifest;
  let remoteManifestRaw: string | undefined;
  try {
    remoteManifestRaw = fs.readFileSync(path.join(checkout, MANIFEST_PATH), "utf8");
  } catch (error: any) {
    if (error?.code !== "ENOENT") throw error;
  }
  if (remoteManifestRaw === undefined) {
    remoteManifest = { schema: GITHUB_SYNC_MANIFEST_SCHEMA, files: [], deletions: [] };
  } else {
    remoteManifest = parseManagedManifest(remoteManifestRaw);
    if (remoteManifest.schema !== GITHUB_SYNC_MANIFEST_SCHEMA && !authoritativeMigrationCutover && !forceLocalAuthority) {
      throw new Error(
        `GitHub Sync requires manifest schema ${GITHUB_SYNC_MANIFEST_SCHEMA}, but the repository uses schema ${remoteManifest.schema}. `
        + "Complete the one-time GitHub publication migration before synchronizing files.",
      );
    }
    const remoteSizes = new Map<string, number>();
    for (const entry of (await git(checkout, ["ls-tree", "-r", "-l", "-z", remoteCommit])).split("\0").filter(Boolean)) {
      const separator = entry.indexOf("\t");
      if (separator < 0) continue;
      const metadata = entry.slice(0, separator).trim().split(/\s+/);
      remoteSizes.set(entry.slice(separator + 1), Number(metadata[3]));
    }
    let batch: Array<{ file: GitHubSyncManagedFile; size: number }> = [];
    let batchBytes = 0;
    let validated = 0;
    const validateBatch = async (): Promise<void> => {
      if (!batch.length) return;
      const contents = await readGitHubRemoteFilesForSubscription(normalized, checkoutRoot, remoteCommit,
        batch.map(({ file, size }) => ({ path: file.path, size })), 64 * 1024 * 1024);
      for (const { file } of batch) {
        const content = contents.get(file.path)!;
        if (!file.digest) file.digest = fileDigest(content);
        validateManagedContent(file, content, true);
        file.content = content;
      }
      validated += batch.length;
      reportFetch(`Validated ${validated}/${remoteManifest.files.length} Remote files`);
      batch = [];
      batchBytes = 0;
    };
    for (const file of remoteManifest.files) {
      const size = remoteSizes.get(file.path);
      if (size === undefined) throw new Error(`Remote manifest references a missing file: ${file.path}.`);
      if (batch.length && batchBytes + size > 32 * 1024 * 1024) await validateBatch();
      batch.push({ file, size });
      batchBytes += size;
    }
    await validateBatch();
    const trackedManagedFiles = (await git(checkout, ["ls-files", "-z", "--cached", "--", ...GITHUB_SYNC_CONTENT_TYPES]))
      .split("\0")
      .filter(Boolean)
      .map(githubSyncSafeRelativePath);
    const manifestPaths = new Set(remoteManifest.files.map(file => file.path.toLocaleLowerCase("en-US")));
    const omitted = trackedManagedFiles.find(file => !manifestPaths.has(file.toLocaleLowerCase("en-US")));
    if (omitted) throw new Error(`Remote managed file is missing from the manifest: ${omitted}`);
  }
  enrichLegacyFiles(remoteManifest.files, localFiles);
  const remoteFiles = new Map(remoteManifest.files.map(file => [file.path, file]));
  reportFetch(`Loaded Remote manifest: ${remoteManifest.files.length} files, ${remoteManifest.deletions.length} deletions`);

  let baseManifest: GitHubSyncManifest = { schema: GITHUB_SYNC_MANIFEST_SCHEMA, files: [], deletions: [] };
  let migratedLocalSyncSchema = false;
  if (normalized.lastSync?.commit) {
    baseManifest = await manifestAtCommit(normalized, checkoutRoot, checkout, normalized.lastSync.commit);
    enrichLegacyFiles(baseManifest.files, new Map([...remoteFiles, ...localFiles]));
    if (baseManifest.schema !== GITHUB_SYNC_MANIFEST_SCHEMA && remoteManifest.schema === GITHUB_SYNC_MANIFEST_SCHEMA) {
      baseManifest = migrateBaseManifestToCanonicalSchema(baseManifest, remoteManifest);
      migratedLocalSyncSchema = true;
    }
  }
  const entityBaseCommit = (key: string): string =>
    normalized.lastSync?.entityBases?.[key] ?? normalized.lastSync?.commit ?? "";
  const historicalManifests = new Map<string, GitHubSyncManifest>();
  for (const [key, commit] of Object.entries(normalized.lastSync?.entityBases || {})) {
    let historical = historicalManifests.get(commit);
    if (!historical) {
      historical = commit ? await manifestAtCommit(normalized, checkoutRoot, checkout, commit)
        : { schema: GITHUB_SYNC_MANIFEST_SCHEMA, files: [], deletions: [] };
      enrichLegacyFiles(historical.files, new Map([...remoteFiles, ...localFiles]));
      historicalManifests.set(commit, historical);
    }
    baseManifest.files = baseManifest.files.filter(file => entityKey(file.type, file.itemId) !== key)
      .concat(historical.files.filter(file => entityKey(file.type, file.itemId) === key));
    baseManifest.deletions = baseManifest.deletions.filter(file => entityKey(file.type, file.itemId) !== key)
      .concat(historical.deletions.filter(file => entityKey(file.type, file.itemId) === key));
  }
  reportFetch(`Loaded Base manifest: ${baseManifest.files.length} files, ${baseManifest.deletions.length} deletions`);
  const baseFiles = new Map(baseManifest.files.map(file => [file.path, file]));
  const scriptLocators = alignSyncScriptIdentities([
    localScopeSnapshot, [...localFiles.values()], [...remoteFiles.values()], [...baseFiles.values()],
  ]);
  // Old item selections are locators, not a new grant of access to a privacy scope.
  for (const privacy of ["public", "private"] as const) {
    const items = normalized.selection[privacy].scripts.items;
    normalized.selection[privacy].scripts.items = [...new Set([...items, ...items.flatMap(id => {
      const canonical = scriptLocators.get(id);
      return canonical ? [canonical] : [];
    })])];
  }
  const canonicalDeletion = (deletion: GitHubSyncDeletionEvidence): GitHubSyncDeletionEvidence =>
    deletion.type === "scripts" && scriptLocators.has(deletion.itemId)
      ? { ...deletion, itemId: scriptLocators.get(deletion.itemId)! } : deletion;
  remoteManifest.deletions = remoteManifest.deletions.map(canonicalDeletion);
  baseManifest.deletions = baseManifest.deletions.map(canonicalDeletion);
  for (const deletion of remoteManifest.deletions) {
    if ([...remoteFiles.values()].some(file => file.type === deletion.type && file.itemId === deletion.itemId)) {
      throw new Error("Remote tombstone conflicts with a validated live Script identity.");
    }
  }
  const scopeProtected = new Set((normalized.pausedItems || []).map(item => entityKey(item.type, item.itemId)));
  for (const file of localScopeSnapshot) if (file.type === "scripts" && localExcluded.has(file.path)) scopeProtected.add(entityKey(file.type, file.itemId));
  for (const item of catalog.scripts) {
    const source = item.dependencies?.find(dependency => dependency.destination === syncScriptSidecarPath(item.destination))?.source;
    if (source && fs.existsSync(source) && fs.lstatSync(source).isSymbolicLink()) throw new Error("Script identity sidecar is a symbolic link; review required.");
    const identity = source && fs.existsSync(source) ? readSyncScriptIdentity(fs.readFileSync(source)).knowledgeId
      : /^script_[a-f0-9]{24}$/.test(item.id) ? item.id : scriptLocators.get(item.destination);
    if (identity && !selectedItem(normalized, "scripts", item)) scopeProtected.add(entityKey("scripts", identity));
  }
  const scopePaths = [...localFiles.keys(), ...remoteFiles.keys(), ...baseFiles.keys()];
  const excluded = await githubSyncExcludedPaths(storeRoot, scopePaths);
  for (const file of [...localFiles.values(), ...remoteFiles.values(), ...baseFiles.values()]) {
    if (file.type === "scripts" && excluded.has(file.path)) scopeProtected.add(entityKey(file.type, file.itemId));
  }
  for (const relative of excluded) {
    localFiles.delete(relative);
    baseFiles.delete(relative);
  }
  const retainedRemote = new Map(remoteFiles);
  for (const relative of excluded) remoteFiles.delete(relative);
  reportFetch(`Excluded ${excluded.size} files by Local ignore rules; existing Remote copies remain untouched`);
  if (storeRoot) {
    for (const managed of [...remoteFiles.values(), ...baseFiles.values()]) {
      if (managed.type === "recipes" || localFiles.has(managed.path)) continue;
      if (scopeProtected.has(entityKey(managed.type, managed.itemId))) continue;
      const source = syncLocalPath(storeRoot, managed.path);
      if (!fs.existsSync(source) || !fs.lstatSync(source).isFile()) continue;
      const rawSnapshot = fs.readFileSync(source);
      const content = githubSyncComparisonContent(managed.type, rawSnapshot, managed.path);
      localFiles.set(managed.path, {
        ...managed,
        digest: fileDigest(content),
        content,
        rawSnapshot,
        sourceDigest: fileDigest(rawSnapshot),
        sourceLocator: { kind: "file", path: source },
      });
    }
  }

  const remoteOwnerCounts = new Map<string, number>();
  for (const file of remoteFiles.values()) {
    const key = entityKey(file.type, file.itemId);
    remoteOwnerCounts.set(key, (remoteOwnerCounts.get(key) || 0) + 1);
  }
  for (const [relative, local] of localFiles) {
    const base = baseFiles.get(relative);
    const remote = remoteFiles.get(relative);
    if (!base || !remote || remote.type === "recipes" || remote.type === "scripts" || base.type !== remote.type || base.itemId !== remote.itemId
      || local.type !== remote.type || local.itemId === remote.itemId
      || (remoteOwnerCounts.get(entityKey(remote.type, remote.itemId)) || 0) < 2
      || !selectionMatches(normalized, remote.type, remote.privacy, remote.itemId, remote.category)) continue;
    localFiles.set(relative, { ...remote, content: local.content, digest: local.digest,
      rawSnapshot: local.rawSnapshot, sourceDigest: local.sourceDigest, sourceLocator: local.sourceLocator });
  }

  const localEntities = groupManagedFiles(localFiles.values());
  const remoteEntities = groupManagedFiles(remoteFiles.values());
  const baseEntities = groupManagedFiles(baseFiles.values());
  reportFetch(`Reconciling entities: ${localEntities.size} Local, ${baseEntities.size} Base, ${remoteEntities.size} Remote`);
  const finalRemote = new Map(retainedRemote);
  const deferredEntities = new Set([...localMaterialized.deferredEntities].map(key => {
    const [type, id] = key.split("\0");
    return entityKey(type as GitHubSyncContentType, type === "scripts" ? scriptLocators.get(id) || scriptLocators.get(`scripts/${id}`) || id : id);
  }));
  for (const key of deferredEntities) reportFetch(`Deferring unstable entity ${key.replace("\0", "/")}; no deletion inferred`);
  const remoteMetadataAuthority = !authoritativeMigrationCutover
    && !forceLocalAuthority
    && !normalized.lastSync?.commit;
  if (remoteMetadataAuthority) {
    reconcileMigratedEntityIdentities(remoteEntities, localEntities);
    reconcileMigratedEntityIdentities(remoteEntities, baseEntities);
  } else {
    reconcileMigratedEntityIdentities(localEntities, baseEntities);
    reconcileMigratedEntityIdentities(localEntities, remoteEntities, finalRemote);
  }
  const retainedEntities = groupManagedFiles(finalRemote.values());
  const candidateEntities = groupManagedFiles(finalRemote.values());
  const localDeletionMap = new Map((migratedLocalSyncSchema ? [] : normalized.pendingDeletions || [])
    .map(canonicalDeletion).map(deletion => [entityKey(deletion.type, deletion.itemId), deletion]));
  const historicalTrash = storeRoot ? syncHistoricalScriptTrash(storeRoot) : [];
  const durableDeletions = new Map((storeRoot ? knowledgeSyncDeletionRecords(storeRoot) : [])
    .map(record => [record.path, record]));
  const gitDeletions = await githubSyncGitDeletionRecords(storeRoot, baseFiles.values());
  for (const [relative, record] of gitDeletions) if (!durableDeletions.has(relative)) durableDeletions.set(relative, { path: relative, ...record });
  for (const [key, files] of new Map([...baseEntities, ...remoteEntities, ...localEntities])) {
    const deletion = githubSyncDurableEntityDeletion(files, localEntities.has(key), durableDeletions);
    if (deletion) localDeletionMap.set(key, deletion);
  }
  reportFetch(`Loaded ${durableDeletions.size} Local deletion records (${gitDeletions.size} verified by Local Git)`);
  const remoteDeletionMap = new Map(remoteManifest.deletions.map(deletion => [entityKey(deletion.type, deletion.itemId), deletion]));
  const baseDeletionMap = new Map(baseManifest.deletions.map(deletion => [entityKey(deletion.type, deletion.itemId), deletion]));
  const finalDeletions = new Map(remoteDeletionMap);
  const identities = new Set<string>([
    ...localEntities.keys(),
    ...remoteEntities.keys(),
    ...baseEntities.keys(),
    ...localDeletionMap.keys(),
    ...remoteDeletionMap.keys(),
    ...baseDeletionMap.keys(),
    ...deferredEntities,
  ]);
  const localWrites: GitHubSyncLocalWrite[] = [];
  const localDeletes: Array<{ file: GitHubSyncManagedFile; expectedLocal?: Buffer }> = [];
  const conflicts: GitHubSyncConflict[] = [];
  const acknowledgedDeletions: GitHubSyncDeletionEvidence[] = migratedLocalSyncSchema
    ? [...(normalized.pendingDeletions || [])]
    : [];
  const resolutionRules: GitHubSyncResolutionReport["rules"] = {};
  const recordResolution = (rule: GitHubSyncResolutionRule, files: GitHubSyncManagedFile[] | undefined, ...others: Array<GitHubSyncManagedFile[] | undefined>): void => {
    const paths = new Set([...(files || []), ...others.flatMap(items => items || [])].map(file => file.path));
    resolutionRules[rule] = (resolutionRules[rule] || 0) + Math.max(1, paths.size);
  };
  const resolutionReport = (): GitHubSyncResolutionReport => ({
    totalFiles: new Set([...localFiles.keys(), ...remoteFiles.keys(), ...baseFiles.keys()]).size,
    assessedEntities: identities.size,
    localFiles: localFiles.size,
    remoteFiles: remoteFiles.size,
    rules: { ...resolutionRules },
    generatedAt: new Date().toISOString(),
  });
  const replaceRemoteEntity = (key: string, files: GitHubSyncManagedFile[] | undefined): void => {
    if ([...(baseEntities.get(key) || []), ...(localEntities.get(key) || []), ...(remoteEntities.get(key) || []), ...(files || [])].some(isSystemManagedFile)) return;
    candidateEntities.set(key, [...(files || []),
      ...(retainedEntities.get(key) || []).filter(file => excluded.has(file.path))]);
    for (const [relative, file] of finalRemote) {
      if (!excluded.has(relative) && entityKey(file.type, file.itemId) === key) finalRemote.delete(relative);
    }
    if (files) for (const file of files) finalRemote.set(file.path, file);
  };
  const conflictEntity = async (
    base: GitHubSyncManagedFile[] | undefined,
    local: GitHubSyncManagedFile[] | undefined,
    remote: GitHubSyncManagedFile[] | undefined,
    reason: GitHubSyncConflict["reason"] = "content-conflict",
  ): Promise<void> => {
    const members = new Set([...(base || []), ...(local || []), ...(remote || [])].map(file => file.member));
    for (const member of [...members].sort()) {
      const baseFile = entityFileByMember(base, member);
      const localFile = entityFileByMember(local, member);
      const remoteFile = entityFileByMember(remote, member);
      const metadata = localFile || remoteFile || baseFile;
      if (!metadata) continue;
      conflicts.push({
      path: localFile?.path || remoteFile?.path || baseFile!.path,
      type: metadata.type,
      itemId: metadata.itemId,
      category: metadata.category,
      privacy: metadata.privacy,
      member,
      basePath: baseFile?.path,
      localPath: localFile?.path,
      remotePath: remoteFile?.path,
      entityDeletion: !local || !remote,
      reason: reason === "content-conflict" && localFile && remoteFile && localFile.path !== remoteFile.path
        ? "move-conflict" : reason,
      baseCommit: entityBaseCommit(entityKey(metadata.type, metadata.itemId)) || undefined,
      deletionEvidence: remoteDeletionMap.get(entityKey(metadata.type, metadata.itemId))
        || localDeletionMap.get(entityKey(metadata.type, metadata.itemId)),
      absenceEvidence: reason === "unrecorded-local-absence" ? {
        selected: selectionMatches(normalized, metadata.type, metadata.privacy, metadata.itemId, metadata.category),
        excludedPaths: [...excluded].filter(relative => [...(base || []), ...(remote || [])].some(file => file.path === relative)),
        historicalPaths: (base || []).map(file => file.path),
        localDeletionRecorded: localDeletionMap.has(entityKey(metadata.type, metadata.itemId)),
        historicalTrash: metadata.type === "scripts" && !local ? historicalTrash.filter(evidence =>
          evidence.knowledgeId === metadata.itemId
          && (base || []).some(file => file.member === "" && file.path === evidence.originalPath)
          && (!normalized.lastSync?.at || Date.parse(evidence.deletedAt) >= Date.parse(normalized.lastSync.at))) : undefined,
      } : undefined,
      base: baseFile && entityBaseCommit(entityKey(metadata.type, metadata.itemId))
        ? await gitBuffer(checkout, ["cat-file", "blob", `${entityBaseCommit(entityKey(metadata.type, metadata.itemId))}:${baseFile.path}`], undefined, 64 * 1024 * 1024)
        : undefined,
      local: localFile?.rawSnapshot || localFile?.content,
      remote: remoteFile ? fs.readFileSync(managedPath(checkout, remoteFile.path)) : undefined,
      });
    }
  };
  const applyRemoteEntity = (base: GitHubSyncManagedFile[] | undefined, local: GitHubSyncManagedFile[] | undefined, remote: GitHubSyncManagedFile[] | undefined): void => {
    if (!storeRoot) return;
    if ([...(base || []), ...(local || []), ...(remote || [])].some(isSystemManagedFile)) return;
    const remotePaths = new Set((remote || []).map(file => file.path));
    for (const file of remote || []) {
      const content = file.content || fs.readFileSync(managedPath(checkout, file.path));
      validateManagedContent(file, content);
      const destinationLocal = localFiles.get(file.path);
      localWrites.push({ file, content: normalizeTextNewlines(file.path, content), expectedLocal: destinationLocal?.rawSnapshot || destinationLocal?.content });
    }
    for (const file of local || base || []) {
      if (file.type === "recipes" && remote?.length) continue;
      if (!remotePaths.has(file.path)) {
        const captured = localFiles.get(file.path);
        localDeletes.push({ file, expectedLocal: captured?.rawSnapshot || captured?.content });
      }
    }
  };

  if (authoritativeMigrationCutover || forceLocalAuthority) {
    const deletedAt = new Date().toISOString();
    for (const [key, remote] of remoteEntities) {
      const metadata = remote[0];
      if (!selectionMatches(normalized, metadata.type, metadata.privacy, metadata.itemId, metadata.category, metadata.path)
        || [...remote, ...(localEntities.get(key) || []), ...(baseEntities.get(key) || [])].some(isSystemManagedFile)) continue;
      replaceRemoteEntity(key, undefined);
      if (!localEntities.has(key)) {
        finalDeletions.set(key, {
          type: metadata.type,
          itemId: metadata.itemId,
          deletedAt,
          category: metadata.category,
          privacy: metadata.privacy,
        });
      }
    }
    for (const [key, local] of localEntities) {
      const metadata = local[0];
      if (!selectionMatches(normalized, metadata.type, metadata.privacy, metadata.itemId, metadata.category, metadata.path)
        || [...local, ...(remoteEntities.get(key) || []), ...(baseEntities.get(key) || [])].some(isSystemManagedFile)) continue;
      replaceRemoteEntity(key, local);
      finalDeletions.delete(key);
    }
    const selectedPaths = new Set<string>();
    for (const files of [...remoteEntities.values(), ...localEntities.values()]) {
      for (const file of files) {
        if (!isSystemManagedFile(file) && selectionMatches(normalized, file.type, file.privacy, file.itemId, file.category, file.path)) selectedPaths.add(file.path);
      }
    }
    resolutionRules[forceLocalAuthority ? "force-local-authority" : "authoritative-migration"] = selectedPaths.size;
  } else {
    for (const key of [...identities].sort((left, right) => left.localeCompare(right))) {
    if (deferredEntities.has(key)) continue;
    const base = baseEntities.get(key);
    const local = localDeletionMap.has(key) ? undefined : localEntities.get(key);
    const remote = remoteDeletionMap.has(key) ? undefined : remoteEntities.get(key);
    const metadata = local?.[0] || remote?.[0] || base?.[0];
    const deletion = localDeletionMap.get(key) || remoteDeletionMap.get(key) || baseDeletionMap.get(key);
    if (!metadata && !deletion) continue;
    const type = metadata?.type || deletion!.type;
    const itemId = metadata?.itemId || deletion!.itemId;
    const category = metadata?.category || deletion?.category || "";
    const privacy = metadata?.privacy || deletion?.privacy || "public";
    if (!selectionMatches(normalized, type, privacy, itemId, category)
      || [...(base || []), ...(local || []), ...(remote || [])].some(isSystemManagedFile)) continue;
    if (scopeProtected.has(key)) {
      recordResolution("unchanged", remote, base);
      continue;
    }
    if (localDeletionMap.has(key) && localEntities.has(key)) {
      recordResolution("human-required", localEntities.get(key), base, remote);
      await conflictEntity(base, localEntities.get(key), remote);
      continue;
    }
    if (!base && !local && !remote && [...retainedRemote.values(), ...baseManifest.files].some(file =>
      excluded.has(file.path) && entityKey(file.type, file.itemId) === key)) continue;
    if (!local && remote && [...retainedRemote.values()].some(file =>
      excluded.has(file.path) && entityKey(file.type, file.itemId) === key)) {
      recordResolution("unchanged", remote, base);
      continue;
    }

    if (local?.some(isBuiltInRecipe)) {
      recordResolution("built-in-authority", local, base, remote);
      replaceRemoteEntity(key, local);
      finalDeletions.delete(key);
      continue;
    }

    if (remote?.some(file => file.content && githubSyncIsTextContent(file.path, file.content)
      && /^(?:<<<<<<<(?: .*)?|>>>>>>>(?: .*)?)\r?$/m.test(file.content.toString("utf8")))
      && (!local || entityState(remote) !== entityState(base))) {
      recordResolution("human-required", local, base, remote);
      await conflictEntity(base, local, remote);
      continue;
    }

    if (githubSyncUnrecordedAbsenceNeedsReview(!!base, !!local, !!remote, localDeletionMap.has(key), remoteDeletionMap.has(key))) {
      recordResolution("human-required", local, base, remote);
      await conflictEntity(base, local, remote, !local ? "unrecorded-local-absence" : "remote-deletion");
      continue;
    }

    const baseState = baseDeletionMap.has(key) ? "deleted" : entityState(base);
    const localState = localDeletionMap.has(key) || (!local && (baseState === "deleted" || remoteDeletionMap.has(key))) ? "deleted" : entityState(local);
    const metadataMigration = localDeletionMap.has(key) && scriptDeletionMetadataEquivalent(base, remote);
    const remoteState = remoteDeletionMap.has(key) ? "deleted" : metadataMigration ? baseState : entityState(remote);
    const localChanged = localState !== baseState;
    const remoteChanged = remoteState !== baseState;

    if (localChanged && remoteChanged && localState !== remoteState) {
      if (!local || !remote) {
        recordResolution("human-required", local, base, remote);
        await conflictEntity(base, local, remote);
        continue;
      }
      const sameContent = entityContentState(local) === entityContentState(remote);
      const frontmatterMigration = local.length === remote.length
        && local.every(localFile => {
          const remoteFile = entityFileByMember(remote, localFile.member);
          return !!remoteFile && localFile.path === remoteFile.path && frontmatterMigrationEquivalent(localFile, remoteFile);
        });
      if (remoteMetadataAuthority && frontmatterMigration) {
        recordResolution("initial-remote-authority", remote, local);
        replaceRemoteEntity(key, remote);
        finalDeletions.delete(key);
        applyRemoteEntity(base, local, remote);
        continue;
      }
      const basePaths = entityPathState(base);
      const localPaths = entityPathState(local);
      const remotePaths = entityPathState(remote);
      const divergentMove = sameContent && base && localPaths !== basePaths && remotePaths !== basePaths && localPaths !== remotePaths;
      if (!sameContent && base && entityBaseCommit(key)) {
        const mergedFiles: GitHubSyncManagedFile[] = [];
        let compatible = true;
        const members = new Set([...base, ...local, ...remote].map(file => file.member));
        for (const member of members) {
          const baseFile = entityFileByMember(base, member);
          const localFile = entityFileByMember(local, member);
          const remoteFile = entityFileByMember(remote, member);
          if (!localFile || !remoteFile) {
            if (!baseFile) {
              mergedFiles.push((localFile || remoteFile)!);
              continue;
            }
            // Missing established members need explicit deletion evidence/review.
            compatible = false;
            break;
          }
          const baseBody = base.find(file => file.member === "");
          const localBody = local.find(file => file.member === "");
          const remoteBody = remote.find(file => file.member === "");
          const migratedSidecar = member === "identity-sidecar" && !baseFile && !!baseBody;
          const chosenMetadata = localFile.path === remoteFile.path
            ? remoteFile
            : migratedSidecar && localBody?.path !== baseBody!.path && remoteBody?.path === baseBody!.path
              ? localFile
              : migratedSidecar && remoteBody?.path !== baseBody!.path && localBody?.path === baseBody!.path
                ? remoteFile
            : baseFile && localFile.path !== baseFile.path && remoteFile.path === baseFile.path
              ? localFile
              : baseFile && remoteFile.path !== baseFile.path && localFile.path === baseFile.path
                ? remoteFile : undefined;
          if (!chosenMetadata) { compatible = false; break; }
          let mergedContent: Buffer | undefined;
          if (member === "identity-sidecar" && localFile.type === "scripts") {
            mergedContent = mergeSyncScriptIdentities(localFile.content!, remoteFile.content!, itemId);
          }
          else if (managedComparisonDigest(localFile) === managedComparisonDigest(remoteFile)) mergedContent = remoteFile.content;
          else if (baseFile && managedComparisonDigest(localFile) === managedComparisonDigest(baseFile)) mergedContent = remoteFile.content;
          else if (baseFile && managedComparisonDigest(remoteFile) === managedComparisonDigest(baseFile)) mergedContent = localFile.content;
          else if (baseFile) mergedContent = await mergeManagedContent(
            chosenMetadata,
            await gitBuffer(checkout, ["cat-file", "blob", `${entityBaseCommit(key)}:${baseFile.path}`], undefined, 64 * 1024 * 1024),
            localFile.content!, remoteFile.content!,
          );
          if (!mergedContent) { compatible = false; break; }
          mergedFiles.push({ ...chosenMetadata, digest: fileDigest(mergedContent), content: mergedContent });
        }
        if (compatible) {
            replaceRemoteEntity(key, mergedFiles);
            finalDeletions.delete(key);
            applyRemoteEntity(base, local, mergedFiles);
            recordResolution(localPaths !== remotePaths ? "move-edit" : "deterministic-three-way", mergedFiles, base, local, remote);
            continue;
        }
      }
      if (!sameContent || divergentMove) {
        recordResolution("human-required", local, base, remote);
        await conflictEntity(base, local, remote);
        continue;
      }
      const chosen = remote;
      recordResolution(base && (localPaths !== basePaths || remotePaths !== basePaths) ? "move-edit" : "identical-convergence", chosen, base, local, remote);
      replaceRemoteEntity(key, chosen);
      finalDeletions.delete(key);
      if (chosen === remote) applyRemoteEntity(base, local, remote);
      continue;
    }

    if (remoteChanged && !localChanged) {
      recordResolution("remote-only", remote, base, local);
      replaceRemoteEntity(key, remote);
      if (remote) finalDeletions.delete(key);
      else finalDeletions.set(key, remoteDeletionMap.get(key)!);
      applyRemoteEntity(base, local, remote);
      continue;
    }
    if (localChanged && !remoteChanged) {
      recordResolution("local-only", local, base, remote);
      replaceRemoteEntity(key, local);
      if (local) finalDeletions.delete(key);
      else {
        const evidence = localDeletionMap.get(key);
        if (!evidence) throw new Error(`GitHub Sync cannot record a machine-local deletion without evidence: ${type}/${itemId}`);
        finalDeletions.set(key, {
          ...evidence,
          category: evidence.category ?? base?.[0]?.category,
          privacy: evidence.privacy ?? base?.[0]?.privacy,
        });
        acknowledgedDeletions.push(evidence);
      }
      continue;
    }
      recordResolution("unchanged", remote, base, local);
      if (!remote && remoteDeletionMap.has(key)) finalDeletions.set(key, remoteDeletionMap.get(key)!);
    }
  }

  const references = new Map<string, string>();
  for (const [key, files] of new Map([...baseEntities, ...remoteEntities, ...localEntities])) {
    references.set(key, key);
    for (const file of files) {
      references.set(file.itemId, key);
      const match = file.content && /(?:^|\n)knowledgeId:\s*["']?(knowledge_[a-f0-9]{24})/.exec(file.content.toString("utf8"));
      if (match) references.set(match[1], key);
    }
  }
  const dependencies = new Map<string, Set<string>>();
  for (const [key, files] of new Map([...remoteEntities, ...candidateEntities])) {
    for (const file of files) {
      if (file.type !== "recipes" || !file.content) continue;
      const value: unknown = JSON.parse(file.content.toString("utf8"));
      if (!value || typeof value !== "object" || !("nodeBindings" in value) || !Array.isArray(value.nodeBindings)) continue;
      for (const node of value.nodeBindings) {
        if (!node || typeof node !== "object" || !("bindings" in node) || !Array.isArray(node.bindings)) continue;
        for (const binding of node.bindings) {
          if (!binding || typeof binding !== "object" || binding.usage !== "required" || typeof binding.knowledgeId !== "string") continue;
          const id = binding.knowledgeId.replace(/^pkm:\/\/knowledge\//, "");
          const required = references.get(`${binding.kind === "skill" ? "skills" : "notes"}\0${id}`) || references.get(id);
          if (required && required !== key) {
            const set = dependencies.get(key) || new Set<string>();
            set.add(required); dependencies.set(key, set);
          }
        }
      }
    }
  }
  const activeUsers = [...candidateEntities].filter(([,files]) => files.some(file =>
    file.type === "profiles" && file.category === "user" && file.content && !JSON.parse(file.content.toString("utf8")).deleted));
  if (activeUsers.length > 1) {
    for (const [key] of activeUsers) {
      recordResolution("human-required", candidateEntities.get(key));
      await conflictEntity(baseEntities.get(key), localEntities.get(key), remoteEntities.get(key));
    }
  }
  const initialBlocked = new Set([...deferredEntities, ...(normalized.pausedItems || []).map(item => entityKey(item.type, item.itemId)),
    ...conflicts.map(file => entityKey(file.type, file.itemId))]);
  const ownershipCollisions = new Set<string>();
  if (!authoritativeMigrationCutover && !forceLocalAuthority) {
    const ownersByPath = new Map<string, Set<string>>();
    for (const entities of [localEntities, remoteEntities]) for (const [key, files] of entities) for (const file of files) {
      const portable = file.path.toLocaleLowerCase("en-US");
      const owners = ownersByPath.get(portable) || new Set<string>();
      owners.add(key);
      ownersByPath.set(portable, owners);
    }
    // Keep Local ownership visible even when a blocked candidate falls back to Remote.
    for (const owners of ownersByPath.values()) if (owners.size > 1) {
      for (const owner of owners) {
        ownershipCollisions.add(owner);
        const required = dependencies.get(owner) || new Set<string>();
        for (const other of owners) if (other !== owner) required.add(other);
        dependencies.set(owner, required);
      }
    }
  }
  const publication = planGitHubSyncPublication(candidateEntities, retainedEntities, initialBlocked, dependencies);
  for (const key of publication.blocked) {
    if (!initialBlocked.has(key)) {
      await conflictEntity(baseEntities.get(key), localEntities.get(key), remoteEntities.get(key),
        publication.collisions.has(key) || ownershipCollisions.has(key) ? "path-collision" : "dependency-conflict");
    }
    if (remoteDeletionMap.has(key)) finalDeletions.set(key, remoteDeletionMap.get(key)!);
    else finalDeletions.delete(key);
  }
  finalRemote.clear();
  for (const file of publication.files) finalRemote.set(file.path, file);
  for (let index = localWrites.length - 1; index >= 0; index--) {
    if (publication.blocked.has(entityKey(localWrites[index].file.type, localWrites[index].file.itemId))) localWrites.splice(index, 1);
  }
  for (let index = localDeletes.length - 1; index >= 0; index--) {
    if (publication.blocked.has(entityKey(localDeletes[index].file.type, localDeletes[index].file.itemId))) localDeletes.splice(index, 1);
  }
  for (let index = acknowledgedDeletions.length - 1; index >= 0; index--) {
    if (publication.blocked.has(entityKey(acknowledgedDeletions[index].type, acknowledgedDeletions[index].itemId))) acknowledgedDeletions.splice(index, 1);
  }
  const entityBases = Object.fromEntries([...publication.blocked].map(key => [key, entityBaseCommit(key)]));

  for (const pending of normalized.pendingDeletions || []) {
    const canonical = canonicalDeletion(pending);
    const key = entityKey(canonical.type, canonical.itemId);
    if (publication.blocked.has(key)) continue;
    if (finalDeletions.has(key) && ![...finalRemote.values()].some(file => entityKey(file.type, file.itemId) === key)
      && !acknowledgedDeletions.some(item => item.type === pending.type && item.itemId === pending.itemId)) {
      acknowledgedDeletions.push(pending);
    }
  }
  const applyChanges = async (conflictCommit: string): Promise<ReturnType<typeof applyLocalChanges>> => {
    try {
      return applyLocalChanges(storeRoot, localWrites, localDeletes.filter(item => !finalRemote.has(item.file.path)));
    } catch (error) {
      if (!(error instanceof GitHubSyncLocalChangeError)) throw error;
      onProgress?.("resolve-conflicts", `Local content changed during synchronization: ${error.file.path}`);
      // A guarded apply aborts the whole batch, so every unapplied member must
      // accompany the changed file before acceptance can advance the base.
      const pending = new Map([...localDeletes.filter(item => !finalRemote.has(item.file.path)).map(item => ({ ...item, content: undefined })), ...localWrites]
        .map(item => [item.file.path, item]));
      const pendingConflicts: GitHubSyncConflict[] = await Promise.all([...pending.values()].map(async (item): Promise<GitHubSyncConflict> => {
        const destination = syncLocalPath(storeRoot!, item.file.path);
        const current = item.file.type === "recipes" ? localFiles.get(item.file.path)?.content
          : fs.existsSync(destination) ? fs.readFileSync(destination) : undefined;
        const baseFile = entityFileByMember(baseEntities.get(entityKey(item.file.type, item.file.itemId)), item.file.member);
        const upstream = entityFileByMember(remoteEntities.get(entityKey(item.file.type, item.file.itemId)), item.file.member);
        return {
          path: item.file.path, type: item.file.type, itemId: item.file.itemId,
          category: item.file.category, privacy: item.file.privacy, member: item.file.member,
          basePath: baseFile?.path,
          localPath: current ? item.file.path : undefined,
          remotePath: upstream?.path,
          entityDeletion: ![...finalRemote.values()].some(file => entityKey(file.type, file.itemId) === entityKey(item.file.type, item.file.itemId)),
          base: baseFile && entityBaseCommit(entityKey(item.file.type, item.file.itemId))
            ? await gitBuffer(checkout, ["cat-file", "blob", `${entityBaseCommit(entityKey(item.file.type, item.file.itemId))}:${baseFile.path}`], undefined, 64 * 1024 * 1024) : undefined,
          baseCommit: entityBaseCommit(entityKey(item.file.type, item.file.itemId)) || undefined,
          local: current,
          remote: upstream?.content,
          expectedLocal: item.expectedLocal,
          plannedContent: item.content,
          plannedOperation: item.content === undefined ? "delete" : "write",
          reason: item.file.path === error.file.path ? "concurrent-local-change" : "pending-apply",
          deletionEvidence: remoteDeletionMap.get(entityKey(item.file.type, item.file.itemId)),
        };
      }));
      const report = resolutionReport();
      report.pendingApplyMembers = pendingConflicts.length;
      report.concurrentChangeBlockers = 1;
      throw new GitHubSyncConflictError(conflictCommit, [...conflicts, ...pendingConflicts], [], [], {}, [], [], report);
    }
  };

  const managedFiles = [...finalRemote.values()].map(file => {
    if (!file.content || excluded.has(file.path) || publication.blocked.has(entityKey(file.type, file.itemId))) return file;
    const content = normalizeTextNewlines(file.path, file.content);
    return { ...file, content, digest: fileDigest(content) };
  });
  for (const file of managedFiles) {
    if (!excluded.has(file.path) && !publication.blocked.has(entityKey(file.type, file.itemId)) && file.content) validateManagedContent(file, file.content);
  }
  let changed = false;
  let commit = remoteCommit;
  let pushed = false;
  let preparedCommit: string | undefined;
  const transactionId = randomUUID();
  const outbox = [...candidateEntities].filter(([key]) => !publication.blocked.has(key))
    .map(([entity, files]) => ({ entity, snapshot: entityState(files) ?? "deleted" }));
  try {
    for (const file of managedFiles) {
      if (!file.content) continue;
      const destination = managedPath(checkout, file.path);
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      fs.writeFileSync(destination, file.content);
    }
    for (const relative of retainedRemote.keys()) {
      if (!finalRemote.has(relative)) fs.rmSync(managedPath(checkout, relative), { force: true });
    }
    const stagingStartedAt = Date.now();
    onProgress?.("fetch", `Checking ${managedFiles.length} reconciled files against the Git index`);
    await git(checkout, ["-c", "core.autocrlf=false", "add", "-A", "--", "."]);
    const verificationStartedAt = Date.now();
    onProgress?.("fetch", `Index preparation completed in ${Date.now() - stagingStartedAt} ms; verifying ${managedFiles.length} staged blobs before manifest creation`);
    await verifyGitHubStagedFiles(normalized, checkoutRoot, managedFiles, verified => {
      onProgress?.("fetch", `Verified ${verified}/${managedFiles.length} staged blobs in ${Date.now() - verificationStartedAt} ms`);
    });
    fs.writeFileSync(path.join(checkout, MANIFEST_PATH), manifestJson(managedFiles, [...finalDeletions.values()]));
    await git(checkout, ["add", "--", MANIFEST_PATH]);
    changed = !!(await git(checkout, ["status", "--porcelain"]));
    if (changed || forceLocalAuthority) {
      onProgress?.("commit", `Preparing commit metadata after ${Date.now() - stagingStartedAt} ms of staging and index validation`);
      await git(checkout, ["config", "user.name", forceLocalAuthority ? forceActor : "Personal Knowledge Manager"]);
      await git(checkout, ["config", "user.email", forceLocalAuthority
        ? `${forceActor.replace(/[^a-zA-Z0-9_.-]+/g, "-")}@users.noreply.github.com`
        : "pkm@localhost"]);
      const commitStartedAt = Date.now();
      onProgress?.("commit", "Running git commit; repository hooks and signing may add latency");
      if (forceLocalAuthority) {
        if (!forceComment) throw new Error("Force use Local requires a non-empty user comment.");
        await git(checkout, [
          "commit",
          "--allow-empty",
          "-m", `PKM force update by ${forceActor}`,
          "-m", `PKM-Operation: force-local-authority\nPKM-Actor: ${forceActor}\nPKM-Comment: ${forceComment}\nPKM-Base-Commit: ${remoteCommit || "(empty branch)"}\nPKM-Transaction-ID: ${transactionId}`,
        ]);
        changed = true;
      } else {
        await git(checkout, ["commit", "-m", `PKM sync ${new Date().toISOString()}`]);
      }
      onProgress?.("commit", `git commit completed in ${Date.now() - commitStartedAt} ms; entire commit phase ${Date.now() - stagingStartedAt} ms`);
    }
    preparedCommit = await git(checkout, ["rev-parse", "HEAD"]);
    await git(checkout, ["update-ref", "refs/pkm/outbox", preparedCommit]);
    writeTransactionReceipt(checkoutRoot, {
      schema: 1, transactionId, targetId: normalized.id, repository: normalized.repository, branch: normalized.branch,
      baseCommit: remoteCommit, pushedCommit: "", pushedAt: "", operation: forceLocalAuthority ? "force-local-authority" : "sync",
      state: "prepared", entityBases, outbox, preparedCommit,
    });
    const currentExclusions = await githubSyncExcludedPaths(storeRoot, scopePaths);
    if (excluded.size !== currentExclusions.size || [...excluded].some(relative => !currentExclusions.has(relative))) {
      throw new Error("Local ignore rules changed during synchronization. Retry Sync; no push was performed.");
    }
    if (gitDeletions.size) {
      const currentDeletions = await githubSyncGitDeletionRecords(storeRoot, baseFiles.values());
      if ([...gitDeletions.keys()].some(relative => !currentDeletions.has(relative))) {
        throw new Error("Local Git deletion evidence changed during synchronization. Retry Sync; no push was performed.");
      }
    }
    const needsUpdates = changed || localWrites.length > 0 || localDeletes.some(item => !finalRemote.has(item.file.path));
    onProgress?.(needsUpdates ? "push" : "fetch", needsUpdates
      ? `Compare-and-swap HEAD onto origin/${normalized.branch}`
      : `Verifying origin/${normalized.branch} still matches the fetched commit`);
    await git(checkout, [
      "push",
      `--force-with-lease=refs/heads/${normalized.branch}:${remoteCommit}`,
      "origin",
      `HEAD:refs/heads/${normalized.branch}`,
    ], normalized, false, credentials);
    pushed = true;
    commit = await git(checkout, ["rev-parse", "HEAD"]);
    writeTransactionReceipt(checkoutRoot, {
      schema: 1,
      transactionId,
      targetId: normalized.id,
      repository: normalized.repository,
      branch: normalized.branch,
      baseCommit: remoteCommit,
      pushedCommit: commit,
      pushedAt: new Date().toISOString(),
      operation: forceLocalAuthority ? "force-local-authority" : "sync",
      ...(forceLocalAuthority ? { actor: forceActor } : {}),
      ...(forceLocalAuthority ? { comment: forceComment } : {}),
      state: "pushed",
      entityBases,
      outbox,
      preparedCommit,
    });
  } catch (error) {
    if (pushed) {
      // A receipt failure is not a failed push. Do not reset the checkout or
      // claim recovery evidence exists when its durable write failed.
      throw new Error(`GitHub accepted the push, but local transaction recording failed: ${error instanceof Error ? error.message : String(error)}. Re-fetch and reconcile before retrying; local apply may still be pending.`);
    }
    try {
      await recoverManagedCheckout(checkout, remoteCommit);
    } catch (recoveryError) {
      const primary = error instanceof Error ? error.message : String(error);
      const recovery = recoveryError instanceof Error ? recoveryError.message : String(recoveryError);
      throw new Error(`${primary} Managed checkout recovery also failed: ${recovery}`);
    }
    throw error;
  }
  const applied = await applyChanges(commit);
  const result: GitHubSyncResult = {
    transactionId,
    commit,
    changed,
    fingerprints: fingerprintsForManifest(normalized, managedFiles.filter(file => !excluded.has(file.path))),
    pulled: applied.pulled,
    deletedLocal: applied.deletedLocal,
    privateTopLevels: applied.privateTopLevels,
    recipePulls: applied.recipePulls,
    recipeDeletes: applied.recipeDeletes,
    acknowledgedDeletions,
    resolutionReport: resolutionReport(),
    entityBases,
    deferredEntities: [...deferredEntities],
  };
  if (conflicts.length) {
    onProgress?.("resolve-conflicts", `${conflicts.length} members isolated; independent changes synchronized`);
    const error = new GitHubSyncConflictError(commit, conflicts, applied.pulled, applied.deletedLocal,
      applied.privateTopLevels, applied.recipePulls, applied.recipeDeletes, resolutionReport());
    error.partialResult = result;
    throw error;
  }
  return result;
}

function concurrentPushFailure(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error);
  return /git push failed/i.test(message)
    && /(?:stale info|non-fast-forward|fetch first|failed to push some refs|rejected)/i.test(message);
}

export interface GitHubSyncExecutionOptions {
  mode?: "normal" | "force-local-authority";
  actor?: string;
  comment?: string;
}

export async function syncGitHubTarget(
  target: GitHubSyncTarget,
  catalog: GitHubSyncCatalog,
  checkoutRoot: string,
  credentials?: GitHubSyncCredentials,
  storeRoot?: string,
  onProgress?: (phase: "fetch" | "resolve-conflicts" | "commit" | "push", detail: string) => void,
  options?: GitHubSyncExecutionOptions,
): Promise<GitHubSyncResult> {
  const maximumAttempts = target.publication?.manualVerificationCompleted === false && options?.mode !== "force-local-authority" ? 1 : 8;
  for (let attempt = 1; attempt <= maximumAttempts; attempt++) {
    try {
      return await syncGitHubTargetAttempt(target, catalog, checkoutRoot, credentials, storeRoot, onProgress, options);
    } catch (error) {
      if (attempt >= maximumAttempts || !concurrentPushFailure(error)) throw error;
      onProgress?.("fetch", `GitHub advanced during push; fetching and reconciling again (${attempt + 1}/${maximumAttempts})`);
      await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * Math.min(4000, 100 * 2 ** (attempt - 1))) + 25));
    }

  }
  throw new Error("GitHub Sync exhausted its reconciliation attempts.");
}

export type GitHubPublicationMigrationPhase = "previewed" | "staged" | "verified" | "cutover" | "rolled-back";

export interface GitHubPublicationMigrationSource {
  target: GitHubSyncTarget;
  remoteCommit: string;
  manifest: string;
  repositoryFiles: string[];
  repositoryDigests?: Record<string, string>;
  canonicalFiles?: GitHubSyncMigrationCanonicalFile[];
  activeCount: number;
  trashCount: number;
  folderCount: number;
  idCount: number;
}

export interface GitHubSyncMigrationCanonicalFile {
  path: string;
  type: GitHubSyncContentType;
  itemId: string;
  member: string;
  category: string;
  privacy: GitHubSyncPrivacy;
}

export function githubSyncMigrationCanonicalFiles(
  catalog: GitHubSyncCatalog,
  target?: GitHubSyncTarget,
): GitHubSyncMigrationCanonicalFile[] {
  const files: GitHubSyncMigrationCanonicalFile[] = [];
  const destinations = new Set<string>();
  for (const type of GITHUB_SYNC_CONTENT_TYPES) {
    for (const item of (catalog[type] || []).filter(candidate => !target || selectedItem(target, type, candidate))) {
      for (const file of collectItemFiles(item)) {
        const portable = file.destination.toLocaleLowerCase("en-US");
        if (destinations.has(portable)) continue;
        destinations.add(portable);
        files.push({
          path: file.destination,
          type,
          itemId: item.id,
          member: file.member,
          category: item.cat,
          privacy: item.isPrivate ? "private" : "public",
        });
      }
    }
  }
  return files;
}

export interface GitHubPublicationMigrationReceipt {
  phase: GitHubPublicationMigrationPhase;
  targetId: string;
  repository: string;
  branch: string;
  remoteCommit: string;
  sourceDigest: string;
  stagedDigest: string;
  activeCount: number;
  trashCount: number;
  folderCount: number;
  idCount: number;
  collisions: string[];
}

interface GitHubPublicationMigrationMarker extends GitHubPublicationMigrationReceipt {
  targetBackup: GitHubSyncTarget;
}

export class GitHubPublicationMigration {
  private readonly migrationRoot: string;
  private readonly markerPath: string;

  constructor(stateRoot: string, private readonly targetId: string) {
    if (!/^[A-Za-z0-9._-]+$/.test(targetId)) throw new Error("GitHub migration target ID is invalid.");
    this.migrationRoot = path.join(stateRoot, "migrations", targetId);
    this.markerPath = path.join(this.migrationRoot, "migration.json");
  }

  stagedManifestPath(): string {
    return path.join(this.migrationRoot, "stage", MANIFEST_PATH);
  }

  restartPreview(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const existing = this.requireMarker();
    if (existing.repository !== source.target.repository || existing.branch !== source.target.branch) {
      throw new Error("GitHub migration repository or branch changed; restart refused.");
    }
    if (source.target.publication?.manualVerificationCompleted) {
      throw new Error("GitHub publication is already verified; a migration restart is not required.");
    }
    const preview = this.buildPreview(source);
    const archive = path.join(this.migrationRoot, "history", randomUUID());
    fs.mkdirSync(archive, { recursive: true });
    fs.copyFileSync(this.markerPath, path.join(archive, "migration.json"));
    for (const directory of ["backup", "stage"]) {
      const original = path.join(this.migrationRoot, directory);
      if (fs.existsSync(original)) fs.cpSync(original, path.join(archive, directory), { recursive: true });
    }
    source.target.automation.enabled = false;
    source.target.automation.initialSyncCompleted = false;
    this.writeMarker({ ...preview, targetBackup: existing.targetBackup });
    return preview;
  }

  preview(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const receipt = this.buildPreview(source);
    const existing = this.readMarker();
    if (existing && existing.sourceDigest === receipt.sourceDigest && existing.phase !== "rolled-back") return this.receipt(existing);
    if (existing && existing.phase !== "rolled-back" && existing.sourceDigest !== receipt.sourceDigest) {
      throw new Error("GitHub migration source changed after preview.");
    }
    const marker: GitHubPublicationMigrationMarker = {
      ...receipt,
      targetBackup: JSON.parse(JSON.stringify(source.target)),
    };
    fs.mkdirSync(this.migrationRoot, { recursive: true });
    this.writeMarker(marker);
    return receipt;
  }

  private buildPreview(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    this.validateSource(source);
    const collisions: string[] = [];
    try {
      const parsed = this.migrationManifest(source);
      const singleFileTypes = new Set<GitHubSyncContentType>(["skills", "notes", "papers", "scripts", "recipes", "agentSnapshots"]);
      for (const [key, files] of groupManagedFiles(parsed.files)) {
        const markdownResources = parsed.schema === GITHUB_SYNC_MANIFEST_SCHEMA
          && ["skills", "notes", "papers"].includes(files[0].type)
          && files.filter(file => !file.member).length <= 1
          && files.every(file => !file.member
            || file.member === file.path && file.path.split("/").slice(0, -1).some(isMarkdownAssetDirectory));
        if (singleFileTypes.has(files[0].type) && files.length > 1 && !isScriptSidecarEntity(files) && !markdownResources) {
          collisions.push(`Stable identity ${key.replace("\0", ":")} maps to ${files.length} files.`);
        }
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (/differ only by case|repeats stable member identity/i.test(message)) collisions.push(message);
      else throw error;
    }
    return {
      phase: "previewed",
      targetId: this.targetId,
      repository: source.target.repository,
      branch: source.target.branch,
      remoteCommit: source.remoteCommit,
      sourceDigest: this.sourceDigest(source),
      stagedDigest: "",
      activeCount: source.activeCount,
      trashCount: source.trashCount,
      folderCount: source.folderCount,
      idCount: source.idCount,
      collisions: [...new Set(collisions)].sort(),
    };
  }

  stage(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const preview = this.buildPreview(source);
    const existing = this.readMarker();
    if (existing && (existing.repository !== preview.repository || existing.branch !== preview.branch)) {
      throw new Error("GitHub migration repository or branch changed after the transaction started.");
    }
    if (existing && existing.sourceDigest === preview.sourceDigest && ["staged", "verified", "cutover"].includes(existing.phase)
      && fs.existsSync(this.stagedManifestPath())) {
      source.target.automation.enabled = false;
      source.target.automation.initialSyncCompleted = false;
      return this.receipt(existing);
    }
    if (existing && existing.phase !== "rolled-back" && existing.sourceDigest !== preview.sourceDigest
      && !(existing.phase === "previewed" && existing.remoteCommit === preview.remoteCommit)) {
      throw new Error(existing.phase === "previewed"
        ? "GitHub remote changed after preview. Run Preview again before staging."
        : "GitHub migration source changed after preview.");
    }
    const parsed = this.migrationManifest(source);
    for (const file of parsed.files) {
      if (file.digest) continue;
      const digest = source.repositoryDigests?.[file.path];
      if (!/^[0-9a-f]{64}$/.test(digest || "")) {
        throw new Error(`GitHub migration requires a verified content digest for legacy manifest file ${file.path}.`);
      }
      file.digest = digest!;
    }
    if (preview.collisions.length) throw new Error(`GitHub migration has unresolved collisions: ${preview.collisions.join("; ")}`);
    const stagedManifest = manifestJson(parsed.files, parsed.deletions);
    const stagedDigest = createHash("sha256").update(stagedManifest).digest("hex");
    fs.rmSync(path.join(this.migrationRoot, "stage"), { recursive: true, force: true });
    fs.rmSync(path.join(this.migrationRoot, "backup"), { recursive: true, force: true });
    fs.mkdirSync(path.dirname(this.stagedManifestPath()), { recursive: true });
    writeAtomic(this.stagedManifestPath(), Buffer.from(stagedManifest, "utf8"));
    writeAtomic(path.join(this.migrationRoot, "backup", MANIFEST_PATH), Buffer.from(source.manifest, "utf8"));
    const marker: GitHubPublicationMigrationMarker = {
      ...preview,
      phase: "staged",
      stagedDigest,
      targetBackup: existing?.targetBackup || JSON.parse(JSON.stringify(source.target)),
    };
    source.target.automation.enabled = false;
    source.target.automation.initialSyncCompleted = false;
    this.writeMarker(marker);
    return this.receipt(marker);
  }

  verify(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const marker = this.requireMarker();
    this.fenceSource(marker, source);
    const content = fs.readFileSync(this.stagedManifestPath(), "utf8");
    if (createHash("sha256").update(content).digest("hex") !== marker.stagedDigest) {
      throw new Error("GitHub migration staged manifest digest does not match the transaction.");
    }
    const parsed = parseManagedManifest(content);
    if (parsed.schema !== GITHUB_SYNC_MANIFEST_SCHEMA) throw new Error("GitHub migration staged manifest did not upgrade to schema 3.");
    marker.phase = "verified";
    this.writeMarker(marker);
    return this.receipt(marker);
  }

  cutover(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const marker = this.requireMarker();
    this.fenceSource(marker, source);
    if (marker.phase === "cutover") {
      source.target.automation.enabled = false;
      source.target.automation.initialSyncCompleted = false;
      source.target.publication = {
        requiredCapability: "stable-entity-identity",
        sourceCommit: marker.remoteCommit,
        sourceDigest: marker.sourceDigest,
        manualVerificationCompleted: source.target.publication?.manualVerificationCompleted === true,
      };
      return this.receipt(marker);
    }
    if (marker.phase !== "verified") throw new Error("GitHub migration must be verified before cutover.");
    source.target.automation.enabled = false;
    source.target.automation.initialSyncCompleted = false;
    source.target.publication = {
      requiredCapability: "stable-entity-identity",
      sourceCommit: marker.remoteCommit,
      sourceDigest: marker.sourceDigest,
      manualVerificationCompleted: false,
    };
    marker.phase = "cutover";
    this.writeMarker(marker);
    return this.receipt(marker);
  }

  completeManualVerification(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const marker = this.requireMarker();
    this.fenceSource(marker, source);
    if (marker.phase !== "cutover") throw new Error("GitHub migration cutover is required before manual publication verification.");
    if (!source.target.publication || source.target.publication.sourceDigest !== marker.sourceDigest) {
      throw new Error("GitHub migration capability authority is not active.");
    }
    source.target.publication.manualVerificationCompleted = true;
    source.target.automation.enabled = false;
    return this.receipt(marker);
  }

  rollback(source: GitHubPublicationMigrationSource): GitHubPublicationMigrationReceipt {
    const marker = this.requireMarker();
    if (marker.repository !== source.target.repository || marker.branch !== source.target.branch) {
      throw new Error("GitHub migration repository or branch changed; rollback refused.");
    }
    for (const key of Object.keys(source.target)) delete (source.target as any)[key];
    Object.assign(source.target, JSON.parse(JSON.stringify(marker.targetBackup)));
    marker.phase = "rolled-back";
    this.writeMarker(marker);
    fs.rmSync(path.join(this.migrationRoot, "stage"), { recursive: true, force: true });
    return this.receipt(marker);
  }

  /** Retires an unfinished staged migration because a local-authority publish will rewrite GitHub in the current schema. */
  supersedeWithLocalAuthority(): GitHubPublicationMigrationReceipt | undefined {
    const marker = this.readMarker();
    if (!marker) return undefined;
    if (marker.phase !== "cutover" && marker.phase !== "rolled-back") {
      marker.phase = "rolled-back";
      this.writeMarker(marker);
      fs.rmSync(path.join(this.migrationRoot, "stage"), { recursive: true, force: true });
    }
    return this.receipt(marker);
  }

  status(): GitHubPublicationMigrationReceipt | undefined {
    const marker = this.readMarker();
    return marker ? this.receipt(marker) : undefined;
  }

  private validateSource(source: GitHubPublicationMigrationSource): void {
    if (source.target.id !== this.targetId) throw new Error("GitHub migration target identity changed.");
    if (!/^[0-9a-f]{40,64}$/i.test(source.remoteCommit)) throw new Error("GitHub migration remote commit is invalid.");
    if (!Array.isArray(source.repositoryFiles) || source.repositoryFiles.length > 10000) throw new Error("GitHub migration repository inventory is invalid.");
    if (source.repositoryDigests) {
      for (const [file, digest] of Object.entries(source.repositoryDigests)) {
        if (!source.repositoryFiles.includes(file) || !/^[0-9a-f]{64}$/.test(digest)) {
          throw new Error("GitHub migration repository digest inventory is invalid.");
        }
      }
      for (const file of source.canonicalFiles || []) {
        githubSyncSafeRelativePath(file.path);
        if (!(GITHUB_SYNC_CONTENT_TYPES as readonly string[]).includes(file.type)
          || !file.itemId || typeof file.member !== "string" || typeof file.category !== "string"
          || (file.privacy !== "public" && file.privacy !== "private")) {
          throw new Error("GitHub migration canonical identity inventory is invalid.");
        }
      }
    }
    for (const value of [source.activeCount, source.trashCount, source.folderCount, source.idCount]) {
      if (!Number.isSafeInteger(value) || value < 0) throw new Error("GitHub migration preview counts are invalid.");
    }
  }

  private sourceDigest(source: GitHubPublicationMigrationSource): string {
    return createHash("sha256").update(JSON.stringify({
      targetId: source.target.id,
      repository: source.target.repository,
      branch: source.target.branch,
      remoteCommit: source.remoteCommit,
      manifest: source.manifest,
      repositoryFiles: [...source.repositoryFiles].sort(),
      activeCount: source.activeCount,
      trashCount: source.trashCount,
      folderCount: source.folderCount,
    })).digest("hex");
  }

  private migrationManifest(source: GitHubPublicationMigrationSource): GitHubSyncManifest {
    const parsed = parseManagedManifest(source.manifest);
    const canonicalByPath = new Map((source.canonicalFiles || []).map(file => [`${file.type}\0${file.path}`, file]));
    const canonicalized = new Set<GitHubSyncManagedFile>();
    for (const file of parsed.files) {
      const canonical = canonicalByPath.get(`${file.type}\0${file.path}`);
      if (!canonical) continue;
      file.itemId = canonical.itemId;
      file.member = canonical.member;
      file.category = canonical.category;
      file.privacy = canonical.privacy;
      canonicalized.add(file);
    }
    if (parsed.schema === 1) {
      const singleFileTypes = new Set<GitHubSyncContentType>(["skills", "notes", "papers", "scripts", "recipes", "agentSnapshots"]);
      for (const files of groupManagedFiles(parsed.files).values()) {
        if (!singleFileTypes.has(files[0].type) || files.length < 2 || isScriptSidecarEntity(files)) continue;
        for (const file of files) {
          if (canonicalized.has(file)) continue;
          const relative = file.path.slice(file.type.length + 1).replace(/\.[^.]+$/, "");
          file.itemId = relative;
          file.member = "";
        }
      }
    }
    return parsed;
  }

  private fenceSource(marker: GitHubPublicationMigrationMarker, source: GitHubPublicationMigrationSource): void {
    if (marker.repository !== source.target.repository || marker.branch !== source.target.branch) {
      throw new Error("GitHub migration repository or branch changed after staging.");
    }
    if (marker.sourceDigest !== this.sourceDigest(source)) throw new Error("GitHub migration source changed after staging.");
  }

  private readMarker(): GitHubPublicationMigrationMarker | undefined {
    try {
      return JSON.parse(fs.readFileSync(this.markerPath, "utf8"));
    } catch (error: any) {
      if (error?.code === "ENOENT") return undefined;
      throw error;
    }
  }

  private requireMarker(): GitHubPublicationMigrationMarker {
    const marker = this.readMarker();
    if (!marker) throw new Error("GitHub migration has not been staged.");
    return marker;
  }

  private writeMarker(marker: GitHubPublicationMigrationMarker): void {
    writeAtomic(this.markerPath, Buffer.from(JSON.stringify(marker, null, 2) + "\n", "utf8"));
  }

  private receipt(marker: GitHubPublicationMigrationMarker): GitHubPublicationMigrationReceipt {
    const { targetBackup: _targetBackup, ...receipt } = marker;
    return JSON.parse(JSON.stringify(receipt));
  }
}