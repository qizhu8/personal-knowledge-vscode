import { createDecipheriv, createHash } from "node:crypto";
import { constants } from "node:fs";
import { lstat, mkdir, open, readdir, realpath, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { readAgentSnapshots } from "./agent-snapshot-reads.js";
import { readSubscriptions } from "./subscription-reads.js";
import { agentSnapshotReadDefinitions } from "./agent-snapshot-reads-contracts.js";
import { snapshotReadProjection } from "./domain/agent-snapshot-reads-projection.js";
import {
  approveSubscriptionIdentity, inspectSubscriptionIdentity, projectOriginalSubscriptionIdentity,
  storeSubscriptionIdentity, type LegacySubscriptionIdentityImport, type SubscriptionIdentityBinding,
} from "./legacy-subscription-identity.js";
import { inspectLegacyCacheFile, inspectLegacySubscriptionCache } from "./legacy-subscription-cache-import.js";
import { validateLegacySkillMaintenanceArtifact } from "./legacy-skill-maintenance.js";

const hash = (bytes: Uint8Array | string) => createHash("sha256").update(bytes).digest("hex");
const snapshotName = /^agent_snapshot_[A-Za-z0-9_-]+\.json$/;
const secretKey = /^(?:(?:(?:access|refresh|id|api|bearer)[_-]?)?tokens?|authorization|passwords?|(?:client[_-]?)?secrets?|(?:api|private)[_-]?keys?|credentials?|authVerifier|recovery|verifier)$/i;
const secretValue = /-----BEGIN (?:[A-Z ]*PRIVATE KEY|OPENSSH PRIVATE KEY)-----|(?:pkms:v1:|Bearer\s+[A-Za-z0-9._~+/-]{8,}|[?&](?:access_token|token|key|secret|password)=)/i;
const limit = 2 * 1024 * 1024;
export class LegacyStateImportError extends Error {
  constructor(readonly code: string, message: string) { super(message); }
}
function fail(code: string, message: string): never { throw new LegacyStateImportError(code, message); }
type StateEntry = { source: string; destination: string; sha256: string; size: number; sourceSha256?: string; sourceSize?: number };
export interface LegacyStateImportPlan {
  schema: "pkm.legacy-state-import/v1";
  sourceRoot: string;
  subscriptionRoot?: string;
  keyEpoch?: string;
  subscriptionIdentity?: SubscriptionIdentityBinding;
  entries: StateEntry[];
  directories?: string[];
  planSha256: string;
}
/** Host-only policy; epoch is a non-secret version, never a Magic Code or public input. */
export interface LegacySnapshotKeyAuthority {
  epoch(): Promise<string | undefined>;
  key(algorithm: string, epoch: string): Promise<Uint8Array | undefined>;
}
export const LEGACY_SUBSCRIPTION_SECRET_POLICY = Object.freeze({
  originalPrivateKey: "native-host-only",
  requiredAuthority: "external-native-secret-store",
  artifactContainsSecret: false,
  subscriptionStateImport: "explicit-durable-native-authority",
} as const);
function object(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function inspectJson(value: unknown, depth = 0, budget = { count: 0 }): void {
  if (++budget.count > 100_000 || depth > 32) fail("LIMIT", "State JSON exceeds safety bounds.");
  if (typeof value === "string" && secretValue.test(value)) fail("SECRET", "Secret material is not supported.");
  if (Array.isArray(value)) for (const item of value) inspectJson(item, depth + 1, budget);
  else if (object(value)) for (const [key, item] of Object.entries(value)) {
    if (["__proto__", "prototype", "constructor"].includes(key) || secretKey.test(key)) {
      fail("SECRET", "Sensitive or unsafe state fields require separate authority.");
    }
    inspectJson(item, depth + 1, budget);
  }
}
async function realDirectory(path: string): Promise<string> {
  if (!isAbsolute(path)) fail("UNSAFE_PATH", "Source and staging directories must be absolute.");
  const root = resolve(path);
  let current: string = sep;
  for (const component of root.slice(1).split(sep).filter(Boolean)) {
    current = join(current, component);
    const stat = await lstat(current);
    if (!stat.isDirectory() || stat.isSymbolicLink()) fail("UNSAFE_PATH", "Directory path contains a link or non-directory.");
  }
  if (await realpath(root) !== root) fail("UNSAFE_PATH", "Directory path is not canonical.");
  return root;
}
async function checkedBytes(path: string, maxBytes = limit): Promise<Buffer> {
  const before = await lstat(path, { bigint: true });
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1n || before.size > BigInt(maxBytes)) {
    fail("UNSAFE_SOURCE", "State input must be a bounded, unlinked regular file.");
  }
  const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const opened = await file.stat({ bigint: true });
    const same = (s: typeof before) => s.dev === before.dev && s.ino === before.ino && s.size === before.size
      && s.mtimeNs === before.mtimeNs && s.ctimeNs === before.ctimeNs && s.nlink === 1n;
    if (!same(opened)) fail("SOURCE_CHANGED", "State input changed while opening.");
    const bytes = await file.readFile();
    if (bytes.length !== Number(before.size) || !same(await file.stat({ bigint: true }))
      || !same(await lstat(path, { bigint: true }))) fail("SOURCE_CHANGED", "State input changed while reading.");
    return bytes;
  } finally { await file.close(); }
}
function parse(bytes: Buffer, originalIdentity = false): Record<string, unknown> {
  let value: unknown;
  try { value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); }
  catch { return fail("INVALID_STATE", "State input is not UTF-8 JSON."); }
  if (!object(value)) fail("INVALID_STATE", "State input must be an object.");
  if (originalIdentity && "privateKey" in value) {
    const { privateKey, ...publicState } = value;
    inspectJson(publicState);
    void privateKey;
  } else inspectJson(value);
  return value;
}
function parseCacheMetadata(bytes: Buffer): Record<string, unknown> {
  let value: unknown;
  try { value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); }
  catch { return fail("INVALID_STATE", "Cache metadata is not UTF-8 JSON."); }
  if (!object(value)) fail("INVALID_STATE", "Cache metadata must be an object.");
  const pending: unknown[] = [value];
  while (pending.length) {
    const item = pending.pop();
    if (typeof item === "string" && secretValue.test(item)) fail("SECRET", "Cache metadata contains secret material.");
    if (Array.isArray(item)) for (const child of item) pending.push(child);
    else if (object(item)) for (const [key, child] of Object.entries(item)) {
      if (["__proto__", "prototype", "constructor"].includes(key) || secretKey.test(key)) fail("SECRET", "Cache metadata contains unsafe fields.");
      pending.push(child);
    }
  }
  return value;
}
async function checkSnapshot(value: Record<string, unknown>, name: string, authority?: LegacySnapshotKeyAuthority, epoch?: string): Promise<void> {
  if (value.schema !== "pkm.agent.snapshot/v1" || value.snapshotId !== name.slice(0, -5)
    || typeof value.magicCode !== "string" || !/^PKM-SNAP-[A-Z0-9-]+$/.test(value.magicCode)
    || !object(value.payload)) fail("INVALID_STATE", "Snapshot schema or identity is invalid.");
  const payload = "algorithm" in value.payload
    ? await decryptSnapshot(value, authority, epoch)
    : value.payload;
  if (!object(payload.session) || !Array.isArray(payload.recipeRuns)) {
    fail("INVALID_STATE", "Snapshot is not a canonical original Session capture.");
  }
  if (object(payload.session.nativeChat) && "messageHistory" in payload.session.nativeChat) {
    fail("UNKNOWN_STATE", "Packed conversation history requires a separate adapter.");
  }
  inspectJson(payload);
  if (object(value.capture)) {
    const checkpoints = payload.session.checkpoints ?? [];
    const todos = payload.session.todos ?? [];
    if (!Array.isArray(checkpoints) || !Array.isArray(todos)
      || value.capture.todoCount !== todos.length || value.capture.recipeRunCount !== payload.recipeRuns.length) {
      fail("INVALID_STATE", "Original capture counts do not match authenticated payload.");
    }
    const latest = checkpoints.at(-1);
    if (latest !== undefined) {
      if (!object(latest) || !object(value.capture.checkpoint)
        || value.capture.checkpoint.checkpointId !== String(latest.checkpointId || "")
        || value.capture.checkpoint.sequence !== Number(latest.sequence || checkpoints.length)
        || value.capture.checkpoint.createdAt !== String(latest.createdAt || "")
        || value.capture.checkpoint.reason !== String(latest.reason || "")) {
        fail("INVALID_STATE", "Original capture checkpoint does not match authenticated history.");
      }
    } else if (value.capture.checkpoint !== undefined && value.capture.checkpoint !== null) {
      fail("INVALID_STATE", "Original capture checkpoint does not match authenticated history.");
    }
  }
  try {
    const result = snapshotReadProjection(value, payload, 12);
    const schema = agentSnapshotReadDefinitions.find(item => item.id === "agent.snapshot.read")!.output;
    if (!schema.safeParse({ ...result, snapshotRevision: "0".repeat(64), adapters: {
      encryptedPayload: "unavailable", networkRecovery: "unavailable", vscode: "unavailable", restore: "unavailable",
    } }).success) fail("INVALID_STATE", "Snapshot read projection is invalid.");
  } catch (error) {
    if (error instanceof LegacyStateImportError) throw error;
    fail("INVALID_STATE", "Snapshot read projection is invalid.");
  }
}
const algorithms = new Set(["A256GCM-PKM-LOCAL-OBFUSCATION/v1", "A256GCM-PKM-INTERNAL/v1"]);
async function assertEpoch(authority: LegacySnapshotKeyAuthority | undefined, epoch: string | undefined): Promise<void> {
  if (!authority || !epoch) fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority is unavailable or stale.");
  let actual: string | undefined;
  try { actual = await authority.epoch(); }
  catch { fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority is unavailable or stale."); }
  if (actual !== epoch) fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority is unavailable or stale.");
}
async function decryptSnapshot(snapshot: Record<string, unknown>, authority?: LegacySnapshotKeyAuthority, epoch?: string): Promise<Record<string, unknown>> {
  let payload: unknown = snapshot.payload;
  for (let depth = 0; object(payload) && "algorithm" in payload; depth++) {
    if (depth >= 4 || typeof payload.algorithm !== "string" || !algorithms.has(payload.algorithm)) {
      fail("UNKNOWN_STATE", "Snapshot encryption envelope is unsupported.");
    }
    if (Object.keys(payload).some(key => !["algorithm", "iv", "tag", "ciphertext"].includes(key))) {
      fail("UNKNOWN_STATE", "Snapshot encryption envelope contains unsupported fields.");
    }
    await assertEpoch(authority, epoch);
    let supplied: Uint8Array | undefined;
    try { supplied = await authority!.key(payload.algorithm, epoch!); }
    catch { fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority did not grant a key."); }
    if (!(supplied instanceof Uint8Array) || supplied.byteLength !== 32) fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority did not grant a key.");
    const key = Buffer.from(supplied);
    try {
      const { iv, tag, ciphertext } = payload;
      if (typeof iv !== "string" || typeof tag !== "string" || typeof ciphertext !== "string"
        || !/^[A-Za-z0-9_-]+$/.test(iv) || !/^[A-Za-z0-9_-]+$/.test(tag) || !/^[A-Za-z0-9_-]+$/.test(ciphertext)) {
        fail("INVALID_STATE", "Snapshot encryption envelope is malformed.");
      }
      const ivBytes = Buffer.from(iv, "base64url"), tagBytes = Buffer.from(tag, "base64url");
      if (ivBytes.length !== 12 || tagBytes.length !== 16) fail("INVALID_STATE", "Snapshot encryption envelope is malformed.");
      const decipher = createDecipheriv("aes-256-gcm", key, ivBytes);
      decipher.setAAD(Buffer.from(`pkm.agent.snapshot/v1:${snapshot.snapshotId}:${snapshot.magicCode}`, "utf8"));
      decipher.setAuthTag(tagBytes);
      const plaintext = Buffer.concat([decipher.update(Buffer.from(ciphertext, "base64url")), decipher.final()]);
      try { payload = parse(plaintext); } finally { plaintext.fill(0); }
    } catch (error) {
      if (error instanceof LegacyStateImportError) throw error;
      fail("INVALID_STATE", "Snapshot authentication or decoding failed.");
    } finally { key.fill(0); }
    await assertEpoch(authority, epoch);
  }
  if (!object(payload)) fail("INVALID_STATE", "Snapshot payload is invalid.");
  return payload;
}
async function optionalDirectory(root: string, parts: string[]): Promise<string | undefined> {
  let path = root;
  for (const part of parts) {
    path = join(path, part);
    try {
      const stat = await lstat(path);
      if (!stat.isDirectory() || stat.isSymbolicLink()) fail("UNSAFE_PATH", "State directory must be real.");
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined;
      throw error;
    }
  }
  return path;
}
function digest(plan: Omit<LegacyStateImportPlan, "planSha256">): string { return hash(JSON.stringify(plan)); }

export async function inspectImportedSubscriptionCache(subscriptionRoot: string) {
  const state = parse(await checkedBytes(join(subscriptionRoot, "subscriptions.json")));
  return inspectLegacySubscriptionCache(subscriptionRoot, state, { read: path => checkedBytes(path, Number.MAX_SAFE_INTEGER), json: parseCacheMetadata, fail });
}

/** Source is a quiescent disposable original copy, never a live Knowledge Root. */
export async function planLegacyStateImport(source: string, subscriptionSource?: string, authority?: LegacySnapshotKeyAuthority,
  identityPolicy?: LegacySubscriptionIdentityImport): Promise<LegacyStateImportPlan> {
  const sourceRoot = await realDirectory(source);
  const subscriptionRoot = subscriptionSource === undefined ? undefined : await realDirectory(subscriptionSource);
  const entries: StateEntry[] = [];
  let directories: string[] | undefined;
  for (const [rootName, allowed] of [
    ["_feedback", new Set(["skill-usage.jsonl"])],
    ["_proposals", new Set(["skills"])],
  ] as const) {
    const root = await optionalDirectory(sourceRoot, [rootName]);
    if (!root) continue;
    directories ??= [];
    directories.push(rootName);
    for (const name of (await readdir(root)).sort()) {
      if (rootName === "_feedback" && !allowed.has(name) || rootName === "_proposals" && name !== "skills") {
        fail("UNKNOWN_STATE", "Unknown original Skill maintenance artifact state.");
      }
      const parent = rootName === "_proposals" ? await optionalDirectory(root, ["skills"]) : root;
      if (!parent) fail("INVALID_STATE", "Original Skill proposal area must be a real directory.");
      if (rootName === "_proposals") directories.push("_proposals/skills");
      for (const artifact of rootName === "_proposals" ? (await readdir(parent)).sort() : [name]) {
        const path = join(parent, artifact);
        const destination = `${rootName}/${rootName === "_proposals" ? "skills/" : ""}${artifact}`;
        const bytes = await checkedBytes(path, Number.MAX_SAFE_INTEGER);
        validateLegacySkillMaintenanceArtifact(destination, new TextDecoder("utf-8", { fatal: true }).decode(bytes));
        entries.push({ source: path, destination, sha256: hash(bytes), size: bytes.length });
      }
    }
  }
  const magicCodes = new Set<string>();
  let epoch: string | undefined;
  try { epoch = authority ? await authority.epoch() : undefined; }
  catch { fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority is unavailable."); }
  if (epoch !== undefined && (typeof epoch !== "string" || !/^[A-Za-z0-9._:-]{1,128}$/.test(epoch))) {
    fail("KEY_AUTHORITY_REQUIRED", "Snapshot key authority epoch is invalid.");
  }
  let usesKey = false;
  let subscriptionIdentity: SubscriptionIdentityBinding | undefined;
  let bytesTotal = 0;
  const add = async (path: string, target: string, snapshot: boolean): Promise<void> => {
    const bytes = await checkedBytes(path);
    const value = parse(bytes, !!identityPolicy && target === "subscriptions/subscriptions.json");
    if (snapshot) {
      if (object(value.payload) && "algorithm" in value.payload) usesKey = true;
      await checkSnapshot(value, path.split(sep).at(-1)!, authority, epoch);
      if (magicCodes.has(value.magicCode as string)) fail("INVALID_STATE", "Duplicate Snapshot Magic Code.");
      magicCodes.add(value.magicCode as string);
    } else {
      if (value.schema !== 1) fail("INVALID_STATE", "Subscription schema is unsupported.");
      if (target.endsWith("/subscriptions.json")) {
        if (!Array.isArray(value.subscriptions) || !Array.isArray(value.shares)) {
          fail("INVALID_STATE", "Subscription state requires shares and subscriptions arrays.");
        }
        for (const record of value.subscriptions) {
          if (!object(record) || !["new", "current", "offline", "error"].includes(String(record.status))) {
            fail("UNKNOWN_STATE", "Subscription status is pending or unsupported.");
          }
        }
      }
    }
    bytesTotal += bytes.length;
    if (bytesTotal > 32 * 1024 * 1024 || entries.filter(entry => !entry.destination.startsWith("_")).length >= 512) fail("LIMIT", "State inventory exceeds safety bounds.");
    if (!snapshot && target === "subscriptions/subscriptions.json" && "privateKey" in value && identityPolicy) {
      if (entries.filter(entry => !entry.destination.startsWith("_")).length > 510) fail("LIMIT", "State inventory exceeds safety bounds.");
      const projected = projectOriginalSubscriptionIdentity(value, sourceRoot, subscriptionRoot!, hash(bytes), identityPolicy,
        entries.find(entry => entry.destination === "subscriptions/subscriber-stats.json")?.sha256 ?? null);
      subscriptionIdentity = projected.binding;
      await approveSubscriptionIdentity(subscriptionIdentity, identityPolicy.authority);
      const publicBytes = Buffer.from(JSON.stringify(projected.projection));
      inspectJson(projected.projection);
      const sidecar = Buffer.from(JSON.stringify(subscriptionIdentity));
      for (const [destination, output] of [[target, publicBytes], ["subscriptions/native-identity.json", sidecar]] as const) {
        entries.push({ source: path, destination, sha256: hash(output), size: output.length,
          sourceSha256: hash(bytes), sourceSize: bytes.length });
      }
    } else entries.push({ source: path, destination: target, sha256: hash(bytes), size: bytes.length });
  };
  const snapshots = await optionalDirectory(sourceRoot, [".pkm", "state", "agent-snapshots"]);
  if (snapshots) {
    for (const name of (await readdir(snapshots)).sort()) {
      if (!snapshotName.test(name) || name.length > 165) fail("UNKNOWN_STATE", "Snapshot inventory contains an unsupported entry.");
      await add(join(snapshots, name), `agent-snapshot-reads/.pkm/state/agent-snapshots/${name}`, true);
    }
    const sessions = await optionalDirectory(sourceRoot, [".pkm", "state", "agent-sessions"]);
    if (sessions && (await readdir(sessions)).length) {
      fail("UNKNOWN_STATE", "Recovery Session history requires separate complete migration; Snapshot recovery counts cannot be omitted.");
    }
  }
  if (subscriptionRoot) {
    for (const name of (await readdir(subscriptionRoot)).sort()) {
      if (name === "cache") continue;
      if (!["subscriptions.json", "subscriber-stats.json"].includes(name)) {
        fail("UNKNOWN_STATE", "Subscription inventory contains unsupported cache, snapshot, or pending state.");
      }
      await add(join(subscriptionRoot, name), `subscriptions/${name}`, false);
    }
    if (entries.some(item => item.destination === "subscriptions/subscriber-stats.json")
      && !entries.some(item => item.destination === "subscriptions/subscriptions.json")) {
      fail("INVALID_STATE", "Subscription statistics require original state.");
    }
    if ((await readdir(subscriptionRoot)).includes("cache")) {
      const stateEntry = entries.find(entry => entry.destination === "subscriptions/subscriptions.json");
      if (!stateEntry) fail("INVALID_STATE", "Subscription cache requires exact native subscriber state.");
      const stateBytes = await checkedBytes(stateEntry.source);
      if (hash(stateBytes) !== (stateEntry.sourceSha256 ?? stateEntry.sha256)) fail("SOURCE_CHANGED", "Subscription membership changed before cache admission.");
      const state = parse(stateBytes, !!identityPolicy);
      const cache = await inspectLegacySubscriptionCache(subscriptionRoot, state, { read: path => checkedBytes(path, Number.MAX_SAFE_INTEGER), json: parseCacheMetadata, fail });
      directories = [...(directories ?? []), ...cache.directories];
      for (const file of cache.files) {
        entries.push({ source: file.source, destination: `subscriptions/${file.relative}`,
          sha256: file.sha256, size: file.size });
      }
    }
  }
  const original = { schema: "pkm.legacy-state-import/v1" as const, sourceRoot,
    ...(subscriptionRoot === undefined ? {} : { subscriptionRoot }), ...(usesKey ? { keyEpoch: epoch! } : {}),
    ...(subscriptionIdentity ? { subscriptionIdentity } : {}), entries, ...(directories ? { directories } : {}) };
  if (usesKey) await assertEpoch(authority, epoch);
  return { ...original, planSha256: digest(original) };
}

/**
 * Writes only into the unpublished workspace owned by the outer legacy importer.
 * The outer importer must discard that entire stage on any error and must replan
 * immediately before its existing atomic no-replace publication.
 */
export async function stageLegacyStateImport(plan: LegacyStateImportPlan, stagingRoot: string, authority?: LegacySnapshotKeyAuthority,
  identityPolicy?: LegacySubscriptionIdentityImport): Promise<void> {
  const { planSha256, ...input } = plan;
  if (digest(input) !== planSha256) fail("PLAN_CHANGED", "State plan was modified.");
  if (plan.keyEpoch) await assertEpoch(authority, plan.keyEpoch);
  const current = await planLegacyStateImport(plan.sourceRoot, plan.subscriptionRoot, authority, identityPolicy);
  if (current.planSha256 !== planSha256) fail("SOURCE_CHANGED", "State inventory changed before staging.");
  const stage = await realDirectory(stagingRoot);
  for (const root of [plan.sourceRoot, ...(plan.subscriptionRoot ? [plan.subscriptionRoot] : [])]) {
    const rel = relative(root, stage);
    const reverse = relative(stage, root);
    if (rel === "" || (!rel.startsWith(`..${sep}`) && rel !== ".." && !isAbsolute(rel))
      || (!reverse.startsWith(`..${sep}`) && reverse !== ".." && !isAbsolute(reverse))) {
      fail("UNSAFE_PATH", "Staging and source directories must be disjoint.");
    }
  }
  const written: string[] = [];
  try {
    for (const directory of current.directories ?? []) {
      let path = stage;
      for (const part of directory.split("/")) {
        path = join(path, part);
        try { await mkdir(path, { mode: 0o700 }); }
        catch (error) { if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error; }
        const stat = await lstat(path);
        if (!stat.isDirectory() || stat.isSymbolicLink()) fail("UNSAFE_PATH", "State stage directory changed.");
      }
    }
    const prepared: Array<{ path: string; bytes: Buffer }> = [];
    for (const entry of current.entries) {
      if (entry.destination.startsWith("subscriptions/cache/") || entry.destination.startsWith("_feedback/") || entry.destination.startsWith("_proposals/")) {
        const path = join(stage, ...entry.destination.split("/"));
        const file = await open(path, "wx", 0o600);
        written.push(path);
        try {
          const pin = await inspectLegacyCacheFile(entry.source, file);
          if (pin.sha256 !== entry.sha256 || pin.size !== entry.size) fail("SOURCE_CHANGED", "Cache source changed during staged copy.");
          await file.sync();
        } finally { await file.close(); }
        continue;
      }
      let bytes = await checkedBytes(entry.source);
      if (hash(bytes) !== (entry.sourceSha256 ?? entry.sha256) || bytes.length !== (entry.sourceSize ?? entry.size)) fail("SOURCE_CHANGED", "State bytes changed during staging.");
      if (entry.sourceSha256) {
        if (!identityPolicy || !plan.subscriptionIdentity) fail("ACCESS_DENIED", "Native subscription identity authority is required.");
        const original = parse(bytes, true);
        const projected = projectOriginalSubscriptionIdentity(original, plan.sourceRoot, plan.subscriptionRoot!, hash(bytes), identityPolicy,
          current.entries.find(item => item.destination === "subscriptions/subscriber-stats.json")?.sha256 ?? null);
        if (entry.destination === "subscriptions/subscriptions.json") {
          await storeSubscriptionIdentity(projected.binding, projected.privateKey, identityPolicy.authority);
        }
        bytes.fill(0);
        bytes = Buffer.from(JSON.stringify(entry.destination.endsWith("native-identity.json") ? projected.binding : projected.projection));
        if (hash(bytes) !== entry.sha256 || bytes.length !== entry.size) fail("PLAN_CHANGED", "Subscription identity projection differs from its exact approval.");
      }
      const path = join(stage, ...entry.destination.split("/"));
      prepared.push({ path, bytes });
    }
    for (const { path, bytes } of prepared) {
      let directory = stage;
      for (const component of relative(stage, dirname(path)).split(sep)) {
        directory = join(directory, component);
        try { await mkdir(directory, { mode: 0o700 }); }
        catch (error) { if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error; }
        const stat = await lstat(directory);
        if (!stat.isDirectory() || stat.isSymbolicLink()) fail("UNSAFE_PATH", "Staging path contains a link or non-directory.");
      }
      const file = await open(path, "wx", 0o600);
      written.push(path);
      try { await file.writeFile(bytes); await file.sync(); } finally { await file.close(); }
    }
    await verifyLegacyStateImport(plan, stage, authority, identityPolicy);
  } catch (error) {
    for (const path of written.reverse()) await unlink(path).catch(() => undefined);
    throw error;
  }
}

/** Call again under the outer importer's exclusive stage immediately before publication. */
export async function verifyLegacyStateImport(plan: LegacyStateImportPlan, stagingRoot: string, authority?: LegacySnapshotKeyAuthority,
  identityPolicy?: LegacySubscriptionIdentityImport): Promise<void> {
  const { planSha256, ...input } = plan;
  if (digest(input) !== planSha256) fail("PLAN_CHANGED", "State plan was modified.");
  if (plan.keyEpoch) await assertEpoch(authority, plan.keyEpoch);
  const current = await planLegacyStateImport(plan.sourceRoot, plan.subscriptionRoot, authority, identityPolicy);
  if (current.planSha256 !== planSha256) fail("SOURCE_CHANGED", "State inventory changed.");
  const stage = await realDirectory(stagingRoot);
  if (plan.subscriptionIdentity && await inspectSubscriptionIdentity(plan.subscriptionIdentity, identityPolicy?.authority) !== "committed") {
    fail("UNKNOWN_EFFECT", "Native subscription secret reference is not durably confirmed.");
  }
  const expected = new Map(current.entries.map(entry => [entry.destination, entry]));
  const directories = new Set<string>(current.directories ?? []);
  for (const path of expected.keys()) {
    const parts = path.split("/");
    for (let i = 1; i < parts.length; i++) directories.add(parts.slice(0, i).join("/"));
  }
  const visited = new Set<string>();
  async function walk(path: string): Promise<void> {
    const full = join(stage, ...path.split("/"));
    let stat;
    try { stat = await lstat(full); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
      throw error;
    }
    if (stat.isSymbolicLink()) fail("UNSAFE_PATH", "Staged state contains a link.");
    if (stat.isDirectory() && directories.has(path)) {
      for (const name of await readdir(full)) await walk(`${path}/${name}`);
    } else {
      const entry = expected.get(path);
      if (!entry || !stat.isFile()) fail("UNKNOWN_STATE", "Staged state contains an unexpected entry.");
      if (entry.destination.startsWith("subscriptions/cache/") || entry.destination.startsWith("_feedback/") || entry.destination.startsWith("_proposals/")) {
        const pin = await inspectLegacyCacheFile(full);
        if (pin.sha256 !== entry.sha256 || pin.size !== entry.size) fail("STAGE_CHANGED", "Staged cache bytes changed.");
      } else {
        const bytes = await checkedBytes(full);
        if (hash(bytes) !== entry.sha256 || bytes.length !== entry.size) fail("STAGE_CHANGED", "Staged state bytes changed.");
      }
      visited.add(path);
    }
  }
  await walk("agent-snapshot-reads");
  await walk("subscriptions");
  await walk("_feedback");
  await walk("_proposals");
  if (visited.size !== expected.size) fail("STAGE_CHANGED", "Staged state is incomplete.");
  const actorId = "legacy-state-import-validation";
  if (current.entries.some(entry => entry.destination.startsWith("agent-snapshot-reads/"))) {
    await readAgentSnapshots(stage, { operation: "agent.snapshot.list", args: {}, actorId } as never);
  }
  if (current.entries.some(entry => entry.destination.startsWith("subscriptions/"))) {
    await readSubscriptions(stage, { operation: "subscription.list", args: {}, actorId });
  }
  const after = await planLegacyStateImport(plan.sourceRoot, plan.subscriptionRoot, authority, identityPolicy);
  if (after.planSha256 !== planSha256) fail("SOURCE_CHANGED", "State inventory changed during verification.");
}

/**
 * Host-only read seam. Host must authorize actor and bind this plan to its
 * verified import receipt; neither Magic Code nor a public argument grants keys.
 * The existing native list/get still expose encrypted metadata without keys.
 */
export async function readImportedEncryptedSnapshot(
  plan: LegacyStateImportPlan, stagingRoot: string,
  request: { actorId: string; args: unknown }, authority: LegacySnapshotKeyAuthority,
): Promise<unknown> {
  const { planSha256, ...input } = plan;
  if (digest(input) !== planSha256 || !plan.keyEpoch) fail("PLAN_CHANGED", "Encrypted import receipt is invalid.");
  if (typeof request.actorId !== "string" || !request.actorId.trim()) fail("FORBIDDEN", "A trusted actor is required.");
  const definition = agentSnapshotReadDefinitions.find(item => item.id === "agent.snapshot.read")!;
  const args = definition.input.safeParse(request.args);
  if (!args.success) fail("INVALID_INPUT", "Snapshot read arguments are invalid.");
  await assertEpoch(authority, plan.keyEpoch);
  const stage = await realDirectory(stagingRoot);
  const listed = await readAgentSnapshots(stage, { operation: "agent.snapshot.list", args: { limit: 100 }, actorId: request.actorId } as never) as {
    snapshotRevision: string;
  };
  if (args.data.snapshotRevision !== undefined && args.data.snapshotRevision !== listed.snapshotRevision) {
    fail("STAGE_CHANGED", "Snapshot revision changed.");
  }
  let match: { snapshot: Record<string, unknown>; entry: StateEntry } | undefined;
  for (const entry of plan.entries.filter(item => item.destination.startsWith("agent-snapshot-reads/"))) {
    if (!/^agent-snapshot-reads\/\.pkm\/state\/agent-snapshots\/agent_snapshot_[A-Za-z0-9_-]+\.json$/.test(entry.destination)) {
      fail("PLAN_CHANGED", "Snapshot receipt path is invalid.");
    }
    const bytes = await checkedBytes(join(stage, ...entry.destination.split("/")));
    if (hash(bytes) !== entry.sha256 || bytes.length !== entry.size) fail("STAGE_CHANGED", "Snapshot bytes differ from the import receipt.");
    const snapshot = parse(bytes);
    if (snapshot.magicCode === args.data.magic_code) {
      if (match) fail("INVALID_STATE", "Duplicate Snapshot Magic Code.");
      match = { snapshot, entry };
    }
  }
  if (!match) fail("NOT_FOUND", "Snapshot does not exist in the imported receipt.");
  await checkSnapshot(match.snapshot, match.entry.destination.split("/").at(-1)!, authority, plan.keyEpoch);
  if (!object(match.snapshot.payload) || !("algorithm" in match.snapshot.payload)) {
    fail("INVALID_STATE", "Snapshot is not an encrypted original.");
  }
  const payload = await decryptSnapshot(match.snapshot, authority, plan.keyEpoch);
  const projection = snapshotReadProjection(match.snapshot, payload, args.data.recent_messages);
  const result = definition.output.safeParse({ ...projection, snapshotRevision: listed.snapshotRevision,
    adapters: { encryptedPayload: "unavailable", networkRecovery: "unavailable", vscode: "unavailable", restore: "unavailable" } });
  if (!result.success) fail("INVALID_STATE", "Snapshot read projection is invalid.");
  const after = await readAgentSnapshots(stage, { operation: "agent.snapshot.list", args: {
    snapshotRevision: listed.snapshotRevision,
  }, actorId: request.actorId } as never);
  void after;
  await assertEpoch(authority, plan.keyEpoch);
  return result.data;
}
