import { lstatSync, readFileSync } from "node:fs";
import { CoreError, type StorageRequest } from "./contracts.js";
import { checkedResourcePath } from "./document-path.js";
import { createNoteQueries, projectNote } from "./domain/notes.js";
import { readTodoBoard, todoBoardFilename } from "./domain/todo-board.js";
import { sha256 } from "./file-write.js";
import { knowledgeSnapshot } from "./knowledge-snapshot.js";
import type { MarkdownRecord } from "./markdown.js";
import { noteRecord } from "./note-contracts.js";

export function readNotes(root: string, documents: MarkdownRecord[], request: StorageRequest) {
  const sources = knowledgeSnapshot(root, documents, "notes", "Note", { maxDocuments: null, maxBytes: null });
  const records = sources.map(source => {
    let board: { mtimeMs: number; digest: string } | undefined;
    try {
      const path = checkedResourcePath(root, `${source.rel.replace(/\.md$/i, ".assets")}/${todoBoardFilename}`, false, "notes");
      const stat = lstatSync(path);
      if (!stat.isFile() || stat.isSymbolicLink()) throw new CoreError("INVALID_DOCUMENT", "Note Board backing must be a regular UTF-8 JSON file.");
      const bytes = readFileSync(path), raw = bytes.toString("utf8");
      if (!Buffer.from(raw, "utf8").equals(bytes)) throw new CoreError("INVALID_DOCUMENT", "Note Board backing is invalid UTF-8; bytes were not replaced.");
      try { readTodoBoard(raw); }
      catch (error) { throw new CoreError("INVALID_DOCUMENT", `Invalid Note Board backing: ${error instanceof Error ? error.message : String(error)}`); }
      board = { mtimeMs: stat.mtimeMs, digest: sha256(bytes) };
    } catch (error) {
      if (!(error instanceof Error && "code" in error && error.code === "ENOENT")) {
        if (error instanceof CoreError) throw error;
        throw new CoreError("INVALID_DOCUMENT", error instanceof Error ? error.message : String(error));
      }
    }
    const parsed = noteRecord.safeParse(projectNote({ ...source, board }));
    if (!parsed.success) throw new CoreError("INVALID_DOCUMENT", `Note metadata violates the original read-model types: notes/${source.rel}. Use knowledge.metadata.get to inspect it.`);
    return { ...parsed.data, documentId: source.document.record.id, path: source.rel, documentSha256: source.document.record.sha256 };
  });
  const snapshotRevision = sha256(JSON.stringify(records));
  if (request.args.snapshotRevision !== undefined && request.args.snapshotRevision !== snapshotRevision) {
    throw new CoreError("CONFLICT", "Note snapshot changed; restart related queries/pagination.");
  }
  if (request.operation === "knowledge.note.get") {
    const found = records.filter(record => request.args.path !== undefined ? record.path === request.args.path
      : request.args.alias !== undefined ? record.aliases.includes(String(request.args.alias))
        : record.documentId === request.args.id || record.knowledgeId === request.args.id);
    if (!found.length) throw new CoreError("NOT_FOUND", "Note not found in this isolated workspace.");
    if (found.length > 1) throw new CoreError("CONFLICT", "Note identity or alias is ambiguous; use an exact list path.");
    return { item: found[0]!, snapshotRevision };
  }
  if (request.operation !== "knowledge.note.list") throw new CoreError("NOT_FOUND", "Unknown Note query.");
  const queries = createNoteQueries(records);
  const all = queries.noteList(request.args.type === undefined ? undefined : String(request.args.type), records.length, false);
  const offset = Number(request.args.offset), limit = Number(request.args.limit);
  const items = limit === 0 ? all.slice(offset) : all.slice(offset, offset + limit), next = offset + items.length;
  return { items, total: all.length, nextOffset: next < all.length ? next : null, snapshotRevision };
}
