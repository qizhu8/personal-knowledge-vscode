import { Worker } from "node:worker_threads";
import { DatabaseSync } from "node:sqlite";
import { mkdir, readFile, readdir, writeFile, lstat, realpath } from "node:fs/promises";
import { resolve, join } from "node:path";
import { randomUUID } from "node:crypto";
import { CoreError, type StorageRequest } from "./contracts.js";
import { knowledgeArea } from "./document-path.js";
import { scanMarkdown } from "./markdown.js";
import { DataRuntime } from "./data-runtime.js";
import { MigrationRuntime } from "./migration-runtime.js";
import { remoteRuntimePending } from "./remote-runtime.js";
import { RUNTIME_PROCESS_DDL } from "./runtime-process-store.js";
import { existsSync } from "node:fs";
import { inspectLegacyControlRecovery } from "./legacy-control-import.js";
import { readLegacyExtensionPendingEnvelope } from "./legacy-command-extension-recovery.js";
import { recoverNativeLegacyCommands } from "./host-composition-legacy-commands.js";
import { readLegacyRecipeTrashPendingEnvelope } from "./legacy-recipe-trash.js";
import { assertPortalRecoveryClear } from "./host-composition-portal.js";
import { readLegacyStateReceipt, readLegacySkillMaintenanceGenesis, verifyBoundLegacyStateBytes, verifyLegacyRetrievalHistoryBinding } from "./host-composition-legacy-state.js";
import { inspectLegacySkillMaintenanceRecovery, recoverLegacySkillMaintenance } from "./legacy-skill-maintenance.js";
import { inspectLegacyRetrievalModelRecovery, recoverLegacyRetrievalModels } from "./legacy-retrieval-model.js";
import { inspectLegacyTodoBoardCreateIntent, type LegacyTodoBoardCreateArguments } from "./legacy-todo-board-create.js";
import { verifyLegacyKnowledgeRecovery } from "./legacy-knowledge-recovery.js";
import { assertLegacyKnowledgeSnapshotPrivacyRoot, verifyLegacyKnowledgeSnapshots } from "./legacy-knowledge-snapshots.js";
import { verifyLegacyActionArtifacts } from "./legacy-action-artifacts.js";
import { inspectLegacyInlineNoteFence } from "./legacy-inline-note-journal.js";
import { inspectPausedSnapshotJournal, assertSharedSourceRecoveryScope } from "./host-composition-legacy-snapshot-restore.js";
import { verifyInlineNoteWorkspace } from "./host-composition-legacy-inline-note.js";
import { inspectBatch15SkillPending, assertBatch15OtherPending, verifyBatch15SkillWorkspace } from "./host-composition-legacy-batch15-skill.js";
import { assertSkillSourceIntegrated } from "./host-composition-legacy-skill-source.js";
import { assertBatch16UnintegratedClear } from "./host-composition-legacy-batch16-fence.js";
import { validateLegacyMemoryErasureLedger } from "./legacy-memory-erasure.js";
import { inspectNativeClassificationPending } from "./legacy-classification-native.js";
import { inspectLegacyClassificationCommand } from "./legacy-classification-command.js";

const marker = ".pkm-next-workspace";
export async function initialize(directory: string) {
  const root = resolve(directory);
  await mkdir(root, { mode: 0o700 });
  await writeFile(join(root, marker), JSON.stringify({ schema: "pkm.next-workspace/v2", id: randomUUID() }), { flag: "wx", mode: 0o600 });
  await mkdir(join(root, "notes"), { mode: 0o700 });
  return root;
}
export async function validateWorkspace(directory: string) {
  const root = resolve(directory);
  if ((await lstat(root)).isSymbolicLink()) throw new CoreError("INVALID_WORKSPACE", "Workspace symlinks are not supported.");
  const entries = await readdir(root);
  const directories = new Set<string>([...knowledgeArea.options, "prompts", "scripts", "packages", "boards", "project", "recipes", "subscriptions", "agent-snapshot-reads", "recipe-usage-reads", "knowledge-read-config", ".pkm"]);
  for (const name of ["_feedback", "_proposals"]) {
    if (!entries.includes(name)) continue;
    const rootStat = await lstat(join(root, name));
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new CoreError("INVALID_WORKSPACE", "Skill maintenance root must be a real directory.");
    const children = await readdir(join(root, name));
    if (name === "_feedback" && children.some(child => child !== "skill-usage.jsonl" && !/^\.pkm-write-[a-fA-F0-9-]{36}$/.test(child))
      || name === "_proposals" && children.some(child => child !== "skills")) {
      throw new CoreError("INVALID_WORKSPACE", "Unknown Skill maintenance artifact state.");
    }
    if (name === "_proposals" && children.includes("skills")) {
      const stat = await lstat(join(root, name, "skills"));
      if (!stat.isDirectory() || stat.isSymbolicLink()) throw new CoreError("INVALID_WORKSPACE", "Skill proposal area must be a real directory.");
    }
    directories.add(name);
  }
  const allowed = new Set([marker, ".legacy-trash-import.json", ...directories, "core.sqlite", "core.sqlite-wal", "core.sqlite-shm",
    ".pkm-paired-memory-backup.json", ".pkm-native-memory-adoption.json", ".pkm-native-memory-publication.json",
    "coding-process.sqlite", "coding-process.sqlite-wal", "coding-process.sqlite-shm"]);
  if (entries.some(name => !allowed.has(name))) throw new CoreError("INVALID_WORKSPACE", "Not an isolated next-server workspace. Legacy data directories must not be used.");
  for (const name of entries) {
    const stat = await lstat(join(root, name));
    if (stat.isSymbolicLink() || !(directories.has(name) ? stat.isDirectory() : stat.isFile())) throw new CoreError("INVALID_WORKSPACE", "Workspace entries must be regular files or knowledge/boards directories.");
  }
  if (entries.includes(".pkm")) {
    let database: DatabaseSync | undefined;
    try {
      const databasePath = join(root, "core.sqlite");
      const stat = await lstat(databasePath);
      if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) throw new Error("Unowned native database.");
      database = new DatabaseSync(databasePath, { readOnly: true });
      assertLegacyKnowledgeSnapshotPrivacyRoot(database, root);
    } catch {
      throw new CoreError("INVALID_WORKSPACE", "Legacy data directories must not be used without explicit native private snapshot authority.");
    } finally { database?.close(); }
  }
  if (entries.includes(".pkm-native-memory-adoption.json") || entries.includes(".pkm-paired-memory-backup.json")) {
    if (!entries.includes(".pkm-native-memory-publication.json"))
      throw new CoreError("RECOVERY_REQUIRED", "Paired native memory publication requires explicit durable reconciliation.");
    const publication = JSON.parse(await readFile(join(root, ".pkm-native-memory-publication.json"), "utf8"));
    if (publication.state !== "committed")
      throw new CoreError("RECOVERY_REQUIRED", "Unknown paired native memory publication must not start workers or replay effects.");
  }
  const identity: unknown = JSON.parse(await readFile(join(root, marker), "utf8"));
  if (!identity || typeof identity !== "object" || !("schema" in identity) || identity.schema !== "pkm.next-workspace/v2") throw new CoreError("INVALID_WORKSPACE", "Initialize a new Markdown-authoritative v2 workspace. Database-only prototype v1 workspaces are not automatically adopted.");
  if (!entries.includes("notes")) throw new CoreError("INVALID_WORKSPACE", "Workspace notes directory is missing.");
  return realpath(root);
}

type Pending = { resolve: (value: unknown) => void; reject: (error: Error) => void };
interface NativeSnapshotSchedulerResource {
  pauseForBackup(): Promise<{ assertHeld(): void; release(): Promise<void> | void }>;
  close(): Promise<void>;
}
export class Storage {
  private readonly pending = new Map<number, Pending>();
  private sequence = 0;
  private closed = false;
  private drain: (() => void) | undefined;
  private closing: Promise<void> | undefined;
  private snapshotScheduler?: NativeSnapshotSchedulerResource;
  private exited = false;
  private recovered = false;
  private recovery: Promise<void> | undefined;
  private worker: Worker;
  private lease?: { ownerId: string; fence: number };
  private leaseDatabase?: DatabaseSync;
  private leaseTimer?: ReturnType<typeof setInterval>;
  private leaseLost = false;
  private leaseLostHandler?: (error: CoreError) => void;
  private exclusiveTail: Promise<void> = Promise.resolve();
  private exclusiveQueued = 0;
  private exclusiveActive = false;
  private constructor(private readonly root: string) {
    this.worker = new Worker(new URL("./storage-worker.js", import.meta.url), { workerData: root });
  }
  static async open(directory: string, options: { deferRecovery?: boolean } = {}) {
    const store = new Storage(await validateWorkspace(directory));
    try {
      await new Promise<void>((resolve, reject) => {
        store.worker.once("error", reject);
        store.worker.once("exit", code => reject(new CoreError("STORAGE_UNAVAILABLE", `Storage exited before ready (${code}).`)));
        store.worker.on("message", message => {
          if (message.ready) { resolve(); return; }
          const pending = store.pending.get(message.id);
          if (!pending) return;
          store.pending.delete(message.id);
          if (message.error) pending.reject(new CoreError(message.error.code, message.error.message, message.error.effect));
          else pending.resolve(message.result);
          if (!store.pending.size) store.drain?.();
        });
        store.worker.on("exit", code => {
          store.exited = true;
          store.closed = true;
          for (const pending of store.pending.values()) pending.reject(new CoreError("STORAGE_UNAVAILABLE", `Storage worker exited (${code}); reconcile pending writes.`, "unknown"));
          store.pending.clear();
          store.drain?.();
        });
      });
    } catch (error) {
      await store.worker.terminate();
      throw error;
    }
    store.worker.on("error", error => {
      console.error("PKM next storage worker:", error);
    });
    try {
      store.acquireWorkspaceLease();
      if (!options.deferRecovery && !store.hasPendingLegacyNoteWorkItemsIntent() && !store.hasPendingSharedSourceIntent()) await store.recover();
    } catch (error) {
      await store.worker.terminate();
      store.releaseWorkspaceLease();
      throw error;
    }
    return store;
  }
  workspaceRoot(): string { return this.root; }
  workspaceLease(): Readonly<{ ownerId: string; fence: number }> {
    this.assertWorkspaceLease();
    return this.lease!;
  }
  onLeaseLost(handler: (error: CoreError) => void): void { this.leaseLostHandler = handler; }
  assertNoPendingLegacyNoteWorkItems(): void {
    if (this.hasPendingLegacyNoteWorkItemsIntent()) {
      throw new CoreError("BUSY", "A legacy Note operation requires exact native recovery before workspace admission.", "unknown");
    }
  }
  assertWorkspaceLease(): void {
    if (this.closed || this.leaseLost || !this.lease) throw new CoreError("STORAGE_UNAVAILABLE", "Workspace ownership lease is unavailable.", "unknown");
    const database = new DatabaseSync(join(this.root, "core.sqlite"));
    try {
      const owner = database.prepare("SELECT owner_id,fence,lease_until FROM native_runtime_owner WHERE singleton=1").get();
      if (owner?.owner_id !== this.lease.ownerId || owner?.fence !== this.lease.fence || Number(owner.lease_until) <= Date.now()) {
        this.loseWorkspaceLease();
        throw new CoreError("STORAGE_UNAVAILABLE", "Workspace ownership lease was lost.", "unknown");
      }
    } finally { database.close(); }
  }
  async workspaceId(): Promise<string> {
    if (this.closed) throw new CoreError("STORAGE_UNAVAILABLE", "Storage is closed.");
    const identity: unknown = JSON.parse(await readFile(join(this.root, marker), "utf8"));
    if (!identity || typeof identity !== "object" || !("id" in identity)
      || typeof identity.id !== "string" || !/^[0-9a-f-]{36}$/i.test(identity.id)) {
      throw new CoreError("INVALID_WORKSPACE", "Workspace identity is invalid.");
    }
    return identity.id;
  }
  connectNative(): DatabaseSync {
    if (this.closed) throw new CoreError("STORAGE_UNAVAILABLE", "Storage is closed.");
    const database = new DatabaseSync(join(this.root, "core.sqlite"));
    try {
      database.exec("PRAGMA busy_timeout=3000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;");
      return database;
    } catch (error) {
      database.close();
      throw error;
    }
  }
  connectCodingProcess(): DatabaseSync {
    this.assertWorkspaceLease();
    const database = new DatabaseSync(join(this.root, "coding-process.sqlite"));
    try {
      database.exec("PRAGMA busy_timeout=3000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;");
      const version = Number(database.prepare("PRAGMA user_version").get()?.user_version);
      if (![0, 1].includes(version)) throw new CoreError("INVALID_CONFIGURATION", "Unsupported coding process journal version.");
      database.exec("BEGIN IMMEDIATE");
      try {
        database.exec(RUNTIME_PROCESS_DDL);
        this.assertWorkspaceLease();
        database.exec("PRAGMA user_version=1; COMMIT");
      } catch (error) { if (database.isTransaction) database.exec("ROLLBACK"); throw error; }
      this.assertWorkspaceLease();
      return database;
    } catch (error) { database.close(); throw error; }
  }
  inspectCodingProcess(): void {
    this.assertWorkspaceLease();
    const path = join(this.root, "coding-process.sqlite");
    if (!existsSync(path)) return;
    const database = new DatabaseSync(path, { readOnly: true });
    try {
      const version = Number(database.prepare("PRAGMA user_version").get()?.user_version);
      if (version !== 1 || database.prepare("PRAGMA quick_check").get()?.quick_check !== "ok")
        throw new CoreError("CODING_RESTART_FENCED", "Coding process journal requires native version/integrity reconciliation.", "unknown");
      if (database.prepare("SELECT 1 FROM runtime_process_owner WHERE closed=0 LIMIT 1").get()
        || database.prepare("SELECT 1 FROM runtime_process_jobs WHERE state IN ('QUEUED','RUNNING') LIMIT 1").get())
        throw new CoreError("CODING_RESTART_FENCED", "Interrupted coding checks require native observation; no process is relaunched.", "unknown");
      this.assertWorkspaceLease();
    } finally { database.close(); }
  }
  async provisionTrash(): Promise<void> {
    this.assertWorkspaceLease();
    for (const area of knowledgeArea.options) {
      const directory = join(this.root, area);
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const stat = await lstat(directory);
      if (stat.isSymbolicLink() || !stat.isDirectory()) throw new CoreError("INVALID_WORKSPACE", "Trash area must be a real directory.");
      await mkdir(join(directory, ".trash"), { recursive: true, mode: 0o700 });
      const trash = await lstat(join(directory, ".trash"));
      if (trash.isSymbolicLink() || !trash.isDirectory()) throw new CoreError("INVALID_WORKSPACE", "Trash must be a real directory.");
    }
    this.assertWorkspaceLease();
  }

  private createDefaultDataRuntime(database: DatabaseSync, root: string, workspaceId: string) {
    const storage = this;
    return new DataRuntime({
      database, root, workspaceId,
      transaction<T>(work: () => T): T {
        storage.assertWorkspaceLease();
        database.exec("BEGIN IMMEDIATE");
        try {
          const result = work();
          if (result && typeof (result as { then?: unknown }).then === "function") throw new Error("Async transaction callback.");
          storage.assertWorkspaceLease();
          database.exec("COMMIT");
          return result;
        } catch (error) {
          if (database.isTransaction) database.exec("ROLLBACK");
          throw error;
        }
      },
      reconcileIndex() {
        const docs = scanMarkdown(root);
        database.prepare("DELETE FROM documents").run();
        const insert = database.prepare("INSERT INTO documents(id,title,revision,deleted,sha256,path,area) VALUES(?,?,?,?,?,?,?)");
        for (const { record } of docs) insert.run(record.id, record.title, record.revision, record.deleted ? 1 : 0,
          record.sha256, record.path, record.area);
      },
      assertOperationAvailable(operationId) {
        if (remoteRuntimePending(database)) throw new CoreError("BUSY", "A remote operation requires native reconciliation.");
        for (const table of ["pending_write", "pending_todo", "pending_asset", "pending_resource",
          "pending_document_lifecycle", "pending_project_mutation", "data_runtime_intents", "migration_runtime_intents",
          "legacy_note_workitems_intent"]) {
          if (database.prepare(`SELECT 1 FROM ${table}`).get()) {
            throw new CoreError("BUSY", "A different durable workspace intent must be reconciled first.");
          }
          if (!operationId) throw new CoreError("INVALID_ARGUMENT", "Durable operationId is required.");
        }
      },
    });
  }
  recover(preflight?: (database: DatabaseSync) => Promise<void>): Promise<void> {
    if (this.recovered) return Promise.resolve();
    if (this.recovery) return this.recovery;
    if (this.closed) return Promise.reject(new CoreError("STORAGE_UNAVAILABLE", "Storage is closed."));
    this.recovery = (async () => {
      this.assertWorkspaceLease();
      this.inspectCodingProcess();
      const database = this.connectNative();
      try {
        const workspaceId = await this.workspaceId();
        verifyLegacyKnowledgeRecovery(database, this.root);
        verifyLegacyKnowledgeSnapshots(database, this.root);
        verifyLegacyActionArtifacts(database, workspaceId);
        inspectLegacyTodoBoardCreateIntent(database, this.root);
        inspectLegacyRetrievalModelRecovery(database, this.root);
        verifyLegacyRetrievalHistoryBinding(database, workspaceId);
        inspectLegacySkillMaintenanceRecovery(database, this.root, readLegacySkillMaintenanceGenesis(database, workspaceId));
        assertBatch16UnintegratedClear(database, true, undefined, !!preflight, false, !!preflight);
        if (assertSkillSourceIntegrated(database, !!preflight).active) return;
        if (validateLegacyMemoryErasureLedger(database, await this.workspaceId()).state !== "uninitialized")
          return;
        assertPortalRecoveryClear(database);
        readLegacyStateReceipt(database, workspaceId);
        const inlineIntent = inspectLegacyInlineNoteFence(database);
        const snapshotUnknown = inspectPausedSnapshotJournal(database);
        const skillIntent = inspectBatch15SkillPending(database);
        const classificationIntent = inspectNativeClassificationPending(database);
        const originalClassification = inspectLegacyClassificationCommand(database);
        if (originalClassification.pending || preflight && originalClassification.receipts.length) return;
        if (classificationIntent || preflight && database.prepare("SELECT 1 FROM legacy_classification_native_receipt LIMIT 1").get()) return;
        if (skillIntent) assertBatch15OtherPending(database);
        if (inlineIntent || snapshotUnknown) assertSharedSourceRecoveryScope(database, !!inlineIntent);
        if (inlineIntent && snapshotUnknown) throw new CoreError("RECOVERY_CONFLICT", "Multiple shared-source effects require reconciliation before any effect.", "unknown");
        const extension = readLegacyExtensionPendingEnvelope(database);
        const recipeTrash = readLegacyRecipeTrashPendingEnvelope(database);
        const noteIntent = database.prepare("SELECT operation_id,actor_id,operation,request_json,native_operation,native_args FROM legacy_note_workitems_intent WHERE singleton=1")
          .get() as Record<string, unknown> | undefined;
        if (!extension && !recipeTrash) inspectLegacyControlRecovery(database, workspaceId);
        if (recipeTrash && !preflight) throw new CoreError("RECOVERY_AUTHORITY_REQUIRED", "Recipe trash recovery requires an explicit native host policy.", "unknown");
        if (noteIntent && (!preflight || extension || recipeTrash)) {
          throw new CoreError("RECOVERY_AUTHORITY_REQUIRED", "Original Note recovery requires its exact injected native host before workspace recovery.", "unknown");
        }
        const pendingTables = ["pending_write", "pending_todo", "pending_asset", "pending_resource",
          "pending_document_lifecycle", "pending_project_mutation", "data_runtime_intents", "migration_runtime_intents",
          "legacy_note_workitems_intent", "legacy_inline_note_intent"];
        let intents = 0;
        for (const table of pendingTables) intents += Number(database.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get()!.count);
        if ((inlineIntent || snapshotUnknown) && (intents !== Number(!!inlineIntent) || extension || recipeTrash
          || remoteRuntimePending(database) || database.prepare("SELECT 1 FROM coding_worker_effects WHERE state='intent'").get()
          || database.prepare("SELECT 1 FROM coding_worker_records WHERE kind IN ('worker','check-intent') AND json_extract(record,'$.status')='intent'").get()))
          throw new CoreError("RECOVERY_CONFLICT", "Shared-source unknown journal conflicts with another workspace effect; no recovery attempted.", "unknown");
        if (!inlineIntent) await verifyInlineNoteWorkspace(database, this.root);
        if (!skillIntent) verifyBatch15SkillWorkspace(database, this.root);
        if (noteIntent) {
          let nativeArgs: Record<string, unknown>;
          try { nativeArgs = JSON.parse(String(noteIntent.native_args)) as Record<string, unknown>; }
          catch { throw new CoreError("RECOVERY_CONFLICT", "Original Note intent arguments are malformed.", "unknown"); }
          const nativeTodo = database.prepare("SELECT operation_id,actor_id,operation,board_slug FROM pending_todo WHERE singleton=1")
            .get() as Record<string, unknown> | undefined;
          if (nativeTodo) {
            if (nativeTodo.operation_id !== noteIntent.operation_id || nativeTodo.actor_id !== noteIntent.actor_id
              || nativeTodo.operation !== noteIntent.native_operation || nativeTodo.board_slug !== nativeArgs.board_slug) {
              throw new CoreError("RECOVERY_CONFLICT", "Native Todo intent disagrees with the original Note recovery envelope.", "unknown");
            }
            intents--;
          }
          if (database.prepare("SELECT 1 FROM legacy_note_workitems_receipt WHERE operation_id=?").get(String(noteIntent.operation_id))) {
            throw new CoreError("RECOVERY_CONFLICT", "Original Note intent already has a compatibility receipt; preserve it for reconciliation.", "unknown");
          }
        }
        const remotePending = remoteRuntimePending(database);
        if (remotePending && (intents || !preflight))
          throw new CoreError("RECOVERY_CONFLICT", "Remote effects require native preflight before any workspace recovery.", "unknown");
        if (database.prepare("SELECT 1 FROM coding_worker_effects WHERE state='intent' LIMIT 1").get()
          || database.prepare("SELECT 1 FROM coding_worker_records WHERE kind IN ('worker','check-intent') AND json_extract(record,'$.status')='intent' LIMIT 1").get())
          throw new CoreError("RECOVERY_CONFLICT", "Coding effects require read-only native reconciliation before workspace recovery.", "unknown");
        // Extension metadata is validated against its pending_project_mutation row above,
        // not a second independently executable intent.
        if (intents + Number(!!recipeTrash) > 1) throw new CoreError("RECOVERY_CONFLICT", "Multiple durable workspace intents require reconciliation before any effect.");
        if (extension) {
          const lease = this.workspaceLease();
          recoverNativeLegacyCommands(database, this.root, () => {
            const owner = database.prepare("SELECT owner_id,fence,lease_until FROM native_runtime_owner WHERE singleton=1").get();
            if (!owner || owner.owner_id !== lease.ownerId || owner.fence !== lease.fence || Number(owner.lease_until) <= Date.now()) {
              throw new CoreError("STORAGE_UNAVAILABLE", "Extension recovery owner lease is fenced.", "unknown");
            }
          });
          inspectLegacyControlRecovery(database, workspaceId);
        }
        if (preflight) await preflight(database);
        else if (!inlineIntent && !snapshotUnknown && !skillIntent) {
          const workspaceId = await this.workspaceId();
          const data = this.createDefaultDataRuntime(database, this.root, workspaceId);
          const migration = new MigrationRuntime({
            database, root: this.root, workspaceId,
            transaction: work => {
              this.assertWorkspaceLease();
              if (database.isTransaction) throw new CoreError("TRANSACTION_BOUNDARY", "Nested recovery transaction.");
              database.exec("BEGIN IMMEDIATE");
              try {
                const result = work();
                if (result && typeof (result as { then?: unknown }).then === "function") throw new CoreError("TRANSACTION_BOUNDARY", "Async recovery transaction.");
                this.assertWorkspaceLease(); database.exec("COMMIT"); return result;
              } catch (error) { if (database.isTransaction) database.exec("ROLLBACK"); throw error; }
            },
            reconcileIndex: () => {
              const documents = scanMarkdown(this.root);
              database.prepare("DELETE FROM documents").run();
              const insert = database.prepare("INSERT INTO documents(id,title,revision,deleted,sha256,path,area) VALUES(?,?,?,?,?,?,?)");
              for (const { record } of documents) insert.run(record.id, record.title, record.revision, record.deleted ? 1 : 0, record.sha256, record.path, record.area);
            },
            assertOperationAvailable: () => { throw new CoreError("BUSY", "Default recovery cannot create new intents."); },
          });
          try { await data.inspectRecovery(); await migration.inspectRecovery(); await data.recover(); await migration.recover(); }
          finally { data.close(); migration.close(); }
        }
        recoverLegacySkillMaintenance(database, this.root, {
          genesis: readLegacySkillMaintenanceGenesis(database, workspaceId),
          assertWorkspaceLease: () => this.assertWorkspaceLease(),
        });
        recoverLegacyRetrievalModels(database, this.root, { assertWorkspaceLease: () => this.assertWorkspaceLease() });
        if (readLegacyStateReceipt(database, workspaceId)?.plan.retrievalHistoryPlan) {
          await verifyBoundLegacyStateBytes(database, this.root, workspaceId);
        }
        const id = ++this.sequence;
        const response = new Promise<void>((resolve, reject) => {
          this.pending.set(id, {
            resolve: () => resolve(),
            reject,
          });
        });
        try { this.worker.postMessage({ id, recover: true, runtimeOwner: this.lease }); }
        catch (error) { this.pending.delete(id); throw error; }
        await response;
        this.recovered = true;
      } finally { database.close(); }
    })().finally(() => { this.recovery = undefined; });
    return this.recovery;
  }
  request(request: StorageRequest): Promise<unknown> {
    if (this.closed || this.closing) return Promise.reject(new CoreError("STORAGE_UNAVAILABLE", "Storage is closed."));
    if (!this.recovered) return Promise.reject(new CoreError("STORAGE_UNAVAILABLE", "Workspace recovery must complete before requests are accepted."));
    try { this.assertNoPendingLegacyNoteWorkItems(); }
    catch (error) { return Promise.reject(error); }
    try {
      if (this.hasPendingSharedSourceIntent()) throw new CoreError("RECOVERY_REQUIRED", "Shared-source journal requires explicit native reconciliation.", "unknown");
    } catch (error) { return Promise.reject(error); }
    if (this.exclusiveActive || this.exclusiveQueued) return Promise.reject(new CoreError("BUSY", "A native workspace journal is being applied; request was not dispatched."));
    return this.postRequest(request);
  }
  requestLegacyNoteWorkItems(request: StorageRequest, operationId: string): Promise<unknown> {
    if (this.closed || !this.exclusiveActive && !this.recovery) {
      return Promise.reject(new CoreError("BUSY", "Legacy Note native dispatch requires its exclusive durable fence.", "unknown"));
    }
    if (!this.recovered && !this.recovery) {
      return Promise.reject(new CoreError("STORAGE_UNAVAILABLE", "Workspace recovery must complete before requests are accepted."));
    }
    try {
      this.assertWorkspaceLease();
      const database = this.connectNative();
      try {
        const intent = database.prepare("SELECT operation_id,actor_id,native_operation,native_args FROM legacy_note_workitems_intent WHERE singleton=1")
          .get() as { operation_id: string; actor_id: string; native_operation: string; native_args: string } | undefined;
        if (!intent || intent.operation_id !== operationId || intent.actor_id !== request.actorId
          || intent.native_operation !== request.operation || intent.native_args !== JSON.stringify(request.args)
          || request.args.operationId !== operationId) {
          throw new CoreError("RECOVERY_CONFLICT", "Native Todo request differs from the exact durable Note intent.", "unknown");
        }
      } finally { database.close(); }
    } catch (error) { return Promise.reject(error); }
    return this.postRequest(request, operationId);
  }
  requestLegacyTodoBoardCreate(input: LegacyTodoBoardCreateArguments, actorId: string): Promise<unknown> {
    if (this.closed || !this.recovered || !this.exclusiveActive) {
      return Promise.reject(new CoreError("BUSY", "Original Board creation requires a recovered exclusive native host."));
    }
    this.assertWorkspaceLease();
    this.assertNoPendingLegacyNoteWorkItems();
    if (this.hasPendingSharedSourceIntent()) return Promise.reject(new CoreError("RECOVERY_REQUIRED", "Shared-source recovery blocks Board creation.", "unknown"));
    return this.postRequest({ operation: "todo.board.create", args: {
      board_slug: input.category ? `${input.category}/${input.title}` : input.title, operationId: input.operationId,
    }, actorId }, undefined, input);
  }
  private postRequest(request: StorageRequest, legacyNoteOperationId?: string, originalNoteCreate?: LegacyTodoBoardCreateArguments): Promise<unknown> {
    if (this.pending.size >= 32) return Promise.reject(new CoreError("BUSY", "Storage queue is full; request was not dispatched."));
    return new Promise((resolve, reject) => {
      const id = ++this.sequence;
      this.pending.set(id, { resolve, reject });
      try {
        this.assertWorkspaceLease();
        this.worker.postMessage({ id, request, runtimeOwner: this.lease, ...(legacyNoteOperationId ? { legacyNoteOperationId } : {}),
          ...(originalNoteCreate ? { originalNoteCreate } : {}) });
      }
      catch (error) {
        this.pending.delete(id);
        console.error("PKM next storage dispatch:", error);
        reject(new CoreError("STORAGE_UNAVAILABLE", "Could not dispatch the request to storage."));
      }

    });
  }
  private hasPendingLegacyNoteWorkItemsIntent(): boolean {
    if (!this.lease) return false;
    const database = this.connectNative();
    try { return !!database.prepare("SELECT 1 FROM legacy_note_workitems_intent WHERE singleton=1").get(); }
    finally { database.close(); }
  }
  private hasPendingSharedSourceIntent(): boolean {
    const database = this.connectNative();
    try { return !!inspectLegacyInlineNoteFence(database) || !!inspectPausedSnapshotJournal(database) || !!inspectBatch15SkillPending(database); }
    finally { database.close(); }
  }
  async withWorkspaceExclusive<T>(work: () => Promise<T> | T): Promise<T> {
    if (this.closed) throw new CoreError("STORAGE_UNAVAILABLE", "Storage is closed.");
    this.exclusiveQueued++;
    const previous = this.exclusiveTail;
    let release!: () => void;
    this.exclusiveTail = previous.then(() => new Promise<void>(resolve => { release = resolve; }));
    await previous;
    if (this.pending.size) await new Promise<void>(resolve => { this.drain = resolve; });
    this.exclusiveQueued--;
    this.exclusiveActive = true;
    try {
      this.assertWorkspaceLease();
      return await work();
    } finally {
      this.exclusiveActive = false;
      release();
    }
  }
  registerNativeSnapshotScheduler(resource: NativeSnapshotSchedulerResource): () => void {
    if (this.closed || this.closing || this.snapshotScheduler)
      throw new CoreError("BUSY", "A native snapshot scheduler is already owned or Storage is closing.");
    this.snapshotScheduler = resource;
    return () => { if (this.snapshotScheduler === resource) this.snapshotScheduler = undefined; };
  }
  async acquireNativeSnapshotSchedulerQuiescence() {
    return this.snapshotScheduler?.pauseForBackup();
  }
  close(): Promise<void> {
    if (this.closing) return this.closing;
    if (!this.snapshotScheduler) this.closed = true;
    this.closing = (async () => {
      let schedulerError: unknown;
      try { await this.snapshotScheduler?.close(); }
      catch (error) { schedulerError = error; }
      this.closed = true;
      try {
        await this.exclusiveTail;
        if (this.pending.size) await new Promise<void>(resolve => { this.drain = resolve; });
        if (!this.exited) await new Promise<void>((resolve, reject) => {
          this.worker.once("exit", code => code === 0 ? resolve() : reject(new CoreError("STORAGE_UNAVAILABLE", `Storage shutdown exited (${code}).`, "unknown")));
          this.worker.postMessage({ close: true });
        });
      } finally { this.releaseWorkspaceLease(); }
      if (schedulerError) throw schedulerError;
    })();
    return this.closing;
  }
  private acquireWorkspaceLease(): void {
    const database = this.connectNative();
    const ownerId = randomUUID(), now = Date.now(), duration = 30_000;
    try {
      database.exec("BEGIN IMMEDIATE");
      const prior = database.prepare("SELECT owner_id,fence,lease_until FROM native_runtime_owner WHERE singleton=1").get();
      if (prior && Number(prior.lease_until) > now) throw new CoreError("BUSY", "Another process currently owns this workspace.", "not-committed");
      const fence = prior ? Number(prior.fence) + 1 : 1;
      database.prepare(`INSERT INTO native_runtime_owner VALUES(1,?,?,?)
        ON CONFLICT(singleton) DO UPDATE SET owner_id=excluded.owner_id,fence=excluded.fence,lease_until=excluded.lease_until`)
        .run(ownerId, fence, now + duration);
      database.exec("COMMIT");
      this.lease = { ownerId, fence };
      this.leaseTimer = setInterval(() => {
        try {
          const current = Date.now();
          database.exec("BEGIN IMMEDIATE");
          const updated = database.prepare(`UPDATE native_runtime_owner SET lease_until=?
            WHERE singleton=1 AND owner_id=? AND fence=? AND lease_until>?`)
            .run(current + duration, ownerId, fence, current);
          if (updated.changes !== 1) throw new CoreError("STORAGE_UNAVAILABLE", "Workspace ownership lease expired or changed.", "unknown");
          database.exec("COMMIT");
        } catch (error) {
          if (database.isTransaction) database.exec("ROLLBACK");
          this.loseWorkspaceLease(error);
        }
      }, Math.floor(duration / 3));
      this.leaseTimer.unref();
      this.leaseDatabase = database;
    } catch (error) {
      if (database.isTransaction) database.exec("ROLLBACK");
      throw error;
    } finally { if (!this.lease) database.close(); }
  }
  private loseWorkspaceLease(error?: unknown): void {
    if (this.leaseLost) return;
    this.leaseLost = true;
    if (this.leaseTimer) clearInterval(this.leaseTimer);
    this.leaseTimer = undefined;
    this.leaseLostHandler?.(error instanceof CoreError ? error
      : new CoreError("STORAGE_UNAVAILABLE", "Workspace ownership lease was lost.", "unknown"));
  }
  private releaseWorkspaceLease(): void {
    if (this.leaseTimer) clearInterval(this.leaseTimer);
    this.leaseTimer = undefined;
    if (!this.lease) return;
    const database = this.leaseDatabase;
    if (!database) { this.lease = undefined; return; }
    try {
      database.exec("BEGIN IMMEDIATE");
      database.prepare("UPDATE native_runtime_owner SET lease_until=0 WHERE singleton=1 AND owner_id=? AND fence=?")
        .run(this.lease.ownerId, this.lease.fence);
      database.exec("COMMIT");
    } catch {
      if (database.isTransaction) database.exec("ROLLBACK");
    } finally { database.close(); this.leaseDatabase = undefined; this.lease = undefined; }
  }
}
