import re
import warnings
from typing import List, Tuple, Union

chat_part_pat = re.compile(r"<\|im_start\|>(system|user|assistant)([\w\W]*?)<\|im_end\|>")
chat_last_part_pat = re.compile(r"<\|im_start\|>assistant([\w\W]*?)$")

# The "prompt not fully covered by chat parts" warning is emitted at most ONCE per
# process. convert_prompt_to_chat_format may be called for millions of prompts in a
# batch, so we must not flood the log - but the issue (text outside the chat blocks
# is silently dropped) is important, so the single warning is made loud and visible.
_partial_coverage_warned = False


def reset_partial_coverage_warning() -> None:
    """Re-arm the once-per-process partial-coverage warning (mainly for tests)."""
    global _partial_coverage_warned
    _partial_coverage_warned = False


def _warn_partial_coverage_once() -> None:
    global _partial_coverage_warned
    if _partial_coverage_warned:
        return
    _partial_coverage_warned = True
    banner = "=" * 76
    msg = (
        "\n" + banner + "\n"
        "[prompt_manager] CHAT prompt is NOT fully covered by <|im_start|> ... <|im_end|> blocks.\n"
        "  -> Text OUTSIDE the chat blocks is DROPPED when converting to chat messages,\n"
        "     which can silently truncate the prompt actually sent to the model.\n"
        "  Fix: wrap ALL content in <|im_start|>role ... <|im_end|> blocks (e.g. a system\n"
        "  block for instructions + a user block for the per-row task).\n"
        "  (This warning is shown only once per process.)\n"
        + banner
    )
    warnings.warn(msg, UserWarning, stacklevel=3)


def is_prompt_matches_endpoint_mode(prompt: Tuple[str, List], endpoint_mode: str) -> bool:
    """
    Check if the prompt matches the endpoint mode. E.g., if the endpoint mode is "COMPLETION", the prompt should be a string.
    If the endpoint mode is "CHAT", the prompt should be a list of tuples, where each tuple contains two strings: (role, content).
    """
    normalized_mode = endpoint_mode.strip().upper()
    if normalized_mode == "COMPLETION":
        return isinstance(prompt, str)
    if normalized_mode == "CHAT":
        if isinstance(prompt, list) or isinstance(prompt, tuple):
            for element in prompt:
                if not isinstance(element, (list, tuple)) or len(element) != 2 or not isinstance(element[0], str) or not isinstance(element[1], str):
                    return False
            return True
        return False
    return False


def convert_prompt_to_chat_format(prompt: Union[str, List, Tuple]) -> Tuple[Tuple, bool]:
    """Convert the prompt to a list of messages for chat mode.
        E.g., prompt = "<|im_start|>user\nHello, how are you?\n <|im_end|> <|im_start|>assistant\nI am fine, thank you.\n<|im_end|>
        will be converted to:
        [
            {"role": "user", "content": "Hello, how are you?"},
            {"role": "assistant", "content": "I am fine, thank you."}
        ]

        return:
            messages: str, List of messages in chat format
            fully_covered: bool, Whether the prompt is fully covered by chat parts
        """
    if isinstance(prompt, list) or isinstance(prompt, tuple):
        # if the prompt is already in chat format, return it directly
        return prompt, True

    chat_parts = chat_part_pat.findall(prompt)
    fully_covered = True

    messages = []
    if not chat_parts:
        # the prompt is in completion mode
        messages.append(("user", prompt))
    else:
        prompt_remain = chat_part_pat.sub("", prompt)
        if prompt_remain.strip() != "":
            fully_covered = False
            _warn_partial_coverage_once()

        for rst in chat_parts:
            if len(rst) != 2:
                continue
            role, content = rst
            messages.append((role, content.strip()))
    return tuple(messages), fully_covered
