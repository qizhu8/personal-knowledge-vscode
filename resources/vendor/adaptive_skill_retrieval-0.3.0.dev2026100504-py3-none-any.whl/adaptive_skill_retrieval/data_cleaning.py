from __future__ import annotations

import json
import re
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Mapping


CLEANER_VERSION = "collector-training-cleaner-v3"
LOG_SCOPE_PATTERN = re.compile(
    r"(^|[/\\*{,.\s-])(debug[-_]?logs?|logs?|transcripts?)([/\\*},.\s-]|$)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class CleaningDecision:
    status: str
    reason: str
    fingerprint: str
    canonical_example_id: str | None = None


def classify_example(
    example: Mapping[str, Any],
    *,
    canonical_example_id: str | None = None,
) -> CleaningDecision:
    fingerprint = example_fingerprint(example)
    if canonical_example_id:
        return CleaningDecision(
            "duplicate", "normalized_exact_duplicate", fingerprint, canonical_example_id
        )
    payload = example.get("payload", {})
    if not isinstance(payload, Mapping):
        return CleaningDecision("quarantined", "invalid_payload", fingerprint)
    if not str(payload.get("query") or "").strip():
        return CleaningDecision("quarantined", "empty_user_query", fingerprint)
    tool_name = str(payload.get("tool_name") or "").strip()
    if not tool_name and payload.get("tool_arguments"):
        return CleaningDecision("quarantined", "missing_tool_name", fingerprint)
    provenance = example.get("label_provenance", {})
    if isinstance(provenance, Mapping):
        if provenance.get("relevance") == "agent_trajectory_no_match":
            return CleaningDecision("quarantined", "unverified_no_match", fingerprint)
        if str(provenance.get("retrieval_results", "")).startswith("unsupported_"):
            return CleaningDecision("quarantined", "unsupported_replay_contract", fingerprint)
    if not isinstance(provenance, Mapping) or provenance.get("query") not in {
        "human_user_turn",
        "agent_search_function_argument",
    }:
        return CleaningDecision("quarantined", "unlinked_user_context", fingerprint)
    if tool_name not in {"grep_search", "functions.grep_search"}:
        return CleaningDecision("usable", "passed_v2_rules", fingerprint)
    arguments = payload.get("tool_arguments", {})
    if not isinstance(arguments, Mapping):
        return CleaningDecision("quarantined", "invalid_tool_arguments", fingerprint)
    tool_query = str(arguments.get("query") or "").strip()
    if not tool_query:
        return CleaningDecision("quarantined", "empty_tool_query", fingerprint)
    include_pattern = str(arguments.get("includePattern") or "")
    if LOG_SCOPE_PATTERN.search(include_pattern):
        return CleaningDecision("quarantined", "log_or_transcript_scope", fingerprint)
    return CleaningDecision("usable", "passed_v2_rules", fingerprint)


def example_fingerprint(example: Mapping[str, Any]) -> str:
    payload = example.get("payload", {})
    if not isinstance(payload, Mapping):
        payload = {}
    arguments = payload.get("tool_arguments", {})
    if not isinstance(arguments, Mapping):
        arguments = {}
    identity = {
        "user_query": _normalize_text(payload.get("query")),
        "tool_name": _normalize_text(payload.get("tool_name")),
        "tool_query": _normalize_text(arguments.get("query")),
        "include_pattern": _normalize_text(arguments.get("includePattern")),
        "is_regexp": bool(arguments.get("isRegexp")),
        "include_ignored": bool(arguments.get("includeIgnoredFiles")),
        "other_arguments": {
            key: value
            for key, value in arguments.items()
            if key not in {"query", "includePattern", "isRegexp", "includeIgnoredFiles"}
        },
    }
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return sha256(encoded).hexdigest()


def _normalize_text(value: object) -> str:
    return " ".join(str(value or "").casefold().split())