from __future__ import annotations

import itertools
import math
from typing import Any, Mapping, Sequence


DEFAULT_SEARCH_SPACE: dict[str, list[Any]] = {
    "learning_rate": [0.00005, 0.0001, 0.0002],
    "stage_weights": [
        {"retrieval": 1.0, "ranking": 1.0},
        {"retrieval": 2.0, "ranking": 1.0},
        {"retrieval": 1.0, "ranking": 2.0},
    ],
    "calibration_method": ["platt", "isotonic"],
    "calibration_threshold": [0.3, 0.5, 0.7],
}

MEASURED_L1_SEARCH_SPACE: dict[str, list[Any]] = {
    "learning_rate": [0.02, 0.05, 0.1, 0.2, 0.4],
    "exact_route_weight": [0.5, 1.0, 2.0],
    "bm25_route_weight": [0.5, 1.0, 2.0],
    "rank_constant": [20, 40, 60, 80],
    "bm25_k1": [0.5, 0.9, 1.2, 1.8],
    "bm25_b": [0.0, 0.4, 0.75, 1.0],
}


def candidate_configs(
    base_config: Mapping[str, Any], search_space: Mapping[str, Sequence[Any]]
) -> list[dict[str, Any]]:
    keys = list(search_space)
    return [
        {**base_config, **dict(zip(keys, values, strict=True))}
        for values in itertools.product(*(search_space[key] for key in keys))
    ]


def select_expected_improvement(
    candidates: Sequence[Mapping[str, Any]],
    observed: Sequence[tuple[Mapping[str, Any], float]],
    search_space: Mapping[str, Sequence[Any]],
) -> dict[str, Any]:
    if not candidates:
        raise ValueError("Bayesian tuning has exhausted its search space")
    if not observed:
        return dict(candidates[0])
    observed_x = [_encode(config, search_space) for config, _ in observed]
    observed_y = [score for _, score in observed]
    kernel = [
        [
            _rbf(left, right) + (1e-6 if row == column else 0.0)
            for column, right in enumerate(observed_x)
        ]
        for row, left in enumerate(observed_x)
    ]
    inverse_y = _solve(kernel, observed_y)
    best_score = max(observed_y)
    ranked: list[tuple[float, str, dict[str, Any]]] = []
    for candidate in candidates:
        vector = _encode(candidate, search_space)
        covariance = [_rbf(vector, item) for item in observed_x]
        mean = sum(value * weight for value, weight in zip(covariance, inverse_y))
        solved_covariance = _solve(kernel, covariance)
        variance = max(
            1e-12,
            1.0
            - sum(
                value * weight
                for value, weight in zip(covariance, solved_covariance)
            ),
        )
        sigma = math.sqrt(variance)
        improvement = mean - best_score - 0.001
        z_score = improvement / sigma
        expected = improvement * _normal_cdf(z_score) + sigma * _normal_pdf(z_score)
        ranked.append((expected, repr(sorted(candidate.items())), dict(candidate)))
    return max(ranked, key=lambda item: (item[0], item[1]))[2]


def _encode(
    config: Mapping[str, Any], search_space: Mapping[str, Sequence[Any]]
) -> list[float]:
    vector: list[float] = []
    for key, values in search_space.items():
        value = config.get(key)
        if all(isinstance(item, (int, float)) for item in values):
            low, high = min(values), max(values)
            vector.append(0.0 if high == low else (float(value) - low) / (high - low))
        else:
            vector.extend(1.0 if value == item else 0.0 for item in values)
    return vector


def _rbf(left: Sequence[float], right: Sequence[float]) -> float:
    distance = sum((a - b) ** 2 for a, b in zip(left, right))
    return math.exp(-distance / 0.5)


def _solve(matrix: Sequence[Sequence[float]], values: Sequence[float]) -> list[float]:
    size = len(values)
    augmented = [list(matrix[row]) + [float(values[row])] for row in range(size)]
    for column in range(size):
        pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        divisor = augmented[column][column]
        if abs(divisor) < 1e-12:
            raise ValueError("Bayesian covariance matrix is singular")
        augmented[column] = [value / divisor for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                value - factor * pivot_value
                for value, pivot_value in zip(augmented[row], augmented[column])
            ]
    return [row[-1] for row in augmented]


def _normal_pdf(value: float) -> float:
    return math.exp(-0.5 * value * value) / math.sqrt(2.0 * math.pi)


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))