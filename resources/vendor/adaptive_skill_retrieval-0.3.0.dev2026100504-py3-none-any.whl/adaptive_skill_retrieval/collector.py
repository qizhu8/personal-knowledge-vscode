from __future__ import annotations

import argparse
import gzip
import json
import logging
import os
import sqlite3
import uuid
from collections import Counter
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .bayesian_tuning import (
    DEFAULT_SEARCH_SPACE,
    MEASURED_L1_SEARCH_SPACE,
    candidate_configs,
    select_expected_improvement,
)
from .benchmark import BenchmarkCase, evaluate_rankings, load_pkm_skills
from .data_cleaning import CLEANER_VERSION, classify_example
from .dataset_partition import BoundedEvaluationSampler
from .routes import academic_bm25_benchmark_route
from .retrieval_architectures import RETRIEVAL_ARCHITECTURES, architecture_by_id

COLLECTOR_SCHEMA_VERSION = 1
EVENT_TYPES = {"retrieval", "skill_load", "outcome"}
PLACEMENT_DECISIONS = {"accepted", "corrected", "create_child", "duplicate"}
DATASET_PARTITION_POLICY = "grouped-anchor200-rolling800-v1"
DEFAULT_INFERENCE_INTERVAL = 10
RETRIEVAL_ARCHITECTURE_KEYS = frozenset(
    {
        "retrieval_architecture_id",
        "architecture_label",
        "operators",
        "output_granularity",
        "retrieval_family",
    }
)
LEGACY_ARCHITECTURE_KEYS = frozenset(
    {
        "model",
        "search_method",
        "feature_selector",
        "retrieval",
        "retrieval_hierarchy",
        "ranking",
        "scoring_method",
        "topology",
        "calibration_method",
        "retrieval_family",
    }
)


def _si_architecture_and_setting(
    config: Mapping[str, Any],
) -> tuple[str, dict[str, Any], str, dict[str, Any]]:
    child_configs = {
        key: value
        for key in ("l1", "l2")
        if isinstance((value := config.get(key)), Mapping)
    }
    if child_configs:
        identity_keys = (
            RETRIEVAL_ARCHITECTURE_KEYS
            if config.get("retrieval_architecture_id")
            else LEGACY_ARCHITECTURE_KEYS
        )
        child_projections = {
            key: _flat_si_projection(value) for key, value in child_configs.items()
        }
        architecture = {
            **{
                key: value
                for key, value in config.items()
                if key in identity_keys
            },
            **{key: projection[0] for key, projection in child_projections.items()},
        }
        settings = {
            **{
                key: value
                for key, value in config.items()
                if key not in identity_keys and key not in child_configs
            },
            **{key: projection[1] for key, projection in child_projections.items()},
        }
    else:
        architecture, settings = _flat_si_projection(config)
    architecture_json = json.dumps(
        architecture, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    setting_json = json.dumps(
        settings, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    path_id = f"path-{sha256(architecture_json.encode('utf-8')).hexdigest()[:16]}"
    setting_id = f"setting-{sha256(setting_json.encode('utf-8')).hexdigest()[:16]}"
    return path_id, architecture, setting_id, settings


def _bayesian_should_stop(
    scores: Sequence[float], patience: int, minimum_improvement: float
) -> bool:
    if len(scores) <= patience:
        return False
    prior_best = max(scores[:-patience])
    recent_best = max(scores[-patience:])
    return recent_best <= prior_best + minimum_improvement


def _flat_si_projection(
    config: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    identity_keys = (
        RETRIEVAL_ARCHITECTURE_KEYS
        if config.get("retrieval_architecture_id")
        else LEGACY_ARCHITECTURE_KEYS
    )
    return (
        {key: value for key, value in config.items() if key in identity_keys},
        {key: value for key, value in config.items() if key not in identity_keys},
    )


def _performance_stage_config(
    config: Mapping[str, Any], stage_key: str
) -> dict[str, Any]:
    child_key = "l2" if stage_key == "l2_markdown_section" else "l1"
    explicit = config.get(child_key)
    if isinstance(explicit, Mapping):
        child = dict(explicit)
        for key, value in config.items():
            if key not in {"l1", "l2"} and key not in child:
                child[key] = value
        return child
    child = dict(config)
    child["retrieval_hierarchy"] = [
        "markdown_section" if child_key == "l2" else "document"
    ]
    return child


def _default_architecture_config(architecture) -> dict[str, Any]:
    defaults = {
        key: (0.5 if key == "retained_dimension_ratio" else values[0])
        for key, values in architecture.hyperparameter_space.items()
        if values
    }
    hierarchy = (
        ["document"]
        if architecture.output_granularity == "document"
        else ["document", "markdown_section"]
    )
    return {
        "retrieval_architecture_id": architecture.architecture_id,
        "architecture_label": architecture.label,
        "operators": list(architecture.operators),
        "output_granularity": architecture.output_granularity,
        "retrieval_family": architecture.architecture_family,
        "retrieval_hierarchy": hierarchy,
        "execution_backend": architecture.execution_backend,
        "engine_profile": "l1_online",
        "execution_mode": "measured",
        **defaults,
    }


def _search_match_mode(payload: Mapping[str, Any]) -> str:
    family = str(payload.get("baseline_family") or "fuzzy")
    arguments = payload.get("tool_arguments")
    method = str(arguments.get("method") or "") if isinstance(arguments, Mapping) else ""
    if family in {"fuzzy", "semantic"} or (
        family == "remote_code" and method == "semantic"
    ):
        return "fuzzy"
    if family in {"exact", "lexical", "filename", "symbol"} or family == "remote_code":
        return "exact"
    return "other"


def _evaluation_resource_id(value: Any, resource_type: str) -> str:
    resource_id = str(value or "")
    if resource_type == "skill":
        return resource_id.removeprefix("skill:")
    return resource_id


def _simulation_base_config(config: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in config.items()
        if key not in {"execution_mode", "simulation_step_seconds"}
    }


def _elapsed_seconds(started_at: str | None, finished_at: str | None) -> float | None:
    if not started_at or not finished_at:
        return None
    try:
        return max(
            0.0,
            (datetime.fromisoformat(finished_at) - datetime.fromisoformat(started_at)).total_seconds(),
        )
    except ValueError:
        return None


def _performance_stage_specs(config: Mapping[str, Any]) -> list[tuple[str, str]]:
    hierarchy = config.get("retrieval_hierarchy") or ["document"]
    if not isinstance(hierarchy, list):
        hierarchy = [hierarchy]
    specs = [("l1_document", "L1 Document Retrieval")]
    if isinstance(config.get("l2"), Mapping) or any(
        str(level) in {"section", "markdown_section"} for level in hierarchy
    ):
        specs.append(("l2_markdown_section", "L2 Markdown Section Retrieval"))
    return specs


def _ensure_performance_stages(
    connection: sqlite3.Connection,
    task_id: str,
    config: Mapping[str, Any],
) -> None:
    now = datetime.now(UTC).isoformat()
    connection.executemany(
        """
        INSERT OR IGNORE INTO performance_task_stages (
            task_id, stage_key, stage_order, label, state, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'pending', ?, ?)
        """,
        [
            (task_id, stage_key, order, label, now, now)
            for order, (stage_key, label) in enumerate(
                _performance_stage_specs(config), start=1
            )
        ],
    )


class CollectorStore:
    def __init__(
        self,
        database_path: str | Path,
        *,
        pkm_root: str | Path | None = None,
        snapshots_dir: str | Path | None = None,
    ) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.pkm_root = Path(pkm_root) if pkm_root is not None else None
        self.snapshots_dir = Path(
            snapshots_dir or self.database_path.parent / "snapshots"
        )
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def append(self, event: Mapping[str, Any]) -> tuple[str, bool]:
        normalized = self._normalize(event)
        snapshot_id = None
        if normalized["event_type"] == "retrieval" and self.pkm_root is not None:
            snapshot_id = self.snapshot_corpus()
            normalized["payload"].setdefault("corpus_snapshot_id", snapshot_id)
        with self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO events (
                    event_id, interaction_id, event_type, occurred_at, received_at,
                    source_node_id, observation_source, schema_version,
                    corpus_snapshot_id, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    normalized["event_id"],
                    normalized["interaction_id"],
                    normalized["event_type"],
                    normalized["occurred_at"],
                    datetime.now(UTC).isoformat(),
                    normalized["source_node_id"],
                    normalized["observation_source"],
                    normalized["schema_version"],
                    snapshot_id or normalized["payload"].get("corpus_snapshot_id"),
                    json.dumps(
                        normalized["payload"], ensure_ascii=False, sort_keys=True
                    ),
                ),
            )
            if cursor.rowcount == 1:
                self._update_collector_status(
                    connection,
                    "pkm-live",
                    collector_kind="pkm_retrieval_events",
                    state="monitoring",
                    last_query_at=(
                        normalized["occurred_at"]
                        if normalized["event_type"] == "retrieval"
                        else None
                    ),
                    last_observation_at=normalized["occurred_at"],
                    observation_increment=1,
                )
        return normalized["event_id"], cursor.rowcount == 1

    def append_many(
        self, events: Iterable[Mapping[str, Any]]
    ) -> dict[str, Any]:
        accepted = duplicates = updated = 0
        event_ids = []
        for event in events:
            event_id, inserted = self.append(event)
            event_ids.append(event_id)
            accepted += int(inserted)
            duplicates += int(not inserted)
        return {
            "accepted": accepted,
            "duplicates": duplicates,
            "event_ids": event_ids,
        }

    def import_training_examples(
        self, examples: Iterable[Mapping[str, Any]]
    ) -> dict[str, Any]:
        normalized = [self._normalize_imported_example(example) for example in examples]
        accepted = duplicates = updated = 0
        partitions: dict[str, int] = {}
        cleaning: dict[str, int] = {}
        partition_version = self._partition_version()
        with self._connect() as connection:
            for example in normalized:
                source_json = json.dumps(
                    example["source"], ensure_ascii=False, sort_keys=True
                )
                provenance_json = json.dumps(
                    example["label_provenance"], ensure_ascii=False, sort_keys=True
                )
                payload_json = json.dumps(
                    example["payload"], ensure_ascii=False, sort_keys=True
                )
                exists = connection.execute(
                    """
                    SELECT source_json, label_provenance_json, payload_json, group_id
                      FROM imported_training_examples WHERE example_id = ?
                    """,
                    (example["example_id"],),
                ).fetchone()
                if exists is not None:
                    if (
                        exists[3] != example["group_id"]
                        and example["source"].get("kind") == "vscode_search_call_trajectory"
                        and json.loads(exists[0]).get("kind") == "vscode_search_call_trajectory"
                    ):
                        raise ValueError("an imported example cannot change its dataset group")
                    if tuple(exists[:3]) == (source_json, provenance_json, payload_json):
                        duplicates += 1
                        continue
                    existing_source = json.loads(exists[0])
                    if (
                        example["source"].get("kind")
                        != "vscode_search_call_trajectory"
                        or existing_source.get("kind")
                        != "vscode_search_call_trajectory"
                    ):
                        duplicates += 1
                        continue
                    connection.execute(
                        """
                        UPDATE imported_training_examples
                           SET group_id = ?, occurred_at = ?, imported_at = ?,
                               source_json = ?, label_provenance_json = ?,
                               payload_json = ?
                         WHERE example_id = ?
                        """,
                        (
                            example["group_id"], example["occurred_at"],
                            datetime.now(UTC).isoformat(), source_json,
                            provenance_json, payload_json, example["example_id"],
                        ),
                    )
                    connection.execute(
                        "DELETE FROM training_example_cleaning WHERE example_id = ?",
                        (example["example_id"],),
                    )
                    updated += 1
                else:
                    connection.execute(
                        """
                        INSERT INTO imported_training_examples (
                            example_id, group_id, occurred_at, imported_at,
                            source_json, label_provenance_json, payload_json
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            example["example_id"], example["group_id"],
                            example["occurred_at"], datetime.now(UTC).isoformat(),
                            source_json, provenance_json, payload_json,
                        ),
                    )
                decision = self._clean_imported_example(connection, example)
                partition = "excluded"
                if decision.status == "usable":
                    previous_partition = connection.execute(
                        "SELECT partition FROM dataset_groups WHERE group_id = ?",
                        (example["group_id"],),
                    ).fetchone()
                    requested_partition = example["payload"].get("dataset_partition")
                    transcript_id = example["source"].get("transcript_id")
                    if transcript_id and requested_partition in {"training", "validation_anchor"}:
                        conflicting_source = connection.execute(
                            """
                            SELECT 1 FROM imported_training_examples e
                            JOIN dataset_groups g USING (group_id)
                            WHERE json_extract(e.source_json, '$.transcript_id') = ?
                              AND g.partition != ? LIMIT 1
                            """,
                            (transcript_id, requested_partition),
                        ).fetchone()
                        if conflicting_source is not None:
                            raise ValueError("source transcript spans partitions; rebuild in a new dataset")
                    if (
                        previous_partition is not None
                        and requested_partition in {"training", "validation_anchor"}
                        and previous_partition[0] != requested_partition
                    ):
                        raise ValueError(
                            "an existing dataset group cannot change partition; "
                            "create a separately versioned dataset instead"
                        )
                    partition, partition_version = self._assign_dataset_group(
                        connection, example["group_id"]
                    )
                    if requested_partition in {"training", "validation_anchor"}:
                        connection.execute(
                            "UPDATE dataset_groups SET partition = ? WHERE group_id = ?",
                            (requested_partition, example["group_id"]),
                        )
                        partition = str(requested_partition)
                accepted += int(exists is None)
                partitions[partition] = partitions.get(partition, 0) + 1
                cleaning[decision.status] = cleaning.get(decision.status, 0) + 1
        return {
            "accepted": accepted,
            "updated": updated,
            "duplicates": duplicates,
            "partitions": partitions,
            "cleaning": cleaning,
            "cleaner_version": CLEANER_VERSION,
            "partition_policy": DATASET_PARTITION_POLICY,
            "partition_version": partition_version if accepted else self._partition_version(),
        }

    def reset_search_training_data(self) -> dict[str, int]:
        tables = (
            "performance_stage_checkpoints",
            "performance_task_stages",
            "performance_checkpoints",
            "bayesian_tuning_observations",
            "performance_tasks",
            "bayesian_tuning_runs",
            "evaluation_dataset_snapshots",
            "evaluation_study_corpora",
            "dataset_versions",
            "dataset_example_versions",
            "training_tasks",
            "implementation_training_cursors",
            "retrieval_architecture_enrollments",
            "si_path_dataset_attachments",
            "si_inference_batch_paths",
            "si_inference_batches",
            "training_example_cleaning",
            "imported_training_examples",
            "dataset_partition_transitions",
            "dataset_groups",
        )
        deleted: dict[str, int] = {}
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for table in tables:
                deleted[table] = int(
                    connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                )
                connection.execute(f"DELETE FROM {table}")
            connection.execute(
                "DELETE FROM runtime_settings WHERE key='dataset_materialization_revision'"
            )
            connection.execute(
                """
                UPDATE dataset_partition_state
                   SET stream_version = 0, evaluation_version = 0,
                       rolling_candidates_seen = 0
                 WHERE singleton = 1
                """
            )
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """
                UPDATE si_paths SET latest_metrics_json = NULL,
                    last_evaluated_at = NULL, archived_at = ?,
                    archive_reason = 'legacy dataset replaced by search-call-ground-truth-v1',
                    updated_at = ?
                """,
                (now, now),
            )
            connection.execute(
                """
                INSERT INTO si_inference_batches (
                    dataset_revision, state, interval_size, evidence_mode,
                    created_at, completed_at, updated_at
                ) VALUES (0, 'completed', ?, 'measured', ?, ?, ?)
                """,
                (DEFAULT_INFERENCE_INTERVAL, now, now, now),
            )
        return deleted

    def import_measured_seed_examples(
        self,
        examples: Iterable[Mapping[str, Any]],
        *,
        training_count: int,
    ) -> dict[str, Any]:
        examples = list(examples)
        if training_count <= 0 or training_count >= len(examples):
            raise ValueError("measured seed requires nonempty training and validation sets")
        normalized = [self._normalize_imported_example(example) for example in examples]
        result = self.import_training_examples(examples)
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            version = int(
                connection.execute(
                    "SELECT stream_version FROM dataset_partition_state WHERE singleton = 1"
                ).fetchone()[0]
            ) + 1
            for index, example in enumerate(normalized):
                partition = "training" if index < training_count else "validation_anchor"
                connection.execute(
                    """
                    UPDATE dataset_groups
                       SET partition = ?, reservoir_slot = NULL,
                           evicted_at = NULL, partition_version = ?
                     WHERE group_id = ?
                    """,
                    (partition, version, example["group_id"]),
                )
            connection.execute(
                """
                UPDATE dataset_partition_state
                   SET stream_version = ?, evaluation_version = ?
                 WHERE singleton = 1
                """,
                (version, version),
            )
        return {
            **result,
            "partitions": {
                "training": training_count,
                "validation_anchor": len(examples) - training_count,
            },
            "partition_version": version,
            "seeded_at": now,
        }

    def reclean_imported_training_data(self) -> dict[str, Any]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT example_id, group_id, occurred_at, source_json,
                       label_provenance_json, payload_json
                  FROM imported_training_examples ORDER BY occurred_at, rowid
                """
            ).fetchall()
            connection.execute("DELETE FROM training_example_cleaning")
            connection.execute("DELETE FROM dataset_partition_transitions")
            connection.execute("DELETE FROM dataset_groups")
            connection.execute(
                """
                UPDATE dataset_partition_state
                   SET stream_version = 0, evaluation_version = 0,
                       rolling_candidates_seen = 0
                 WHERE singleton = 1
                """
            )
            counts: dict[str, int] = {}
            for row in rows:
                example = {
                    "example_id": row[0],
                    "group_id": row[1],
                    "occurred_at": row[2],
                    "source": json.loads(row[3]),
                    "label_provenance": json.loads(row[4]),
                    "payload": json.loads(row[5]),
                }
                decision = self._clean_imported_example(connection, example)
                counts[decision.status] = counts.get(decision.status, 0) + 1
                if decision.status == "usable":
                    self._assign_dataset_group(connection, example["group_id"])
        return {
            "raw_examples": len(rows),
            "cleaning": counts,
            "cleaner_version": CLEANER_VERSION,
            "partition_version": self._partition_version(),
        }

    def events(
        self,
        *,
        event_type: str | None = None,
        interaction_id: str | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        clauses = []
        parameters: list[Any] = []
        if event_type:
            clauses.append("event_type = ?")
            parameters.append(event_type)
        if interaction_id:
            clauses.append("interaction_id = ?")
            parameters.append(interaction_id)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        parameters.append(max(1, min(int(limit), 100_000)))
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT event_id, interaction_id, event_type, occurred_at,
                       received_at, source_node_id, observation_source,
                       schema_version, corpus_snapshot_id, payload_json
                  FROM events
                """
                + where
                + " ORDER BY rowid ASC LIMIT ?",
                parameters,
            ).fetchall()
        return [self._event_from_row(row) for row in rows]

    def update_collector_status(
        self,
        collector_id: str,
        *,
        collector_kind: str,
        state: str,
        last_query_at: str | None = None,
        last_observation_at: str | None = None,
        cursor: str | None = None,
        error: str | None = None,
        observation_increment: int = 0,
    ) -> None:
        with self._connect() as connection:
            self._update_collector_status(
                connection,
                collector_id,
                collector_kind=collector_kind,
                state=state,
                last_query_at=last_query_at,
                last_observation_at=last_observation_at,
                cursor=cursor,
                error=error,
                observation_increment=observation_increment,
                record_scan=True,
            )

    def collector_statuses(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT collector_id, collector_kind, state, last_scan_at,
                       last_query_at, last_observation_at, last_success_at,
                       last_error, cursor, scan_count, observation_count,
                       updated_at
                  FROM collector_status
                 ORDER BY collector_id
                """
            ).fetchall()
        return [
            {
                "collector_id": row[0],
                "collector_kind": row[1],
                "state": row[2],
                "last_scan_at": row[3],
                "last_query_at": row[4],
                "last_observation_at": row[5],
                "last_success_at": row[6],
                "last_error": row[7],
                "cursor": row[8],
                "scan_count": row[9],
                "observation_count": row[10],
                "updated_at": row[11],
            }
            for row in rows
        ]

    def enqueue_performance_task(
        self,
        config: Mapping[str, Any],
        *,
        priority: int = 0,
        dataset_revision: int | None = None,
        trigger_kind: str | None = None,
        dataset_snapshot_id: str | None = None,
    ) -> dict[str, Any]:
        normalized_config = json.loads(
            json.dumps(dict(config), ensure_ascii=False, sort_keys=True)
        )
        if not normalized_config:
            raise ValueError("path config must not be empty")
        config_json = json.dumps(
            normalized_config, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
        path_id = f"path-{sha256(config_json.encode('utf-8')).hexdigest()[:16]}"
        task_id = str(uuid.uuid4())
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if normalized_config.get("execution_mode") == "measured" and dataset_revision is not None:
                if dataset_snapshot_id is None:
                    dataset_snapshot_id = self._capture_dataset_snapshot(
                        connection, dataset_revision
                    )
                elif connection.execute(
                    "SELECT 1 FROM evaluation_dataset_snapshots WHERE snapshot_id = ?",
                    (dataset_snapshot_id,),
                ).fetchone() is None:
                    raise ValueError("unknown evaluation dataset snapshot")
            physical_path = connection.execute(
                "SELECT archived_at FROM si_paths WHERE path_id = ?", (path_id,)
            ).fetchone()
            if physical_path is None:
                self._ensure_implementation_capacity(
                    connection, normalized_config, now=now
                )
            connection.execute(
                """
                INSERT OR IGNORE INTO si_paths (
                    path_id, config_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?)
                """,
                (path_id, config_json, now, now),
            )
            existing = connection.execute(
                """
                SELECT task_id, dataset_revision, dataset_snapshot_id FROM performance_tasks
                 WHERE path_id = ? AND state IN ('pending', 'running')
                 ORDER BY created_at LIMIT 1
                """,
                (path_id,),
            ).fetchone()
            if existing is not None:
                if (existing[1], existing[2]) != (dataset_revision, dataset_snapshot_id):
                    raise ValueError("this path already has an active task for a different dataset")
                _ensure_performance_stages(
                    connection, existing[0], normalized_config
                )
                return self._performance_task(connection, existing[0])
            connection.execute(
                """
                INSERT INTO performance_tasks (
                    task_id, path_id, state, priority, dataset_revision,
                    trigger_kind, created_at, updated_at, dataset_snapshot_id
                ) VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?)
                """,
                (
                    task_id, path_id, int(priority), dataset_revision,
                    trigger_kind, now, now, dataset_snapshot_id,
                ),
            )
            _ensure_performance_stages(connection, task_id, normalized_config)
            return self._performance_task(connection, task_id)

    def retry_performance_task(self, task_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT t.path_id, t.state, t.priority, t.dataset_revision,
                       t.trigger_kind, p.config_json, t.dataset_snapshot_id
                  FROM performance_tasks t JOIN si_paths p USING (path_id)
                 WHERE t.task_id = ?
                """,
                (task_id,),
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance task: {task_id}")
            if row[1] not in {"failed", "cancelled"}:
                raise ValueError("only a failed or cancelled task can be retried")
            active = connection.execute(
                """
                SELECT 1 FROM performance_tasks
                 WHERE path_id = ? AND state IN ('pending', 'running') LIMIT 1
                """,
                (row[0],),
            ).fetchone()
            if active is not None:
                raise ValueError("this path already has an active task")
        return self.enqueue_performance_task(
            json.loads(row[5]),
            priority=int(row[2]),
            dataset_revision=row[3],
            trigger_kind=row[4],
            dataset_snapshot_id=row[6],
        )

    def register_performance_path(self, config: Mapping[str, Any]) -> dict[str, Any]:
        normalized_config = json.loads(
            json.dumps(dict(config), ensure_ascii=False, sort_keys=True)
        )
        if normalized_config.get("execution_mode") != "measured":
            raise ValueError("active SI paths must use execution_mode='measured'")
        config_json = json.dumps(
            normalized_config, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
        physical_path_id = f"path-{sha256(config_json.encode('utf-8')).hexdigest()[:16]}"
        path_id, architecture, setting_id, settings = _si_architecture_and_setting(
            normalized_config
        )
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            existing_configs = connection.execute(
                "SELECT config_json FROM si_paths"
            ).fetchall()
            path_existed = any(
                _si_architecture_and_setting(json.loads(row[0]))[0] == path_id
                for row in existing_configs
            )
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO si_paths (
                    path_id, architecture_id, trial_configuration_id,
                    config_json, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (physical_path_id, path_id, setting_id, config_json, now, now),
            )
            created = cursor.rowcount == 1
        return {
            "path_id": path_id,
            "architecture_id": path_id,
            "setting_id": setting_id,
            "trial_configuration_id": setting_id,
            "architecture": architecture,
            "settings": settings,
            "config": normalized_config,
            "created": created,
            "path_existed": path_existed,
            "setting_existed": not created,
        }

    def register_all_measured_paths(self) -> dict[str, Any]:
        registrations = [
            self.register_performance_path(_default_architecture_config(architecture))
            for architecture in RETRIEVAL_ARCHITECTURES
        ]
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            attached = 0
            registry_attached = 0
            runnable = 0
            for architecture, registration in zip(
                RETRIEVAL_ARCHITECTURES, registrations, strict=True
            ):
                state = "enrolled"
                cursor = connection.execute(
                    """
                    INSERT INTO retrieval_architecture_enrollments (
                        architecture_id, dataset_id, state, execution_backend,
                        enrolled_at, updated_at
                    ) VALUES (?, 'search-call-ground-truth-v1', ?, ?, ?, ?)
                    ON CONFLICT(architecture_id, dataset_id) DO UPDATE SET
                        state = excluded.state,
                        execution_backend = excluded.execution_backend,
                        updated_at = excluded.updated_at
                    WHERE retrieval_architecture_enrollments.state != excluded.state
                       OR retrieval_architecture_enrollments.execution_backend
                          IS NOT excluded.execution_backend
                    """,
                    (
                        registration["architecture_id"], state,
                        architecture.execution_backend, now, now,
                    ),
                )
                newly_attached = int(cursor.rowcount == 1)
                attached += newly_attached
                registry_attached += newly_attached
                runnable += int(state == "enrolled")
            custom_rows = {
                str(row[0]): json.loads(row[1])
                for row in connection.execute(
                    """
                    SELECT architecture_id, config_json FROM si_paths
                     WHERE archived_at IS NULL ORDER BY created_at
                    """
                ).fetchall()
                if not json.loads(row[1]).get("retrieval_architecture_id")
            }
            custom_supported = [
                row for row in custom_rows.items() if self._measured_path_supported(row[1])
            ]
            for architecture_id, _ in custom_supported:
                cursor = connection.execute(
                    """
                    INSERT OR IGNORE INTO retrieval_architecture_enrollments (
                        architecture_id, dataset_id, state, execution_backend,
                        enrolled_at, updated_at
                    ) VALUES (?, 'search-call-ground-truth-v1', 'enrolled',
                              'measured_l1', ?, ?)
                    """,
                    (architecture_id, now, now),
                )
                attached += int(cursor.rowcount == 1)
                runnable += 1
        tasks = self.enqueue_due_inference_tasks()
        return {
            "attached_count": attached,
            "already_attached_count": (
                len(RETRIEVAL_ARCHITECTURES) + len(custom_supported) - attached
            ),
            "registry_attached_count": registry_attached,
            "custom_attached_count": attached - registry_attached,
            "runnable_count": runnable,
            "registry_architecture_count": len(RETRIEVAL_ARCHITECTURES),
            "custom_path_count": len(custom_supported),
            "attachment_count": len(RETRIEVAL_ARCHITECTURES) + len(custom_supported),
            "materialized_count": len(registrations),
            "tasks": tasks,
            "task_count": len(tasks),
            "readiness": self.inference_interval_status(),
        }

    @staticmethod
    def _measured_path_supported(config: Mapping[str, Any]) -> bool:
        architecture_id = config.get("retrieval_architecture_id")
        if architecture_id:
            try:
                return architecture_by_id(str(architecture_id)).execution_backend is not None
            except LookupError:
                return False
        return (
            (
                config.get("engine_profile") == "l1_online"
                or config.get("model") == "l1_online"
            )
            and config.get("retrieval_hierarchy", ["document"]) == ["document"]
        )

    def enqueue_due_inference_tasks(self, *, priority: int = 0) -> list[dict[str, Any]]:
        with self._connect() as connection:
            automatic = connection.execute(
                "SELECT value FROM runtime_settings WHERE key = 'automatic_bayesian_enabled'"
            ).fetchone()
            if automatic and automatic[0] == "true":
                return []
            connection.execute("BEGIN IMMEDIATE")
            interval_row = connection.execute(
                "SELECT value FROM runtime_settings WHERE key = 'si_inference_interval'"
            ).fetchone()
            interval = max(
                1,
                int(interval_row[0]) if interval_row is not None else DEFAULT_INFERENCE_INTERVAL,
            )
            current_revision = self._labeled_training_count(connection)
            validation_count = self._labeled_validation_count(connection)
            target_revision = current_revision - current_revision % interval
            if target_revision < interval or validation_count == 0:
                return []
            snapshots = {
                revision: self._capture_dataset_snapshot(connection, revision)
                for revision in range(interval, target_revision + 1, interval)
            }
            rows = connection.execute(
                """
                SELECT p.path_id, p.config_json
                  FROM retrieval_architecture_enrollments a
                  JOIN si_paths p USING (architecture_id)
                 WHERE a.dataset_id = 'search-call-ground-truth-v1'
                                     AND a.state = 'enrolled'
                   AND p.archived_at IS NULL
                   AND (
                       json_extract(p.config_json, '$.retrieval_architecture_id')
                           IS NULL
                       OR json_extract(p.config_json, '$.execution_backend')
                           IS a.execution_backend
                   )
                   AND NOT EXISTS (
                       SELECT 1 FROM performance_tasks t
                        WHERE t.path_id = p.path_id
                     AND t.state IN ('pending', 'running')
                   )
                 ORDER BY a.enrolled_at, p.path_id
                """,
            ).fetchall()
            terminal_rows = connection.execute(
                    """
                    SELECT path_id, dataset_revision, dataset_snapshot_id, state FROM performance_tasks
                     WHERE state IN ('completed', 'failed', 'cancelled')
                       AND dataset_revision IS NOT NULL
                    """
                ).fetchall()
            completed_revisions = {
                (str(row[0]), int(row[1]), row[2]) for row in terminal_rows
                if row[3] == "completed"
            }
            terminal_revisions = {
                (str(row[0]), int(row[1]), row[2]) for row in terminal_rows
            }
            pending = []
            for row in rows:
                for revision, snapshot_id in snapshots.items():
                    key = (str(row[0]), revision, snapshot_id)
                    if key in completed_revisions:
                        continue
                    if key not in terminal_revisions:
                        pending.append((row[1], revision, snapshot_id))
                    break
        return [
            self.enqueue_performance_task(
                json.loads(config_json),
                priority=priority,
                dataset_revision=revision,
                trigger_kind="labeled_training_interval",
                dataset_snapshot_id=snapshot_id,
            )
            for config_json, revision, snapshot_id in pending
        ]

    @staticmethod
    def _cleaned_training_count(connection: sqlite3.Connection) -> int:
        return int(
            connection.execute(
                """
                SELECT COUNT(*)
                  FROM imported_training_examples e
                  JOIN training_example_cleaning c USING (example_id)
                  JOIN dataset_groups g USING (group_id)
                 WHERE c.status = 'usable' AND g.partition = 'training'
                     AND COALESCE(
                         json_extract(e.payload_json, '$.resource_type'), 'skill'
                         ) = 'skill'
                     AND (
                         COALESCE(json_extract(e.payload_json, '$.baseline_family'), 'fuzzy')
                             IN ('fuzzy', 'semantic')
                         OR (
                             json_extract(e.payload_json, '$.baseline_family') = 'remote_code'
                             AND json_extract(e.payload_json, '$.tool_arguments.method') = 'semantic'
                         )
                     )
                """
            ).fetchone()[0]
        )

    def _labeled_training_count(self, connection: sqlite3.Connection) -> int:
        return len(self._measured_dataset_cases(connection, "training"))

    def _labeled_validation_count(self, connection: sqlite3.Connection) -> int:
        return len(self._measured_dataset_cases(connection, "validation_anchor"))

    @staticmethod
    def _dataset_readiness_by_resource(
        connection: sqlite3.Connection,
    ) -> dict[str, dict[str, Any]]:
        rows = connection.execute(
            """
            WITH evidence AS (
                SELECT COALESCE(
                           json_extract(e.payload_json, '$.resource_type'), 'skill'
                       ) AS resource_type,
                       g.partition,
                       e.group_id,
                       MAX(
                           CASE WHEN (
                               json_array_length(COALESCE(
                                   json_extract(e.payload_json, '$.relevant_resource_ids'),
                                   json_extract(e.payload_json, '$.relevant_skill_ids')
                               )) > 0
                               OR json_extract(e.payload_json, '$.no_match') = 1
                           ) AND json_extract(
                               e.label_provenance_json, '$.relevance'
                           ) NOT IN ('unavailable', 'unknown')
                           THEN 1 ELSE 0 END
                       ) AS labeled,
                       MAX(
                           CASE WHEN (
                               (
                                   json_array_length(COALESCE(
                                       json_extract(e.payload_json, '$.relevant_resource_ids'),
                                       json_extract(e.payload_json, '$.relevant_skill_ids')
                                   )) > 0
                                   AND json_array_length(json_extract(
                                       e.payload_json, '$.final_ranking'
                                   )) > 0
                               )
                               OR json_extract(e.payload_json, '$.no_match') = 1
                           ) AND json_extract(
                               e.label_provenance_json, '$.relevance'
                           ) NOT IN ('unavailable', 'unknown')
                             AND json_extract(
                               e.label_provenance_json, '$.retrieval_results'
                           ) NOT IN ('unavailable', 'unknown')
                           THEN 1 ELSE 0 END
                       ) AS ranking_ready,
                       MAX(
                           CASE WHEN json_array_length(COALESCE(
                               json_extract(e.payload_json, '$.relevant_resource_ids'),
                               json_extract(e.payload_json, '$.relevant_skill_ids')
                           )) > 0
                             AND json_array_length(json_extract(
                               e.payload_json, '$.final_ranking'
                           )) > 0
                             AND json_extract(
                               e.label_provenance_json, '$.relevance'
                           ) NOT IN ('unavailable', 'unknown')
                             AND json_extract(
                               e.label_provenance_json, '$.retrieval_results'
                           ) NOT IN ('unavailable', 'unknown')
                           THEN 1 ELSE 0 END
                       ) AS positive_ready,
                       MAX(
                           CASE WHEN json_extract(
                               e.payload_json, '$.no_match'
                           ) = 1
                             AND json_extract(
                               e.label_provenance_json, '$.relevance'
                           ) NOT IN ('unavailable', 'unknown')
                             AND json_extract(
                               e.label_provenance_json, '$.retrieval_results'
                           ) NOT IN ('unavailable', 'unknown')
                           THEN 1 ELSE 0 END
                       ) AS no_match_ready
                  FROM imported_training_examples e
                  JOIN training_example_cleaning c USING (example_id)
                  JOIN dataset_groups g USING (group_id)
                 WHERE c.status = 'usable'
                   AND g.partition IN ('training', 'validation_anchor')
                   AND COALESCE(
                       json_extract(e.payload_json, '$.baseline_family'), 'fuzzy'
                   ) IN ('fuzzy', 'semantic')
                 GROUP BY resource_type, g.partition, e.group_id
            )
            SELECT resource_type, partition, COUNT(*) AS observed,
                   SUM(labeled), SUM(ranking_ready), SUM(positive_ready),
                   SUM(no_match_ready)
              FROM evidence
             GROUP BY resource_type, partition
             ORDER BY resource_type, partition
            """
        ).fetchall()
        readiness: dict[str, dict[str, Any]] = {}
        for row in rows:
            resource = readiness.setdefault(
                str(row[0]),
                {
                    "observed": 0,
                    "labeled": 0,
                    "ranking_ready": 0,
                    "positive_ready": 0,
                    "no_match_ready": 0,
                    "partitions": {},
                },
            )
            values = {
                "observed": int(row[2]),
                "labeled": int(row[3]),
                "ranking_ready": int(row[4]),
                "positive_ready": int(row[5]),
                "no_match_ready": int(row[6]),
            }
            resource["partitions"][str(row[1])] = values
            for key, value in values.items():
                resource[key] += value
        return readiness

    def measured_dataset_cases(
        self,
        partition: str,
        *,
        resource_type: str = "skill",
        match_mode: str = "fuzzy",
    ) -> list[dict[str, Any]]:
        with self._connect() as connection:
            return self._measured_dataset_cases(
                connection, partition, resource_type=resource_type, match_mode=match_mode
            )

    def _measured_dataset_cases(
        self,
        connection: sqlite3.Connection,
        partition: str,
        *,
        resource_type: str = "skill",
        match_mode: str = "fuzzy",
    ) -> list[dict[str, Any]]:
        if partition not in {"training", "validation_anchor"}:
            raise ValueError("measured SI uses training or fixed validation_anchor data")
        if not resource_type.strip():
            raise ValueError("resource_type is required")
        if match_mode not in {"exact", "fuzzy", "other"}:
            raise ValueError("match_mode must be exact, fuzzy, or other")
        rows = connection.execute(
                """
                SELECT e.example_id, e.group_id, e.occurred_at, e.source_json,
                       e.label_provenance_json, e.payload_json, g.partition_version
                  FROM imported_training_examples e
                  JOIN training_example_cleaning c USING (example_id)
                  JOIN dataset_groups g USING (group_id)
                 WHERE c.status = 'usable' AND c.cleaner_version = ? AND g.partition = ?
                     AND COALESCE(
                         json_extract(e.payload_json, '$.resource_type'), 'skill'
                         ) = ?
                 ORDER BY e.occurred_at, e.example_id
                """,
                (CLEANER_VERSION, partition, resource_type),
        ).fetchall()
        grouped: dict[str, dict[str, Any]] = {}
        alias_row = connection.execute(
            "SELECT value FROM runtime_settings WHERE key='evaluation_skill_aliases'"
        ).fetchone() if resource_type == "skill" else None
        aliases = json.loads(alias_row[0]) if alias_row else None
        for row in rows:
            provenance = json.loads(row[4])
            payload = json.loads(row[5])
            if _search_match_mode(payload) != match_mode:
                continue
            relevant = payload.get("relevant_resource_ids")
            if not isinstance(relevant, list):
                relevant = payload.get("relevant_skill_ids")
            ranking = payload.get("final_ranking")
            no_match = payload.get("no_match") is True
            if (
                not isinstance(relevant, list)
                or (not relevant and not no_match)
                or not isinstance(ranking, list)
                or (not ranking and not no_match)
                or provenance.get("relevance") in {None, "unavailable", "unknown"}
                or provenance.get("retrieval_results")
                in {None, "unavailable", "unknown"}
            ):
                continue
            resolution = {}
            if aliases is not None:
                normalized = [_evaluation_resource_id(item, resource_type) for item in relevant]
                if any(item not in aliases for item in normalized):
                    continue
                resolution = {item: aliases[item] for item in normalized if aliases[item] != item}
                relevant = [aliases[item] for item in normalized]
            case = grouped.setdefault(
                row[1],
                {
                    "query_id": row[1],
                    "query": str(payload.get("query") or ""),
                    "relevant_skill_ids": [],
                    "label_resolution": {},
                    "source_example_ids": [],
                    "source": json.loads(row[3]),
                    "split_group_id": payload.get("split_group_id")
                    or json.loads(row[3]).get("transcript_id") or row[1],
                    "label_provenance": provenance,
                    "partition": partition,
                    "resource_type": resource_type,
                    "partition_version": int(row[6]),
                    "query_intent": str(payload.get("query_intent") or "unknown"),
                    "baseline_family": str(payload.get("baseline_family") or "unknown"),
                    "match_mode": match_mode,
                    "baseline_ranking": [
                        _evaluation_resource_id(
                            item.get("resource_id") or item.get("skill_id"),
                            resource_type,
                        )
                        for item in ranking
                        if item.get("resource_id") or item.get("skill_id")
                    ],
                    "search_function": str(payload.get("tool_name") or "unknown"),
                },
            )
            case["source_example_ids"].append(row[0])
            case["label_resolution"].update(resolution)
            case["relevant_skill_ids"] = sorted(
                set(case["relevant_skill_ids"]) | {str(item) for item in relevant}
            )
        return [case for case in grouped.values() if case["query"]]

    def _capture_dataset_snapshot(
        self, connection: sqlite3.Connection, revision: int
    ) -> str:
        payload = {
            "schema_version": 1,
            "cleaner_version": CLEANER_VERSION,
            "training": self._measured_dataset_cases(connection, "training")[:max(0, revision)],
            "validation_anchor": self._measured_dataset_cases(connection, "validation_anchor"),
        }
        training_groups = {row["split_group_id"] for row in payload["training"]}
        validation_groups = {row["split_group_id"] for row in payload["validation_anchor"]}
        if training_groups & validation_groups:
            raise ValueError("evaluation dataset has source groups in both training and validation")
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        snapshot_id = sha256(encoded.encode("utf-8")).hexdigest()
        connection.execute(
            "INSERT OR IGNORE INTO evaluation_dataset_snapshots VALUES (?, ?)",
            (snapshot_id, encoded),
        )
        return snapshot_id

    def evaluation_dataset(
        self, task_id: str, *, require_current: bool = False
    ) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT s.snapshot_id, s.payload_json
                  FROM performance_tasks t
                  JOIN evaluation_dataset_snapshots s
                    ON s.snapshot_id = t.dataset_snapshot_id
                 WHERE t.task_id = ?
                """,
                (task_id,),
            ).fetchone()
            if row is not None and require_current and not self._snapshot_is_current(
                connection, json.loads(row[1])
            ):
                raise ValueError("snapshot data was corrected or removed; requeue the task")
        if row is None:
            raise ValueError("task has no frozen evaluation dataset; requeue legacy tasks")
        if sha256(row[1].encode("utf-8")).hexdigest() != row[0]:
            raise ValueError("evaluation dataset snapshot digest mismatch")
        return {"snapshot_id": row[0], **json.loads(row[1])}

    def _snapshot_is_current(
        self, connection: sqlite3.Connection, snapshot: Mapping[str, Any]
    ) -> bool:
        if snapshot.get("schema_version") != 1 or snapshot.get("cleaner_version") != CLEANER_VERSION:
            return False
        for partition in ("training", "validation_anchor"):
            current = {
                row["query_id"]: row
                for row in self._measured_dataset_cases(connection, partition)
            }
            if any(current.get(row["query_id"]) != row for row in snapshot[partition]):
                return False
        return True

    def pin_study_corpus(self, run_id: str, corpus_revision: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO evaluation_study_corpora VALUES (?, ?)",
                (run_id, corpus_revision),
            )
            pinned = connection.execute(
                "SELECT corpus_revision FROM evaluation_study_corpora WHERE run_id = ?",
                (run_id,),
            ).fetchone()[0]
            if pinned != corpus_revision:
                raise ValueError("tuning study corpus changed; start a new study")

    def search_function_baseline(
        self, partition: str = "validation_anchor", *, k: int = 5
    ) -> dict[str, Any]:
        task_resources = {
            "document": ("skill", "note", "paper", "knowledge"),
            "file": ("file_or_section",),
            "function": ("function_api",),
            "script": ("script",),
            "recipe": ("recipe",),
        }
        rows_by_task = {
            task: [
                row
                for resource_type in resource_types
                for row in self.measured_dataset_cases(
                    partition, resource_type=resource_type
                )
            ]
            for task, resource_types in task_resources.items()
        }
        rows = [row for task_rows in rows_by_task.values() for row in task_rows]

        def evaluate(items: list[dict[str, Any]]) -> dict[str, Any]:
            cases = [
                BenchmarkCase(
                    case_id=item["query_id"],
                    domain=item["resource_type"],
                    language="unknown",
                    query=item["query"],
                    relevant_skill_ids=frozenset(item["relevant_skill_ids"]),
                    split=partition,
                )
                for item in items
            ]
            rankings = {
                item["query_id"]: item["baseline_ranking"] for item in items
            }
            return asdict(evaluate_rankings(cases, rankings, k=k)) if cases else {}

        intents = sorted({item["query_intent"] for item in rows})
        return {
            "partition": partition,
            "k": k,
            "overall": evaluate(rows),
            "by_task": {
                task: {
                    "resource_types": list(task_resources[task]),
                    "cases": len(task_rows),
                    "metrics": evaluate(task_rows),
                }
                for task, task_rows in rows_by_task.items()
            },
            "by_query_intent": {
                intent: evaluate(
                    [item for item in rows if item["query_intent"] == intent]
                )
                for intent in intents
            },
            "cases": len(rows),
            "baseline_family": "fuzzy",
            "overall_aggregation": "macro_by_query",
            "replay_scope": "current-corpus replay; not captured historical output",
        }

    def inference_interval_status(self) -> dict[str, Any]:
        with self._connect() as connection:
            interval_row = connection.execute(
                "SELECT value FROM runtime_settings WHERE key = 'si_inference_interval'"
            ).fetchone()
            completed = connection.execute(
                """
                SELECT COALESCE(MAX(dataset_revision), 0)
                                    FROM si_inference_batches
                                 WHERE state = 'completed' AND evidence_mode = 'measured'
                """
            ).fetchone()[0]
            running = connection.execute(
                """
                SELECT dataset_revision FROM si_inference_batches
                 WHERE state = 'running' AND evidence_mode = 'measured'
                 ORDER BY dataset_revision LIMIT 1
                """
            ).fetchone()
            cleaned = self._cleaned_training_count(connection)
            current = self._labeled_training_count(connection)
            validation = self._labeled_validation_count(connection)
            readiness_by_resource = self._dataset_readiness_by_resource(connection)
            path_cursors = [
                {"architecture_id": row[0], "completed_revision": int(row[1] or 0)}
                for row in connection.execute(
                    """
                                        WITH trial_cursors AS (
                                                SELECT a.architecture_id, p.path_id,
                                                             COALESCE(MAX(CASE WHEN t.state = 'completed'
                                                                     THEN t.dataset_revision END), 0) AS revision
                                                    FROM retrieval_architecture_enrollments a
                                                    JOIN si_paths p USING (architecture_id)
                                                    LEFT JOIN performance_tasks t ON t.path_id = p.path_id
                                                 WHERE a.dataset_id = 'search-call-ground-truth-v1'
                                                     AND a.state = 'enrolled'
                                                     AND p.archived_at IS NULL
                                                 GROUP BY a.architecture_id, p.path_id
                                        )
                                        SELECT architecture_id, MIN(revision)
                                            FROM trial_cursors GROUP BY architecture_id
                                         ORDER BY architecture_id
                    """
                ).fetchall()
            ]
            attached_running = connection.execute(
                """
                SELECT MIN(t.dataset_revision)
                  FROM performance_tasks t
                                    JOIN si_paths p USING (path_id)
                                    JOIN retrieval_architecture_enrollments a USING (architecture_id)
                 WHERE a.dataset_id = 'search-call-ground-truth-v1'
                   AND a.state = 'enrolled'
                   AND t.state = 'running'
                """
            ).fetchone()[0]
            architecture_enrollments = []
            for row in connection.execute(
                """
                SELECT json_extract(
                           MIN(p.config_json), '$.retrieval_architecture_id'
                       ) AS retrieval_architecture_id,
                       a.state, a.execution_backend
                  FROM retrieval_architecture_enrollments a
                  JOIN si_paths p USING (architecture_id)
                 WHERE a.dataset_id = 'search-call-ground-truth-v1'
                   AND json_extract(
                           p.config_json, '$.retrieval_architecture_id'
                       ) IS NOT NULL
                                     AND json_extract(
                                                     p.config_json, '$.retrieval_architecture_id'
                                             ) != ''
                 GROUP BY a.architecture_id, a.state, a.execution_backend
                 ORDER BY MIN(a.enrolled_at)
                """
            ).fetchall():
                architecture_id = row[0]
                architecture_enrollments.append(
                    {
                        "architecture_id": architecture_id,
                        "state": row[1],
                        "execution_backend": row[2],
                    }
                )
        interval = max(
            1,
            int(interval_row[0]) if interval_row is not None else DEFAULT_INFERENCE_INTERVAL,
        )
        return {
            "interval": interval,
            "cleaned_training_examples": cleaned,
            "labeled_training_examples": current,
            "labeled_validation_examples": validation,
            "dataset_readiness_by_resource": readiness_by_resource,
            "last_completed_revision": (
                min(item["completed_revision"] for item in path_cursors)
                if path_cursors else int(completed)
            ),
            "running_revision": (
                int(attached_running) if attached_running is not None
                else int(running[0]) if running else None
            ),
            "next_due_revision": (
                min(item["completed_revision"] for item in path_cursors) + interval
                if path_cursors else int(completed) + interval
            ),
            "enrolled_architectures": len(path_cursors),
            "architecture_cursors": path_cursors,
            "architecture_enrollments": architecture_enrollments,
            "attached_paths": len(path_cursors),
            "path_cursors": path_cursors,
        }

    @classmethod
    def _ensure_implementation_capacity(
        cls,
        connection: sqlite3.Connection,
        config: Mapping[str, Any],
        *,
        now: str,
        maximum: int = 20,
    ) -> None:
        projected_path_id = _si_architecture_and_setting(config)[0]
        rows = connection.execute(
            """
            SELECT path_id, config_json, latest_metrics_json, last_evaluated_at
              FROM si_paths WHERE archived_at IS NULL
            """
        ).fetchall()
        matching = [
            row
            for row in rows
            if _si_architecture_and_setting(json.loads(row[1]))[0]
            == projected_path_id
        ]
        needed = len(matching) - maximum + 1
        if needed <= 0:
            return
        archived = cls._archive_ranked_implementations(
            connection, matching, count=needed, now=now, maximum=maximum
        )
        if archived < needed:
            raise ValueError(
                f"Path already has {len(matching)} active Implementations; "
                f"the limit is {maximum} and no completed slot can be archived"
            )

    def enqueue_missing_simulations(
        self,
        *,
        priority: int = 0,
        simulation_step_seconds: float = 0.5,
    ) -> list[dict[str, Any]]:
        if simulation_step_seconds < 0:
            raise ValueError("simulation_step_seconds must be non-negative")
        candidates: dict[str, dict[str, Any]] = {}
        scheduled: set[str] = set()
        for task in self.performance_tasks(limit=10_000):
            base_config = _simulation_base_config(task["config"])
            identity = json.dumps(
                base_config,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            candidates[identity] = base_config
            if task["config"].get("execution_mode") == "simulation" and (
                task["state"] in {"pending", "running"}
                or (
                    task["state"] == "completed"
                    and task["metrics"]
                    and task["metrics"].get("execution_mode") == "simulation"
                )
            ):
                scheduled.add(identity)
        return [
            self.enqueue_performance_task(
                {
                    **candidates[identity],
                    "execution_mode": "simulation",
                    "simulation_step_seconds": float(simulation_step_seconds),
                },
                priority=priority,
            )
            for identity in sorted(candidates.keys() - scheduled)
        ]

    def cancel_unassigned_performance_tasks(self) -> int:
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            task_ids = [
                row[0]
                for row in connection.execute(
                    """
                    SELECT t.task_id
                      FROM performance_tasks t JOIN si_paths p USING (path_id)
                     WHERE t.state = 'pending'
                       AND json_extract(p.config_json, '$.execution_mode') IS NULL
                    """
                ).fetchall()
            ]
            if not task_ids:
                return 0
            placeholders = ",".join("?" for _ in task_ids)
            connection.execute(
                f"""
                UPDATE performance_tasks
                   SET state = 'cancelled', finished_at = ?, updated_at = ?
                 WHERE task_id IN ({placeholders})
                """,
                (now, now, *task_ids),
            )
            connection.execute(
                f"""
                UPDATE performance_task_stages
                   SET state = 'cancelled', finished_at = ?, updated_at = ?
                 WHERE task_id IN ({placeholders}) AND state = 'pending'
                """,
                (now, now, *task_ids),
            )
            return len(task_ids)

    def enqueue_training_range(
        self,
        config: Mapping[str, Any],
        *,
        stage_key: str,
        dataset_id: str,
        dataset_revision: int,
        range_start: int,
        range_end: int,
        priority: int = 0,
    ) -> dict[str, Any]:
        if stage_key not in {"l1_document", "l2_markdown_section"}:
            raise ValueError("stage_key must identify an L1 or L2 child task")
        dataset_id = dataset_id.strip()
        if not dataset_id:
            raise ValueError("dataset_id is required")
        if dataset_revision < 0:
            raise ValueError("dataset_revision must be non-negative")
        if range_start < 0 or range_end <= range_start:
            raise ValueError("training range must be a non-empty half-open [a,b) range")
        if range_end > dataset_revision:
            raise ValueError("range_end must not exceed dataset_revision")
        path_id, _, setting_id, _ = _si_architecture_and_setting(config)
        task_id = str(uuid.uuid4())
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                INSERT OR IGNORE INTO implementation_training_cursors (
                    stage_key, path_id, setting_id, dataset_id, dataset_revision,
                    next_index, updated_at
                ) VALUES (?, ?, ?, ?, ?, 0, ?)
                """,
                (stage_key, path_id, setting_id, dataset_id, dataset_revision, now),
            )
            cursor = connection.execute(
                """
                SELECT dataset_revision, next_index, checkpoint_id
                  FROM implementation_training_cursors
                 WHERE stage_key = ? AND path_id = ? AND setting_id = ?
                   AND dataset_id = ?
                """,
                (stage_key, path_id, setting_id, dataset_id),
            ).fetchone()
            if range_start != cursor[1]:
                raise ValueError(
                    f"range_start must equal the Implementation cursor {cursor[1]}"
                )
            if dataset_revision < cursor[0]:
                raise ValueError("dataset_revision must not move backwards")
            active = connection.execute(
                """
                SELECT task_id FROM training_tasks
                 WHERE stage_key = ? AND path_id = ? AND setting_id = ?
                   AND dataset_id = ? AND state IN ('pending', 'running')
                 LIMIT 1
                """,
                (stage_key, path_id, setting_id, dataset_id),
            ).fetchone()
            if active is not None:
                return self._training_task(connection, active[0])
            try:
                connection.execute(
                    """
                    INSERT INTO training_tasks (
                        task_id, stage_key, path_id, setting_id, dataset_id,
                        dataset_revision, range_start, range_end,
                        input_checkpoint_id, state, priority, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
                    """,
                    (
                        task_id, stage_key, path_id, setting_id, dataset_id,
                        int(dataset_revision), int(range_start), int(range_end),
                        cursor[2], int(priority), now, now,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise ValueError("training range already exists") from error
            return self._training_task(connection, task_id)

    def training_tasks(self, *, limit: int = 1000) -> list[dict[str, Any]]:
        with self._connect() as connection:
            task_ids = connection.execute(
                """
                SELECT task_id FROM training_tasks
                 ORDER BY CASE state
                            WHEN 'running' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
                          priority DESC, created_at ASC
                 LIMIT ?
                """,
                (max(1, min(int(limit), 10_000)),),
            ).fetchall()
            return [self._training_task(connection, row[0]) for row in task_ids]

    def claim_training_task(self, worker_id: str) -> dict[str, Any] | None:
        worker_id = worker_id.strip()
        if not worker_id:
            raise ValueError("worker_id is required")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT task_id FROM training_tasks WHERE state = 'pending'
                 ORDER BY priority DESC, created_at ASC LIMIT 1
                """
            ).fetchone()
            if row is None:
                return None
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """
                UPDATE training_tasks
                   SET state = 'running', worker_id = ?, started_at = ?, updated_at = ?
                 WHERE task_id = ? AND state = 'pending'
                """,
                (worker_id, now, now, row[0]),
            )
            return self._training_task(connection, row[0])

    def finish_training_task(
        self, task_id: str, *, output_checkpoint_id: str
    ) -> dict[str, Any]:
        output_checkpoint_id = output_checkpoint_id.strip()
        if not output_checkpoint_id:
            raise ValueError("output_checkpoint_id is required")
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            task = self._training_task(connection, task_id)
            if task["state"] != "running":
                raise ValueError("only a running training task can be completed")
            cursor = connection.execute(
                """
                SELECT next_index, checkpoint_id, completed_updates
                  FROM implementation_training_cursors
                 WHERE stage_key = ? AND path_id = ? AND setting_id = ?
                   AND dataset_id = ?
                """,
                (
                    task["stage_key"], task["path_id"], task["setting_id"],
                    task["dataset_id"],
                ),
            ).fetchone()
            if cursor[0] != task["range_start"] or cursor[1] != task["input_checkpoint_id"]:
                raise ValueError("training task no longer matches its Implementation cursor")
            completed_updates = cursor[2] + 1
            connection.execute(
                """
                UPDATE implementation_training_cursors
                   SET dataset_revision = ?, next_index = ?, checkpoint_id = ?,
                       completed_updates = ?, updated_at = ?
                 WHERE stage_key = ? AND path_id = ? AND setting_id = ?
                   AND dataset_id = ?
                """,
                (
                    task["dataset_revision"], task["range_end"], output_checkpoint_id,
                    completed_updates, now, task["stage_key"], task["path_id"],
                    task["setting_id"], task["dataset_id"],
                ),
            )
            connection.execute(
                """
                UPDATE training_tasks
                   SET state = 'completed', output_checkpoint_id = ?,
                       finished_at = ?, updated_at = ?
                 WHERE task_id = ?
                """,
                (output_checkpoint_id, now, now, task_id),
            )
            result = self._training_task(connection, task_id)
            result["evaluation_due"] = completed_updates % self._evaluation_period(
                connection
            ) == 0
            return result

    @staticmethod
    def _evaluation_period(connection: sqlite3.Connection) -> int:
        row = connection.execute(
            "SELECT value FROM runtime_settings WHERE key = 'training_evaluation_period'"
        ).fetchone()
        return max(1, int(row[0])) if row is not None else 10

    @staticmethod
    def _training_task(
        connection: sqlite3.Connection, task_id: str
    ) -> dict[str, Any]:
        row = connection.execute(
            """
            SELECT task_id, stage_key, path_id, setting_id, dataset_id,
                   dataset_revision, range_start, range_end, input_checkpoint_id,
                   output_checkpoint_id, state, priority, worker_id, error,
                   created_at, started_at, finished_at, updated_at
              FROM training_tasks WHERE task_id = ?
            """,
            (task_id,),
        ).fetchone()
        if row is None:
            raise LookupError(f"unknown training task: {task_id}")
        return {
            "task_id": row[0], "stage_key": row[1], "path_id": row[2],
            "setting_id": row[3], "dataset_id": row[4],
            "dataset_revision": row[5], "range_start": row[6],
            "range_end": row[7], "input_checkpoint_id": row[8],
            "output_checkpoint_id": row[9], "state": row[10],
            "priority": row[11], "worker_id": row[12], "error": row[13],
            "created_at": row[14], "started_at": row[15],
            "finished_at": row[16], "updated_at": row[17],
        }

    def executor_settings(self) -> dict[str, Any]:
        maximum = max(1, os.cpu_count() or 1)
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT key, value, updated_at FROM runtime_settings
                 WHERE key IN ('executor_processes', 'executor_enabled')
                """
            ).fetchall()
        settings = {row[0]: row for row in rows}
        process_row = settings.get("executor_processes")
        enabled_row = settings.get("executor_enabled")
        processes = int(process_row[1]) if process_row is not None else 1
        return {
            "processes": processes,
            "enabled": enabled_row is None or enabled_row[1] == "1",
            "maximum_processes": maximum,
            "updated_at": max(
                (row[2] for row in rows),
                default=None,
            ),
        }

    def update_executor_processes(self, processes: int) -> dict[str, Any]:
        maximum = max(1, os.cpu_count() or 1)
        if processes < 1 or processes > maximum:
            raise ValueError(f"processes must be between 1 and {maximum}")
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO runtime_settings (key, value, updated_at)
                VALUES ('executor_processes', ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    updated_at = excluded.updated_at
                """,
                (str(int(processes)), now),
            )
        return self.executor_settings()

    def update_executor_enabled(self, enabled: bool) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO runtime_settings (key, value, updated_at)
                VALUES ('executor_enabled', ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    updated_at = excluded.updated_at
                """,
                ("1" if enabled else "0", now),
            )
        return self.executor_settings()

    def bayesian_search_settings(self) -> dict[str, Any]:
        defaults = {
            "strategy": "bfs",
            "cpu_workers": min(12, max(1, os.cpu_count() or 1)),
            "max_iterations_per_path": 40,
            "metric": "recall_at_k",
            "early_stop_patience": 8,
            "minimum_improvement": 0.001,
        }
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT key, value FROM runtime_settings WHERE key LIKE 'bayesian_%'"
            ).fetchall()
        stored = {row[0]: row[1] for row in rows}
        return {
            "strategy": stored.get("bayesian_strategy", defaults["strategy"]),
            "cpu_workers": int(
                stored.get("bayesian_cpu_workers", defaults["cpu_workers"])
            ),
            "max_iterations_per_path": int(
                stored.get(
                    "bayesian_max_iterations_per_path",
                    defaults["max_iterations_per_path"],
                )
            ),
            "metric": stored.get("bayesian_metric", defaults["metric"]),
            "early_stop_patience": int(
                stored.get(
                    "bayesian_early_stop_patience",
                    defaults["early_stop_patience"],
                )
            ),
            "minimum_improvement": float(
                stored.get(
                    "bayesian_minimum_improvement",
                    defaults["minimum_improvement"],
                )
            ),
            "search_space": MEASURED_L1_SEARCH_SPACE,
        }

    def update_bayesian_search_settings(
        self, settings: Mapping[str, Any]
    ) -> dict[str, Any]:
        current = self.bayesian_search_settings()
        updated = {**current, **dict(settings)}
        if updated["strategy"] not in {"bfs", "dfs"}:
            raise ValueError("strategy must be bfs or dfs")
        maximum_cpus = max(1, os.cpu_count() or 1)
        workers = int(updated["cpu_workers"])
        if workers < 1 or workers > maximum_cpus:
            raise ValueError(f"cpu_workers must be between 1 and {maximum_cpus}")
        iterations = int(updated["max_iterations_per_path"])
        if iterations < 1 or iterations > len(candidate_configs({}, MEASURED_L1_SEARCH_SPACE)):
            raise ValueError("max_iterations_per_path exceeds the measured search space")
        patience = int(updated["early_stop_patience"])
        if "early_stop_patience" not in settings:
            patience = min(patience, iterations)
        if patience < 1 or patience > iterations:
            raise ValueError("early_stop_patience must be within the iteration budget")
        minimum_improvement = float(updated["minimum_improvement"])
        if minimum_improvement < 0:
            raise ValueError("minimum_improvement must be non-negative")
        if updated["metric"] not in {"recall_at_k", "mrr", "ndcg_at_k", "top1_accuracy"}:
            raise ValueError("unsupported Bayesian optimization metric")
        values = {
            "bayesian_strategy": updated["strategy"],
            "bayesian_cpu_workers": str(workers),
            "bayesian_max_iterations_per_path": str(iterations),
            "bayesian_metric": updated["metric"],
            "bayesian_early_stop_patience": str(patience),
            "bayesian_minimum_improvement": str(minimum_improvement),
        }
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.executemany(
                """
                INSERT INTO runtime_settings (key, value, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value, updated_at = excluded.updated_at
                """,
                [(key, value, now) for key, value in values.items()],
            )
        return self.bayesian_search_settings()

    def register_bm25_baseline(
        self, metrics: Mapping[str, Any], *, dataset_version: str = "benchmark"
    ) -> dict[str, Any]:
        if not metrics:
            raise ValueError("BM25 baseline metrics must not be empty")
        config = {
            "model": "BM25",
            "search_method": "lexical search",
            "feature_selector": "none",
            "retrieval": "BM25",
            "retrieval_hierarchy": ["document"],
            "scoring_method": "BM25 score",
            "calibration_method": "none",
            "dataset_version": dataset_version,
            "search_strategy": "baseline",
            "execution_mode": "benchmark_baseline",
        }
        config_json = json.dumps(
            config, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
        path_id = f"path-{sha256(config_json.encode('utf-8')).hexdigest()[:16]}"
        task_id = f"baseline-{path_id}"
        now = datetime.now(UTC).isoformat()
        metrics_json = json.dumps(dict(metrics), ensure_ascii=False, sort_keys=True)
        with self._connect() as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO si_paths (
                    path_id, config_json, latest_metrics_json, last_evaluated_at,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (path_id, config_json, metrics_json, now, now, now),
            )
            connection.execute(
                """
                INSERT OR IGNORE INTO performance_tasks (
                    task_id, path_id, state, metrics_json, created_at,
                    started_at, finished_at, updated_at
                ) VALUES (?, ?, 'completed', ?, ?, ?, ?, ?)
                """,
                (task_id, path_id, metrics_json, now, now, now, now),
            )
            _ensure_performance_stages(connection, task_id, config)
            connection.execute(
                """
                UPDATE performance_task_stages
                   SET state = 'completed', metrics_json = ?, started_at = ?,
                       finished_at = ?, updated_at = ? WHERE task_id = ?
                """,
                (metrics_json, now, now, now, task_id),
            )
            connection.execute(
                """
                INSERT OR REPLACE INTO performance_checkpoints
                    (task_id, examples_seen, metrics_json, recorded_at)
                VALUES (?, 0, ?, ?)
                """,
                (task_id, metrics_json, now),
            )
            connection.execute(
                """
                INSERT OR REPLACE INTO performance_stage_checkpoints
                    (task_id, stage_key, examples_seen, metrics_json, recorded_at)
                VALUES (?, 'l1_document', 0, ?, ?)
                """,
                (task_id, metrics_json, now),
            )
            return self._performance_task(connection, task_id)

    @staticmethod
    def measured_path_blocker(config: Mapping[str, Any]) -> str | None:
        if not CollectorStore._measured_path_supported(config):
            return "unsupported measured execution path"
        if config.get("preflight_error"):
            return str(config["preflight_error"])
        architecture_id = config.get("retrieval_architecture_id")
        if architecture_id and architecture_id not in {"bm25-document", "hybrid-exact-bm25-document"}:
            if config.get("embedding_enabled") is not True:
                return "embedding requires an explicitly enabled, validated local bundle"
            architecture = architecture_by_id(str(architecture_id))
            keys = ["model"]
            if "cross_encoder_section" in architecture.operators:
                keys.append("reranker_model")
            for key in keys:
                if not config.get(key) or not Path(str(config[key])).is_dir() or not config.get(f"{key}_bundle_sha256"):
                    return f"{key} requires a pinned local bundle"
        return None

    def ensure_automatic_tuning(self) -> list[dict[str, Any]]:
        if self.pkm_root is None:
            raise ValueError("automatic tuning requires a corpus root")
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO runtime_settings (key,value,updated_at)
                   VALUES ('automatic_bayesian_enabled','true',?)
                   ON CONFLICT(key) DO UPDATE SET value='true',updated_at=excluded.updated_at
                   WHERE value != 'true'""",
                (datetime.now(UTC).isoformat(),),
            )
        documents, _ = load_pkm_skills(self.pkm_root)
        aliases = {d.version.skill_id: d.version.skill_id for d in documents}
        titles: dict[str, list[str]] = {}
        for document in documents:
            titles.setdefault(document.title, []).append(document.version.skill_id)
        for title, ids in titles.items():
            if len(ids) == 1:
                aliases.setdefault(title, ids[0])
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO runtime_settings(key,value,updated_at)
                   VALUES ('evaluation_skill_aliases',?,?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at
                   WHERE value != excluded.value""",
                (json.dumps(aliases, sort_keys=True), datetime.now(UTC).isoformat()),
            )
        corpus_key = sha256(json.dumps(sorted(
            (d.version.skill_id, d.version.content_hash, d.content_type.value, d.source_uri, d.read_only)
            for d in documents
        )).encode()).hexdigest()
        self.materialize_dataset_versions(corpus_key)
        settings = self.bayesian_search_settings()
        with self._connect() as connection:
            interval = int(connection.execute(
                "SELECT value FROM runtime_settings WHERE key = 'si_inference_interval'"
            ).fetchone()[0])
            revision = self._labeled_training_count(connection) // interval * interval
            if not documents or revision < interval or not self._labeled_validation_count(connection):
                return []
            snapshot_id = self._capture_dataset_snapshot(connection, revision)
            configs = connection.execute(
                """SELECT DISTINCT p.config_json FROM si_paths p
                   JOIN retrieval_architecture_enrollments a USING (architecture_id)
                   WHERE p.archived_at IS NULL AND a.state = 'enrolled'
                     AND a.dataset_id = 'search-call-ground-truth-v1'
                     AND json_extract(p.config_json, '$.tuning_run_id') IS NULL"""
            ).fetchall()
        created = []
        blocked = []
        for row in configs:
            config = json.loads(row[0])
            reason = self.measured_path_blocker(config)
            if reason:
                blocked.append({"architecture_id": config.get("retrieval_architecture_id"), "reason": reason})
                continue
            config_key = sha256(row[0].encode()).hexdigest()
            config.update({
                "automatic_config_key": config_key,
                "automatic_dataset_snapshot_id": snapshot_id,
                "automatic_dataset_revision": revision,
                "automatic_corpus_key": corpus_key,
            })
            config["automatic_study_key"] = sha256(
                json.dumps(config, sort_keys=True).encode()
            ).hexdigest()
            with self._connect() as connection:
                exists = connection.execute(
                    """SELECT 1 FROM bayesian_tuning_runs
                       WHERE json_extract(base_config_json, '$.automatic_study_key') = ?
                          OR (state = 'running' AND
                              json_extract(base_config_json, '$.automatic_config_key') = ?)""",
                    (config["automatic_study_key"], config_key),
                ).fetchone()
            if exists is None:
                created.append(self.start_bayesian_tuning(
                    config, max_iterations=int(settings["max_iterations_per_path"]),
                    metric=str(settings["metric"]),
                ))
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO runtime_settings (key, value, updated_at)
                   VALUES ('automatic_blocked_configs', ?, ?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                (json.dumps(blocked), datetime.now(UTC).isoformat()),
            )
        return created

    def recover_expired_performance_tasks(self, *, timeout_seconds: int = 120) -> int:
        if timeout_seconds < 30:
            raise ValueError("task heartbeat timeout must be at least 30 seconds")
        now = datetime.now(UTC)
        cutoff = (now - timedelta(seconds=timeout_seconds)).isoformat()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT t.task_id,t.dataset_revision,t.dataset_snapshot_id,t.priority,p.config_json
                   FROM performance_tasks t JOIN si_paths p USING(path_id)
                   WHERE t.state='running' AND t.updated_at < ?""",
                (cutoff,),
            ).fetchall()
            for task_id, *_ in rows:
                connection.execute(
                    """UPDATE performance_tasks SET state='cancelled', error='worker heartbeat expired',
                       finished_at=?, updated_at=? WHERE task_id=?""",
                    (now.isoformat(), now.isoformat(), task_id),
                )
                connection.execute(
                    """UPDATE performance_task_stages SET state='cancelled', finished_at=?, updated_at=?
                       WHERE task_id=? AND state IN ('pending','running')""",
                    (now.isoformat(), now.isoformat(), task_id),
                )
        for task_id, revision, snapshot_id, priority, config_json in rows:
            config = json.loads(config_json)
            if not snapshot_id or not config.get("automatic_study_key") or config.get("worker_recovery_attempt"):
                continue
            try:
                replacement = self.enqueue_performance_task(
                    {**config, "worker_recovery_attempt": 1},
                    priority=priority, dataset_revision=revision,
                    dataset_snapshot_id=snapshot_id, trigger_kind="bayesian_tuning",
                )
            except (ValueError, LookupError) as error:
                logging.getLogger(__name__).warning("Cannot recover expired task %s: %s", task_id, error)
                continue
            with self._connect() as connection:
                connection.execute(
                    """UPDATE bayesian_tuning_observations SET task_id=?,state='pending',updated_at=?
                       WHERE task_id=?""",
                    (replacement["task_id"], now.isoformat(), task_id),
                )
        return len(rows)

    def materialize_dataset_versions(self, corpus_key: str) -> int:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            stamp = connection.execute(
                """SELECT COUNT(*), MAX(imported_at),
                   (SELECT MAX(cleaned_at) FROM training_example_cleaning),
                   (SELECT evaluation_version FROM dataset_partition_state WHERE singleton=1)
                   FROM imported_training_examples"""
            ).fetchone()
            revision = sha256(json.dumps([*stamp, corpus_key, CLEANER_VERSION]).encode()).hexdigest()
            previous = connection.execute(
                "SELECT value FROM runtime_settings WHERE key='dataset_materialization_revision'"
            ).fetchone()
            if previous and previous[0] == revision:
                return 0
            alias_row = connection.execute(
                "SELECT value FROM runtime_settings WHERE key='evaluation_skill_aliases'"
            ).fetchone()
            aliases = json.loads(alias_row[0]) if alias_row else {}
            families: dict[str, list[dict[str, Any]]] = {}
            for row in connection.execute(
                """SELECT e.example_id,e.group_id,e.source_json,e.label_provenance_json,
                          e.payload_json,g.partition
                   FROM imported_training_examples e
                   JOIN training_example_cleaning c USING(example_id)
                   JOIN dataset_groups g USING(group_id)
                   WHERE c.status='usable' AND c.cleaner_version=?
                   ORDER BY e.occurred_at,e.example_id""", (CLEANER_VERSION,)
            ).fetchall():
                source, provenance, payload = (json.loads(value) for value in row[2:5])
                relevant = payload.get("relevant_resource_ids")
                if not isinstance(relevant, list):
                    relevant = payload.get("relevant_skill_ids")
                no_match = payload.get("no_match") is True
                if not isinstance(relevant, list) or (not relevant and not no_match) or provenance.get("relevance") in {None, "unknown", "unavailable"}:
                    continue
                resource_type = str(payload.get("resource_type") or "skill")
                resolved = {}
                if resource_type == "skill":
                    normalized = [_evaluation_resource_id(value, resource_type) for value in relevant]
                    if not all(value in aliases for value in normalized):
                        continue
                    resolved = {value: aliases[value] for value in normalized}
                    relevant = list(dict.fromkeys(resolved.values()))
                family = f"{resource_type}/{_search_match_mode(payload)}"
                record = {
                    "schema": 1, "example_id": row[0], "group_id": row[1],
                    "split_group_id": payload.get("split_group_id") or source.get("transcript_id") or row[1],
                    "partition": row[5], "query": payload["query"],
                    "resource_type": resource_type, "relevant_resource_ids": relevant,
                    "no_match": no_match,
                    "label_resolution": resolved, "source": source, "label_provenance": provenance,
                    "tool_arguments": payload.get("tool_arguments", {}),
                    "consumption_evidence": payload.get("consumption_evidence", []),
                    "ranking": payload.get("final_ranking", []),
                }
                encoded = json.dumps(record, ensure_ascii=False, sort_keys=True)
                example_version = sha256(encoded.encode()).hexdigest()
                connection.execute(
                    "INSERT OR IGNORE INTO dataset_example_versions VALUES (?,?,?)",
                    (example_version, row[0], encoded),
                )
                families.setdefault(family, []).append({
                    "example_version": example_version, "group_id": row[1],
                    "split_group_id": record["split_group_id"], "partition": row[5],
                })
            created = 0
            now = datetime.now(UTC).isoformat()
            for (family,) in connection.execute("SELECT DISTINCT family FROM dataset_versions"):
                families.setdefault(family, [])
            for family, examples in families.items():
                partitions = dict(Counter(item["partition"] for item in examples))
                supported = family == "skill/fuzzy"
                manifest = {
                    "schema": 1, "family": family, "cleaner_version": CLEANER_VERSION,
                    "label_policy": "observed-positive-labels; unknown is not negative",
                    "corpus_key": corpus_key if family.startswith("skill/") else None,
                    "example_count": len(examples),
                    "query_group_count": len({item["group_id"] for item in examples}),
                    "source_group_count": len({item["split_group_id"] for item in examples}),
                    "partitions": partitions, "examples": examples,
                    "has_training_and_validation": bool(
                        partitions.get("training") and partitions.get("validation_anchor")
                    ),
                    "executor_supported": supported,
                    "blocked_reason": None if supported else "requires a matching corpus/executor contract",
                }
                encoded = json.dumps(manifest, ensure_ascii=False, sort_keys=True)
                version_id = sha256(encoded.encode()).hexdigest()
                created += connection.execute(
                    "INSERT OR IGNORE INTO dataset_versions VALUES (?,?,?,?)",
                    (version_id, family, encoded, now),
                ).rowcount
            connection.execute(
                """INSERT INTO runtime_settings(key,value,updated_at)
                   VALUES ('dataset_materialization_revision',?,?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
                (revision, now),
            )
        return created

    def dataset_versions(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """SELECT version_id,manifest_json,created_at FROM dataset_versions
                   ORDER BY created_at DESC,rowid DESC LIMIT 100"""
            ).fetchall()
        return [
            {
                **{key: value for key, value in json.loads(row[1]).items() if key != "examples"},
                "version_id": row[0], "created_at": row[2],
            }
            for row in rows
        ]

    def automatic_tuning_status(self) -> dict[str, Any]:
        with self._connect() as connection:
            settings = dict(connection.execute(
                "SELECT key,value FROM runtime_settings WHERE key LIKE 'automatic_%'"
            ).fetchall())
        return {
            "enabled": settings.get("automatic_bayesian_enabled") == "true",
            "blocked": json.loads(settings.get("automatic_blocked_configs", "[]")),
        }

    def fail_running_performance_task(self, task_id: str, error: str) -> None:
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """UPDATE performance_tasks SET state='failed',error=?,finished_at=?,updated_at=?
                   WHERE task_id=? AND state='running'""",
                (error, now, now, task_id),
            )
            connection.execute(
                """UPDATE performance_task_stages SET state='failed',error=?,finished_at=?,updated_at=?
                   WHERE task_id=? AND state IN ('pending','running')
                     AND EXISTS (SELECT 1 FROM performance_tasks t
                                 WHERE t.task_id=? AND t.state='failed')""",
                (error, now, now, task_id, task_id),
            )

    def start_bayesian_tuning(
        self,
        base_config: Mapping[str, Any],
        *,
        max_iterations: int = 40,
        metric: str = "recall_at_k",
        priority: int = 0,
    ) -> dict[str, Any]:
        if max_iterations < 1 or max_iterations > 40:
            raise ValueError("max_iterations must be between 1 and 40")
        if not base_config:
            raise ValueError("base_config must not be empty")
        if not self._measured_path_supported(base_config):
            raise ValueError("Bayesian tuning requires a supported measured path")
        normalized_config = {
            **dict(base_config),
            "engine_profile": "l1_online",
            "execution_mode": "measured",
        }
        architecture_id = normalized_config.get("retrieval_architecture_id")
        search_space = (
            dict(architecture_by_id(str(architecture_id)).hyperparameter_space)
            if architecture_id else MEASURED_L1_SEARCH_SPACE
        )
        if architecture_id:
            for key in ("model", "reranker_model"):
                if key in search_space:
                    if normalized_config.get("embedding_enabled") is not True or not normalized_config.get(f"{key}_bundle_sha256"):
                        raise ValueError("embedding tuning requires explicitly enabled pinned local bundles")
                    search_space[key] = (normalized_config[key],)
        canonical_base = json.dumps(
            normalized_config, ensure_ascii=False, sort_keys=True
        )
        with self._connect() as connection:
            existing = connection.execute(
                """
                SELECT run_id FROM bayesian_tuning_runs
                 WHERE (state = 'running' OR
                        json_extract(base_config_json, '$.automatic_study_key') IS NOT NULL)
                   AND base_config_json = ?
                 ORDER BY created_at LIMIT 1
                """,
                (canonical_base,),
            ).fetchone()
        if existing is not None:
            return next(
                run
                for run in self.bayesian_tuning_runs()
                if run["run_id"] == existing[0]
            )
        run_id = f"tuning-{uuid.uuid4()}"
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO bayesian_tuning_runs (
                    run_id, state, base_config_json, search_space_json, metric,
                    max_iterations, priority, created_at, updated_at
                ) VALUES (?, 'running', ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    canonical_base,
                    json.dumps(
                        search_space,
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    metric,
                    max_iterations,
                    int(priority),
                    now,
                    now,
                ),
            )
        return next(
            run for run in self.bayesian_tuning_runs() if run["run_id"] == run_id
        )

    def bayesian_tuning_runs(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT run_id, state, metric, max_iterations, best_score,
                       best_config_json, last_error, created_at, updated_at,
                       (SELECT COUNT(*) FROM bayesian_tuning_observations o
                         WHERE o.run_id = r.run_id)
                  FROM bayesian_tuning_runs r ORDER BY created_at DESC
                """
            ).fetchall()
        return [
            {
                "run_id": row[0], "state": row[1], "metric": row[2],
                "max_iterations": row[3], "best_score": row[4],
                "best_config": json.loads(row[5]) if row[5] else None,
                "last_error": row[6], "created_at": row[7],
                "updated_at": row[8], "iterations": row[9],
            }
            for row in rows
        ]

    def advance_bayesian_tuning(
        self, run_id: str | None = None, *, strategy: str | None = None
    ) -> list[dict[str, Any]]:
        settings = self.bayesian_search_settings()
        selected_strategy = strategy or settings["strategy"]
        if selected_strategy not in {"bfs", "dfs"}:
            raise ValueError("Bayesian traversal strategy must be bfs or dfs")
        with self._connect() as connection:
            runs = connection.execute(
                """
                SELECT run_id, base_config_json, search_space_json, metric,
                       max_iterations, priority
                  FROM bayesian_tuning_runs
                 WHERE state = 'running' AND (? IS NULL OR run_id = ?)
                 ORDER BY CASE WHEN ? = 'bfs' THEN
                    (SELECT COUNT(*) FROM bayesian_tuning_observations o
                     WHERE o.run_id = bayesian_tuning_runs.run_id)
                    ELSE 0 END, created_at
                """,
                (run_id, run_id, selected_strategy),
            ).fetchall()
            active = int(
                connection.execute(
                    """
                    SELECT COUNT(*) FROM performance_tasks
                     WHERE state IN ('pending', 'running')
                       AND trigger_kind = 'bayesian_tuning'
                    """
                ).fetchone()[0]
            )
        slots = max(0, int(settings["cpu_workers"]) - active)
        if slots == 0:
            return []
        scheduled = []
        for run in runs:
            task = self._advance_bayesian_run(*run)
            if task is not None:
                scheduled.append(task)
                slots -= 1
            if slots <= 0 or selected_strategy == "dfs":
                break
        return scheduled

    def _advance_bayesian_run(
        self,
        run_id: str,
        base_json: str,
        space_json: str,
        metric: str,
        max_iterations: int,
        priority: int,
    ) -> dict[str, Any] | None:
        now = datetime.now(UTC).isoformat()
        search_settings = self.bayesian_search_settings()
        with self._connect() as connection:
            observations = connection.execute(
                """
                  SELECT o.iteration, o.task_id, o.config_json, o.state,
                      t.state, t.metrics_json, t.dataset_revision, t.dataset_snapshot_id
                  FROM bayesian_tuning_observations o
                  JOIN performance_tasks t USING (task_id)
                 WHERE o.run_id = ? ORDER BY o.iteration
                """,
                (run_id,),
            ).fetchall()
            base_config = json.loads(base_json)
            pinned_revision = observations[0][6] if observations else base_config.get("automatic_dataset_revision")
            pinned_snapshot = observations[0][7] if observations else base_config.get("automatic_dataset_snapshot_id")
            if observations and (
                pinned_snapshot is None
                or any((item[6], item[7]) != (pinned_revision, pinned_snapshot) for item in observations)
            ):
                connection.execute(
                    """UPDATE bayesian_tuning_runs
                          SET state = 'cancelled', best_score = NULL,
                              best_config_json = NULL, last_error = ?, updated_at = ?
                        WHERE run_id = ?""",
                    ("incompatible evaluation snapshots; start a new study", now, run_id),
                )
                return None
            if pinned_snapshot is not None:
                frozen = json.loads(connection.execute(
                    "SELECT payload_json FROM evaluation_dataset_snapshots WHERE snapshot_id = ?",
                    (pinned_snapshot,),
                ).fetchone()[0])
                if not self._snapshot_is_current(connection, frozen):
                    connection.execute(
                        """UPDATE bayesian_tuning_runs
                              SET state = 'cancelled', best_score = NULL,
                                  best_config_json = NULL, last_error = ?, updated_at = ?
                            WHERE run_id = ?""",
                        ("frozen dataset labels or membership changed; start a new study", now, run_id),
                    )
                    return None
            for item in observations:
                if item[4] == "completed" and item[3] != "completed":
                    metrics = json.loads(item[5]) if item[5] else {}
                    connection.execute(
                        """
                        UPDATE bayesian_tuning_observations
                           SET state = 'completed', score = ?, updated_at = ?
                         WHERE run_id = ? AND iteration = ?
                        """,
                        (metrics.get(metric), now, run_id, item[0]),
                    )
                elif item[4] in {"failed", "cancelled"}:
                    connection.execute(
                        """
                        UPDATE bayesian_tuning_observations
                           SET state = ?, updated_at = ?
                         WHERE run_id = ? AND iteration = ?
                        """,
                        (item[4], now, run_id, item[0]),
                    )
            observations = connection.execute(
                """
                SELECT iteration, task_id, config_json, state, score
                  FROM bayesian_tuning_observations
                 WHERE run_id = ? ORDER BY iteration
                """,
                (run_id,),
            ).fetchall()
            if base_config.get("automatic_study_key") and any(
                item[3] in {"failed", "cancelled"} for item in observations
            ):
                connection.execute(
                    """UPDATE bayesian_tuning_runs SET state='failed',
                       last_error='trial failed or lost its worker; inspect task before retrying',
                       updated_at=? WHERE run_id=?""",
                    (now, run_id),
                )
                return None
            scored = [item for item in observations if item[4] is not None]
            best = max(scored, key=lambda item: item[4]) if scored else None
            connection.execute(
                """
                UPDATE bayesian_tuning_runs
                   SET best_score = ?, best_config_json = ?, last_error = NULL,
                       updated_at = ? WHERE run_id = ?
                """,
                (best[4] if best else None, best[2] if best else None, now, run_id),
            )
            if any(item[3] in {"pending", "running"} for item in observations):
                return None
            patience = int(search_settings["early_stop_patience"])
            minimum_improvement = float(search_settings["minimum_improvement"])
            scores = [float(item[4]) for item in scored]
            if _bayesian_should_stop(scores, patience, minimum_improvement):
                    connection.execute(
                        """
                        UPDATE bayesian_tuning_runs
                           SET state = 'completed', updated_at = ? WHERE run_id = ?
                        """,
                        (now, run_id),
                    )
                    return None
            if len(observations) >= max_iterations:
                connection.execute(
                    """
                    UPDATE bayesian_tuning_runs
                       SET state = 'completed', updated_at = ? WHERE run_id = ?
                    """,
                    (now, run_id),
                )
                return None
            interval = max(
                1,
                int(
                    connection.execute(
                        "SELECT value FROM runtime_settings WHERE key = 'si_inference_interval'"
                    ).fetchone()[0]
                ),
            )
            labeled_training = self._labeled_training_count(connection)
            labeled_validation = self._labeled_validation_count(connection)
            dataset_revision = (labeled_training // interval) * interval
            if pinned_snapshot is not None:
                dataset_revision = int(pinned_revision)
                dataset_snapshot_id = pinned_snapshot
            else:
                if dataset_revision < interval or labeled_validation == 0:
                    return None
                dataset_snapshot_id = self._capture_dataset_snapshot(connection, dataset_revision)
        space = json.loads(space_json)
        candidates = candidate_configs(json.loads(base_json), space)
        used = {item[2] for item in observations}
        remaining = [
            candidate
            for candidate in candidates
            if json.dumps(candidate, ensure_ascii=False, sort_keys=True) not in used
        ]
        if not remaining:
            with self._connect() as connection:
                connection.execute(
                    """
                    UPDATE bayesian_tuning_runs
                       SET state = 'completed', updated_at = ? WHERE run_id = ?
                    """,
                    (now, run_id),
                )
            return None
        proposal = select_expected_improvement(
            remaining,
            [(json.loads(item[2]), float(item[4])) for item in scored],
            space,
        )
        iteration = len(observations) + 1
        task_config = {
            **proposal,
            "search_strategy": "bayesian",
            "tuning_run_id": run_id,
            "tuning_iteration": iteration,
            "execution_mode": "measured",
        }
        try:
            task = self.enqueue_performance_task(
                task_config,
                priority=priority,
                dataset_revision=dataset_revision,
                trigger_kind="bayesian_tuning",
                dataset_snapshot_id=dataset_snapshot_id,
            )
        except ValueError as error:
            with self._connect() as connection:
                connection.execute(
                    """
                    UPDATE bayesian_tuning_runs
                       SET last_error = ?, updated_at = ? WHERE run_id = ?
                    """,
                    (str(error), now, run_id),
                )
            return None
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO bayesian_tuning_observations (
                    run_id, iteration, task_id, config_json, state,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, 'pending', ?, ?)
                """,
                (
                    run_id,
                    iteration,
                    task["task_id"],
                    json.dumps(proposal, ensure_ascii=False, sort_keys=True),
                    now,
                    now,
                ),
            )
            return task

    def performance_tasks(
        self, *, limit: int = 1000, execution_mode: str | None = None
    ) -> list[dict[str, Any]]:
        with self._connect() as connection:
            task_ids = connection.execute(
                """
                SELECT t.task_id FROM performance_tasks t
                  JOIN si_paths p USING (path_id)
                 WHERE (? IS NULL OR json_extract(p.config_json, '$.execution_mode') = ?)
                 ORDER BY CASE t.state
                            WHEN 'running' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
                          t.priority DESC, t.created_at ASC
                 LIMIT ?
                """,
                (execution_mode, execution_mode, max(1, min(int(limit), 10_000))),
            ).fetchall()
            return [self._performance_task(connection, row[0]) for row in task_ids]

    def reset_si_results(self) -> dict[str, int]:
        tables = (
            "performance_stage_checkpoints",
            "performance_task_stages",
            "performance_checkpoints",
            "bayesian_tuning_observations",
            "performance_tasks",
            "bayesian_tuning_runs",
            "training_tasks",
            "implementation_training_cursors",
            "si_path_dataset_attachments",
            "retrieval_architecture_enrollments",
            "si_inference_batch_paths",
            "si_inference_batches",
        )
        deleted: dict[str, int] = {}
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for table in tables:
                deleted[table] = int(
                    connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                )
                connection.execute(f"DELETE FROM {table}")
            connection.execute(
                """
                UPDATE si_paths
                   SET latest_metrics_json = NULL, last_evaluated_at = NULL
                """
            )
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """
                INSERT INTO si_inference_batches (
                    dataset_revision, state, interval_size, evidence_mode,
                    created_at, completed_at, updated_at
                ) VALUES (0, 'completed', ?, 'measured', ?, ?, ?)
                """,
                (DEFAULT_INFERENCE_INTERVAL, now, now, now),
            )
        return deleted

    def claim_performance_task(
        self, worker_id: str, *, execution_mode: str | None = None
    ) -> dict[str, Any] | None:
        worker_id = worker_id.strip()
        if not worker_id:
            raise ValueError("worker_id is required")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT t.task_id
                  FROM performance_tasks t JOIN si_paths p USING (path_id)
                 WHERE t.state = 'pending'
                   AND (? IS NULL OR json_extract(p.config_json, '$.execution_mode') = ?)
                 ORDER BY t.priority DESC, t.created_at ASC LIMIT 1
                """,
                (execution_mode, execution_mode),
            ).fetchone()
            if row is None:
                return None
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """
                UPDATE performance_tasks
                   SET state = 'running', worker_id = ?, started_at = ?,
                       updated_at = ?
                 WHERE task_id = ? AND state = 'pending'
                """,
                (worker_id, now, now, row[0]),
            )
            return self._performance_task(connection, row[0])

    def finish_performance_task(
        self,
        task_id: str,
        *,
        state: str,
        metrics: Mapping[str, Any] | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        if state not in {"completed", "failed", "cancelled"}:
            raise ValueError("state must be completed, failed, or cancelled")
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT path_id, state FROM performance_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance task: {task_id}")
            if state != "cancelled" and row[1] != "running":
                raise ValueError("only a running task can be completed or failed")
            if state == "completed":
                incomplete = connection.execute(
                    """
                    SELECT 1 FROM performance_task_stages
                     WHERE task_id = ? AND state != 'completed' LIMIT 1
                    """,
                    (task_id,),
                ).fetchone()
                if incomplete is not None:
                    raise ValueError("all task stages must complete before the parent")
            metrics_json = (
                json.dumps(dict(metrics), ensure_ascii=False, sort_keys=True)
                if metrics is not None
                else None
            )
            connection.execute(
                """
                UPDATE performance_tasks
                   SET state = ?, metrics_json = ?, error = ?, finished_at = ?,
                       updated_at = ?
                 WHERE task_id = ?
                """,
                (state, metrics_json, error, now, now, task_id),
            )
            if state == "cancelled":
                connection.execute(
                    """
                    UPDATE performance_task_stages
                       SET state = 'cancelled', finished_at = ?, updated_at = ?
                     WHERE task_id = ? AND state IN ('pending', 'running')
                    """,
                    (now, now, task_id),
                )
            if state == "completed":
                connection.execute(
                    """
                    UPDATE si_paths
                       SET latest_metrics_json = ?, last_evaluated_at = ?,
                           updated_at = ?
                     WHERE path_id = ?
                    """,
                    (metrics_json, now, now, row[0]),
                )
                self._archive_excess_implementations(connection, row[0], now=now)
            return self._performance_task(connection, task_id)

    @staticmethod
    def _archive_excess_implementations(
        connection: sqlite3.Connection,
        completed_path_id: str,
        *,
        now: str,
        maximum: int = 20,
    ) -> None:
        completed = connection.execute(
            "SELECT config_json FROM si_paths WHERE path_id = ?",
            (completed_path_id,),
        ).fetchone()
        if completed is None:
            return
        projected_path_id = _si_architecture_and_setting(json.loads(completed[0]))[0]
        rows = connection.execute(
            """
            SELECT path_id, config_json, latest_metrics_json, last_evaluated_at
              FROM si_paths WHERE archived_at IS NULL
            """
        ).fetchall()
        matching = [
            row for row in rows
            if _si_architecture_and_setting(json.loads(row[1]))[0]
            == projected_path_id
        ]
        excess = len(matching) - maximum
        if excess > 0:
            CollectorStore._archive_ranked_implementations(
                connection, matching, count=excess, now=now, maximum=maximum
            )

    @staticmethod
    def _archive_ranked_implementations(
        connection: sqlite3.Connection,
        rows: list[sqlite3.Row | tuple[Any, ...]],
        *,
        count: int,
        now: str,
        maximum: int,
    ) -> int:
        candidates = []
        for row in rows:
            if connection.execute(
                """
                SELECT 1 FROM performance_tasks
                 WHERE path_id = ? AND state IN ('pending', 'running') LIMIT 1
                """,
                (row[0],),
            ).fetchone() is not None:
                continue
            metrics = json.loads(row[2]) if row[2] else {}
            score = next(
                (
                    float(metrics[key])
                    for key in (
                        "recall_at_k", "ndcg_at_k", "mrr", "map_at_k",
                        "top1_accuracy", "accuracy",
                    )
                    if isinstance(metrics.get(key), (int, float))
                ),
                float("-inf"),
            )
            candidates.append((score, row[3] or "", row[0]))
        candidates.sort()
        archived = 0
        for _, _, path_id in candidates[:count]:
            connection.execute(
                """
                UPDATE si_paths
                   SET archived_at = ?, archive_reason = ?, updated_at = ?
                 WHERE path_id = ? AND archived_at IS NULL
                """,
                (
                    now,
                    f"active Implementation limit ({maximum}); lower completed metric",
                    now,
                    path_id,
                ),
            )
            archived += 1
        return archived

    def record_performance_checkpoint(
        self,
        task_id: str,
        *,
        examples_seen: int,
        metrics: Mapping[str, Any],
    ) -> dict[str, Any]:
        if examples_seen < 0:
            raise ValueError("examples_seen must be non-negative")
        if not metrics:
            raise ValueError("metrics must not be empty")
        metrics_json = json.dumps(
            dict(metrics), ensure_ascii=False, sort_keys=True, allow_nan=False
        )
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            state = connection.execute(
                "SELECT state FROM performance_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
            if state is None:
                raise LookupError(f"unknown performance task: {task_id}")
            if state[0] != "running":
                raise ValueError("checkpoints require a running task")
            connection.execute(
                """
                INSERT INTO performance_checkpoints (
                    task_id, examples_seen, metrics_json, recorded_at
                ) VALUES (?, ?, ?, ?)
                ON CONFLICT(task_id, examples_seen) DO UPDATE SET
                    metrics_json = excluded.metrics_json,
                    recorded_at = excluded.recorded_at
                """,
                (task_id, int(examples_seen), metrics_json, now),
            )
            return self._performance_task(connection, task_id)

    def start_performance_stage(
        self, task_id: str, stage_key: str
    ) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT s.state, t.state
                  FROM performance_task_stages s
                  JOIN performance_tasks t USING (task_id)
                 WHERE s.task_id = ? AND s.stage_key = ?
                """,
                (task_id, stage_key),
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance stage: {task_id}/{stage_key}")
            if row[1] != "running" or row[0] != "pending":
                raise ValueError("only a pending stage of a running task can start")
            predecessor = connection.execute(
                """
                SELECT 1 FROM performance_task_stages current
                JOIN performance_task_stages previous
                  ON previous.task_id = current.task_id
                 AND previous.stage_order < current.stage_order
                 AND previous.state != 'completed'
                WHERE current.task_id = ? AND current.stage_key = ? LIMIT 1
                """,
                (task_id, stage_key),
            ).fetchone()
            if predecessor is not None:
                raise ValueError("all predecessor stages must complete first")
            connection.execute(
                """
                UPDATE performance_task_stages
                   SET state = 'running', started_at = ?, updated_at = ?
                 WHERE task_id = ? AND stage_key = ?
                """,
                (now, now, task_id, stage_key),
            )
            return self._performance_task(connection, task_id)

    def record_performance_stage_checkpoint(
        self,
        task_id: str,
        stage_key: str,
        *,
        examples_seen: int,
        metrics: Mapping[str, Any],
    ) -> dict[str, Any]:
        if examples_seen < 0 or not metrics:
            raise ValueError("stage checkpoint requires non-negative samples and metrics")
        metrics_json = json.dumps(
            dict(metrics), ensure_ascii=False, sort_keys=True, allow_nan=False
        )
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT state FROM performance_task_stages
                 WHERE task_id = ? AND stage_key = ?
                """,
                (task_id, stage_key),
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance stage: {task_id}/{stage_key}")
            if row[0] != "running":
                raise ValueError("stage checkpoints require a running stage")
            connection.execute(
                """
                INSERT INTO performance_stage_checkpoints (
                    task_id, stage_key, examples_seen, metrics_json, recorded_at
                ) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(task_id, stage_key, examples_seen) DO UPDATE SET
                    metrics_json = excluded.metrics_json,
                    recorded_at = excluded.recorded_at
                """,
                (task_id, stage_key, int(examples_seen), metrics_json, now),
            )
            connection.execute(
                """
                UPDATE performance_task_stages SET updated_at = ?
                 WHERE task_id = ? AND stage_key = ?
                """,
                (now, task_id, stage_key),
            )
            connection.execute(
                "UPDATE performance_tasks SET updated_at = ? WHERE task_id = ?",
                (now, task_id),
            )
            return self._performance_task(connection, task_id)

    def heartbeat_performance_task(
        self, task_id: str, *, stage_key: str | None = None
    ) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT state FROM performance_tasks WHERE task_id = ?", (task_id,)
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance task: {task_id}")
            if row[0] != "running":
                raise ValueError("heartbeats require a running task")
            connection.execute(
                "UPDATE performance_tasks SET updated_at = ? WHERE task_id = ?",
                (now, task_id),
            )
            if stage_key is not None:
                connection.execute(
                    """
                    UPDATE performance_task_stages SET updated_at = ?
                     WHERE task_id = ? AND stage_key = ? AND state = 'running'
                    """,
                    (now, task_id, stage_key),
                )
            return self._performance_task(connection, task_id)

    def finish_performance_stage(
        self,
        task_id: str,
        stage_key: str,
        *,
        state: str = "completed",
        metrics: Mapping[str, Any] | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        if state not in {"completed", "failed", "cancelled"}:
            raise ValueError("stage state must be completed, failed, or cancelled")
        now = datetime.now(UTC).isoformat()
        metrics_json = (
            json.dumps(dict(metrics), ensure_ascii=False, sort_keys=True)
            if metrics is not None
            else None
        )
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT state FROM performance_task_stages
                 WHERE task_id = ? AND stage_key = ?
                """,
                (task_id, stage_key),
            ).fetchone()
            if row is None:
                raise LookupError(f"unknown performance stage: {task_id}/{stage_key}")
            if state != "cancelled" and row[0] != "running":
                raise ValueError("only a running stage can complete or fail")
            connection.execute(
                """
                UPDATE performance_task_stages
                   SET state = ?, metrics_json = ?, error = ?, finished_at = ?,
                       updated_at = ?
                 WHERE task_id = ? AND stage_key = ?
                """,
                (state, metrics_json, error, now, now, task_id, stage_key),
            )
            return self._performance_task(connection, task_id)

    def si_paths(self, *, execution_mode: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT path_id, config_json, latest_metrics_json,
                       last_evaluated_at, created_at, updated_at
                   FROM si_paths
                  WHERE archived_at IS NULL
                    AND (? IS NULL OR json_extract(config_json, '$.execution_mode') = ?)
                  ORDER BY updated_at DESC
                """,
                (execution_mode, execution_mode),
            ).fetchall()
            checkpoint_rows = connection.execute(
                """
                SELECT t.path_id, c.examples_seen, c.metrics_json, c.recorded_at
                  FROM performance_checkpoints c
                  JOIN performance_tasks t USING (task_id)
                  JOIN si_paths p USING (path_id)
                 WHERE (? IS NULL OR json_extract(p.config_json, '$.execution_mode') = ?)
                 ORDER BY c.examples_seen ASC, c.recorded_at ASC
                """,
                (execution_mode, execution_mode),
            ).fetchall()
        history_points: dict[str, dict[int, dict[str, Any]]] = {}
        for physical_path_id, examples_seen, metrics_json, recorded_at in checkpoint_rows:
            history_points.setdefault(physical_path_id, {})[examples_seen] = {
                "examples_seen": examples_seen,
                "metrics": json.loads(metrics_json),
                "recorded_at": recorded_at,
            }
        histories = {
            path_id: [points[key] for key in sorted(points)]
            for path_id, points in history_points.items()
        }
        grouped: dict[str, dict[str, Any]] = {}
        for row in rows:
            full_config = json.loads(row[1])
            path_id, architecture, setting_id, settings = (
                _si_architecture_and_setting(full_config)
            )
            path = grouped.setdefault(
                path_id,
                {
                    "path_id": path_id,
                    "architecture": architecture,
                    "settings": [],
                    "created_at": row[4],
                    "updated_at": row[5],
                },
            )
            path["created_at"] = min(path["created_at"], row[4])
            path["updated_at"] = max(path["updated_at"], row[5])
            path["settings"].append(
                {
                    "setting_id": setting_id,
                    "parameters": settings,
                    "history": histories.get(row[0], []),
                    "latest_metrics": json.loads(row[2]) if row[2] else None,
                    "last_evaluated_at": row[3],
                    "created_at": row[4],
                    "updated_at": row[5],
                }
            )
        for path in grouped.values():
            path["settings"].sort(key=lambda item: item["setting_id"])
        return sorted(
            grouped.values(), key=lambda item: item["updated_at"], reverse=True
        )

    def _performance_task(
        self, connection: sqlite3.Connection, task_id: str
    ) -> dict[str, Any]:
        row = connection.execute(
            """
                 SELECT t.task_id, t.path_id, t.state, t.priority, t.worker_id,
                   t.metrics_json, t.error, t.created_at, t.started_at,
                     t.finished_at, t.updated_at, t.dataset_revision,
                     t.trigger_kind, p.config_json, t.dataset_snapshot_id
              FROM performance_tasks t JOIN si_paths p USING (path_id)
             WHERE t.task_id = ?
            """,
            (task_id,),
        ).fetchone()
        if row is None:
            raise LookupError(f"unknown performance task: {task_id}")
        snapshot_row = connection.execute(
            "SELECT payload_json FROM evaluation_dataset_snapshots WHERE snapshot_id = ?",
            (row[14],),
        ).fetchone()
        frozen_dataset = json.loads(snapshot_row[0]) if snapshot_row else None
        task_metrics = json.loads(row[5]) if row[5] else {}

        def compatible_history(point: Sequence[Any]) -> bool:
            if point[5] == task_id:
                return True
            if frozen_dataset is None or point[4] is None:
                return False
            prefix = {**frozen_dataset, "training": frozen_dataset["training"][:point[3]]}
            encoded = json.dumps(prefix, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            if sha256(encoded.encode("utf-8")).hexdigest() != point[4]:
                return False
            corpus = task_metrics.get("corpus_revision")
            return not corpus or json.loads(point[1]).get("corpus_revision") == corpus

        full_config = json.loads(row[13])
        _ensure_performance_stages(connection, task_id, full_config)
        path_id, architecture, setting_id, settings = _si_architecture_and_setting(
            full_config
        )
        checkpoints = connection.execute(
            """
            SELECT examples_seen, metrics_json, recorded_at
              FROM performance_checkpoints
             WHERE task_id = ? ORDER BY examples_seen ASC
            """,
            (task_id,),
        ).fetchall()
        stages = connection.execute(
            """
            SELECT stage_key, stage_order, label, state, metrics_json, error,
                   created_at, started_at, finished_at, updated_at
              FROM performance_task_stages
             WHERE task_id = ? ORDER BY stage_order
            """,
            (task_id,),
        ).fetchall()
        stage_histories: dict[str, list[dict[str, Any]]] = {}
        for stage in stages:
            if row[12] == "labeled_training_interval" and row[11] is not None:
                history_rows = connection.execute(
                    """
                    SELECT c.examples_seen, c.metrics_json, c.recorded_at,
                           prior.dataset_revision, prior.dataset_snapshot_id, prior.task_id
                      FROM performance_stage_checkpoints c
                      JOIN performance_tasks prior USING (task_id)
                     WHERE prior.path_id = ? AND c.stage_key = ?
                       AND prior.trigger_kind = 'labeled_training_interval'
                       AND prior.dataset_revision <= ?
                     ORDER BY c.examples_seen, c.recorded_at
                    """,
                    (row[1], stage[0], row[11]),
                ).fetchall()
                history_rows = [point[:3] for point in history_rows if compatible_history(point)]
            else:
                history_rows = connection.execute(
                    """
                    SELECT examples_seen, metrics_json, recorded_at
                      FROM performance_stage_checkpoints
                     WHERE task_id = ? AND stage_key = ?
                     ORDER BY examples_seen, recorded_at
                    """,
                    (task_id, stage[0]),
                ).fetchall()
            by_sample = {
                int(point[0]): {
                    "examples_seen": int(point[0]),
                    "metrics": json.loads(point[1]),
                    "recorded_at": point[2],
                }
                for point in history_rows
            }
            stage_histories[str(stage[0])] = [
                by_sample[sample] for sample in sorted(by_sample)
            ]
        return {
            "task_id": row[0], "path_id": path_id,
            "architecture_id": path_id,
            "setting_id": setting_id, "state": row[2],
            "trial_configuration_id": setting_id,
            "priority": row[3], "worker_id": row[4],
            "metrics": json.loads(row[5]) if row[5] else None,
            "error": row[6], "created_at": row[7], "started_at": row[8],
            "finished_at": row[9], "updated_at": row[10],
            "dataset_revision": row[11], "trigger_kind": row[12],
            "dataset_snapshot_id": row[14],
            "dataset_current": (
                self._snapshot_is_current(connection, frozen_dataset)
                if frozen_dataset is not None else False
            ),
            "architecture": architecture, "settings": settings,
            "config": full_config,
            "history": [
                {
                    "examples_seen": checkpoint[0],
                    "metrics": json.loads(checkpoint[1]),
                    "recorded_at": checkpoint[2],
                }
                for checkpoint in checkpoints
            ],
            "stages": [
                {
                    "stage_key": stage[0], "stage_order": stage[1],
                    "label": stage[2], "state": stage[3],
                    "path_id": _si_architecture_and_setting(
                        _performance_stage_config(full_config, stage[0])
                    )[0],
                    "architecture": _si_architecture_and_setting(
                        _performance_stage_config(full_config, stage[0])
                    )[1],
                    "setting_id": _si_architecture_and_setting(
                        _performance_stage_config(full_config, stage[0])
                    )[2],
                    "trial_configuration_id": _si_architecture_and_setting(
                        _performance_stage_config(full_config, stage[0])
                    )[2],
                    "parameters": _si_architecture_and_setting(
                        _performance_stage_config(full_config, stage[0])
                    )[3],
                    "metrics": json.loads(stage[4]) if stage[4] else None,
                    "error": stage[5], "created_at": stage[6],
                    "started_at": stage[7], "finished_at": stage[8],
                    "runtime_seconds": _elapsed_seconds(stage[7], stage[8]),
                    "updated_at": stage[9],
                    "history": stage_histories[str(stage[0])],
                }
                for stage in stages
            ],
        }

    def summary(self) -> dict[str, Any]:
        with self._connect() as connection:
            total = connection.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            interactions = connection.execute(
                "SELECT COUNT(DISTINCT interaction_id) FROM events"
            ).fetchone()[0]
            by_type = dict(
                connection.execute(
                    "SELECT event_type, COUNT(*) FROM events GROUP BY event_type"
                ).fetchall()
            )
            nodes = connection.execute(
                "SELECT COUNT(DISTINCT source_node_id) FROM events"
            ).fetchone()[0]
            snapshots = connection.execute(
                "SELECT COUNT(DISTINCT corpus_snapshot_id) FROM events "
                "WHERE corpus_snapshot_id IS NOT NULL"
            ).fetchone()[0]
            imported = connection.execute(
                "SELECT COUNT(*) FROM imported_training_examples"
            ).fetchone()[0]
            imported_by_partition = dict(
                connection.execute(
                    """
                    SELECT g.partition, COUNT(*)
                      FROM imported_training_examples e
                      JOIN dataset_groups g USING (group_id)
                      JOIN training_example_cleaning c USING (example_id)
                     WHERE c.status = 'usable'
                     GROUP BY g.partition
                    """
                ).fetchall()
            )
            imported_by_source = dict(
                connection.execute(
                    """
                    SELECT json_extract(source_json, '$.provider'), COUNT(*)
                      FROM imported_training_examples
                     GROUP BY json_extract(source_json, '$.provider')
                    """
                ).fetchall()
            )
            groups_by_partition = dict(
                connection.execute(
                    "SELECT partition, COUNT(*) FROM dataset_groups GROUP BY partition"
                ).fetchall()
            )
            cleaning_by_status = dict(
                connection.execute(
                    """
                    SELECT status, COUNT(*) FROM training_example_cleaning
                     GROUP BY status
                    """
                ).fetchall()
            )
            cleaning_by_reason = dict(
                connection.execute(
                    """
                    SELECT reason, COUNT(*) FROM training_example_cleaning
                     WHERE status != 'usable'
                     GROUP BY reason
                     ORDER BY COUNT(*) DESC, reason
                    """
                ).fetchall()
            )
            ground_truth_by_lifecycle = dict(
                connection.execute(
                    """
                    SELECT COALESCE(json_extract(payload_json, '$.lifecycle'), 'unknown'),
                           COUNT(*)
                      FROM imported_training_examples GROUP BY 1
                    """
                ).fetchall()
            )
            ground_truth_by_resource = dict(
                connection.execute(
                    """
                    SELECT COALESCE(json_extract(payload_json, '$.resource_type'), 'unknown'),
                           COUNT(*)
                      FROM imported_training_examples GROUP BY 1
                    """
                ).fetchall()
            )
            ground_truth_by_intent = dict(
                connection.execute(
                    """
                    SELECT COALESCE(json_extract(payload_json, '$.query_intent'), 'unknown'),
                           COUNT(*)
                      FROM imported_training_examples GROUP BY 1
                    """
                ).fetchall()
            )
            dataset_rows = connection.execute(
                """
                SELECT COALESCE(json_extract(e.payload_json, '$.resource_type'), 'unknown'),
                       COALESCE(json_extract(e.payload_json, '$.lifecycle'), 'unknown'),
                       COALESCE(json_extract(e.payload_json, '$.baseline_family'), 'fuzzy'),
                       COALESCE(json_extract(e.payload_json, '$.tool_arguments.method'), ''),
                       g.partition, COUNT(*)
                  FROM imported_training_examples e
                  JOIN training_example_cleaning c USING (example_id)
                  JOIN dataset_groups g USING (group_id)
                 WHERE c.status = 'usable'
                 GROUP BY 1, 2, 3, 4, 5 ORDER BY 1, 2, 3, 4, 5
                """
            ).fetchall()
            dataset_inventory: dict[str, dict[str, Any]] = {}
            baseline_inventory: dict[str, dict[str, int]] = {}
            match_mode_inventory: dict[str, dict[str, int]] = {}
            fuzzy_dataset_inventory: dict[str, dict[str, Any]] = {}
            for resource_type, lifecycle, baseline_family, method, partition, count in dataset_rows:
                family = str(baseline_family)
                match_mode = _search_match_mode(
                    {"baseline_family": family, "tool_arguments": {"method": method}}
                )
                family_counts = baseline_inventory.setdefault(
                    family, {"observed": 0, "program_labeled": 0, "ambiguous": 0}
                )
                family_counts["observed"] += int(count)
                if lifecycle in {"complete", "no_match"}:
                    family_counts["program_labeled"] += int(count)
                elif lifecycle == "ambiguous":
                    family_counts["ambiguous"] += int(count)
                mode_counts = match_mode_inventory.setdefault(
                    match_mode, {"observed": 0, "program_labeled": 0, "ambiguous": 0}
                )
                mode_counts["observed"] += int(count)
                if lifecycle in {"complete", "no_match"}:
                    mode_counts["program_labeled"] += int(count)
                elif lifecycle == "ambiguous":
                    mode_counts["ambiguous"] += int(count)
                item = dataset_inventory.setdefault(
                    str(resource_type),
                    {
                        "resource_type": str(resource_type),
                        "observed": 0,
                        "program_labeled": 0,
                        "ambiguous": 0,
                        "training_labeled": 0,
                        "validation_labeled": 0,
                        "by_partition": {},
                    },
                )
                item["observed"] += int(count)
                item["by_partition"][str(partition)] = (
                    item["by_partition"].get(str(partition), 0) + int(count)
                )
                if lifecycle in {"complete", "no_match"}:
                    item["program_labeled"] += int(count)
                    if partition == "training":
                        item["training_labeled"] += int(count)
                    elif str(partition).startswith("validation"):
                        item["validation_labeled"] += int(count)
                elif lifecycle == "ambiguous":
                    item["ambiguous"] += int(count)
                if match_mode == "fuzzy":
                    fuzzy_item = fuzzy_dataset_inventory.setdefault(
                        str(resource_type),
                        {
                            "resource_type": str(resource_type),
                            "observed": 0,
                            "program_labeled": 0,
                            "ambiguous": 0,
                            "training_labeled": 0,
                            "validation_labeled": 0,
                            "by_partition": {},
                        },
                    )
                    fuzzy_item["observed"] += int(count)
                    fuzzy_item["by_partition"][str(partition)] = (
                        fuzzy_item["by_partition"].get(str(partition), 0) + int(count)
                    )
                    if lifecycle in {"complete", "no_match"}:
                        fuzzy_item["program_labeled"] += int(count)
                        if partition == "training":
                            fuzzy_item["training_labeled"] += int(count)
                        elif str(partition).startswith("validation"):
                            fuzzy_item["validation_labeled"] += int(count)
                    elif lifecycle == "ambiguous":
                        fuzzy_item["ambiguous"] += int(count)
            partition_state = connection.execute(
                """
                SELECT stream_version, evaluation_version, rolling_candidates_seen
                  FROM dataset_partition_state WHERE singleton = 1
                """
            ).fetchone()
        return {
            "events": total,
            "interactions": interactions,
            "source_nodes": nodes,
            "corpus_snapshots": snapshots,
            "by_type": by_type,
            "imported_training_examples": imported,
            "imported_by_partition": imported_by_partition,
            "imported_by_source": imported_by_source,
            "cleaning": {
                "version": CLEANER_VERSION,
                "by_status": cleaning_by_status,
                "by_reason": cleaning_by_reason,
                "usable_examples": cleaning_by_status.get("usable", 0),
                "excluded_examples": sum(
                    count
                    for status, count in cleaning_by_status.items()
                    if status != "usable"
                ),
            },
            "ground_truth": {
                "schema_version": "search-call-ground-truth-v1",
                "observed": imported,
                "program_labeled": (
                    ground_truth_by_lifecycle.get("complete", 0)
                    + ground_truth_by_lifecycle.get("no_match", 0)
                ),
                "quarantined": ground_truth_by_lifecycle.get("ambiguous", 0),
                "no_match": ground_truth_by_lifecycle.get("no_match", 0),
                "clean_program_labeled": sum(
                    int(item["program_labeled"])
                    for item in dataset_inventory.values()
                ),
                "clean_ambiguous": sum(
                    int(item["ambiguous"])
                    for item in dataset_inventory.values()
                ),
                "by_lifecycle": ground_truth_by_lifecycle,
                "by_resource_type": ground_truth_by_resource,
                "by_query_intent": ground_truth_by_intent,
                "by_baseline_family": baseline_inventory,
                "by_match_mode": match_mode_inventory,
                "dataset_inventory": list(dataset_inventory.values()),
                "fuzzy_dataset_inventory": list(fuzzy_dataset_inventory.values()),
            },
            "dataset_partition": {
                "policy": DATASET_PARTITION_POLICY,
                "capacity": 1000,
                "capacity_unit": "groups",
                "anchor_capacity": 200,
                "rolling_capacity": 800,
                "groups_by_partition": groups_by_partition,
                "stream_version": partition_state[0],
                "evaluation_version": partition_state[1],
                "rolling_candidates_seen": partition_state[2],
            },
            "si_inference": self.inference_interval_status(),
            "collectors": self.collector_statuses(),
        }

    def record_path_recommendation(
        self,
        *,
        draft: Mapping[str, Any],
        suggestion: Mapping[str, Any],
        taxonomy_version: str,
        corpus_snapshot_id: str,
        model_version: str,
    ) -> dict[str, Any]:
        recommendation_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        draft_json = json.dumps(dict(draft), ensure_ascii=False, sort_keys=True)
        draft_hash = sha256(draft_json.encode("utf-8")).hexdigest()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO path_recommendations (
                    recommendation_id, created_at, skill_draft_hash, draft_json,
                    suggestion_json, taxonomy_version, corpus_snapshot_id,
                    model_version
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    recommendation_id,
                    created_at,
                    draft_hash,
                    draft_json,
                    json.dumps(dict(suggestion), ensure_ascii=False, sort_keys=True),
                    taxonomy_version,
                    corpus_snapshot_id,
                    model_version,
                ),
            )
        return self.path_recommendation(recommendation_id) or {}

    def path_recommendation(self, recommendation_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT recommendation_id, created_at, skill_draft_hash, draft_json,
                       suggestion_json, taxonomy_version, corpus_snapshot_id,
                       model_version
                  FROM path_recommendations
                 WHERE recommendation_id = ?
                """,
                (recommendation_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "recommendation_id": row[0],
            "created_at": row[1],
            "skill_draft_hash": row[2],
            "draft": json.loads(row[3]),
            "suggestion": json.loads(row[4]),
            "taxonomy_version": row[5],
            "corpus_snapshot_id": row[6],
            "model_version": row[7],
        }

    def record_path_decision(
        self,
        *,
        recommendation_id: str,
        decision: str,
        accepted_category: str = "",
        existing_skill_id: str = "",
        new_child_name: str = "",
    ) -> dict[str, Any]:
        decision = decision.strip().casefold()
        if decision not in PLACEMENT_DECISIONS:
            raise ValueError(f"unsupported placement decision: {decision}")
        recommendation = self.path_recommendation(recommendation_id)
        if recommendation is None:
            raise LookupError("path recommendation not found")
        suggested_category = str(recommendation["suggestion"]["category"])
        if decision == "accepted":
            accepted_category = suggested_category
        elif decision == "corrected" and not accepted_category.strip():
            raise ValueError("accepted_category is required for corrected decisions")
        elif decision == "create_child":
            if not accepted_category.strip() or not new_child_name.strip():
                raise ValueError(
                    "accepted_category and new_child_name are required for create_child decisions"
                )
            accepted_category = (
                f"{accepted_category.strip().rstrip('/')}/{new_child_name.strip()}"
            )
        elif decision == "duplicate" and not existing_skill_id.strip():
            raise ValueError("existing_skill_id is required for duplicate decisions")
        decision_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO path_decisions (
                    decision_id, recommendation_id, created_at, decision,
                    accepted_category, existing_skill_id, new_child_name
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision_id,
                    recommendation_id,
                    created_at,
                    decision,
                    accepted_category.strip(),
                    existing_skill_id.strip(),
                    new_child_name.strip(),
                ),
            )
        return {
            "decision_id": decision_id,
            "recommendation_id": recommendation_id,
            "created_at": created_at,
            "decision": decision,
            "accepted_category": accepted_category.strip(),
            "existing_skill_id": existing_skill_id.strip(),
            "new_child_name": new_child_name.strip(),
            "taxonomy_version": recommendation["taxonomy_version"],
            "corpus_snapshot_id": recommendation["corpus_snapshot_id"],
        }

    def path_decisions(self, *, limit: int = 1000) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT d.decision_id, d.recommendation_id, d.created_at,
                       d.decision, d.accepted_category, d.existing_skill_id,
                       d.new_child_name, r.skill_draft_hash, r.draft_json,
                       r.suggestion_json, r.taxonomy_version,
                       r.corpus_snapshot_id, r.model_version
                  FROM path_decisions d
                  JOIN path_recommendations r USING (recommendation_id)
                 ORDER BY d.rowid DESC LIMIT ?
                """,
                (max(1, min(int(limit), 100_000)),),
            ).fetchall()
        return [
            {
                "decision_id": row[0],
                "recommendation_id": row[1],
                "created_at": row[2],
                "decision": row[3],
                "accepted_category": row[4],
                "existing_skill_id": row[5],
                "new_child_name": row[6],
                "skill_draft_hash": row[7],
                "draft": json.loads(row[8]),
                "suggestion": json.loads(row[9]),
                "taxonomy_version": row[10],
                "corpus_snapshot_id": row[11],
                "model_version": row[12],
            }
            for row in rows
        ]

    def training_examples(self, *, include_trashed: bool = False) -> list[dict[str, Any]]:
        with self._connect() as connection:
            trashed = dict(
                connection.execute(
                    "SELECT interaction_id, deleted_at FROM trashed_interactions"
                ).fetchall()
            )
        interactions: dict[str, dict[str, Any]] = {}
        for event in self.events(limit=100_000):
            interaction = interactions.setdefault(
                event["interaction_id"],
                {"retrieval": None, "loads": [], "outcome": None},
            )
            if event["event_type"] == "retrieval":
                interaction["retrieval"] = event
            elif event["event_type"] == "skill_load":
                interaction["loads"].append(event)
            elif event["event_type"] == "outcome":
                interaction["outcome"] = event

        examples = []
        for interaction_id, interaction in interactions.items():
            if interaction_id in trashed and not include_trashed:
                continue
            retrieval = interaction["retrieval"]
            if retrieval is None:
                continue
            payload = retrieval["payload"]
            candidates = payload.get("candidates") or []
            final_ranking = []
            for fallback_rank, candidate in enumerate(candidates, start=1):
                final_ranking.append(
                    {
                        "skill_id": candidate.get("skill_id"),
                        "content_hash": candidate.get("content_hash", ""),
                        "rank": candidate.get("rank", fallback_rank),
                        "score": candidate.get("score", 0.0),
                        "calibrated_probabilities": {},
                        "contributors": [
                            {
                                "route_key": payload.get("retriever", {}).get(
                                    "name", "pkm-skill-context"
                                ),
                                "source_rank": candidate.get("rank", fallback_rank),
                                "source_score": candidate.get("score", 0.0),
                            }
                        ],
                    }
                )
            loaded_skill_ids = [
                event["payload"].get("skill", {}).get("skill_id")
                for event in interaction["loads"]
            ]
            loaded_skill_ids = [skill_id for skill_id in loaded_skill_ids if skill_id]
            outcome_payload = (
                interaction["outcome"]["payload"].get("feedback", {})
                if interaction["outcome"]
                else {}
            )
            used_skill_ids = outcome_payload.get("used_skills") or []
            outcome = str(outcome_payload.get("outcome") or "").casefold()
            lifecycle = (
                "complete"
                if interaction["outcome"]
                else "loaded"
                if loaded_skill_ids
                else "no_match"
                if not candidates
                else "pending"
            )
            relevant_skill_ids = list(dict.fromkeys(used_skill_ids or loaded_skill_ids))
            examples.append(
                {
                    "query_id": interaction_id,
                    "interaction_id": interaction_id,
                    "query": payload.get("query", ""),
                    "domain": payload.get("domain", "live"),
                    "language": payload.get("language", "unknown"),
                    "split": "live",
                    "dataset_kind": "live",
                    "lifecycle": lifecycle,
                    "occurred_at": retrieval["occurred_at"],
                    "collected_at": retrieval["received_at"],
                    "session_id": payload.get("collector_session_id", "legacy-unknown"),
                    "source_node_id": retrieval["source_node_id"],
                    "observation_source": retrieval["observation_source"],
                    "corpus_snapshot_id": retrieval["corpus_snapshot_id"],
                    "retrieved": [
                        {
                            "route_key": payload.get("retriever", {}).get(
                                "name", "pkm-skill-context"
                            ),
                            "candidates": candidates,
                        }
                    ],
                    "final_ranking": final_ranking,
                    "selected_skill_id": loaded_skill_ids[0]
                    if loaded_skill_ids
                    else None,
                    "used_skill_id": used_skill_ids[0] if used_skill_ids else None,
                    "relevant_skill_ids": relevant_skill_ids,
                    "success": outcome in {"success", "succeeded", "completed"}
                    if interaction["outcome"]
                    else None,
                    "reward": 1.0
                    if outcome in {"success", "succeeded", "completed"}
                    else 0.0
                    if interaction["outcome"]
                    else None,
                    "deleted_at": trashed.get(interaction_id),
                }
            )
        examples.extend(self._imported_training_examples())
        return sorted(examples, key=lambda item: item["occurred_at"], reverse=True)

    def trash_examples(self) -> list[dict[str, Any]]:
        return [
            example
            for example in self.training_examples(include_trashed=True)
            if example["deleted_at"] is not None
        ]

    def trash_interaction(self, interaction_id: str) -> bool:
        interaction_id = interaction_id.strip()
        if not interaction_id:
            raise ValueError("interaction_id is required")
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM events WHERE interaction_id = ? LIMIT 1",
                (interaction_id,),
            ).fetchone()
            if exists is None:
                return False
            cursor = connection.execute(
                "INSERT OR IGNORE INTO trashed_interactions (interaction_id, deleted_at) VALUES (?, ?)",
                (interaction_id, datetime.now(UTC).isoformat()),
            )
        return cursor.rowcount == 1

    def restore_interaction(self, interaction_id: str) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            )
        return cursor.rowcount == 1

    def purge_interaction(self, interaction_id: str) -> bool:
        with self._connect() as connection:
            trashed = connection.execute(
                "SELECT 1 FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            ).fetchone()
            if trashed is None:
                return False
            connection.execute(
                "DELETE FROM events WHERE interaction_id = ?", (interaction_id,)
            )
            connection.execute(
                "DELETE FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            )
        return True

    def export_jsonl(self) -> str:
        return "".join(
            json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n"
            for event in self.events(limit=100_000)
        )

    def snapshot_corpus(self) -> str:
        if self.pkm_root is None:
            raise RuntimeError("pkm_root is required to snapshot the Skillset")
        documents, paths = load_pkm_skills(self.pkm_root)
        by_id = {document.version.skill_id: document for document in documents}
        entries = []
        for skill_id in sorted(paths):
            document = by_id[skill_id]
            raw = paths[skill_id].read_text(encoding="utf-8")
            entries.append(
                {
                    "skill_id": skill_id,
                    "content_hash": document.version.content_hash,
                    "title": document.title,
                    "description": document.description,
                    "body": document.body,
                    "metadata": dict(document.metadata),
                    "source_markdown": raw,
                }
            )
        manifest = [
            (entry["skill_id"], entry["content_hash"]) for entry in entries
        ]
        snapshot_id = sha256(
            json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).encode(
                "utf-8"
            )
        ).hexdigest()
        target = self.snapshots_dir / f"{snapshot_id}.json.gz"
        if not target.exists():
            temporary = target.with_suffix(".tmp")
            with gzip.open(temporary, "wt", encoding="utf-8") as stream:
                json.dump(
                    {
                        "schema_version": 1,
                        "snapshot_id": snapshot_id,
                        "created_at": datetime.now(UTC).isoformat(),
                        "skills": entries,
                    },
                    stream,
                    ensure_ascii=False,
                    sort_keys=True,
                )
            temporary.replace(target)
        return snapshot_id

    def load_snapshot(self, snapshot_id: str) -> dict[str, Any]:
        path = self.snapshots_dir / f"{snapshot_id}.json.gz"
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            return json.load(stream)

    def _normalize(self, event: Mapping[str, Any]) -> dict[str, Any]:
        event_type = str(event.get("event_type") or "")
        if event_type not in EVENT_TYPES:
            raise ValueError(f"unsupported event_type: {event_type}")
        interaction_id = str(event.get("interaction_id") or "").strip()
        if not interaction_id:
            raise ValueError("interaction_id is required")
        payload = event.get("payload") or {}
        if not isinstance(payload, dict):
            raise ValueError("payload must be an object")
        return {
            "event_id": str(event.get("event_id") or uuid.uuid4()),
            "interaction_id": interaction_id,
            "event_type": event_type,
            "occurred_at": str(
                event.get("occurred_at") or datetime.now(UTC).isoformat()
            ),
            "source_node_id": str(event.get("source_node_id") or "unknown"),
            "observation_source": str(
                event.get("observation_source") or "live_agent"
            ),
            "schema_version": int(
                event.get("schema_version") or COLLECTOR_SCHEMA_VERSION
            ),
            "payload": dict(payload),
        }

    def _normalize_imported_example(self, example: Mapping[str, Any]) -> dict[str, Any]:
        example_id = str(example.get("example_id") or "").strip()
        if not example_id:
            raise ValueError("example_id is required")
        source = example.get("source")
        if not isinstance(source, dict):
            raise ValueError("source must be an object")
        for field in ("provider", "kind", "record_id"):
            if not str(source.get(field) or "").strip():
                raise ValueError(f"source.{field} is required")
        label_provenance = example.get("label_provenance")
        if not isinstance(label_provenance, dict) or not label_provenance:
            raise ValueError("label_provenance must be a non-empty object")
        payload = dict(example)
        for field in ("example_id", "group_id", "source", "label_provenance"):
            payload.pop(field, None)
        return {
            "example_id": example_id,
            "group_id": str(example.get("group_id") or example_id).strip(),
            "occurred_at": str(
                example.get("occurred_at") or datetime.now(UTC).isoformat()
            ),
            "source": dict(source),
            "label_provenance": dict(label_provenance),
            "payload": payload,
        }

    def _assign_dataset_group(
        self, connection: sqlite3.Connection, group_id: str
    ) -> tuple[str, int]:
        existing = connection.execute(
            "SELECT partition, partition_version FROM dataset_groups WHERE group_id = ?",
            (group_id,),
        ).fetchone()
        if existing is not None:
            return str(existing[0]), int(existing[1])

        state = connection.execute(
            """
            SELECT stream_version, evaluation_version, rolling_candidates_seen
              FROM dataset_partition_state WHERE singleton = 1
            """
        ).fetchone()
        anchor_count = connection.execute(
            "SELECT COUNT(*) FROM dataset_groups WHERE partition = 'validation_anchor'"
        ).fetchone()[0]
        rolling_slots = dict(
            connection.execute(
                """
                SELECT reservoir_slot, group_id FROM dataset_groups
                 WHERE partition = 'validation_rolling'
                """
            ).fetchall()
        )
        sampler = BoundedEvaluationSampler()
        decision = sampler.assign(
            group_id,
            existing_partition=None,
            anchor_count=anchor_count,
            rolling_slots=rolling_slots,
            rolling_candidates_seen=int(state[2]),
        )
        now = datetime.now(UTC).isoformat()
        stream_version = int(state[0]) + 1
        evaluation_changed = decision.partition.startswith("validation")
        evaluation_version = int(state[1]) + int(evaluation_changed)
        if decision.evicted_group_id:
            connection.execute(
                """
                UPDATE dataset_groups
                   SET partition = 'training', reservoir_slot = NULL,
                       evicted_at = ?, partition_version = ?
                 WHERE group_id = ?
                """,
                (now, stream_version, decision.evicted_group_id),
            )
            self._record_partition_transition(
                connection,
                decision.evicted_group_id,
                "validation_rolling",
                "training",
                "reservoir_replacement",
                stream_version,
                evaluation_version,
                now,
            )
        connection.execute(
            """
            INSERT INTO dataset_groups (
                group_id, partition, reservoir_slot, admitted_at,
                evicted_at, partition_version
            ) VALUES (?, ?, ?, ?, NULL, ?)
            """,
            (
                group_id,
                decision.partition,
                decision.reservoir_slot,
                now,
                stream_version,
            ),
        )
        self._record_partition_transition(
            connection,
            group_id,
            None,
            decision.partition,
            "initial_assignment",
            stream_version,
            evaluation_version,
            now,
        )
        connection.execute(
            """
            UPDATE dataset_partition_state
               SET stream_version = ?, evaluation_version = ?,
                   rolling_candidates_seen = rolling_candidates_seen + ?
             WHERE singleton = 1
            """,
            (stream_version, evaluation_version, int(decision.rolling_candidate)),
        )
        return decision.partition, stream_version

    @staticmethod
    def _record_partition_transition(
        connection: sqlite3.Connection,
        group_id: str,
        from_partition: str | None,
        to_partition: str,
        reason: str,
        stream_version: int,
        evaluation_version: int,
        occurred_at: str,
    ) -> None:
        connection.execute(
            """
            INSERT INTO dataset_partition_transitions (
                group_id, from_partition, to_partition, reason,
                stream_version, evaluation_version, occurred_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                group_id,
                from_partition,
                to_partition,
                reason,
                stream_version,
                evaluation_version,
                occurred_at,
            ),
        )

    def _partition_version(self) -> int:
        with self._connect() as connection:
            return int(
                connection.execute(
                    "SELECT stream_version FROM dataset_partition_state WHERE singleton = 1"
                ).fetchone()[0]
            )

    @staticmethod
    def _clean_imported_example(
        connection: sqlite3.Connection, example: Mapping[str, Any]
    ):
        initial = classify_example(example)
        canonical = connection.execute(
            """
            SELECT example_id FROM training_example_cleaning
             WHERE fingerprint = ? AND status = 'usable'
             ORDER BY cleaned_at, example_id LIMIT 1
            """,
            (initial.fingerprint,),
        ).fetchone()
        decision = classify_example(
            example,
            canonical_example_id=str(canonical[0]) if canonical else None,
        )
        connection.execute(
            """
            INSERT INTO training_example_cleaning (
                example_id, status, reason, fingerprint,
                canonical_example_id, cleaner_version, cleaned_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                example["example_id"],
                decision.status,
                decision.reason,
                decision.fingerprint,
                decision.canonical_example_id,
                CLEANER_VERSION,
                datetime.now(UTC).isoformat(),
            ),
        )
        return decision

    def _imported_training_examples(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT e.example_id, e.group_id, e.occurred_at, e.imported_at,
                       e.source_json, e.label_provenance_json, e.payload_json,
                       g.partition, g.partition_version, g.admitted_at, g.evicted_at,
                       c.status, c.reason, c.cleaner_version
                  FROM imported_training_examples e
                  JOIN dataset_groups g USING (group_id)
                   JOIN training_example_cleaning c USING (example_id)
                  WHERE c.status = 'usable'
                 ORDER BY e.rowid DESC
                """
            ).fetchall()
        results = []
        for row in rows:
            payload = json.loads(row[6])
            payload.setdefault("domain", "tool_planning")
            payload.setdefault("language", "unknown")
            payload.setdefault("final_ranking", [])
            payload.setdefault("retrieved", [])
            payload.setdefault("relevant_skill_ids", [])
            payload.setdefault("selected_skill_id", None)
            payload.setdefault("used_skill_id", None)
            payload.setdefault("success", None)
            payload.setdefault("reward", None)
            payload.setdefault("observation_source", "imported_transcript")
            payload.update(
                {
                    "example_id": row[0],
                    "query_id": row[0],
                    "interaction_id": row[0],
                    "group_id": row[1],
                    "occurred_at": row[2],
                    "collected_at": row[3],
                    "source": json.loads(row[4]),
                    "label_provenance": json.loads(row[5]),
                    "split": row[7],
                    "dataset_partition": row[7],
                    "partition_version": row[8],
                    "admitted_at": row[9],
                    "evicted_at": row[10],
                    "dataset_kind": "imported",
                    "deleted_at": None,
                    "cleaning_status": row[11],
                    "cleaning_reason": row[12],
                    "cleaner_version": row[13],
                }
            )
            results.append(payload)
        return results

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=30)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    @staticmethod
    def _update_collector_status(
        connection: sqlite3.Connection,
        collector_id: str,
        *,
        collector_kind: str,
        state: str,
        last_query_at: str | None = None,
        last_observation_at: str | None = None,
        cursor: str | None = None,
        error: str | None = None,
        observation_increment: int = 0,
        record_scan: bool = False,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        connection.execute(
            """
            INSERT INTO collector_status (
                collector_id, collector_kind, state, last_scan_at,
                last_query_at, last_observation_at, last_success_at,
                last_error, cursor, scan_count, observation_count, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(collector_id) DO UPDATE SET
                collector_kind = excluded.collector_kind,
                state = excluded.state,
                last_scan_at = COALESCE(excluded.last_scan_at, last_scan_at),
                last_query_at = COALESCE(excluded.last_query_at, last_query_at),
                last_observation_at = COALESCE(
                    excluded.last_observation_at, last_observation_at
                ),
                last_success_at = COALESCE(
                    excluded.last_success_at, last_success_at
                ),
                last_error = excluded.last_error,
                cursor = COALESCE(excluded.cursor, cursor),
                scan_count = scan_count + excluded.scan_count,
                observation_count = observation_count + excluded.observation_count,
                updated_at = excluded.updated_at
            """,
            (
                collector_id,
                collector_kind,
                state,
                now if record_scan else None,
                last_query_at,
                last_observation_at,
                now if error is None else None,
                error,
                cursor,
                int(record_scan),
                observation_increment,
                now,
            ),
        )

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    interaction_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    source_node_id TEXT NOT NULL,
                    observation_source TEXT NOT NULL,
                    schema_version INTEGER NOT NULL,
                    corpus_snapshot_id TEXT,
                    payload_json TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS events_interaction "
                "ON events(interaction_id, occurred_at)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS events_type ON events(event_type)"
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS trashed_interactions (
                    interaction_id TEXT PRIMARY KEY,
                    deleted_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS path_recommendations (
                    recommendation_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    skill_draft_hash TEXT NOT NULL,
                    draft_json TEXT NOT NULL,
                    suggestion_json TEXT NOT NULL,
                    taxonomy_version TEXT NOT NULL,
                    corpus_snapshot_id TEXT NOT NULL,
                    model_version TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS path_decisions (
                    decision_id TEXT PRIMARY KEY,
                    recommendation_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    accepted_category TEXT NOT NULL,
                    existing_skill_id TEXT NOT NULL,
                    new_child_name TEXT NOT NULL,
                    FOREIGN KEY (recommendation_id)
                        REFERENCES path_recommendations(recommendation_id)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS imported_training_examples (
                    example_id TEXT PRIMARY KEY,
                    group_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    imported_at TEXT NOT NULL,
                    source_json TEXT NOT NULL,
                    label_provenance_json TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS training_example_cleaning (
                    example_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    fingerprint TEXT NOT NULL,
                    canonical_example_id TEXT,
                    cleaner_version TEXT NOT NULL,
                    cleaned_at TEXT NOT NULL,
                    FOREIGN KEY (example_id)
                        REFERENCES imported_training_examples(example_id)
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS cleaning_fingerprint
                    ON training_example_cleaning(fingerprint, status)
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS dataset_groups (
                    group_id TEXT PRIMARY KEY,
                    partition TEXT NOT NULL,
                    reservoir_slot INTEGER,
                    admitted_at TEXT NOT NULL,
                    evicted_at TEXT,
                    partition_version INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS dataset_rolling_slot
                    ON dataset_groups(reservoir_slot)
                 WHERE partition = 'validation_rolling'
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS dataset_partition_transitions (
                    transition_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    group_id TEXT NOT NULL,
                    from_partition TEXT,
                    to_partition TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    stream_version INTEGER NOT NULL,
                    evaluation_version INTEGER NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS dataset_partition_state (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    stream_version INTEGER NOT NULL,
                    evaluation_version INTEGER NOT NULL,
                    rolling_candidates_seen INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS collector_status (
                    collector_id TEXT PRIMARY KEY,
                    collector_kind TEXT NOT NULL,
                    state TEXT NOT NULL,
                    last_scan_at TEXT,
                    last_query_at TEXT,
                    last_observation_at TEXT,
                    last_success_at TEXT,
                    last_error TEXT,
                    cursor TEXT,
                    scan_count INTEGER NOT NULL DEFAULT 0,
                    observation_count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS si_paths (
                    path_id TEXT PRIMARY KEY,
                    architecture_id TEXT,
                    trial_configuration_id TEXT,
                    config_json TEXT NOT NULL UNIQUE,
                    latest_metrics_json TEXT,
                    last_evaluated_at TEXT,
                    archived_at TEXT,
                    archive_reason TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            path_columns = {
                row[1] for row in connection.execute("PRAGMA table_info(si_paths)")
            }
            if "archived_at" not in path_columns:
                connection.execute("ALTER TABLE si_paths ADD COLUMN archived_at TEXT")
            if "archive_reason" not in path_columns:
                connection.execute("ALTER TABLE si_paths ADD COLUMN archive_reason TEXT")
            if "architecture_id" not in path_columns:
                connection.execute("ALTER TABLE si_paths ADD COLUMN architecture_id TEXT")
            if "trial_configuration_id" not in path_columns:
                connection.execute(
                    "ALTER TABLE si_paths ADD COLUMN trial_configuration_id TEXT"
                )
            for physical_path_id, config_json in connection.execute(
                """
                SELECT path_id, config_json FROM si_paths
                 WHERE architecture_id IS NULL OR trial_configuration_id IS NULL
                """
            ).fetchall():
                architecture_id, _, trial_id, _ = _si_architecture_and_setting(
                    json.loads(config_json)
                )
                connection.execute(
                    """
                    UPDATE si_paths
                       SET architecture_id = ?, trial_configuration_id = ?
                     WHERE path_id = ?
                    """,
                    (architecture_id, trial_id, physical_path_id),
                )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS performance_tasks (
                    task_id TEXT PRIMARY KEY,
                    path_id TEXT NOT NULL REFERENCES si_paths(path_id),
                    state TEXT NOT NULL,
                    priority INTEGER NOT NULL DEFAULT 0,
                    worker_id TEXT,
                    metrics_json TEXT,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    updated_at TEXT NOT NULL,
                    dataset_revision INTEGER,
                    trigger_kind TEXT
                )
                """
            )
            performance_columns = {
                row[1]
                for row in connection.execute("PRAGMA table_info(performance_tasks)")
            }
            if "dataset_revision" not in performance_columns:
                connection.execute(
                    "ALTER TABLE performance_tasks ADD COLUMN dataset_revision INTEGER"
                )
            if "trigger_kind" not in performance_columns:
                connection.execute(
                    "ALTER TABLE performance_tasks ADD COLUMN trigger_kind TEXT"
                )
            if "dataset_snapshot_id" not in performance_columns:
                connection.execute(
                    "ALTER TABLE performance_tasks ADD COLUMN dataset_snapshot_id TEXT"
                )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS evaluation_dataset_snapshots (
                    snapshot_id TEXT PRIMARY KEY,
                    payload_json TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS dataset_example_versions (
                    version_id TEXT PRIMARY KEY, example_id TEXT NOT NULL, payload_json TEXT NOT NULL)"""
            )
            connection.execute(
                """CREATE TABLE IF NOT EXISTS dataset_versions (
                    version_id TEXT PRIMARY KEY, family TEXT NOT NULL,
                    manifest_json TEXT NOT NULL, created_at TEXT NOT NULL)"""
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS imported_example_time ON imported_training_examples(imported_at)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS cleaned_example_time ON training_example_cleaning(cleaned_at)"
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS evaluation_study_corpora (
                    run_id TEXT PRIMARY KEY,
                    corpus_revision TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS performance_task_queue
                    ON performance_tasks(state, priority DESC, created_at ASC)
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS performance_checkpoints (
                    task_id TEXT NOT NULL REFERENCES performance_tasks(task_id),
                    examples_seen INTEGER NOT NULL,
                    metrics_json TEXT NOT NULL,
                    recorded_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, examples_seen)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS runtime_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                INSERT OR IGNORE INTO runtime_settings (key, value, updated_at)
                VALUES ('si_inference_interval', '10', ?)
                """,
                (datetime.now(UTC).isoformat(),),
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS si_inference_batches (
                    dataset_revision INTEGER PRIMARY KEY,
                    state TEXT NOT NULL,
                    interval_size INTEGER NOT NULL,
                    evidence_mode TEXT NOT NULL DEFAULT 'measured',
                    created_at TEXT NOT NULL,
                    completed_at TEXT,
                    updated_at TEXT NOT NULL
                )
                """
            )
            inference_columns = {
                row[1]
                for row in connection.execute("PRAGMA table_info(si_inference_batches)")
            }
            if "evidence_mode" not in inference_columns:
                connection.execute(
                    """
                    ALTER TABLE si_inference_batches
                    ADD COLUMN evidence_mode TEXT NOT NULL DEFAULT 'synthetic_archived'
                    """
                )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS si_inference_batch_paths (
                    dataset_revision INTEGER NOT NULL
                        REFERENCES si_inference_batches(dataset_revision),
                    path_id TEXT NOT NULL REFERENCES si_paths(path_id),
                    PRIMARY KEY (dataset_revision, path_id)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS si_path_dataset_attachments (
                    path_id TEXT NOT NULL REFERENCES si_paths(path_id),
                    dataset_id TEXT NOT NULL,
                    attached_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (path_id, dataset_id)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS retrieval_architecture_enrollments (
                    architecture_id TEXT NOT NULL,
                    dataset_id TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'enrolled',
                    execution_backend TEXT,
                    enrolled_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (architecture_id, dataset_id)
                )
                """
            )
            enrollment_columns = {
                row[1]
                for row in connection.execute(
                    "PRAGMA table_info(retrieval_architecture_enrollments)"
                )
            }
            if "state" not in enrollment_columns:
                connection.execute(
                    "ALTER TABLE retrieval_architecture_enrollments "
                    "ADD COLUMN state TEXT NOT NULL DEFAULT 'enrolled'"
                )
            if "execution_backend" not in enrollment_columns:
                connection.execute(
                    "ALTER TABLE retrieval_architecture_enrollments "
                    "ADD COLUMN execution_backend TEXT"
                )
            inference_batch_count = connection.execute(
                """
                SELECT COUNT(*) FROM si_inference_batches
                 WHERE evidence_mode = 'measured'
                """
            ).fetchone()[0]
            if inference_batch_count == 0:
                current_revision = self._labeled_training_count(connection)
                now = datetime.now(UTC).isoformat()
                connection.execute(
                    """
                    INSERT INTO si_inference_batches (
                        dataset_revision, state, interval_size, evidence_mode,
                        created_at, completed_at, updated_at
                    ) VALUES (?, 'completed', 10, 'measured', ?, ?, ?)
                    """,
                    (current_revision, now, now, now),
                )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS performance_task_stages (
                    task_id TEXT NOT NULL REFERENCES performance_tasks(task_id),
                    stage_key TEXT NOT NULL,
                    stage_order INTEGER NOT NULL,
                    label TEXT NOT NULL,
                    state TEXT NOT NULL,
                    metrics_json TEXT,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, stage_key)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS performance_stage_checkpoints (
                    task_id TEXT NOT NULL,
                    stage_key TEXT NOT NULL,
                    examples_seen INTEGER NOT NULL,
                    metrics_json TEXT NOT NULL,
                    recorded_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, stage_key, examples_seen),
                    FOREIGN KEY (task_id, stage_key)
                        REFERENCES performance_task_stages(task_id, stage_key)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS implementation_training_cursors (
                    stage_key TEXT NOT NULL,
                    path_id TEXT NOT NULL,
                    setting_id TEXT NOT NULL,
                    dataset_id TEXT NOT NULL,
                    dataset_revision INTEGER NOT NULL,
                    next_index INTEGER NOT NULL,
                    checkpoint_id TEXT,
                    completed_updates INTEGER NOT NULL DEFAULT 0,
                    last_evaluated_update INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (stage_key, path_id, setting_id, dataset_id)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS training_tasks (
                    task_id TEXT PRIMARY KEY,
                    stage_key TEXT NOT NULL,
                    path_id TEXT NOT NULL,
                    setting_id TEXT NOT NULL,
                    dataset_id TEXT NOT NULL,
                    dataset_revision INTEGER NOT NULL,
                    range_start INTEGER NOT NULL,
                    range_end INTEGER NOT NULL,
                    input_checkpoint_id TEXT,
                    output_checkpoint_id TEXT,
                    state TEXT NOT NULL,
                    priority INTEGER NOT NULL DEFAULT 0,
                    worker_id TEXT,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    updated_at TEXT NOT NULL,
                    UNIQUE (
                        stage_key, path_id, setting_id, dataset_id,
                        range_start, range_end
                    )
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS training_task_queue
                    ON training_tasks(state, priority DESC, created_at ASC)
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS bayesian_tuning_runs (
                    run_id TEXT PRIMARY KEY,
                    state TEXT NOT NULL,
                    base_config_json TEXT NOT NULL,
                    search_space_json TEXT NOT NULL,
                    metric TEXT NOT NULL,
                    max_iterations INTEGER NOT NULL,
                    priority INTEGER NOT NULL DEFAULT 0,
                    best_score REAL,
                    best_config_json TEXT,
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS bayesian_tuning_observations (
                    run_id TEXT NOT NULL REFERENCES bayesian_tuning_runs(run_id),
                    iteration INTEGER NOT NULL,
                    task_id TEXT NOT NULL REFERENCES performance_tasks(task_id),
                    config_json TEXT NOT NULL,
                    state TEXT NOT NULL,
                    score REAL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (run_id, iteration),
                    UNIQUE (task_id)
                )
                """
            )
            connection.execute(
                """CREATE UNIQUE INDEX IF NOT EXISTS automatic_study_identity
                   ON bayesian_tuning_runs(json_extract(base_config_json, '$.automatic_study_key'))
                   WHERE json_extract(base_config_json, '$.automatic_study_key') IS NOT NULL"""
            )
            now = datetime.now(UTC).isoformat()
            connection.executemany(
                """
                INSERT OR IGNORE INTO collector_status (
                    collector_id, collector_kind, state, scan_count,
                    observation_count, updated_at
                ) VALUES (?, ?, 'idle', 0, 0, ?)
                """,
                (
                    ("pkm-live", "pkm_retrieval_events", now),
                    ("copilot-transcripts", "vscode_chat_transcripts", now),
                ),
            )
            connection.execute(
                """
                UPDATE collector_status
                   SET last_query_at = COALESCE(
                           last_query_at,
                           (SELECT MAX(occurred_at) FROM events
                             WHERE event_type = 'retrieval')
                       ),
                       last_observation_at = COALESCE(
                           last_observation_at,
                           (SELECT MAX(occurred_at) FROM events)
                       )
                 WHERE collector_id = 'pkm-live'
                """
            )
            connection.execute(
                """
                INSERT OR IGNORE INTO dataset_partition_state (
                    singleton, stream_version, evaluation_version,
                    rolling_candidates_seen
                ) VALUES (1, 0, 0, 0)
                """
            )
            for row in connection.execute(
                "SELECT path_id FROM si_paths WHERE latest_metrics_json IS NOT NULL"
            ).fetchall():
                self._archive_excess_implementations(connection, row[0], now=now)

    @staticmethod
    def _event_from_row(row: tuple[Any, ...]) -> dict[str, Any]:
        return {
            "event_id": row[0],
            "interaction_id": row[1],
            "event_type": row[2],
            "occurred_at": row[3],
            "received_at": row[4],
            "source_node_id": row[5],
            "observation_source": row[6],
            "schema_version": row[7],
            "corpus_snapshot_id": row[8],
            "payload": json.loads(row[9]),
        }


def replay_collected(store: CollectorStore) -> dict[str, Any]:
    events = store.events(limit=100_000)
    retrievals = {
        event["interaction_id"]: event
        for event in events
        if event["event_type"] == "retrieval"
    }
    final_hits: dict[str, str] = {}
    for event in events:
        if event["event_type"] != "skill_load":
            continue
        skill_id = event["payload"].get("skill", {}).get("skill_id")
        if skill_id:
            final_hits[event["interaction_id"]] = skill_id

    cases = []
    rankings: dict[str, list[str]] = {}
    historical_rankings: dict[str, list[str]] = {}
    for interaction_id, retrieval in retrievals.items():
        relevant = final_hits.get(interaction_id)
        snapshot_id = retrieval.get("corpus_snapshot_id")
        if not relevant or not snapshot_id:
            continue
        payload = retrieval["payload"]
        case = BenchmarkCase(
            case_id=interaction_id,
            domain=str(payload.get("domain") or "live"),
            language=str(payload.get("language") or "unknown"),
            query=str(payload.get("query") or ""),
            relevant_skill_ids=frozenset({relevant}),
        )
        snapshot = store.load_snapshot(snapshot_id)
        from .models import SkillDocument

        documents = [
            SkillDocument.create(
                skill_id=item["skill_id"],
                title=item["title"],
                description=item["description"],
                body=item["body"],
                metadata=item.get("metadata") or {},
            )
            for item in snapshot["skills"]
        ]
        route = academic_bm25_benchmark_route()
        route.retriever.index(documents)
        rankings[interaction_id] = [
            hit.skill_version.skill_id
            for hit in route.retriever.search(case.query, 5)
        ]
        historical_rankings[interaction_id] = [
            str(item["skill_id"])
            for item in payload.get("candidates", [])
            if item.get("skill_id")
        ]
        cases.append(case)

    if not cases:
        return {"cases": 0, "reason": "no linked retrieval and skill_load events"}
    return {
        "cases": len(cases),
        "reference": "historical final loaded Skill",
        "historical": asdict(evaluate_rankings(cases, historical_rankings, k=5)),
        "bm25_replay": asdict(evaluate_rankings(cases, rankings, k=5)),
        "case_results": {
            case.case_id: {
                "query": case.query,
                "reference_skill_id": next(iter(case.relevant_skill_ids)),
                "historical": historical_rankings[case.case_id],
                "bm25_replay": rankings[case.case_id],
            }
            for case in cases
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Replay collected PKM Skill interactions locally"
    )
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--snapshots-dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = replay_collected(
        CollectorStore(args.database, snapshots_dir=args.snapshots_dir)
    )
    payload = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    else:
        print(payload)


if __name__ == "__main__":
    main()