from __future__ import annotations

from enum import StrEnum

from .engine import RetrievalEngine
from .model_validation import ValidatedLocalModel
from .models import EmbeddingModelVersion, RouteState
from .perspectives import RetrievalPerspective
from .routes import academic_bm25_benchmark_route, embedding_route, exact_match_route


class EngineProfile(StrEnum):
    L1_ONLINE = "l1_online"
    L1_WEIGHTED = "l1_weighted"
    L1_L2_WEIGHTED = "l1_l2_weighted"


class EngineProfileUnavailableError(RuntimeError):
    pass


def build_engine(
    profile: EngineProfile | str,
    *,
    local_model: ValidatedLocalModel | None = None,
) -> RetrievalEngine:
    selected = EngineProfile(profile)
    if selected is EngineProfile.L1_ONLINE:
        return RetrievalEngine(
            [exact_match_route(), academic_bm25_benchmark_route()]
        )
    if selected is EngineProfile.L1_L2_WEIGHTED:
        raise EngineProfileUnavailableError(
            "l1_l2_weighted is not available: production L2 section retrieval "
            "must be implemented and measured before release"
        )
    if local_model is None:
        raise ValueError(
            "l1_weighted requires a validated local model bundle; "
            "runtime downloads are not allowed"
        )

    validation = local_model.validation
    model = EmbeddingModelVersion(
        provider="local",
        model=validation.model_id,
        revision=validation.revision,
        dimensions=validation.dimensions,
        query_prompt=validation.query_prompt,
        document_prompt=validation.document_prompt,
    )
    selector = RetrievalPerspective(
        name="none",
        field_repetitions={"title": 1, "description": 1, "body": 1},
    )
    return RetrievalEngine(
        [
            exact_match_route(),
            embedding_route(
                name="dense-l1",
                model=model,
                feature_selector=selector,
                embedder=local_model.embedder,
                state=RouteState.SERVING,
                revision=validation.bundle_sha256,
            ),
        ]
    )