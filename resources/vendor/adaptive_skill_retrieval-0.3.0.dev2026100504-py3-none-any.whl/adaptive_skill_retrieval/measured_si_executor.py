from __future__ import annotations

import argparse
import math
import logging
import multiprocessing
import subprocess
import sys
import socket
import sqlite3
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import asdict
from pathlib import Path
from threading import Event, Thread
from time import perf_counter, sleep
from typing import Any, Mapping, Sequence

from .architecture_retriever import ArchitectureRetriever
from .benchmark import BenchmarkCase, evaluate_rankings, load_pkm_skills
from .collector import CollectorStore
from .document_linkage import build_trajectory_links
from .engine import RetrievalEngine, Route
from .fusion import FusedHit
from .models import RouteState, SkillVersion
from .model_validation import local_model_bundle_fingerprint
from .profiles import EngineProfile, build_engine
from .retrieval_architectures import architecture_by_id
from .retrievers import SearchHit


def _parameter(
    config: Mapping[str, Any], name: str, legacy_name: str, default: float
) -> float:
    if name in config and legacy_name in config and config[name] != config[legacy_name]:
        raise ValueError(f"conflicting {name} and {legacy_name}")
    value = float(config.get(name, config.get(legacy_name, default)))
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def weighted_reciprocal_rank_fusion(
    route_hits: Mapping[str, Sequence[SearchHit]],
    route_weights: Mapping[str, float],
    *,
    limit: int,
    rank_constant: int = 60,
) -> list[FusedHit]:
    scores: dict[SkillVersion, float] = {}
    contributors: dict[SkillVersion, set[str]] = {}
    for route_key, hits in route_hits.items():
        weight = max(0.0, float(route_weights.get(route_key, 0.0)))
        for hit in hits:
            scores[hit.skill_version] = scores.get(hit.skill_version, 0.0) + (
                weight / (rank_constant + hit.rank)
            )
            contributors.setdefault(hit.skill_version, set()).add(route_key)
    ordered = sorted(
        scores,
        key=lambda version: (-scores[version], version.skill_id, version.content_hash),
    )
    return [
        FusedHit(
            skill_version=version,
            score=scores[version],
            rank=rank,
            contributing_routes=tuple(sorted(contributors[version])),
        )
        for rank, version in enumerate(ordered[:limit], start=1)
    ]


def update_route_weights(
    route_weights: Mapping[str, float],
    route_hits: Mapping[str, Sequence[SearchHit]],
    relevant_skill_ids: set[str] | frozenset[str],
    *,
    learning_rate: float,
) -> tuple[dict[str, float], dict[str, float]]:
    if learning_rate <= 0:
        raise ValueError("learning_rate must be positive")
    route_keys = sorted(set(route_weights) | set(route_hits))
    if not route_keys:
        raise ValueError("at least one retrieval route is required")
    current = _normalize_weights(route_weights, route_keys)
    rewards = {
        route_key: max(
            (
                1.0 / hit.rank
                for hit in route_hits.get(route_key, ())
                if hit.skill_version.skill_id in relevant_skill_ids
            ),
            default=0.0,
        )
        for route_key in route_keys
    }
    expected_reward = sum(current[key] * rewards[key] for key in route_keys)
    updated = {
        key: current[key] * math.exp(learning_rate * (rewards[key] - expected_reward))
        for key in route_keys
    }
    return _normalize_weights(updated, route_keys), rewards


def execute_measured(
    database: str | Path,
    task: Mapping[str, Any],
    *,
    pkm_root: str | Path,
    limit: int = 5,
) -> dict[str, Any]:
    store = CollectorStore(database, pkm_root=pkm_root)
    task_id = str(task["task_id"])
    config = dict(task.get("config") or {})
    revision = int(task.get("dataset_revision") or 0)
    interval = int(store.inference_interval_status()["interval"])
    heartbeat_stop = Event()

    def maintain_heartbeat() -> None:
        while not heartbeat_stop.wait(10):
            try:
                store.heartbeat_performance_task(task_id)
            except (LookupError, ValueError):
                return
            except sqlite3.OperationalError:
                continue

    store.heartbeat_performance_task(task_id)
    heartbeat_thread = Thread(target=maintain_heartbeat, daemon=True)
    heartbeat_thread.start()
    try:
        if config.get("execution_mode") != "measured":
            raise ValueError("measured executor only accepts execution_mode='measured'")
        if task.get("trigger_kind") not in {
            "labeled_training_interval",
            "bayesian_tuning",
        } or revision <= 0:
            raise ValueError("measured SI tasks require a labeled training revision")
        dataset = store.evaluation_dataset(task_id, require_current=True)
        training_rows = dataset["training"]
        validation_rows = dataset["validation_anchor"]
        if len(training_rows) < revision:
            raise ValueError(
                f"training revision {revision} requires {revision} labeled query groups; "
                f"only {len(training_rows)} are available"
            )
        if not validation_rows:
            raise ValueError("fixed validation_anchor has no labeled query groups")

        profile = EngineProfile(config.get("engine_profile", EngineProfile.L1_ONLINE))
        if profile is not EngineProfile.L1_ONLINE:
            raise ValueError(
                f"{profile.value} requires an explicit validated local model bundle"
            )
        architecture_id = str(config.get("retrieval_architecture_id") or "")
        corpus_load_started = perf_counter()
        documents, _ = load_pkm_skills(pkm_root)
        corpus_load_seconds = perf_counter() - corpus_load_started
        if not documents:
            raise ValueError("the measured corpus contains no Skill documents")
        engine_build_started = perf_counter()
        graph_retriever: ArchitectureRetriever | None = None
        if not architecture_id or architecture_id in {
            "bm25-document", "hybrid-exact-bm25-document"
        }:
            engine = build_engine(profile)
        else:
            architecture = architecture_by_id(architecture_id)
            if config.get("embedding_enabled") is not True:
                raise ValueError("embedding architectures require explicit embedding_enabled=true")
            for key in ("model", "reranker_model"):
                if key == "reranker_model" and "cross_encoder_section" not in architecture.operators:
                    continue
                if not config.get(key) or not config.get(f"{key}_bundle_sha256"):
                    raise ValueError(f"{key} requires a pinned local bundle and bundle_sha256")
                path, digest = local_model_bundle_fingerprint(config[key])
                if config[f"{key}_bundle_sha256"] != digest:
                    raise ValueError(f"{key} local bundle digest mismatch")
                config[key] = str(path)
            if "source_weight_learning_rate" in config or "learning_rate" in config:
                raise ValueError("this architecture does not implement internal weight learning")
            retriever = ArchitectureRetriever(
                architecture, config,
                graph_links=(),
            )
            if "typed_graph_expansion" in architecture.operators:
                graph_retriever = retriever
            engine = RetrievalEngine([
                Route(
                    identity=retriever.identity,
                    retriever=retriever,
                    state=RouteState.SERVING,
                )
            ])
        engine_build_seconds = perf_counter() - engine_build_started
        if architecture_id == "bm25-document":
            engine.routes = [
                route
                for route in engine.routes
                if route.identity.name == "bm25-academic-benchmark"
            ]
        bm25_k1 = float(config.get("bm25_k1", 0.9))
        bm25_b = float(config.get("bm25_b", 0.4))
        if bm25_k1 <= 0 or not 0 <= bm25_b <= 1:
            raise ValueError("measured BM25 requires k1 > 0 and 0 <= b <= 1")
        for route in engine.routes:
            if route.identity.name == "bm25-academic-benchmark":
                route.retriever.k1 = bm25_k1
                route.retriever.b = bm25_b
        index_started = perf_counter()
        corpus_revision = engine.index(documents)
        if config.get("tuning_run_id"):
            store.pin_study_corpus(str(config["tuning_run_id"]), corpus_revision)
        index_seconds = perf_counter() - index_started
        route_keys = [route.identity.key for route in engine.routes]
        supplied_weights = dict(config.get("route_weights", {}))
        for route in engine.routes:
            if route.identity.name == "exact-match":
                supplied_weights.setdefault(
                    route.identity.key, _parameter(config, "exact_route_weight", "exact_source_weight", 1.0)
                )
            elif route.identity.name == "bm25-academic-benchmark":
                supplied_weights.setdefault(
                    route.identity.key, _parameter(config, "bm25_route_weight", "lexical_source_weight", 1.0)
                )
        weights = _normalize_weights(supplied_weights, route_keys)
        learning_rate = _parameter(config, "learning_rate", "source_weight_learning_rate", 0.1)
        rank_constant = int(config.get("rank_constant", 60))
        if rank_constant <= 0:
            raise ValueError("rank_constant must be positive")
        weights_before = dict(weights)
        batch_start = max(0, revision - interval)
        training_lineage = []

        stage_keys = [stage["stage_key"] for stage in task.get("stages", ())]
        stage_key = stage_keys[-1] if stage_keys else "l1_document"
        for prerequisite in stage_keys[:-1]:
            store.start_performance_stage(task_id, prerequisite)
            store.finish_performance_stage(
                task_id, prerequisite, state="completed",
                metrics={
                    "execution_mode": "measured",
                    "retrieval_architecture_id": architecture_id,
                    "stage_role": "candidate_generation",
                },
            )
        store.start_performance_stage(task_id, stage_key)
        validation_cases = [_benchmark_case(row) for row in validation_rows]
        batch_size = revision - batch_start
        validation_hits: dict[str, dict[str, list[SearchHit]]] = {}
        validation_latency_ms: float | None = None
        validation_seconds = 0.0

        def validate_checkpoint(examples_seen: int) -> dict[str, Any]:
            nonlocal validation_latency_ms, validation_seconds
            rankings: dict[str, list[str]] = {}
            validation_lineage = []
            started = perf_counter()
            for row in validation_rows:
                query_id = str(row["query_id"])
                hits = validation_hits.get(query_id)
                if hits is None:
                    hits = _search_routes(engine, row["query"], limit=max(20, limit))
                    validation_hits[query_id] = hits
                fused = weighted_reciprocal_rank_fusion(
                    hits, weights, limit=limit, rank_constant=rank_constant
                )
                ranking = [hit.skill_version.skill_id for hit in fused]
                rankings[row["query_id"]] = ranking
                relevant = set(row["relevant_skill_ids"])
                validation_lineage.append(
                    {
                        "query_id": row["query_id"],
                        "source_example_ids": row["source_example_ids"],
                        "relevant_skill_ids": row["relevant_skill_ids"],
                        "ranking": ranking,
                        "correct_at_1": bool(ranking and ranking[0] in relevant),
                        "hit_at_k": bool(relevant.intersection(ranking)),
                    }
                )
                store.heartbeat_performance_task(task_id, stage_key=stage_key)
            validation_seconds += perf_counter() - started
            if validation_latency_ms is None:
                validation_latency_ms = (
                    (perf_counter() - started) * 1000 / len(validation_rows)
                )
            measured = asdict(
                evaluate_rankings(
                    validation_cases,
                    rankings,
                    k=limit,
                    latency_ms=validation_latency_ms,
                )
            )
            completed_in_batch = examples_seen - batch_start
            progress_percent = round(100 * completed_in_batch / batch_size, 2)
            metrics = {
                **measured,
                "execution_mode": "measured",
                "evidence_type": "real_query_retrieval",
                "retrieval_architecture_id": architecture_id or "legacy-custom",
                "dataset_revision": revision,
                "dataset_snapshot_id": dataset["snapshot_id"],
                "embedding_enabled": config.get("embedding_enabled") is True,
                "learning_rate": learning_rate,
                "training_batch_start": batch_start,
                "training_batch_size": batch_size,
                "training_examples_completed": completed_in_batch,
                "progress_percent": progress_percent,
                "training_query_ids": [
                    item["query_id"] for item in training_lineage
                ],
                "validation_partition": "validation_anchor",
                "validation_query_count": len(validation_rows),
                "corpus_revision": corpus_revision,
                "weights_before": weights_before,
                "weights_after": dict(weights),
                "rank_constant": rank_constant,
                "bm25_k1": bm25_k1,
                "bm25_b": bm25_b,
                "training_lineage": list(training_lineage),
                "validation_lineage": validation_lineage,
            }
            store.record_performance_stage_checkpoint(
                task_id, stage_key, examples_seen=examples_seen, metrics=metrics
            )
            store.record_performance_checkpoint(
                task_id, examples_seen=examples_seen, metrics=metrics
            )
            return metrics

        metrics: dict[str, Any] | None = None
        training_started = perf_counter()
        for index, row in enumerate(training_rows[:revision]):
            hits = _search_routes(engine, row["query"], limit=max(20, limit))
            if index == batch_start:
                weights_before = dict(weights)
                metrics = validate_checkpoint(batch_start)
            weights, rewards = update_route_weights(
                weights,
                hits,
                frozenset(row["relevant_skill_ids"]),
                learning_rate=learning_rate,
            )
            if graph_retriever is not None:
                graph_retriever.set_graph_links(
                    build_trajectory_links(training_rows[:index + 1], minimum_support=1)
                )
                validation_hits.clear()
                validation_latency_ms = None
            if index >= batch_start:
                training_lineage.append(
                    {
                        "query_id": row["query_id"],
                        "source_example_ids": row["source_example_ids"],
                        "relevant_skill_ids": row["relevant_skill_ids"],
                        "route_rewards": rewards,
                    }
                )
                metrics = validate_checkpoint(index + 1)
        if metrics is None:
            raise ValueError("measured training batch contains no examples")
        training_seconds = max(0.0, perf_counter() - training_started - validation_seconds)
        metrics = {
            **metrics,
            "startup_seconds": (
                corpus_load_seconds
                + engine_build_seconds
                + index_seconds
                + training_seconds
            ),
            "startup_components": {
                "corpus_load_seconds": corpus_load_seconds,
                "engine_build_seconds": engine_build_seconds,
                "index_seconds": index_seconds,
                "training_seconds": training_seconds,
            },
        }
        store.evaluation_dataset(task_id, require_current=True)
        store.finish_performance_stage(
            task_id, stage_key, state="completed", metrics=metrics
        )
        return store.finish_performance_task(
            task_id, state="completed", metrics=metrics
        )
    except Exception as error:
        current = next(
            (item for item in store.performance_tasks() if item["task_id"] == task_id),
            None,
        )
        if current is not None:
            for stage in current["stages"]:
                if stage["state"] == "running":
                    store.finish_performance_stage(
                        task_id, stage["stage_key"], state="failed", error=str(error)
                    )
            store.finish_performance_task(task_id, state="failed", error=str(error))
        raise
    finally:
        heartbeat_stop.set()
        heartbeat_thread.join(timeout=1)


def execute_isolated(
    database: str | Path, task: Mapping[str, Any], *, pkm_root: str | Path,
) -> None:
    log_dir = Path(database).parent / "task-logs"
    log_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    log_path = log_dir / f"{task['task_id']}.log"
    with log_path.open("xb") as output:
        try:
            subprocess.run(
                [sys.executable, "-m", "adaptive_skill_retrieval.measured_si_executor",
                 "--database", str(database), "--pkm-root", str(pkm_root),
                 "--task-id", str(task["task_id"])],
                stdout=output, stderr=subprocess.STDOUT, check=True, timeout=1800,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as error:
            raise RuntimeError(f"isolated SI worker failed: {error}; log: {log_path}") from error


def run_scheduler(
    database: str | Path,
    *,
    pkm_root: str | Path,
    once: bool = False,
    poll_seconds: float = 5.0,
    automatic: bool = False,
) -> int:
    if poll_seconds <= 0:
        raise ValueError("poll_seconds must be positive")
    store = CollectorStore(database, pkm_root=pkm_root)
    completed = 0
    if once:
        if automatic:
            store.recover_expired_performance_tasks()
            store.ensure_automatic_tuning()
        else:
            store.enqueue_due_inference_tasks()
        store.advance_bayesian_tuning()
        task = store.claim_performance_task(
            f"measured:{socket.gethostname()}", execution_mode="measured"
        )
        if task is None:
            return 0
        execute_measured(database, task, pkm_root=pkm_root)
        store.advance_bayesian_tuning()
        return 1

    pool: ProcessPoolExecutor | None = None
    pool_size = 0
    futures = set()
    task_ids = {}
    while True:
        configured_workers = int(store.bayesian_search_settings()["cpu_workers"])
        if pool is None or configured_workers != pool_size and not futures:
            if pool is not None:
                pool.shutdown()
            pool = (
                ProcessPoolExecutor(
                    max_workers=configured_workers,
                    mp_context=multiprocessing.get_context("spawn"),
                )
                if automatic else ProcessPoolExecutor(max_workers=configured_workers)
            )
            pool_size = configured_workers
        try:
            if automatic:
                recovered = store.recover_expired_performance_tasks()
                if recovered:
                    logging.getLogger(__name__).warning("Expired %d abandoned SI tasks", recovered)
                store.ensure_automatic_tuning()
            else:
                store.enqueue_due_inference_tasks()
            store.advance_bayesian_tuning()
        except sqlite3.OperationalError:
            sleep(poll_seconds)
            continue
        try:
            while len(futures) < pool_size:
                task = store.claim_performance_task(
                    f"measured:{socket.gethostname()}", execution_mode="measured"
                )
                if task is None:
                    break
                future = pool.submit(
                    execute_isolated if automatic else execute_measured,
                    database, task, pkm_root=pkm_root,
                )
                futures.add(future)
                task_ids[future] = task["task_id"]
        except sqlite3.OperationalError:
            sleep(poll_seconds)
            continue
        if not futures:
            sleep(poll_seconds)
            continue
        done, futures = wait(
            futures, timeout=poll_seconds, return_when=FIRST_COMPLETED
        )
        for future in done:
            task_id = task_ids.pop(future)
            try:
                future.result()
            except Exception as error:
                logging.getLogger(__name__).exception("SI worker failed for task %s", task_id)
                if automatic:
                    store.fail_running_performance_task(task_id, str(error))
                continue
            else:
                completed += 1


def _search_routes(engine, query: str, *, limit: int) -> dict[str, list[SearchHit]]:
    return {
        route.identity.key: route.retriever.search(query, limit)
        for route in engine.routes
    }


def _normalize_weights(
    supplied: Mapping[str, float], route_keys: Sequence[str]
) -> dict[str, float]:
    weights = {key: max(0.0, float(supplied.get(key, 1.0))) for key in route_keys}
    total = sum(weights.values())
    if total <= 0:
        return {key: 1.0 / len(route_keys) for key in route_keys}
    return {key: value / total for key, value in weights.items()}


def _benchmark_case(row: Mapping[str, Any]) -> BenchmarkCase:
    return BenchmarkCase(
        case_id=str(row["query_id"]),
        domain="live",
        language="unknown",
        query=str(row["query"]),
        relevant_skill_ids=frozenset(row["relevant_skill_ids"]),
        split="validation_anchor",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run measured real-data SI tasks")
    parser.add_argument("--database", required=True)
    parser.add_argument("--pkm-root", required=True)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--automatic", action="store_true", help="Create snapshot-bound studies automatically")
    parser.add_argument("--task-id", help="Execute one already-claimed task in an isolated process")
    parser.add_argument("--poll-seconds", type=float, default=5.0)
    args = parser.parse_args()
    if args.task_id:
        store = CollectorStore(args.database, pkm_root=args.pkm_root)
        with store._connect() as connection:
            task = store._performance_task(connection, args.task_id)
        execute_measured(args.database, task, pkm_root=args.pkm_root)
        return
    run_scheduler(
        args.database,
        pkm_root=args.pkm_root,
        once=args.once,
        poll_seconds=args.poll_seconds,
        automatic=args.automatic,
    )


if __name__ == "__main__":
    main()