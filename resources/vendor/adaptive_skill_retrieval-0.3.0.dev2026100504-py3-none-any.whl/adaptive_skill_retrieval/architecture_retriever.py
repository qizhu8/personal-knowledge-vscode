from __future__ import annotations

import math
import re
from collections import defaultdict
from typing import Any, Callable, Mapping, Protocol, Sequence

from .document_linkage import DocumentLink, expand_ranking_with_links
from .models import ExpertIdentity, SkillDocument
from .perspectives import RetrievalPerspective
from .retrieval_architectures import RetrievalArchitecture
from .retrievers import BM25Retriever, SearchHit, tokenize

_HEADING = re.compile(r"(?m)^#{1,6}\s+(.+?)\s*$")


class ArchitectureEncoder(Protocol):
    dimensions: int

    def encode_queries(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...

    def encode_tokens(self, texts: Sequence[str]) -> list[list[tuple[float, ...]]]: ...


class SentenceTransformerArchitectureEncoder:
    def __init__(
        self, model_name: str, *, device: str = "cpu",
        query_prompt: str = "", document_prompt: str = "",
    ) -> None:
        from sentence_transformers import SentenceTransformer

        self.model_name = model_name
        self.query_prompt = query_prompt
        self.document_prompt = document_prompt
        self._model = SentenceTransformer(model_name, device=device, local_files_only=True)
        get_dimensions = getattr(self._model, "get_embedding_dimension", None)
        if get_dimensions is None:
            get_dimensions = self._model.get_sentence_embedding_dimension
        dimensions = get_dimensions()
        if dimensions is None:
            raise ValueError(f"model {model_name!r} does not report embedding dimensions")
        self.dimensions = int(dimensions)

    def encode_queries(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._encode_sentences([self.query_prompt + text for text in texts])

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._encode_sentences([self.document_prompt + text for text in texts])

    def encode_tokens(self, texts: Sequence[str]) -> list[list[tuple[float, ...]]]:
        encoded = self._model.encode(
            list(texts), output_value="token_embeddings", convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [[_normalize(tuple(float(value) for value in vector)) for vector in item] for item in encoded]

    def _encode_sentences(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        encoded = self._model.encode(
            list(texts), normalize_embeddings=True, convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [tuple(float(value) for value in vector) for vector in encoded]


class SentenceTransformerCrossEncoder:
    def __init__(
        self,
        model_name: str,
        *,
        device: str = "cpu",
        max_length: int = 512,
        trust_remote_code: bool = False,
    ) -> None:
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        self._device = device
        self._max_length = max_length
        self._tokenizer = AutoTokenizer.from_pretrained(model_name, local_files_only=True)
        self._model = AutoModelForSequenceClassification.from_pretrained(
            model_name, trust_remote_code=trust_remote_code, local_files_only=True
        )
        self._model.to(device)
        self._model.eval()

    def __call__(self, query: str, texts: Sequence[str]) -> list[float]:
        if not texts:
            return []
        import torch

        inputs = self._tokenizer(
            [[query, text] for text in texts],
            padding=True,
            truncation=True,
            return_tensors="pt",
            max_length=self._max_length,
        )
        inputs = {name: value.to(self._device) for name, value in inputs.items()}
        with torch.no_grad():
            scores = self._model(**inputs, return_dict=True).logits.view(-1).float()
        return [float(score) for score in scores.tolist()]


class ArchitectureRetriever:
    """Execute a registry architecture and return document-level ranked hits."""

    def __init__(
        self,
        architecture: RetrievalArchitecture,
        config: Mapping[str, Any],
        *,
        encoder: ArchitectureEncoder | None = None,
        reranker: Callable[[str, Sequence[str]], Sequence[float]] | None = None,
        graph_links: Sequence[DocumentLink] = (),
    ) -> None:
        self.architecture = architecture
        self.config = dict(config)
        self.identity = ExpertIdentity(
            name=architecture.architecture_id,
            perspective="architecture-v1",
            revision="operators=" + "+".join(architecture.operators),
        )
        self._encoder = encoder
        self._reranker = reranker
        self._graph_links = tuple(graph_links)
        self._documents: list[SkillDocument] = []
        self._units: list[tuple[int, str]] = []
        self._document_vectors: list[tuple[float, ...]] = []
        self._unit_vectors: list[tuple[float, ...]] = []
        self._token_vectors: list[list[tuple[float, ...]]] = []
        self._pca: Any | None = None
        self._bm25: BM25Retriever | None = None

    def set_graph_links(self, links: Sequence[DocumentLink]) -> None:
        self._graph_links = tuple(links)

    def index(self, documents: Sequence[SkillDocument]) -> None:
        self._documents = list(documents)
        operators = set(self.architecture.operators)
        if "bm25" in operators:
            perspective = RetrievalPerspective(
                name="architecture-bm25", field_repetitions={"title": 1, "description": 1, "body": 1}
            )
            self._bm25 = BM25Retriever(
                self.identity, perspective,
                k1=float(self.config.get("bm25_k1", 0.9)),
                b=float(self.config.get("bm25_b", 0.4)),
            )
            self._bm25.index(self._documents)
        if not operators.intersection({"dense_encoder", "dense_document", "dense_section", "token_encoder"}):
            return
        encoder = self._get_encoder()
        document_texts = [_document_text(document) for document in self._documents]
        self._document_vectors = encoder.encode_documents(document_texts)
        if self.architecture.output_granularity == "markdown_section":
            self._units = [
                (index, section)
                for index, document in enumerate(self._documents)
                for section in _sections(document)
            ]
        else:
            self._units = list(enumerate(document_texts))
        if "token_encoder" in operators:
            self._token_vectors = encoder.encode_tokens([text for _, text in self._units])
            if "residual_compression" in operators:
                bits = int(self.config.get("compression_bits", 2))
                self._token_vectors = [
                    [_quantize(vector, bits) for vector in vectors]
                    for vectors in self._token_vectors
                ]
            return
        self._unit_vectors = encoder.encode_documents([text for _, text in self._units])
        if "pca_projection" in operators:
            self._fit_pca(self._document_vectors + self._unit_vectors)
            self._document_vectors = self._project(self._document_vectors)
            self._unit_vectors = self._project(self._unit_vectors)

    def search(self, query: str, limit: int) -> list[SearchHit]:
        if limit <= 0 or not self._documents:
            return []
        operators = set(self.architecture.operators)
        if "token_encoder" in operators:
            ranked = self._late_interaction(query)
        elif "cross_encoder_section" in operators:
            ranked = self._cross_encoder(query)
        else:
            ranked = self._dense(query)
        if "bm25" in operators and self._bm25 is not None:
            lexical = [hit.skill_version.skill_id for hit in self._bm25.search(query, max(limit, 20))]
            ranked = _weighted_rrf(
                ranked, lexical,
                float(self.config.get("dense_source_weight", 1.0)),
                float(self.config.get("lexical_source_weight", 1.0)),
                int(self.config.get("rank_constant", 60)),
            )
        if "typed_graph_expansion" in operators:
            ranked = expand_ranking_with_links(
                ranked, self._graph_links, limit=max(limit, len(ranked)),
                minimum_confidence=float(self.config.get("graph_minimum_confidence", 0.5)),
            )
        versions = {document.version.skill_id: document.version for document in self._documents}
        return [
            SearchHit(versions[skill_id], 1.0 / rank, rank, self.identity.key)
            for rank, skill_id in enumerate(ranked[:limit], start=1)
            if skill_id in versions
        ]

    def _dense(self, query: str) -> list[str]:
        query_vector = self._get_encoder().encode_queries([query])[0]
        if self._pca is not None:
            query_vector = self._project([query_vector])[0]
        if self.architecture.output_granularity == "markdown_section":
            unit_scores = _scores(query_vector, self._unit_vectors)
            document_scores: dict[int, float] = defaultdict(lambda: -math.inf)
            for (document_index, _), score in zip(self._units, unit_scores, strict=True):
                document_scores[document_index] = max(document_scores[document_index], score)
            if "candidate_filter" in self.architecture.operators:
                candidates = set(self._document_candidates(query_vector))
                document_scores = {index: score for index, score in document_scores.items() if index in candidates}
            return self._ordered(document_scores)
        return self._ordered(dict(enumerate(_scores(query_vector, self._document_vectors))))

    def _cross_encoder(self, query: str) -> list[str]:
        query_vector = self._get_encoder().encode_queries([query])[0]
        if self._pca is not None:
            query_vector = self._project([query_vector])[0]
        candidates = set(self._document_candidates(query_vector))
        selected = [(index, text) for index, text in self._units if index in candidates]
        reranker = self._get_reranker()
        scores = reranker(query, [text for _, text in selected])
        document_scores: dict[int, float] = defaultdict(lambda: -math.inf)
        for (document_index, _), score in zip(selected, scores, strict=True):
            document_scores[document_index] = max(document_scores[document_index], float(score))
        return self._ordered(document_scores)

    def _late_interaction(self, query: str) -> list[str]:
        query_tokens = self._get_encoder().encode_tokens([query])[0]
        candidate_tokens = int(self.config.get("candidate_tokens", 64))
        document_scores: dict[int, float] = defaultdict(lambda: -math.inf)
        for (document_index, _), vectors in zip(self._units, self._token_vectors, strict=True):
            vectors = vectors[:candidate_tokens]
            score = sum(max((_dot(query_vector, vector) for vector in vectors), default=0.0) for query_vector in query_tokens)
            document_scores[document_index] = max(document_scores[document_index], score)
        return self._ordered(document_scores)

    def _document_candidates(self, query_vector: Sequence[float]) -> list[int]:
        count = int(self.config.get("rerank_candidates", 20))
        scores = _scores(query_vector, self._document_vectors)
        return sorted(range(len(scores)), key=lambda index: (-scores[index], self._documents[index].version.skill_id))[:count]

    def _ordered(self, scores: Mapping[int, float]) -> list[str]:
        return [
            self._documents[index].version.skill_id
            for index in sorted(scores, key=lambda item: (-scores[item], self._documents[item].version.skill_id))
        ]

    def _get_encoder(self) -> ArchitectureEncoder:
        if self._encoder is None:
            self._encoder = SentenceTransformerArchitectureEncoder(
                str(self.config["model"]), device=str(self.config.get("device", "cpu")),
                query_prompt=str(self.config.get("query_prompt", "")),
                document_prompt=str(self.config.get("document_prompt", "")),
            )
        return self._encoder

    def _get_reranker(self) -> Callable[[str, Sequence[str]], Sequence[float]]:
        if self._reranker is None:
            self._reranker = SentenceTransformerCrossEncoder(
                str(self.config["reranker_model"]),
                device=str(
                    self.config.get(
                        "reranker_device", self.config.get("device", "cpu")
                    )
                ),
                max_length=int(self.config.get("reranker_max_length", 512)),
                trust_remote_code=bool(
                    self.config.get("reranker_trust_remote_code", True)
                ),
            )
        return self._reranker

    def _fit_pca(self, vectors: Sequence[Sequence[float]]) -> None:
        ratio = float(self.config.get("retained_dimension_ratio", 1.0))
        if ratio >= 1.0 or not vectors:
            return
        import numpy as np
        from sklearn.decomposition import PCA

        components = max(1, min(len(vectors), len(vectors[0]), round(len(vectors[0]) * ratio)))
        self._pca = PCA(n_components=components, svd_solver="full").fit(np.asarray(vectors))

    def _project(self, vectors: Sequence[Sequence[float]]) -> list[tuple[float, ...]]:
        if self._pca is None:
            return [tuple(vector) for vector in vectors]
        import numpy as np

        return [_normalize(tuple(float(value) for value in row)) for row in self._pca.transform(np.asarray(vectors))]


def _document_text(document: SkillDocument) -> str:
    metadata = " ".join(document.metadata.values())
    return f"{document.title}\n{document.description}\n{metadata}\n{document.body}".strip()


def _sections(document: SkillDocument) -> list[str]:
    matches = list(_HEADING.finditer(document.body))
    prefix = f"{document.title}\n{document.description}".strip()
    if not matches:
        return [f"{prefix}\n{document.body}".strip()]
    sections = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(document.body)
        sections.append(f"{prefix}\n{document.body[match.start():end]}".strip())
    return sections


def _scores(query: Sequence[float], vectors: Sequence[Sequence[float]]) -> list[float]:
    return [_dot(query, vector) for vector in vectors]


def _dot(left: Sequence[float], right: Sequence[float]) -> float:
    return sum(a * b for a, b in zip(left, right))


def _normalize(vector: Sequence[float]) -> tuple[float, ...]:
    norm = math.sqrt(sum(value * value for value in vector))
    return tuple(value / norm for value in vector) if norm else tuple(vector)


def _quantize(vector: Sequence[float], bits: int) -> tuple[float, ...]:
    if bits not in {1, 2, 4}:
        raise ValueError("compression_bits must be 1, 2, or 4")
    peak = max((abs(value) for value in vector), default=0.0)
    if peak == 0:
        return tuple(vector)
    levels = 2 ** (bits - 1) - 1 if bits > 1 else 1
    quantized = tuple(round(value / peak * levels) / levels * peak for value in vector)
    return _normalize(quantized)


def _weighted_rrf(dense: Sequence[str], lexical: Sequence[str], dense_weight: float, lexical_weight: float, rank_constant: int) -> list[str]:
    if rank_constant <= 0:
        raise ValueError("rank_constant must be positive")
    scores: dict[str, float] = defaultdict(float)
    for weight, ranking in ((dense_weight, dense), (lexical_weight, lexical)):
        for rank, skill_id in enumerate(ranking, start=1):
            scores[skill_id] += max(0.0, weight) / (rank_constant + rank)
    return sorted(scores, key=lambda item: (-scores[item], item))
