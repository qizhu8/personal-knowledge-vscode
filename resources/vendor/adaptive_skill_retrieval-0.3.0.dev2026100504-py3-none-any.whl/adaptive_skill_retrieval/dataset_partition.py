from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256


@dataclass(frozen=True)
class PartitionDecision:
    group_id: str
    partition: str
    reservoir_slot: int | None = None
    evicted_group_id: str | None = None
    rolling_candidate: bool = False


class BoundedEvaluationSampler:
    def __init__(
        self,
        *,
        evaluation_ratio: float = 0.1,
        anchor_capacity: int = 200,
        rolling_capacity: int = 800,
        seed: str = "adaptive-retrieval-eval-v1",
    ) -> None:
        if not 0.0 <= evaluation_ratio <= 1.0:
            raise ValueError("evaluation_ratio must be between 0 and 1")
        if anchor_capacity < 0 or rolling_capacity < 0:
            raise ValueError("evaluation capacities must be non-negative")
        self.evaluation_ratio = evaluation_ratio
        self.anchor_capacity = anchor_capacity
        self.rolling_capacity = rolling_capacity
        self.seed = seed

    @property
    def evaluation_capacity(self) -> int:
        return self.anchor_capacity + self.rolling_capacity

    def assign(
        self,
        group_id: str,
        *,
        existing_partition: str | None,
        anchor_count: int,
        rolling_slots: dict[int, str],
        rolling_candidates_seen: int,
    ) -> PartitionDecision:
        group_id = group_id.strip()
        if not group_id:
            raise ValueError("group_id is required")
        if existing_partition is not None:
            return PartitionDecision(group_id, existing_partition)
        if not self._selected(group_id, "admission", self.evaluation_ratio):
            return PartitionDecision(group_id, "training")
        if anchor_count < self.anchor_capacity:
            return PartitionDecision(group_id, "validation_anchor")
        if self.rolling_capacity == 0:
            return PartitionDecision(group_id, "training")

        if len(rolling_slots) < self.rolling_capacity:
            slot = min(set(range(self.rolling_capacity)) - rolling_slots.keys())
            return PartitionDecision(
                group_id, "validation_rolling", slot, rolling_candidate=True
            )

        candidate_number = rolling_candidates_seen + 1
        slot = self._integer(group_id, "replacement", candidate_number)
        if slot >= self.rolling_capacity:
            return PartitionDecision(group_id, "training", rolling_candidate=True)
        return PartitionDecision(
            group_id,
            "validation_rolling",
            slot,
            rolling_slots[slot],
            True,
        )

    def _selected(self, group_id: str, purpose: str, probability: float) -> bool:
        maximum = 2**256
        return self._hash(group_id, purpose) < int(probability * maximum)

    def _integer(self, group_id: str, purpose: str, upper_bound: int) -> int:
        if upper_bound <= 0:
            raise ValueError("upper_bound must be positive")
        return self._hash(group_id, purpose) % upper_bound

    def _hash(self, group_id: str, purpose: str) -> int:
        payload = f"{self.seed}\0{purpose}\0{group_id}".encode("utf-8")
        return int.from_bytes(sha256(payload).digest(), "big")