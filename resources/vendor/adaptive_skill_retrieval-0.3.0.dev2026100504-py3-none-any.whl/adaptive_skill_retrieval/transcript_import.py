from __future__ import annotations

import argparse
from hashlib import sha256
import json
import logging
import os
import re
import time
from collections.abc import Iterable, Iterator
from pathlib import Path
from urllib.request import Request, urlopen


SECRET_PATTERNS = (
    re.compile(r"(?i)(bearer\s+)[a-z0-9._~+/-]{12,}"),
    re.compile(r"(?i)((?:api[_-]?key|token|password|secret)\s*[:=]\s*)[^\s,;]+"),
    re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,})\b"),
)
GREP_TOOLS = {"grep_search", "functions.grep_search"}
READ_TOOLS = {"read_file", "functions.read_file"}
SEARCH_ADAPTERS = {
    "rg": ("pattern", "file_or_section", "lexical"),
    "glob": ("pattern", "file", "filename"),
    "tool_search_tool": ("query", "function_api", "semantic"),
    "grep_search": ("query", "file_or_section", "lexical"),
    "functions.grep_search": ("query", "file_or_section", "lexical"),
    "file_search": ("query", "file", "filename"),
    "semantic_search": ("query", "code_or_document", "semantic"),
    "tool_search": ("query", "function_api", "semantic"),
    "mcp_pkm_skill_context": ("task", "skill", "fuzzy"),
    "mcp_pkm_search_skills": ("query", "skill", "fuzzy"),
    "mcp_uone-knowledg_search_skills": ("query", "skill", "fuzzy"),
    "mcp_pkm_search_notes": ("query", "note", "fuzzy"),
    "mcp_pkm_search_papers": ("query", "paper", "fuzzy"),
    "mcp_pkm_recipe_search": ("query", "recipe", "fuzzy"),
    "mcp_pkm_search_subscribed_content": ("query", "knowledge", "fuzzy"),
    "mcp_pkm_search_knowledge": ("query", "knowledge", "fuzzy"),
    "mcp_pkm2_skill_context": ("task", "skill", "fuzzy"),
    "mcp_pkm2_search_skills": ("query", "skill", "fuzzy"),
    "mcp_pkm2_search_notes": ("query", "note", "fuzzy"),
    "mcp_pkm2_search_papers": ("query", "paper", "fuzzy"),
    "mcp_pkm2_recipe_search": ("query", "recipe", "fuzzy"),
    "mcp_pkm2_search_subscribed_content": ("query", "knowledge", "fuzzy"),
    "mcp_pkm2_search_knowledge": ("query", "knowledge", "fuzzy"),
    "mcp_bluebird_code_search": ("query", "code_or_api", "remote_code"),
    "mcp_bluebird_project_search": ("query", "project_document", "remote_project"),
    "github_text_search": ("query", "code", "remote_code"),
    "vscode_listCodeUsages": ("symbol", "function_api", "symbol"),
    "mcp_notion_mcp_notion-search": ("query", "note", "remote_knowledge"),
}
GET_RESOURCE_TOOLS = {
    "mcp_pkm_get_skill": ("name", "skill"),
    "mcp_pkm_get_note": ("slug", "note"),
    "mcp_pkm_get_paper": ("slug", "paper"),
    "mcp_pkm2_get_skill": ("name", "skill"),
    "mcp_pkm2_get_note": ("slug", "note"),
    "mcp_pkm2_get_paper": ("slug", "paper"),
}
RECIPE_RUN_START_TOOLS = {
    "mcp_pkm_recipe_run_start",
    "mcp_pkm2_recipe_run_start",
    "mcp_pkm2_recipe_run_start_adhoc",
}


def redact_text(value: str) -> str:
    redacted = value
    for pattern in SECRET_PATTERNS:
        redacted = pattern.sub(lambda match: f"{match.group(1) if match.lastindex else ''}[REDACTED]", redacted)
    return redacted


def transcript_examples(paths: Iterable[Path]) -> Iterator[dict[str, object]]:
    seen: set[str] = set()
    for path in sorted(paths):
        records = _read_records(path)
        successful = {
            str(record.get("data", {}).get("toolCallId"))
            for record in records
            if record.get("type") == "tool.execution_complete"
            and record.get("data", {}).get("success") is True
        }
        latest_user: dict[str, object] | None = None
        transcript_id = path.stem
        for record in records:
            if record.get("type") == "user.message":
                latest_user = record
                continue
            data = record.get("data")
            if (
                record.get("type") != "tool.execution_start"
                or not isinstance(data, dict)
                or data.get("toolName") not in GREP_TOOLS
            ):
                continue
            tool_call_id = str(data.get("toolCallId") or "").strip()
            if not tool_call_id or tool_call_id in seen:
                continue
            seen.add(tool_call_id)
            arguments = data.get("arguments")
            if not isinstance(arguments, dict):
                arguments = {}
            user_data = latest_user.get("data", {}) if latest_user else {}
            user_content = (
                user_data.get("content", "") if isinstance(user_data, dict) else ""
            )
            user_record_id = str(latest_user.get("id")) if latest_user else "unlinked"
            yield {
                "example_id": f"copilot-grep:{tool_call_id}",
                "group_id": (
                    f"copilot-transcript:{transcript_id}:user:{user_record_id}"
                ),
                "query": redact_text(str(user_content))[:16_000],
                "tool_name": "grep_search",
                "tool_arguments": {
                    str(key): redact_text(str(value)) if isinstance(value, str) else value
                    for key, value in arguments.items()
                },
                "lifecycle": "planning_only",
                "execution_success": tool_call_id in successful,
                "occurred_at": str(record.get("timestamp") or ""),
                "session_id": transcript_id,
                "source": {
                    "provider": "github_copilot",
                    "kind": "vscode_chat_transcript",
                    "record_id": tool_call_id,
                    "transcript_id": transcript_id,
                    "transcript_record_id": str(record.get("id") or ""),
                    "parent_id": str(record.get("parentId") or ""),
                },
                "label_provenance": {
                    "query": "human_user_turn" if latest_user else "unavailable",
                    "tool_plan": "github_copilot",
                    "execution_status": "vscode_tool_completion",
                    "retrieval_results": "unavailable",
                    "relevance": "unavailable",
                },
            }


def replay_skill_grep(arguments: dict[str, object], skill_root: Path) -> list[str]:
    query = str(arguments.get("query") or "")
    if not query:
        return []
    try:
        pattern = re.compile(
            query if arguments.get("isRegexp") else re.escape(query), re.IGNORECASE
        )
    except re.error:
        return []
    maximum = max(1, int(arguments.get("maxResults") or 100))
    ranked: list[str] = []
    matches = 0
    for path in sorted(skill_root.rglob("*.md")):
        relative = path.relative_to(skill_root)
        if any(part.startswith((".", "_")) for part in relative.parts):
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeError):
            continue
        file_matches = sum(bool(pattern.search(line)) for line in lines)
        if not file_matches:
            continue
        ranked.append(relative.with_suffix("").as_posix())
        matches += file_matches
        if matches >= maximum:
            break
    return ranked


def trajectory_examples(
    paths: Iterable[Path], *, skill_root: Path
) -> Iterator[dict[str, object]]:
    for path in sorted(paths):
        records = _read_records(path)
        completions = {
            str(record.get("data", {}).get("toolCallId")): record["data"]
            for record in records
            if record.get("type") == "tool.execution_complete"
        }
        successful = {
            str(record.get("data", {}).get("toolCallId"))
            for record in records
            if record.get("type") == "tool.execution_complete"
            and record.get("data", {}).get("success") is True
        }
        turns: list[tuple[dict[str, object], list[dict[str, object]]]] = []
        user_record: dict[str, object] | None = None
        actions: list[dict[str, object]] = []
        for record in records:
            if record.get("type") == "user.message":
                if user_record is not None:
                    turns.append((user_record, actions))
                user_record, actions = record, []
            elif user_record is not None:
                actions.append(record)
        if user_record is not None:
            turns.append((user_record, actions))

        for user, turn_records in turns:
            actions = [_tool_action(record) for record in turn_records]
            actions = [action for action in actions if action is not None]
            narrative = "\n".join(
                str(record.get("data", {}).get("content") or "")
                for record in turn_records
                if record.get("type") == "assistant.message"
            )
            user_data = user.get("data")
            content = user_data.get("content", "") if isinstance(user_data, dict) else ""
            user_id = str(user.get("id") or "unlinked")
            transcript_id = path.parent.name if path.name == "events.jsonl" else path.stem
            for action_index, action in enumerate(actions):
                adapter = SEARCH_ADAPTERS.get(action["tool_name"])
                if adapter is None:
                    continue
                query_field, resource_type, baseline_family = adapter
                resource_type = _search_resource_type(action, skill_root)
                query = str(action["arguments"].get(query_field) or "").strip()
                if not query or not action["tool_call_id"]:
                    continue
                captured = _captured_ranking(completions.get(action["tool_call_id"], {}))
                if captured is None:
                    candidates, replay_scope = _replay_search(
                        action["tool_name"], action["arguments"], skill_root
                    )
                else:
                    candidates = [item["resource_id"] for item in captured]
                    replay_scope = "captured_search_output"
                next_search = next(
                    (
                        index for index in range(action_index + 1, len(actions))
                        if _search_resource_type(actions[index], skill_root)
                        == resource_type
                    ),
                    len(actions),
                )
                consumed = _consumed_resources(
                    [
                        item for item in actions[action_index + 1 : next_search]
                        if item["tool_call_id"] in successful
                        and action["tool_call_id"] in successful
                    ], skill_root,
                    resource_type=resource_type,
                )
                relevant = [resource["resource_id"] for resource in consumed]
                relevant = list(dict.fromkeys(relevant))
                succeeded = action["tool_call_id"] in successful
                observed_zero_hits = (
                    succeeded
                    and replay_scope in {
                        "current_corpus_replay", "current_pkm_worker_replay",
                        "current_recipe_catalog_replay",
                    }
                    and not candidates
                )
                no_match = False
                relevance = (
                    "agent_trajectory_consumption"
                    if relevant
                    else "unavailable"
                )
                dataset_partition, split_policy = _dataset_partition(
                    transcript_id=transcript_id,
                    example_id=f"copilot-search:{action['tool_call_id']}",
                    resource_type=resource_type,
                    relevance=relevance,
                )
                yield {
                    "example_id": f"copilot-search:{action['tool_call_id']}",
                    "group_id": f"copilot-search:{action['tool_call_id']}",
                    "query": redact_text(query)[:16_000],
                    "query_context": redact_text(str(content))[:16_000],
                    "tool_name": action["tool_name"],
                    "tool_arguments": _redact_mapping(action["arguments"]),
                    "resource_type": resource_type,
                    "baseline_family": baseline_family,
                    "query_intent": _query_intent(
                        baseline_family, action["arguments"]
                    ),
                    "lifecycle": "complete" if relevant else "no_match" if no_match else "ambiguous",
                    "execution_success": succeeded,
                    "occurred_at": action["timestamp"],
                    "session_id": transcript_id,
                    "split_group_id": f"copilot-transcript:{transcript_id}",
                    "turn_id": user_id,
                    "dataset_partition": dataset_partition,
                    "split_policy": split_policy,
                    "relevant_skill_ids": relevant,
                    "relevant_resource_ids": relevant,
                    "relevant_not_in_replay": [
                        resource_id for resource_id in relevant
                        if resource_id not in set(candidates)
                    ],
                    "consumption_evidence": [
                        resource for resource in consumed
                        if resource["resource_id"] in set(relevant)
                    ],
                    "final_ranking": captured if captured is not None else [
                        {"skill_id": candidate, "resource_id": candidate, "rank": rank}
                        for rank, candidate in enumerate(candidates, start=1)
                    ],
                    "no_match": no_match,
                    "observed_zero_hits": observed_zero_hits,
                    "replay_scope": replay_scope,
                    "narrative_candidate_mentions": [
                        candidate for candidate in candidates if candidate in narrative
                    ],
                    "source": {
                        "provider": "github_copilot",
                        "kind": "vscode_search_call_trajectory",
                        "record_id": action["tool_call_id"],
                        "transcript_id": transcript_id,
                        "user_turn_id": user_id,
                    },
                    "label_provenance": {
                        "query": "agent_search_function_argument",
                        "query_field": query_field,
                        "tool_plan": "github_copilot",
                        "retrieval_results": replay_scope,
                        "relevance": relevance,
                        "relevance_evidence": "candidate_intersection_with_downstream_consumption",
                    },
                }


def _tool_action(record: dict[str, object]) -> dict[str, object] | None:
    data = record.get("data")
    if record.get("type") != "tool.execution_start" or not isinstance(data, dict):
        return None
    arguments = data.get("arguments")
    tool_name = str(data.get("toolName") or "").removeprefix("functions.")
    if tool_name.startswith("pkm-"):
        tool_name = "mcp_pkm_" + tool_name[4:]
    elif tool_name.startswith("Agency--bluebird-"):
        tool_name = "mcp_bluebird_" + tool_name[len("Agency--bluebird-"):]
    if tool_name == "view" and isinstance(arguments, dict):
        view_range = arguments.get("view_range") or [None, None]
        arguments = {
            "filePath": arguments.get("path"),
            "startLine": view_range[0], "endLine": view_range[-1],
        }
        tool_name = "read_file"
    return {
        "tool_name": tool_name,
        "tool_call_id": str(data.get("toolCallId") or ""),
        "arguments": arguments if isinstance(arguments, dict) else {},
        "timestamp": str(record.get("timestamp") or ""),
    }


def _captured_ranking(completion: dict[str, object]) -> list[dict[str, object]] | None:
    if completion.get("success") is not True:
        return None
    result = completion.get("result")
    if not isinstance(result, dict):
        return None
    payload = result.get("structuredContent")
    if payload is None and isinstance(result.get("content"), str):
        try:
            payload = json.loads(result["content"])
        except json.JSONDecodeError:
            return None
    if isinstance(payload, dict):
        if payload.get("ok") is False or payload.get("incomplete") or payload.get("stale"):
            return None
        payload = next(
            (payload[key] for key in ("hits", "skills", "candidates") if key in payload),
            None,
        )
    if not isinstance(payload, list):
        return None
    ranking = []
    for rank, item in enumerate(payload, start=1):
        if not isinstance(item, dict):
            return None
        resource_id = item.get("resource_id") or item.get("skill_id") or item.get("recipe_id") or item.get("slug")
        if not isinstance(resource_id, str) or not resource_id:
            return None
        ranking.append({
            "skill_id": resource_id, "resource_id": resource_id, "rank": rank,
            "content_hash": str(item.get("content_hash") or ""),
        })
    return ranking


def _search_resource_type(action: dict[str, object], skill_root: Path) -> str | None:
    adapter = SEARCH_ADAPTERS.get(str(action["tool_name"]))
    if adapter is None:
        return None
    resource_type = adapter[1]
    if action["tool_name"] not in GREP_TOOLS:
        return resource_type
    arguments = action["arguments"]
    assert isinstance(arguments, dict)
    include_pattern = str(arguments.get("includePattern") or "")
    roots = {
        "skill": skill_root,
        "note": skill_root.parent / "notes",
        "paper": skill_root.parent / "papers",
        "script": skill_root.parent / "scripts",
    }
    return next(
        (kind for kind, root in roots.items() if str(root) in include_pattern),
        resource_type,
    )


def _consumed_resources(
    actions: list[dict[str, object]], skill_root: Path, *, resource_type: str
) -> list[dict[str, str]]:
    consumed: list[dict[str, str]] = []
    for action in actions:
        tool_name = str(action["tool_name"])
        arguments = action["arguments"]
        assert isinstance(arguments, dict)
        if resource_type == "function_api" and tool_name not in SEARCH_ADAPTERS:
            consumed.append(
                {"resource_id": tool_name, "evidence": "subsequent_tool_invocation"}
            )
            continue
        if resource_type == "recipe" and tool_name in RECIPE_RUN_START_TOOLS:
            recipe_id = str(arguments.get("recipe_id") or "").strip()
            if recipe_id:
                consumed.append(
                    {"resource_id": recipe_id, "evidence": "recipe_run_start"}
                )
            continue
        if tool_name in READ_TOOLS:
            resource_id = _resource_id_from_path(
                arguments.get("filePath"), skill_root, resource_type
            )
            if resource_id:
                consumed.append(
                    {
                        "resource_id": resource_id,
                        "evidence": "read_file",
                        "section_start": str(arguments.get("startLine") or ""),
                        "section_end": str(arguments.get("endLine") or ""),
                    }
                )
        elif tool_name in GET_RESOURCE_TOOLS:
            field, kind = GET_RESOURCE_TOOLS[tool_name]
            if kind != resource_type and not (
                resource_type == "knowledge" and kind in {"skill", "note", "paper"}
            ):
                continue
            resource_id = str(arguments.get(field) or "").removesuffix(".md").strip()
            if resource_id:
                consumed.append({"resource_id": resource_id, "evidence": f"get_{kind}"})
    unique: dict[str, dict[str, str]] = {}
    for item in consumed:
        unique.setdefault(item["resource_id"], item)
    return list(unique.values())


def _resource_id_from_path(
    value: object, skill_root: Path, resource_type: str
) -> str | None:
    if not value:
        return None
    path = Path(str(value)).resolve()
    knowledge_root = skill_root.parent.resolve()
    roots = {
        "skill": skill_root.resolve(),
        "note": knowledge_root / "notes",
        "paper": knowledge_root / "papers",
        "script": knowledge_root / "scripts",
    }
    root = roots.get(resource_type)
    if root is not None:
        try:
            relative = path.relative_to(root)
        except ValueError:
            return None
        return relative.with_suffix("").as_posix() if relative.suffix == ".md" else None
    if resource_type in {
        "file", "file_or_section", "code", "code_or_document", "code_or_api"
    }:
        return path.as_posix()
    return None


def _replay_search(
    tool_name: str, arguments: dict[str, object], skill_root: Path
) -> tuple[list[str], str]:
    include_pattern = str(arguments.get("includePattern") or "")
    if tool_name in GREP_TOOLS and str(skill_root) in include_pattern:
        return replay_skill_grep(arguments, skill_root), "current_corpus_replay"
    pkm_types = {
        "mcp_pkm_skill_context": ["skill"],
        "mcp_pkm_search_skills": ["skill"],
        "mcp_uone-knowledg_search_skills": ["skill"],
        "mcp_pkm_search_notes": ["note"],
        "mcp_pkm_search_papers": ["note"],
        "mcp_pkm_search_subscribed_content": None,
        "mcp_pkm_search_knowledge": None,
        "mcp_pkm2_skill_context": ["skill"],
        "mcp_pkm2_search_skills": ["skill"],
        "mcp_pkm2_search_notes": ["note"],
        "mcp_pkm2_search_papers": ["note"],
        "mcp_pkm2_search_subscribed_content": None,
        "mcp_pkm2_search_knowledge": None,
    }
    if tool_name in pkm_types:
        adapter = SEARCH_ADAPTERS[tool_name]
        if set(arguments) - {adapter[0], "limit", "content_type_filter"}:
            return [], "unsupported_query_arguments"
        content_types = pkm_types[tool_name]
        requested_types = arguments.get("content_type_filter")
        if requested_types is not None:
            if not isinstance(requested_types, list) or any(
                not isinstance(value, str) or value not in {
                    "skill", "note", "research", "script", "recipe", "subscription"
                }
                for value in requested_types
            ):
                return [], "unsupported_content_type_filter"
            content_types = [
                value for value in requested_types
                if content_types is None or value in content_types
            ]
            if not content_types:
                return [], "current_pkm_worker_replay"
        query = str(arguments.get(adapter[0]) or "")
        limit = int(arguments.get("limit") or 20)
        candidates = replay_pkm_search(
            query, content_types=content_types, limit=limit
        )
        return (
            (candidates, "current_pkm_worker_replay")
            if candidates is not None
            else ([], "unavailable")
        )
    if tool_name in {"mcp_pkm_recipe_search", "mcp_pkm2_recipe_search"}:
        candidates = replay_recipe_search(arguments, skill_root.parent)
        return (
            (candidates, "current_recipe_catalog_replay")
            if candidates is not None
            else ([], "unavailable")
        )
    return [], "unavailable"


def replay_recipe_search(
    arguments: dict[str, object], store: Path
) -> list[str] | None:
    query = str(arguments.get("query") or "")
    category = str(arguments.get("category") or "").strip().lower()
    project_id = str(arguments.get("project_id") or "")
    try:
        limit = max(1, min(int(arguments.get("limit") or 10), 50))
    except (TypeError, ValueError):
        return None
    recipes = _canonical_recipe_catalog(store)
    if recipes is None:
        try:
            envelope = json.loads(
                (store / ".pkm" / "state" / "projects.json").read_text(
                    encoding="utf-8"
                )
            )
            payload = envelope.get("payload")
            if not isinstance(payload, dict):
                return None
            state = payload.get("state")
            if not isinstance(state, dict):
                return None
            recipes = state.get("recipes")
            if not isinstance(recipes, list):
                return None
        except (OSError, TypeError, KeyError, json.JSONDecodeError):
            return None

    terms = [term for term in query.lower().split() if term]
    ranked: list[tuple[int, str, str]] = []
    for recipe in recipes:
        if not isinstance(recipe, dict):
            continue
        if recipe.get("scope") != "global" and recipe.get("projectId") != project_id:
            continue
        recipe_category = str(recipe.get("category") or "")
        if category and not recipe_category.lower().startswith(category):
            continue
        metadata = recipe.get("metadata") or {}
        definition = recipe.get("definition") or {}
        nodes = (definition.get("spec") or {}).get("nodes") or []
        metadata_fields = [
            *(metadata.get("requiredInputs") or []),
            *(metadata.get("expectedOutputs") or []),
        ]
        text = "\n".join(
            str(value or "")
            for value in [
                recipe.get("name"), recipe.get("description"), recipe_category,
                *(metadata.get("applicableFunctions") or []), metadata.get("solution"),
                *[field.get("name") for field in metadata_fields if isinstance(field, dict)],
                *[field.get("description") for field in metadata_fields if isinstance(field, dict)],
                *[node.get("nodeId") for node in nodes if isinstance(node, dict)],
                *[node.get("kind") for node in nodes if isinstance(node, dict)],
            ]
        ).lower()
        if terms and not all(term in text for term in terms):
            continue
        name = str(recipe.get("name") or "")
        recipe_id = str(recipe.get("recipeId") or "")
        if not recipe_id:
            continue
        lowered_name = name.lower()
        score = 40 if category and recipe_category.lower() == category else 20 if category else 0
        score += 30 if query and query.lower() == lowered_name else 10 * sum(
            term in lowered_name for term in terms
        )
        score += 5 * sum(term in text for term in terms)
        ranked.append((score, name, recipe_id))
    ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [recipe_id for _, _, recipe_id in ranked[:limit]]


def _canonical_recipe_catalog(store: Path) -> list[dict[str, object]] | None:
    recipe_root = store / "recipes"
    if not recipe_root.is_dir():
        return None
    recipes: list[dict[str, object]] = []
    for path in sorted(recipe_root.rglob("*.json")):
        if any(part.startswith((".", "_")) for part in path.relative_to(recipe_root).parts):
            continue
        try:
            recipe = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(recipe, dict):
            recipes.append(recipe)
    return recipes


def replay_pkm_search(
    query: str, *, content_types: list[str] | None, limit: int
) -> list[str] | None:
    if not query:
        return []
    state = Path(
        "/home/yuwang8/.vscode-server/data/User/globalStorage/"
        "uone.personal-knowledge/retrieval/6a25f0db40c0f2db/worker.json"
    )
    try:
        endpoint = json.loads(state.read_text(encoding="utf-8"))
        payload = json.dumps(
            {
                "query": query,
                "limit": max(1, min(limit, 100)),
                "content_type_filter": content_types,
            },
            ensure_ascii=False,
        ).encode("utf-8")
        request = Request(
            f"http://127.0.0.1:{endpoint['port']}/search",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-PKM-Retrieval-Token": endpoint["token"],
            },
            method="POST",
        )
        with urlopen(request, timeout=30) as response:
            result = json.load(response)
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return None
    if not result.get("ok"):
        return None
    return [
        str(hit.get("skill_id") or hit.get("resource_id") or "")
        for hit in result.get("hits") or []
        if hit.get("skill_id") or hit.get("resource_id")
    ]


def _redact_value(value: object) -> object:
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, dict):
        return {str(key): _redact_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    return value


def _redact_mapping(value: dict[str, object]) -> dict[str, object]:
    redacted = _redact_value(value)
    assert isinstance(redacted, dict)
    return redacted


def _query_intent(
    baseline_family: str, arguments: dict[str, object]
) -> str:
    if baseline_family == "lexical":
        return "lexical" if arguments.get("isRegexp") else "exact"
    if baseline_family in {"fuzzy", "semantic"}:
        return "fuzzy"
    return baseline_family


def _dataset_partition(
    *, transcript_id: str, example_id: str, resource_type: str, relevance: str
) -> tuple[str | None, str]:
    split_key = transcript_id
    policy = "transcript-hash-80-20-v1"
    partition = (
        "validation_anchor"
        if int(sha256(split_key.encode()).hexdigest()[:8], 16) % 5 == 0
        else "training"
    )
    return partition, policy


def _skill_id_from_path(value: object, skill_root: Path) -> str | None:
    if not value:
        return None
    try:
        relative = Path(str(value)).resolve().relative_to(skill_root.resolve())
    except (OSError, ValueError):
        return None
    return relative.with_suffix("").as_posix() if relative.suffix == ".md" else None


def discover_transcripts(root: Path, sdk_root: Path | None = None) -> list[Path]:
    paths = list(root.glob("*/GitHub.copilot-chat/transcripts/*.jsonl"))
    if sdk_root is not None:
        paths.extend(sdk_root.glob("*/events.jsonl"))
    return sorted(set(paths))


def import_batches(
    examples: list[dict[str, object]],
    server_url: str,
    *,
    batch_size: int = 500,
    token: str | None = None,
) -> dict[str, object]:
    totals: dict[str, object] = {
        "accepted": 0, "updated": 0, "duplicates": 0, "partitions": {}
    }
    endpoint = server_url.rstrip("/") + "/api/collector/training-data/import"
    for offset in range(0, len(examples), batch_size):
        request = Request(
            endpoint,
            data=json.dumps({"examples": examples[offset : offset + batch_size]}).encode(
                "utf-8"
            ),
            headers={
                "Content-Type": "application/json",
                **({"Authorization": f"Bearer {token}"} if token else {}),
            },
            method="POST",
        )
        with urlopen(request) as response:
            result = json.load(response)
        totals["accepted"] = int(totals["accepted"]) + int(result["accepted"])
        totals["updated"] = int(totals["updated"]) + int(result.get("updated", 0))
        totals["duplicates"] = int(totals["duplicates"]) + int(result["duplicates"])
        partition_totals = totals["partitions"]
        assert isinstance(partition_totals, dict)
        for partition, count in result.get("partitions", {}).items():
            partition_totals[partition] = partition_totals.get(partition, 0) + count
        totals["partition_version"] = result["partition_version"]
        totals["partition_policy"] = result["partition_policy"]
    return totals


def post_heartbeat(
    server_url: str,
    *,
    state: str,
    last_query_at: str | None = None,
    cursor: str | None = None,
    observation_increment: int = 0,
    error: str | None = None,
    token: str | None = None,
) -> None:
    request = Request(
        server_url.rstrip("/") + "/api/collector/heartbeat",
        data=json.dumps(
            {
                "collector_id": "copilot-transcripts",
                "collector_kind": "vscode_chat_transcripts",
                "state": state,
                "last_query_at": last_query_at,
                "last_observation_at": last_query_at,
                "cursor": cursor,
                "observation_increment": observation_increment,
                "error": error,
            }
        ).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            **({"Authorization": f"Bearer {token}"} if token else {}),
        },
        method="POST",
    )
    with urlopen(request):
        pass


def monitor_transcripts(
    root: Path,
    server_url: str,
    *,
    interval_seconds: float,
    skill_root: Path,
    batch_size: int = 500,
    token: str | None = None,
    sdk_root: Path | None = None,
    cursor_file: Path | None = None,
) -> None:
    seen: dict[str, str] = {}
    file_revisions: dict[str, list[int]] = {}
    if cursor_file is not None and cursor_file.exists():
        saved = json.loads(cursor_file.read_text(encoding="utf-8"))
        if saved.get("compiler_version") == "trajectory-v4":
            file_revisions = saved["files"]
    while True:
        try:
            paths = discover_transcripts(root) if sdk_root is None else discover_transcripts(root, sdk_root)
            current_files = {
                str(path): [path.stat().st_mtime_ns, path.stat().st_size] for path in paths
            }
            changed = [
                path for path in paths
                if file_revisions.get(str(path)) != current_files[str(path)]
            ]
            examples = list(
                trajectory_examples(
                    changed,
                    skill_root=skill_root,
                )
            )
            revisions = {
                str(example["example_id"]): sha256(
                    json.dumps(example, ensure_ascii=False, sort_keys=True).encode()
                ).hexdigest()
                for example in examples
            }
            unseen = [
                example for example in examples
                if seen.get(str(example["example_id"]))
                != revisions[str(example["example_id"])]
            ]
            accepted = 0
            if unseen:
                result = import_batches(
                    unseen, server_url, batch_size=batch_size, token=token
                )
                accepted = int(result["accepted"]) + int(result.get("updated", 0))
            seen.update(revisions)
            file_revisions = current_files
            if cursor_file is not None:
                cursor_file.parent.mkdir(parents=True, exist_ok=True)
                temporary = cursor_file.with_suffix(".tmp")
                temporary.write_text(json.dumps({
                    "compiler_version": "trajectory-v4", "files": file_revisions,
                }), encoding="utf-8")
                temporary.replace(cursor_file)
            latest = max(
                (str(example["occurred_at"]) for example in examples), default=""
            )
            cursor = str(examples[-1]["source"]["record_id"]) if examples else None
            post_heartbeat(
                server_url,
                state="monitoring",
                last_query_at=latest or None,
                cursor=cursor,
                observation_increment=accepted,
                token=token,
            )
        except Exception as error:
            logging.getLogger(__name__).exception("Transcript compilation failed")
            try:
                post_heartbeat(
                    server_url,
                    state="error",
                    error=str(error)[:2000],
                    token=token,
                )
            except Exception:
                logging.getLogger(__name__).exception("Collector error heartbeat failed")
        if interval_seconds <= 0:
            return
        time.sleep(interval_seconds)


def _read_records(path: Path) -> list[dict[str, object]]:
    records = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict):
                records.append(record)
    return records


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract provenance-aware grep_search planning examples"
    )
    parser.add_argument("--transcripts-root", type=Path, required=True)
    parser.add_argument("--sdk-root", type=Path)
    parser.add_argument("--cursor-file", type=Path)
    parser.add_argument(
        "--skill-root",
        type=Path,
        default=Path("/home/yuwang8/uone-knowledge/skills"),
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--server-url")
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--token-env", default="ADAPTIVE_SKILL_COLLECTOR_TOKEN")
    parser.add_argument(
        "--watch-interval",
        type=float,
        default=0,
        help="Continuously rescan at this interval in seconds; zero runs once",
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.server_url and not args.dry_run and args.watch_interval > 0:
        monitor_transcripts(
            args.transcripts_root, args.server_url,
            interval_seconds=args.watch_interval, skill_root=args.skill_root,
            batch_size=args.batch_size, token=os.environ.get(args.token_env),
            sdk_root=args.sdk_root, cursor_file=args.cursor_file,
        )
        return
    paths = discover_transcripts(args.transcripts_root, args.sdk_root)
    examples = list(trajectory_examples(paths, skill_root=args.skill_root))
    summary: dict[str, object] = {
        "transcript_files": len(paths),
        "examples": len(examples),
        "linked_user_turns": sum(
            example["label_provenance"]["query"] == "human_user_turn"
            for example in examples
        ),
        "successful_executions": sum(
            bool(example["execution_success"]) for example in examples
        ),
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            "".join(json.dumps(example, ensure_ascii=False) + "\n" for example in examples),
            encoding="utf-8",
        )
    if args.server_url and not args.dry_run:
        summary["import"] = import_batches(
            examples, args.server_url, batch_size=args.batch_size,
            token=os.environ.get(args.token_env),
        )
        post_heartbeat(
            args.server_url,
            state="monitoring",
            last_query_at=max(
                (str(example["occurred_at"]) for example in examples), default=""
            ) or None,
            cursor=str(examples[-1]["source"]["record_id"]) if examples else None,
            observation_increment=int(summary["import"]["accepted"]),
            token=os.environ.get(args.token_env),
        )
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()