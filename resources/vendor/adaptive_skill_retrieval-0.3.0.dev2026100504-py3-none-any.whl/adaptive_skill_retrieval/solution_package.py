"""Data-only, offline retrieval packages. Import never loads model code."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import zipfile

SCHEMA = "pkm.retrieval-solution/v1"
ARCHITECTURES = {
    "dense-document", "dense-section", "hierarchical-dense-section",
    "pca-dense-document", "pca-dense-section", "hierarchical-pca-dense-section",
    "hybrid-dense-lexical-document", "hybrid-pca-dense-lexical-document",
    "late-interaction-section", "compressed-late-interaction-section",
}
PARAMETERS = {
    "query_prompt", "document_prompt", "bm25_k1", "bm25_b", "rank_constant",
    "dense_source_weight", "lexical_source_weight", "retained_dimension_ratio",
    "rerank_candidates", "candidate_tokens", "compression_bits",
}
MODEL_FILES = {
    "config.json", "modules.json", "config_sentence_transformers.json",
    "sentence_bert_config.json", "tokenizer.json", "tokenizer_config.json",
    "special_tokens_map.json", "added_tokens.json", "vocab.txt", "vocab.json",
    "merges.txt", "sentencepiece.bpe.model", "tokenizer.model",
    "model.safetensors", "model.safetensors.index.json",
    "1_Pooling/config.json", "2_Normalize/config.json",
}
MAX_BYTES = 8 * 1024 ** 3
MAX_FILES = 4096
ID = re.compile(r"^[a-f0-9]{64}$")


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()


def file_digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def package_id(manifest: dict) -> str:
    return hashlib.sha256(canonical(manifest)).hexdigest()


def model_file(name: str) -> bool:
    return name in MODEL_FILES or bool(re.fullmatch(r"model-\d{5}-of-\d{5}\.safetensors", name))


def validate_manifest(value: dict) -> None:
    if not isinstance(value, dict) or set(value) != {
        "schema", "name", "architecture", "parameters", "files", "license", "validation",
    } or value["schema"] != SCHEMA:
        raise ValueError("Unsupported solution manifest schema or fields")
    if not isinstance(value["name"], str) or not 1 <= len(value["name"]) <= 120:
        raise ValueError("Solution name must contain 1 through 120 characters")
    if value["architecture"] not in ARCHITECTURES:
        raise ValueError("Path is not portable: graph links and cross-encoder artifacts are not supported in v1")
    if not isinstance(value["license"], str) or not 1 <= len(value["license"]) <= 200:
        raise ValueError("A model license declaration is required")
    parameters = value["parameters"]
    if not isinstance(parameters, dict) or set(parameters) - PARAMETERS:
        raise ValueError("Unsupported path parameters")
    for key, item in parameters.items():
        if key.endswith("_prompt"):
            if not isinstance(item, str) or len(item) > 1024:
                raise ValueError("Invalid model prompt")
        elif isinstance(item, bool) or not isinstance(item, (float, int)) or not math.isfinite(item):
            raise ValueError("Parameters must be finite numbers")
        elif key == "bm25_b":
            if not 0 <= item <= 1:
                raise ValueError("bm25_b must be between zero and one")
        elif not 0 < item <= 10000:
            raise ValueError("Path parameter out of range")
        elif key in {"rank_constant", "rerank_candidates", "candidate_tokens", "compression_bits"} and not isinstance(item, int):
            raise ValueError("Path parameter must be an integer")
        elif key == "retained_dimension_ratio" and item > 1:
            raise ValueError("PCA ratio cannot exceed one")
    evidence = value["validation"]
    if not isinstance(evidence, dict) or set(evidence) - {
        "recall_at_k", "mrr", "ndcg_at_k", "validation_query_count",
        "dataset_snapshot_id", "corpus_revision", "task_id",
    }:
        raise ValueError("Validation must contain aggregate provenance only")
    for key, item in evidence.items():
        if key in {"dataset_snapshot_id", "corpus_revision", "task_id"}:
            if not isinstance(item, str) or not re.fullmatch(r"[a-f0-9-]{1,128}", item):
                raise ValueError("Invalid provenance identifier")
        elif isinstance(item, bool) or not isinstance(item, (int, float)) or not math.isfinite(item) or item < 0:
            raise ValueError("Invalid validation metric")
        elif key != "validation_query_count" and item > 1:
            raise ValueError("Validation score exceeds one")
    files = value["files"]
    if not isinstance(files, dict) or not 1 <= len(files) <= MAX_FILES:
        raise ValueError("Invalid model file inventory")
    total = 0
    for name, descriptor in files.items():
        if not model_file(name) or not isinstance(descriptor, dict) or set(descriptor) != {"sha256", "bytes"}:
            raise ValueError("Package contains an unsupported model file")
        if not isinstance(descriptor["sha256"], str) or not ID.fullmatch(descriptor["sha256"]):
            raise ValueError("Invalid file checksum")
        size = descriptor["bytes"]
        if type(size) is not int or size < 0:
            raise ValueError("Invalid file size")
        total += size
    if total > MAX_BYTES or not {"modules.json", "config.json"} <= files.keys() or not any(name.endswith(".safetensors") for name in files):
        raise ValueError("Incomplete or oversized safetensors bundle")


def validate_model(root: Path, manifest: dict) -> None:
    for name, descriptor in manifest["files"].items():
        path = root / name
        if root.is_symlink() or not path.resolve().is_relative_to(root.resolve()) or not path.is_file() or path.is_symlink() or path.stat().st_size != descriptor["bytes"] or file_digest(path) != descriptor["sha256"]:
            raise ValueError(f"Model file verification failed: {name}")
    modules = json.loads((root / "modules.json").read_text())
    allowed = {
        ("sentence_transformers.models.Transformer", ""),
        ("sentence_transformers.models.Pooling", "1_Pooling"),
        ("sentence_transformers.models.Normalize", "2_Normalize"),
    }
    if not isinstance(modules, list) or not modules:
        raise ValueError("Invalid SentenceTransformer modules")
    for index, module in enumerate(modules):
        if not isinstance(module, dict) or set(module) != {"idx", "name", "path", "type"} or module["idx"] != index or (module["type"], module["path"]) not in allowed:
            raise ValueError("Custom model modules are not allowed")
    if modules[0]["type"] != "sentence_transformers.models.Transformer":
        raise ValueError("First model module must be Transformer")
    # Reject external code hooks and local/remote path redirection in loader configs.
    def check(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"auto_map", "trust_remote_code", "model_name_or_path", "tokenizer_name_or_path",
                           "config_name", "model_args", "tokenizer_args", "config_args", "backend",
                           "file_name"}:
                    raise ValueError(f"Model loader override is not allowed: {key}")
                check(item)
        elif isinstance(value, list):
            for item in value:
                check(item)
    for name in manifest["files"]:
        if name.endswith(".json"):
            if (root / name).stat().st_size > 64 * 1024 ** 2:
                raise ValueError("Model JSON exceeds admission limit")
            check(json.loads((root / name).read_text()))
    index = root / "model.safetensors.index.json"
    if index.exists():
        mapping = json.loads(index.read_text())["weight_map"]
        if any(name not in manifest["files"] or not name.endswith(".safetensors") for name in mapping.values()):
            raise ValueError("Weight index references a file outside this package")


def export_package(output: Path, *, name: str, config: dict, validation: dict,
                   license: str) -> dict:
    from .model_validation import local_model_bundle_fingerprint

    model, digest = local_model_bundle_fingerprint(config["model"])
    if config.get("model_bundle_sha256") != digest or config.get("embedding_enabled") is not True:
        raise ValueError("Export requires an explicitly enabled, fingerprint-pinned model")
    files = {p.relative_to(model).as_posix(): p for p in model.rglob("*")
             if p.is_file() and model_file(p.relative_to(model).as_posix())}
    manifest = {
        "schema": SCHEMA, "name": name, "architecture": config["retrieval_architecture_id"],
        "parameters": {key: config[key] for key in sorted(PARAMETERS) if key in config},
        "files": {key: {"sha256": file_digest(path), "bytes": path.stat().st_size}
                  for key, path in sorted(files.items())},
        "license": license,
        "validation": {key: validation[key] for key in (
            "recall_at_k", "mrr", "ndcg_at_k", "validation_query_count",
            "dataset_snapshot_id", "corpus_revision", "task_id",
        ) if key in validation},
    }
    validate_manifest(manifest)
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
        stage = Path(temporary)
        for key, path in files.items():
            target = stage / "model" / key
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
        validate_model(stage / "model", manifest)
        archive = stage / "solution.zip"
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED) as bundle:
            bundle.writestr("manifest.json", canonical(manifest))
            for key in files:
                bundle.write(stage / "model" / key, "model/" + key)
        archive.chmod(0o600)
        os.link(archive, output)
    return {"package_id": package_id(manifest), "manifest": manifest, "archive": str(output)}


def load_installed(packages: Path, identity: str, *, verify: bool = True) -> dict:
    if not isinstance(identity, str) or not ID.fullmatch(identity):
        raise ValueError("Invalid solution package ID")
    root = packages / identity
    if root.is_symlink():
        raise ValueError("Package directory must not be a symlink")
    manifest = json.loads((root / "manifest.json").read_text())
    validate_manifest(manifest)
    if package_id(manifest) != identity:
        raise ValueError("Installed manifest digest mismatch")
    if verify:
        validate_model(root / "model", manifest)
    return manifest


def import_package(archive: Path, packages: Path) -> dict:
    packages.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as bundle, tempfile.TemporaryDirectory(prefix=".import-", dir=packages) as temporary:
        members = bundle.infolist()
        names = [item.filename for item in members]
        if len(names) != len(set(names)) or len(names) > MAX_FILES + 1 or "manifest.json" not in names:
            raise ValueError("Duplicate, missing or excessive package entries")
        info = bundle.getinfo("manifest.json")
        if info.file_size > 1024 ** 2:
            raise ValueError("Manifest exceeds admission limit")
        manifest = json.loads(bundle.read(info))
        validate_manifest(manifest)
        if set(names) != {"manifest.json", *("model/" + key for key in manifest["files"])}:
            raise ValueError("Unlisted or missing archive files")
        stage = Path(temporary)
        for item in members:
            mode = item.external_attr >> 16
            if stat.S_IFMT(mode) not in {0, stat.S_IFREG} or item.flag_bits & 1:
                raise ValueError("Links, directories, devices and encrypted entries are not allowed")
            size = len(canonical(manifest)) if item.filename == "manifest.json" else manifest["files"][item.filename[6:]]["bytes"]
            if item.filename != "manifest.json" and item.file_size != size:
                raise ValueError("Archive size does not match manifest")
            target = stage.joinpath(*PurePosixPath(item.filename).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(item) as source, target.open("xb") as output:
                remaining = item.file_size
                while block := source.read(min(1024 ** 2, remaining + 1)):
                    remaining -= len(block)
                    if remaining < 0:
                        raise ValueError("Archive expands beyond declared size")
                    output.write(block)
        validate_model(stage / "model", manifest)
        identity = package_id(manifest)
        destination = packages / identity
        if destination.exists():
            load_installed(packages, identity)
        else:
            os.rename(stage, destination)
        return {"package_id": identity, "manifest": manifest}
