from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations
from typing import Any, Iterable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class DocumentLink:
    left_id: str
    right_id: str
    support: int
    confidence: float
    evidence_type: str = "trajectory_co_consumption"


def build_trajectory_links(
    examples: Iterable[Mapping[str, Any]], *, minimum_support: int = 2
) -> list[DocumentLink]:
    if minimum_support < 1:
        raise ValueError("minimum_support must be positive")
    pair_counts: Counter[tuple[str, str]] = Counter()
    document_counts: Counter[str] = Counter()
    for example in examples:
        relevant = sorted(set(str(item) for item in example.get("relevant_skill_ids") or []))
        document_counts.update(relevant)
        pair_counts.update(combinations(relevant, 2))
    links = []
    for (left, right), support in pair_counts.items():
        if support < minimum_support:
            continue
        confidence = support / max(1, min(document_counts[left], document_counts[right]))
        links.append(DocumentLink(left, right, support, confidence))
    return sorted(links, key=lambda link: (-link.support, link.left_id, link.right_id))


def expand_ranking_with_links(
    ranking: Sequence[str],
    links: Sequence[DocumentLink],
    *,
    limit: int,
    minimum_confidence: float = 0.5,
) -> list[str]:
    if limit <= 0:
        return []
    neighbors: dict[str, list[tuple[str, float, int]]] = defaultdict(list)
    for link in links:
        if link.confidence < minimum_confidence:
            continue
        neighbors[link.left_id].append((link.right_id, link.confidence, link.support))
        neighbors[link.right_id].append((link.left_id, link.confidence, link.support))
    output: list[str] = []
    seen: set[str] = set()
    for document_id in ranking:
        if document_id not in seen:
            output.append(document_id)
            seen.add(document_id)
        additions = sorted(neighbors.get(document_id, ()), key=lambda item: (-item[1], -item[2], item[0]))
        for neighbor, _, _ in additions:
            if neighbor not in seen:
                output.append(neighbor)
                seen.add(neighbor)
        if len(output) >= limit:
            break
    return output[:limit]
