from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RetrievalArchitecture:
    architecture_id: str
    label: str
    architecture_family: str
    operators: tuple[str, ...]
    output_granularity: str
    hyperparameter_space: dict[str, tuple[Any, ...]]
    execution_backend: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


MODELS = (
    "intfloat/multilingual-e5-small",
    "Alibaba-NLP/gte-multilingual-base",
    "BAAI/bge-m3",
)
RETAINED_DIMENSION_RATIOS = (1.0, 0.5, 0.25)
SOURCE_WEIGHT_LEARNING_RATES = (0.02, 0.05, 0.1, 0.2)


def _space(*, pca: bool, hybrid: bool, reranker: bool = False) -> dict[str, tuple[Any, ...]]:
    space: dict[str, tuple[Any, ...]] = {"model": MODELS}
    if pca:
        space["retained_dimension_ratio"] = RETAINED_DIMENSION_RATIOS
    if hybrid:
        space.update(
            {
                "dense_source_weight": (0.5, 1.0, 2.0),
                "lexical_source_weight": (0.5, 1.0, 2.0),
                "rank_constant": (20, 40, 60, 80),
            }
        )
    if reranker:
        space["reranker_model"] = (
            "Alibaba-NLP/gte-multilingual-reranker-base",
        )
        space["rerank_candidates"] = (10, 20, 50)
    return space


LEXICAL_RETRIEVAL_ARCHITECTURES = (
    RetrievalArchitecture(
        "bm25-document",
        "BM25 document retrieval",
        "lexical",
        ("bm25",),
        "document",
        {"bm25_k1": (0.5, 0.9, 1.2, 1.8), "bm25_b": (0.0, 0.4, 0.75, 1.0)},
        "measured_l1",
    ),
    RetrievalArchitecture(
        "hybrid-exact-bm25-document",
        "Exact and BM25 document fusion",
        "lexical",
        ("exact_match", "bm25", "weighted_rrf"),
        "document",
        {
            "bm25_k1": (0.5, 0.9, 1.2, 1.8),
            "bm25_b": (0.0, 0.4, 0.75, 1.0),
            "learning_rate": SOURCE_WEIGHT_LEARNING_RATES,
            "exact_route_weight": (0.5, 1.0, 2.0),
            "bm25_route_weight": (0.5, 1.0, 2.0),
            "rank_constant": (20, 40, 60, 80),
        },
        "measured_l1",
    ),
)

EMBEDDING_RETRIEVAL_ARCHITECTURES = (
    RetrievalArchitecture("dense-document", "Dense document retrieval", "embedding", ("dense_encoder", "ann"), "document", _space(pca=False, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("pca-dense-document", "PCA-compressed dense document retrieval", "embedding", ("dense_encoder", "pca_projection", "ann"), "document", _space(pca=True, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("hybrid-dense-lexical-document", "Dense and lexical document fusion", "embedding", ("dense_encoder", "bm25", "weighted_rrf"), "document", _space(pca=False, hybrid=True), "measured_architecture"),
    RetrievalArchitecture("hybrid-pca-dense-lexical-document", "PCA dense and lexical document fusion", "embedding", ("dense_encoder", "pca_projection", "bm25", "weighted_rrf"), "document", _space(pca=True, hybrid=True), "measured_architecture"),
    RetrievalArchitecture("dense-section", "Dense section retrieval", "embedding", ("sectionizer", "dense_encoder", "ann", "max_pool_document"), "markdown_section", _space(pca=False, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("pca-dense-section", "PCA-compressed dense section retrieval", "embedding", ("sectionizer", "dense_encoder", "pca_projection", "ann", "max_pool_document"), "markdown_section", _space(pca=True, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("hierarchical-dense-section", "Hierarchical document then dense section retrieval", "embedding", ("dense_document", "candidate_filter", "dense_section"), "markdown_section", _space(pca=False, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("hierarchical-pca-dense-section", "Hierarchical PCA document then dense section retrieval", "embedding", ("dense_document", "pca_projection", "candidate_filter", "dense_section"), "markdown_section", _space(pca=True, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("hierarchical-cross-encoder-section", "Dense document retrieval with cross-encoder section reranking", "embedding", ("dense_document", "candidate_filter", "cross_encoder_section"), "markdown_section", _space(pca=False, hybrid=False, reranker=True), "measured_architecture"),
    RetrievalArchitecture("hierarchical-pca-cross-encoder-section", "PCA document retrieval with cross-encoder section reranking", "embedding", ("dense_document", "pca_projection", "candidate_filter", "cross_encoder_section"), "markdown_section", _space(pca=True, hybrid=False, reranker=True), "measured_architecture"),
    RetrievalArchitecture("graph-expanded-dense-document", "Graph-expanded dense document retrieval", "embedding", ("dense_encoder", "ann", "typed_graph_expansion"), "document", _space(pca=False, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("graph-expanded-pca-document", "Graph-expanded PCA document retrieval", "embedding", ("dense_encoder", "pca_projection", "ann", "typed_graph_expansion"), "document", _space(pca=True, hybrid=False), "measured_architecture"),
    RetrievalArchitecture("late-interaction-section", "Late-interaction section retrieval", "embedding", ("token_encoder", "late_interaction_index", "maxsim"), "markdown_section", {"model": ("BAAI/bge-m3",), "candidate_tokens": (32, 64, 128)}, "measured_architecture"),
    RetrievalArchitecture("compressed-late-interaction-section", "Compressed late-interaction section retrieval", "embedding", ("token_encoder", "residual_compression", "late_interaction_index", "maxsim"), "markdown_section", {"model": ("BAAI/bge-m3",), "compression_bits": (1, 2, 4), "candidate_tokens": (32, 64, 128)}, "measured_architecture"),
)

RETRIEVAL_ARCHITECTURES = (
    *LEXICAL_RETRIEVAL_ARCHITECTURES,
    *EMBEDDING_RETRIEVAL_ARCHITECTURES,
)


def architecture_by_id(architecture_id: str) -> RetrievalArchitecture:
    try:
        return next(item for item in RETRIEVAL_ARCHITECTURES if item.architecture_id == architecture_id)
    except StopIteration as error:
        raise LookupError(f"unknown retrieval architecture: {architecture_id}") from error


def refine_retained_ratio(left: float, right: float) -> float:
    if not 0 < right < left <= 1:
        raise ValueError("retained-dimension bounds must satisfy 0 < right < left <= 1")
    return (left + right) / 2
