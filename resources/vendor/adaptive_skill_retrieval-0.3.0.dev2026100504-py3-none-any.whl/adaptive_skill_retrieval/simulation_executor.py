from __future__ import annotations

import argparse
import json
import math
import multiprocessing
import socket
import time
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping

from .collector import CollectorStore

SIMULATION_SAMPLES = (
    0, 25, 50, 100, 150, 250, 375, 500, 750,
    1000, 1250, 1500, 2000, 2500, 3000, 3500, 4000,
)
SIMULATION_CURVE_VERSION = "training-dynamics-v2"


def _wait_until_enabled(store: CollectorStore) -> None:
    while not store.executor_settings()["enabled"]:
        time.sleep(0.1)


def simulated_metrics(
    config: Mapping[str, Any], stage_key: str, examples_seen: int
) -> dict[str, float | str]:
    architecture_config = {
        key: value
        for key, value in config.items()
        if key not in {
            "calibration_threshold", "dataset_version", "execution_mode",
            "learning_rate", "search_strategy", "simulation_curve_version",
            "simulation_step_seconds", "stage_weights", "tuning_run_id",
            "tuning_iteration",
        }
    }
    identity = json.dumps(
        architecture_config, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    digest = sha256(f"{identity}:{stage_key}".encode("utf-8")).digest()
    quality = int.from_bytes(digest[:4], "big") / (2**32 - 1)
    phase = int.from_bytes(digest[4:8], "big") / (2**32 - 1) * math.tau
    sample_count = max(0, int(examples_seen))
    learning_rate = max(1e-8, float(config.get("learning_rate") or 0.0001))
    rate_ratio = min(4.0, max(0.25, learning_rate / 0.0001))
    weights = config.get("stage_weights") or {}
    retrieval_weight = max(0.0, float(weights.get("retrieval", 1.0)))
    ranking_weight = max(0.0, float(weights.get("ranking", 1.0)))
    total_weight = retrieval_weight + ranking_weight
    retrieval_share = retrieval_weight / total_weight if total_weight else 0.5
    preferred_share = 0.65 if stage_key == "l1_document" else 0.5
    weight_alignment = 1.0 - abs(retrieval_share - preferred_share)

    sample_scale = 1050.0 / math.sqrt(rate_ratio)
    progress = 1.0 - math.exp(-sample_count / sample_scale)
    warmup = 1.0 - math.exp(-sample_count / 90.0)
    hierarchy_bonus = 0.025 if stage_key == "l2_markdown_section" else 0.0
    baseline = 0.36 + quality * 0.12 + hierarchy_bonus
    learnable_gain = 0.27 + quality * 0.025 + weight_alignment * 0.055
    instability = (
        math.sin(sample_count / 170.0 + phase)
        * (0.002 + max(0.0, rate_ratio - 1.0) * 0.004)
        * progress
    )
    overfit_progress = max(0.0, sample_count - 2800) / 1200.0
    overfit_penalty = min(1.0, overfit_progress) * max(
        0.0, rate_ratio - 1.0
    ) * 0.018
    top1 = min(
        0.96,
        max(
            0.0,
            baseline + learnable_gain * progress * warmup
            + instability - overfit_penalty,
        ),
    )
    recall = min(0.985, top1 + 0.11 + quality * 0.025)
    mrr = min(0.975, top1 + 0.055)
    ndcg = min(0.98, top1 + 0.075)
    return {
        "top1_accuracy": round(top1, 6),
        "recall_at_k": round(recall, 6),
        "mrr": round(mrr, 6),
        "ndcg_at_k": round(ndcg, 6),
        "execution_mode": "simulation",
        "simulation_curve_version": SIMULATION_CURVE_VERSION,
        "curve_phase": _curve_phase(sample_count),
    }


def _curve_phase(examples_seen: int) -> str:
    if examples_seen <= 100:
        return "cold_start"
    if examples_seen <= 750:
        return "rapid_learning"
    if examples_seen <= 2000:
        return "refinement"
    return "plateau_or_overfit"


def execute_simulation(database: str | Path, task: Mapping[str, Any]) -> None:
    store = CollectorStore(database)
    task_id = str(task["task_id"])
    config = task.get("config") or {}
    step_seconds = max(0.0, float(config.get("simulation_step_seconds") or 0))
    target_revision = task.get("dataset_revision")
    samples = (
        (int(target_revision),) if target_revision is not None else SIMULATION_SAMPLES
    )
    try:
        final_metrics: dict[str, Any] | None = None
        for stage in task.get("stages") or ():
            _wait_until_enabled(store)
            stage_key = str(stage["stage_key"])
            store.start_performance_stage(task_id, stage_key)
            for examples_seen in samples:
                _wait_until_enabled(store)
                metrics = simulated_metrics(config, stage_key, examples_seen)
                store.record_performance_stage_checkpoint(
                    task_id,
                    stage_key,
                    examples_seen=examples_seen,
                    metrics=metrics,
                )
                if step_seconds:
                    time.sleep(step_seconds)
            final_metrics = simulated_metrics(config, stage_key, samples[-1])
            store.finish_performance_stage(
                task_id, stage_key, metrics=final_metrics
            )
        if final_metrics is None:
            raise ValueError("simulation task has no executable stages")
        for examples_seen in samples:
            store.record_performance_checkpoint(
                task_id,
                examples_seen=examples_seen,
                metrics=simulated_metrics(config, str(task["stages"][-1]["stage_key"]), examples_seen),
            )
        store.finish_performance_task(
            task_id, state="completed", metrics=final_metrics
        )
    except Exception as error:
        try:
            store.finish_performance_task(
                task_id, state="failed", error=f"simulation: {error}"
            )
        except (LookupError, ValueError):
            pass
        raise


def _worker(database: str, task: Mapping[str, Any]) -> None:
    execute_simulation(database, task)


def run_scheduler(
    database: str | Path,
    *,
    once: bool = False,
    poll_seconds: float = 1.0,
) -> int:
    database = str(database)
    store = CollectorStore(database)
    active: dict[int, multiprocessing.Process] = {}
    completed = 0
    worker_sequence = 0
    while True:
        for process_id, process in list(active.items()):
            if process.is_alive():
                continue
            process.join()
            active.pop(process_id)
            completed += 1

        store.enqueue_due_inference_tasks()
        store.advance_bayesian_tuning()
        executor = store.executor_settings()
        process_limit = executor["processes"]
        while executor["enabled"] and len(active) < process_limit:
            worker_sequence += 1
            worker_id = f"simulation:{socket.gethostname()}:{worker_sequence}"
            task = store.claim_performance_task(
                worker_id, execution_mode="simulation"
            )
            if task is None:
                break
            process = multiprocessing.Process(
                target=_worker,
                args=(database, task),
                name=worker_id,
            )
            process.start()
            active[process.pid or worker_sequence] = process

        if once and not active:
            return completed
        time.sleep(max(0.05, poll_seconds))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run deterministic System Integration simulations"
    )
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    arguments = parser.parse_args()
    run_scheduler(
        arguments.database,
        once=arguments.once,
        poll_seconds=arguments.poll_seconds,
    )


if __name__ == "__main__":
    main()
