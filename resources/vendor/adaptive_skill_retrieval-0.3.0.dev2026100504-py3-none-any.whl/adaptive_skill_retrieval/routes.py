from __future__ import annotations

from .engine import Route
from .models import EmbeddingModelVersion, ExpertIdentity, RouteState
from .perspectives import RetrievalPerspective
from .query_intent import QueryIntent
from .retrievers import BM25Retriever, Embedder, EmbeddingRetriever, ExactMatchRetriever

ACADEMIC_BM25_K1 = 0.9
ACADEMIC_BM25_B = 0.4
ACADEMIC_BM25_PROFILE = "anserini-lucene-k1=0.9-b=0.4-skill-code-v1"
EXACT_MATCH_PROFILE = "raw-substring-fields-v1"


def exact_match_route(*, state: RouteState = RouteState.SERVING) -> Route:
    identity = ExpertIdentity(
        name="exact-match",
        perspective="raw-fields",
        revision=EXACT_MATCH_PROFILE,
    )
    return Route(
        identity=identity,
        retriever=ExactMatchRetriever(identity),
        state=state,
        intents=frozenset({QueryIntent.EXACT, QueryIntent.HYBRID}),
    )


def academic_bm25_benchmark_route(
    *,
    state: RouteState = RouteState.SERVING,
    k1: float = ACADEMIC_BM25_K1,
    b: float = ACADEMIC_BM25_B,
) -> Route:
    """Create the frozen lexical baseline used for route comparisons.

    The scoring parameters follow the widely reported Anserini/Pyserini BM25
    baseline. The analyzer is deliberately versioned separately because this
    library preserves code symbols and is not Lucene StandardAnalyzer-equivalent.
    """
    selected_perspective = RetrievalPerspective(
        name="academic-benchmark",
        field_repetitions={"title": 1, "description": 1, "body": 1},
    )
    if k1 <= 0 or not 0 <= b <= 1:
        raise ValueError("BM25 requires k1 > 0 and 0 <= b <= 1")
    revision = (
        ACADEMIC_BM25_PROFILE
        if k1 == ACADEMIC_BM25_K1 and b == ACADEMIC_BM25_B
        else f"{ACADEMIC_BM25_PROFILE};k1={k1:g};b={b:g}"
    )
    identity = ExpertIdentity(
        name="bm25-academic-benchmark",
        perspective=selected_perspective.name,
        revision=revision,
    )
    return Route(
        identity=identity,
        retriever=BM25Retriever(
            identity,
            selected_perspective,
            k1=k1,
            b=b,
        ),
        state=state,
    )


def embedding_route(
    *,
    name: str,
    model: EmbeddingModelVersion,
    feature_selector: RetrievalPerspective,
    embedder: Embedder,
    state: RouteState = RouteState.SHADOW,
    revision: str = "1",
    estimated_cost: float = 0.0,
) -> Route:
    if embedder.dimensions != model.dimensions:
        raise ValueError(
            "embedder dimensions must match the embedding model version"
        )
    identity = ExpertIdentity(
        name=name,
        perspective=feature_selector.name,
        model=model,
        revision=revision,
        feature_selector=feature_selector.version,
    )
    return Route(
        identity=identity,
        retriever=EmbeddingRetriever(identity, feature_selector, embedder),
        state=state,
        estimated_cost=estimated_cost,
    )