from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping


JUDGMENTS = {"useful", "wrong", "unknown"}


def build_adjudication_prompt(
    example: Mapping[str, Any], skill_root: Path, *, max_candidates: int = 30
) -> str:
    ranking = example.get("final_ranking") or []
    candidates = []
    for item in ranking[:max_candidates]:
        skill_id = str(item.get("skill_id") or "")
        path = skill_root / f"{skill_id}.md"
        try:
            content = path.read_text(encoding="utf-8")[:2_000]
        except (OSError, UnicodeError):
            content = ""
        candidates.append({"skill_id": skill_id, "content": content})
    evidence = {
        "search_query": example.get("query", ""),
        "deterministic_relevant_skill_ids": example.get("relevant_skill_ids") or [],
        "baseline_candidates": candidates,
        "consumption_evidence": example.get("consumption_evidence") or [],
    }
    return (
        "You label retrieval candidates from a historical Copilot trajectory. "
        "Infer what the historical agent found useful, not what merely looks topically related. "
        "Use downstream reads/gets and explicit claims in the agent narrative as positive evidence. "
        "Mark wrong only when the trajectory or candidate mismatch provides affirmative evidence; "
        "otherwise mark unknown. Multiple useful documents are allowed. If no candidate can satisfy "
        "the query and the trajectory confirms no result, set no_match=true. Return JSON only with "
        'schema {"labels":[{"skill_id":str,"judgment":"useful|wrong|unknown",'
        '"confidence":0..1,"evidence":str}],"no_match":bool,"rationale":str}.\n\n'
        + json.dumps(evidence, ensure_ascii=False)
    )


def parse_adjudication(
    response: str, *, allowed_ids: set[str] | None = None
) -> dict[str, Any]:
    text = response.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    result = json.loads(text)
    labels = result.get("labels")
    if not isinstance(labels, list) or not isinstance(result.get("no_match"), bool):
        raise ValueError("adjudication must contain labels and boolean no_match")
    normalized = []
    for label in labels:
        if not isinstance(label, dict) or label.get("judgment") not in JUDGMENTS:
            raise ValueError("invalid candidate judgment")
        skill_id = str(label.get("skill_id") or "")
        if not skill_id or (allowed_ids is not None and skill_id not in allowed_ids):
            raise ValueError("judgment contains a resource outside the candidate set")
        confidence = float(label.get("confidence", 0))
        if not 0 <= confidence <= 1:
            raise ValueError("confidence must be between zero and one")
        normalized.append(
            {
                "skill_id": skill_id,
                "judgment": label["judgment"],
                "confidence": confidence,
                "evidence": str(label.get("evidence") or ""),
            }
        )
    return {
        "labels": normalized,
        "no_match": result["no_match"],
        "rationale": str(result.get("rationale") or ""),
    }


def apply_adjudication(
    example: Mapping[str, Any], adjudication: Mapping[str, Any], *, model: str
) -> dict[str, Any]:
    updated = dict(example)
    deterministic = list(example.get("relevant_skill_ids") or [])
    useful = [
        label["skill_id"]
        for label in adjudication.get("labels", [])
        if label.get("judgment") == "useful"
        and float(label.get("confidence", 0)) >= 0.75
    ]
    relevant = list(dict.fromkeys([*deterministic, *useful]))
    wrong = [
        label["skill_id"]
        for label in adjudication.get("labels", [])
        if label.get("judgment") == "wrong"
        and float(label.get("confidence", 0)) >= 0.75
    ]
    no_match = bool(adjudication.get("no_match")) and not relevant
    updated["relevant_skill_ids"] = relevant
    updated["wrong_skill_ids"] = wrong
    updated["no_match"] = no_match
    updated["adjudication"] = dict(adjudication)
    provenance = dict(example.get("label_provenance") or {})
    provenance.update(
        {
            "relevance": "gpt56_trajectory_adjudication",
            "adjudication_model": model,
            "relevance_evidence": "function_replay_and_historical_agent_trajectory",
        }
    )
    updated["label_provenance"] = provenance
    updated["lifecycle"] = "complete" if relevant else "no_match" if no_match else "ambiguous"
    return updated
