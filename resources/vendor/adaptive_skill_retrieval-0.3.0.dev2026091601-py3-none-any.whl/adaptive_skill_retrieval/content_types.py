from __future__ import annotations

import re
from collections.abc import Iterable

from .models import ContentType


_TYPE_PATTERNS: tuple[tuple[ContentType, re.Pattern[str]], ...] = (
    (ContentType.SCRIPT, re.compile(r"(?<![A-Za-z])scripts?(?![A-Za-z])|脚本", re.IGNORECASE)),
    (ContentType.NOTE, re.compile(r"(?<![A-Za-z])notes?(?![A-Za-z])|笔记", re.IGNORECASE)),
    (ContentType.SKILL, re.compile(r"(?<![A-Za-z])skills?(?![A-Za-z])|技能", re.IGNORECASE)),
    (
        ContentType.SUBSCRIPTION,
        re.compile(r"(?<![A-Za-z])subscriptions?(?![A-Za-z])|订阅", re.IGNORECASE),
    ),
)


def infer_content_types(query: str) -> tuple[ContentType, ...]:
    return tuple(
        content_type
        for content_type, pattern in _TYPE_PATTERNS
        if pattern.search(query)
    )


def normalize_content_types(
    content_types: Iterable[ContentType | str],
) -> tuple[ContentType, ...]:
    return tuple(dict.fromkeys(ContentType(item) for item in content_types))
