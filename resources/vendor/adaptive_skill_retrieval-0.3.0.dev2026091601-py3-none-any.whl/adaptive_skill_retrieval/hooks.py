from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterator, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from typing import ParamSpec, Protocol, TypeVar

from .engine import RetrievalResult
from .models import SkillVersion
from .telemetry import OutcomeEvent

P = ParamSpec("P")
T = TypeVar("T")


class TelemetrySink(Protocol):
    def record_impression(
        self,
        result: RetrievalResult,
        *,
        agent_id: str | None = None,
        session_id: str | None = None,
    ) -> None: ...

    def record_outcome(self, event: OutcomeEvent) -> None: ...


class SkillInteraction:
    def __init__(
        self,
        sink: TelemetrySink,
        result: RetrievalResult,
        *,
        agent_id: str,
        session_id: str,
    ) -> None:
        self.sink = sink
        self.result = result
        self.agent_id = agent_id
        self.session_id = session_id
        self._selected: dict[tuple[str, str], SkillVersion] = {}
        self._used: dict[tuple[str, str], SkillVersion] = {}
        self._finished = False

    def mark_selected(self, versions: Sequence[SkillVersion]) -> None:
        self._ensure_active()
        for version in versions:
            self._selected[(version.skill_id, version.content_hash)] = version

    def mark_used(self, version: SkillVersion) -> None:
        self._ensure_active()
        self._used[(version.skill_id, version.content_hash)] = version

    def finish(
        self,
        *,
        success: bool | None = None,
        reward: float | None = None,
        correction: str | None = None,
    ) -> None:
        if self._finished:
            return
        self.sink.record_outcome(
            OutcomeEvent(
                query_id=self.result.query_id,
                agent_id=self.agent_id,
                session_id=self.session_id,
                selected_skills=tuple(self._selected.values()),
                used_skills=tuple(self._used.values()),
                success=success,
                reward=reward,
                correction=correction,
            )
        )
        self._finished = True

    def _ensure_active(self) -> None:
        if self._finished:
            raise RuntimeError("cannot update a finished Skill interaction")


_CURRENT_INTERACTION: ContextVar[SkillInteraction | None] = ContextVar(
    "adaptive_skill_interaction", default=None
)


class AgentSkillHooks:
    def __init__(self, sink: TelemetrySink) -> None:
        self.sink = sink

    @contextmanager
    def trace(
        self,
        result: RetrievalResult,
        *,
        agent_id: str,
        session_id: str,
    ) -> Iterator[SkillInteraction]:
        interaction = SkillInteraction(
            self.sink,
            result,
            agent_id=agent_id,
            session_id=session_id,
        )
        self.sink.record_impression(
            result, agent_id=agent_id, session_id=session_id
        )
        token = _CURRENT_INTERACTION.set(interaction)
        try:
            yield interaction
        except BaseException as error:
            interaction.finish(
                success=False,
                correction=f"{type(error).__name__}: {error}",
            )
            raise
        else:
            interaction.finish()
        finally:
            _CURRENT_INTERACTION.reset(token)

    def wrap_selector(
        self, selector: Callable[P, Sequence[SkillVersion]]
    ) -> Callable[P, Sequence[SkillVersion]]:
        @wraps(selector)
        def tracked(*args: P.args, **kwargs: P.kwargs) -> Sequence[SkillVersion]:
            selected = selector(*args, **kwargs)
            interaction = self.current()
            if interaction is not None:
                interaction.mark_selected(selected)
            return selected

        return tracked

    def wrap_skill_loader(
        self, loader: Callable[[SkillVersion], T]
    ) -> Callable[[SkillVersion], T]:
        @wraps(loader)
        def tracked(version: SkillVersion) -> T:
            loaded = loader(version)
            interaction = self.current()
            if interaction is not None:
                interaction.mark_used(version)
            return loaded

        return tracked

    def wrap_async_selector(
        self, selector: Callable[P, Awaitable[Sequence[SkillVersion]]]
    ) -> Callable[P, Awaitable[Sequence[SkillVersion]]]:
        @wraps(selector)
        async def tracked(*args: P.args, **kwargs: P.kwargs) -> Sequence[SkillVersion]:
            selected = await selector(*args, **kwargs)
            interaction = self.current()
            if interaction is not None:
                interaction.mark_selected(selected)
            return selected

        return tracked

    def wrap_async_skill_loader(
        self, loader: Callable[[SkillVersion], Awaitable[T]]
    ) -> Callable[[SkillVersion], Awaitable[T]]:
        @wraps(loader)
        async def tracked(version: SkillVersion) -> T:
            loaded = await loader(version)
            interaction = self.current()
            if interaction is not None:
                interaction.mark_used(version)
            return loaded

        return tracked

    @staticmethod
    def current() -> SkillInteraction | None:
        return _CURRENT_INTERACTION.get()