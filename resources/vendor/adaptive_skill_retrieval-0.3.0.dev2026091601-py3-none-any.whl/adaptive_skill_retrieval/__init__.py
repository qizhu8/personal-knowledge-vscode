"""Adaptive retrieval for evolving agent skill libraries."""

from .models import (
    ContentType,
    EmbeddingModelVersion,
    ExpertIdentity,
    FeatureSelectorVersion,
    RouteState,
    SkillDocument,
    SkillVersion,
)
from .content_types import infer_content_types
from .engine import RetrievalEngine, RetrievalResult, Route
from .differentiable_fusion import (
    soft_rank,
    soft_reciprocal_rank_fusion,
    soft_rrf_listwise_loss,
)
from .evaluation import (
    EvaluationCase,
    RouteContribution,
    evaluate_route_contributions,
)
from .hooks import AgentSkillHooks, SkillInteraction
from .graph_routing import (
    EmbeddingSphereIndex,
    RoutingCandidate,
    SphereHit,
    build_skill_sphere_index,
    routing_candidates,
)
from .perspectives import RetrievalPerspective
from .retrievers import (
    AsymmetricEmbedder,
    BM25Retriever,
    EmbeddingRetriever,
    ExactMatchRetriever,
    HashingEmbedder,
    SentenceTransformerEmbedder,
)
from .query_intent import QueryIntent, QueryIntentDecision, classify_query_intent
from .routes import (
    ACADEMIC_BM25_B,
    ACADEMIC_BM25_K1,
    ACADEMIC_BM25_PROFILE,
    EXACT_MATCH_PROFILE,
    academic_bm25_benchmark_route,
    embedding_route,
    exact_match_route,
)
from .shortcuts import (
    ConditionalShortcut,
    ShortcutHypothesis,
    active_shortcut_neighbors,
    discover_shortcut_hypotheses,
    verify_shortcut,
)
from .skill_paths import SkillPathRecommender, SkillPathSuggestion
from .summary import build_dashboard_summary
from .telemetry import JsonlTelemetryStore, OutcomeEvent, TrainingIterationEvent
from .training import ResidualTrainingExample, collect_residual_training_examples

__all__ = [
    "ACADEMIC_BM25_B",
    "ACADEMIC_BM25_K1",
    "ACADEMIC_BM25_PROFILE",
    "EXACT_MATCH_PROFILE",
    "AgentSkillHooks",
    "AsymmetricEmbedder",
    "ConditionalShortcut",
    "ContentType",
    "EmbeddingModelVersion",
    "EmbeddingSphereIndex",
    "EmbeddingRetriever",
    "ExactMatchRetriever",
    "EvaluationCase",
    "ExpertIdentity",
    "FeatureSelectorVersion",
    "BM25Retriever",
    "HashingEmbedder",
    "SentenceTransformerEmbedder",
    "JsonlTelemetryStore",
    "OutcomeEvent",
    "QueryIntent",
    "QueryIntentDecision",
    "RetrievalEngine",
    "RetrievalPerspective",
    "RetrievalResult",
    "ResidualTrainingExample",
    "Route",
    "RouteContribution",
    "RouteState",
    "RoutingCandidate",
    "SkillDocument",
    "SkillInteraction",
    "SkillPathRecommender",
    "SkillPathSuggestion",
    "SkillVersion",
    "SphereHit",
    "ShortcutHypothesis",
    "soft_rank",
    "soft_reciprocal_rank_fusion",
    "soft_rrf_listwise_loss",
    "TrainingIterationEvent",
    "academic_bm25_benchmark_route",
    "active_shortcut_neighbors",
    "embedding_route",
    "exact_match_route",
    "build_dashboard_summary",
    "build_skill_sphere_index",
    "collect_residual_training_examples",
    "classify_query_intent",
    "infer_content_types",
    "discover_shortcut_hypotheses",
    "evaluate_route_contributions",
    "routing_candidates",
    "verify_shortcut",
]

