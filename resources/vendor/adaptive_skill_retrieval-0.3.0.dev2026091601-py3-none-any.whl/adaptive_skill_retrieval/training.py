from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .evaluation import EvaluationCase, _route_succeeds


@dataclass(frozen=True, slots=True)
class ResidualTrainingExample:
    query_id: str
    query: str
    positive_skill_ids: frozenset[str]


def collect_residual_training_examples(
    cases: Sequence[EvaluationCase],
    *,
    serving_routes: frozenset[str],
) -> list[ResidualTrainingExample]:
    """Select explicitly labeled cases missed by the current serving ensemble."""
    examples: list[ResidualTrainingExample] = []
    for case in cases:
        serving_succeeds = any(
            _route_succeeds(case, route_key) for route_key in serving_routes
        )
        if not serving_succeeds and case.relevant_skill_ids:
            examples.append(
                ResidualTrainingExample(
                    query_id=case.result.query_id,
                    query=case.result.query,
                    positive_skill_ids=case.relevant_skill_ids,
                )
            )
    return examples
