from __future__ import annotations

import math
from dataclasses import dataclass
from hashlib import sha256
from typing import Iterable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class ShortcutHypothesis:
    hypothesis_id: str
    source_id: str
    target_id: str
    perspective_id: str
    activation_topic: str
    similarity: float
    embedding_version: str


@dataclass(frozen=True, slots=True)
class ConditionalShortcut:
    shortcut_id: str
    source_id: str
    target_id: str
    relation: str
    perspective_id: str
    activation_topic: str
    discovery_score: float
    verification_score: float
    embedding_version: str
    verifier_version: str
    evidence: tuple[str, ...]
    status: str

    @property
    def confidence(self) -> float:
        return min(self.discovery_score, self.verification_score)

    def is_active(self, active_topics: Iterable[str]) -> bool:
        topics = {topic.casefold() for topic in active_topics}
        return self.status == "active" and self.activation_topic.casefold() in topics


def discover_shortcut_hypotheses(
    vectors_by_perspective: Mapping[
        str, Mapping[str, Sequence[float]]
    ],
    *,
    activation_topics: Mapping[str, str],
    embedding_versions: Mapping[str, str],
    similarity_threshold: float = 0.8,
) -> list[ShortcutHypothesis]:
    if not -1 <= similarity_threshold <= 1:
        raise ValueError("similarity_threshold must be between -1 and 1")
    hypotheses = []
    for perspective_id in sorted(vectors_by_perspective):
        if perspective_id not in activation_topics:
            raise ValueError(f"missing activation topic for {perspective_id}")
        if perspective_id not in embedding_versions:
            raise ValueError(f"missing embedding version for {perspective_id}")
        normalized = {
            node_id: _normalize(vector)
            for node_id, vector in sorted(
                vectors_by_perspective[perspective_id].items()
            )
        }
        node_ids = sorted(normalized)
        for index, source_id in enumerate(node_ids):
            for target_id in node_ids[index + 1 :]:
                similarity = sum(
                    left * right
                    for left, right in zip(
                        normalized[source_id], normalized[target_id]
                    )
                )
                if similarity < similarity_threshold:
                    continue
                identity = ":".join(
                    (perspective_id, source_id, target_id, embedding_versions[perspective_id])
                )
                hypotheses.append(
                    ShortcutHypothesis(
                        hypothesis_id=f"hypothesis:{sha256(identity.encode()).hexdigest()[:24]}",
                        source_id=source_id,
                        target_id=target_id,
                        perspective_id=perspective_id,
                        activation_topic=activation_topics[perspective_id],
                        similarity=round(similarity, 8),
                        embedding_version=embedding_versions[perspective_id],
                    )
                )
    return sorted(
        hypotheses,
        key=lambda hypothesis: (
            hypothesis.perspective_id,
            -hypothesis.similarity,
            hypothesis.source_id,
            hypothesis.target_id,
        ),
    )


def verify_shortcut(
    hypothesis: ShortcutHypothesis,
    *,
    verification_score: float,
    verifier_version: str,
    evidence: Sequence[str],
    activation_threshold: float = 0.8,
    relation: str = "ANALOGOUS_TO",
) -> ConditionalShortcut:
    if not 0 <= verification_score <= 1:
        raise ValueError("verification_score must be between 0 and 1")
    if not verifier_version.strip():
        raise ValueError("verifier_version is required")
    if not evidence:
        raise ValueError("verification evidence is required")
    shortcut_identity = f"{hypothesis.hypothesis_id}:{verifier_version}:{relation}"
    return ConditionalShortcut(
        shortcut_id=f"shortcut:{sha256(shortcut_identity.encode()).hexdigest()[:24]}",
        source_id=hypothesis.source_id,
        target_id=hypothesis.target_id,
        relation=relation,
        perspective_id=hypothesis.perspective_id,
        activation_topic=hypothesis.activation_topic,
        discovery_score=hypothesis.similarity,
        verification_score=verification_score,
        embedding_version=hypothesis.embedding_version,
        verifier_version=verifier_version,
        evidence=tuple(evidence),
        status="active" if verification_score >= activation_threshold else "rejected",
    )


def active_shortcut_neighbors(
    shortcuts: Iterable[ConditionalShortcut],
    *,
    node_id: str,
    active_topics: Iterable[str],
) -> list[tuple[str, float]]:
    neighbors = []
    for shortcut in shortcuts:
        if not shortcut.is_active(active_topics):
            continue
        if shortcut.source_id == node_id:
            neighbors.append((shortcut.target_id, shortcut.confidence))
        elif shortcut.target_id == node_id:
            neighbors.append((shortcut.source_id, shortcut.confidence))
    return sorted(neighbors, key=lambda item: (-item[1], item[0]))


def _normalize(vector: Sequence[float]) -> tuple[float, ...]:
    values = tuple(float(value) for value in vector)
    if any(not math.isfinite(value) for value in values):
        raise ValueError("embedding vectors must contain only finite values")
    norm = math.sqrt(sum(value * value for value in values))
    if norm == 0:
        raise ValueError("embedding vectors must be non-zero")
    return tuple(value / norm for value in values)