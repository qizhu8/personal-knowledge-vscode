from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

from .retrievers import SentenceTransformerEmbedder


class LocalModelValidationError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class LocalModelValidation:
    model_path: str
    model_id: str
    revision: str
    bundle_sha256: str
    dimensions: int
    query_prompt: str
    document_prompt: str
    local_files_only: bool = True

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ValidatedLocalModel:
    embedder: SentenceTransformerEmbedder
    validation: LocalModelValidation


def load_validated_local_model(
    model_path: str | Path,
    *,
    model_id: str | None = None,
    query_prompt: str = "query: ",
    document_prompt: str = "passage: ",
    backend: Any | None = None,
) -> ValidatedLocalModel:
    path = Path(model_path).expanduser().resolve()
    if not path.is_dir():
        raise LocalModelValidationError(
            "model path must be a complete local model bundle directory"
        )
    files = tuple(sorted(item for item in path.rglob("*") if item.is_file()))
    if not files:
        raise LocalModelValidationError("model bundle directory is empty")

    digest = sha256()
    for item in files:
        digest.update(item.relative_to(path).as_posix().encode("utf-8"))
        with item.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    bundle_sha256 = digest.hexdigest()

    try:
        embedder = SentenceTransformerEmbedder(
            str(path),
            query_prompt=query_prompt,
            document_prompt=document_prompt,
            local_files_only=True,
            backend=backend,
        )
        vectors = (
            *embedder.encode_queries(("multilingual retrieval validation",)),
            *embedder.encode_documents(("local model validation document",)),
        )
    except Exception as error:
        raise LocalModelValidationError(f"model load or probe failed: {error}") from error

    if len(vectors) != 2:
        raise LocalModelValidationError("model probe must return two vectors")
    for vector in vectors:
        if len(vector) != embedder.dimensions:
            raise LocalModelValidationError("model probe dimension mismatch")
        if not all(math.isfinite(value) for value in vector):
            raise LocalModelValidationError("model probe returned a non-finite value")
        if not any(value != 0 for value in vector):
            raise LocalModelValidationError("model probe returned a zero vector")

    revision = f"sha256:{bundle_sha256}"
    validation = LocalModelValidation(
        model_path=str(path),
        model_id=(model_id or path.name).strip(),
        revision=revision,
        bundle_sha256=bundle_sha256,
        dimensions=embedder.dimensions,
        query_prompt=query_prompt,
        document_prompt=document_prompt,
    )
    if not validation.model_id:
        raise LocalModelValidationError("model id is required")
    return ValidatedLocalModel(embedder, validation)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate a complete local SentenceTransformer model bundle"
    )
    parser.add_argument("model_path")
    parser.add_argument("--model-id")
    parser.add_argument("--query-prompt", default="query: ")
    parser.add_argument("--document-prompt", default="passage: ")
    args = parser.parse_args()
    try:
        validated = load_validated_local_model(
            args.model_path,
            model_id=args.model_id,
            query_prompt=args.query_prompt,
            document_prompt=args.document_prompt,
        )
    except LocalModelValidationError as error:
        print(json.dumps({"valid": False, "error": str(error)}))
        raise SystemExit(2) from error
    print(json.dumps({"valid": True, **validated.validation.as_dict()}, indent=2))


if __name__ == "__main__":
    main()