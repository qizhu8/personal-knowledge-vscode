from __future__ import annotations

from dataclasses import dataclass
from threading import Lock
from typing import Any, Sequence

from .fusion import reciprocal_rank_fusion
from .knowledge_graph import (
    KnowledgeGraphProjection,
    KnowledgeGraphSelection,
    ProjectedGraphNode,
    SelectedGraphLink,
    SelectedGraphNode,
)
from .models import ExpertIdentity, SkillDocument
from .model_validation import (
    LocalModelValidationError,
    load_validated_local_model,
)
from .perspectives import RetrievalPerspective
from .retrievers import (
    BM25Retriever,
    Embedder,
    EmbeddingRetriever,
    SearchHit,
)
from .routes import ACADEMIC_BM25_PROFILE, academic_bm25_benchmark_route
from .skill_graph import SkillGraphSnapshot, graph_node_id


BM25_PROVIDER_ID = "bm25-academic"
DENSE_PROVIDER_ID = "dense-local"
HYBRID_PROVIDER_ID = "bm25-dense-rrf"


@dataclass(frozen=True, slots=True)
class ProviderManifest:
    provider_id: str
    label: str
    kind: str
    version: str
    projection_source_id: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider_id": self.provider_id,
            "label": self.label,
            "kind": self.kind,
            "version": self.version,
            "projection_source_id": self.projection_source_id,
        }


class KnowledgeGraphProviderRegistry:
    def __init__(
        self,
        documents: Sequence[SkillDocument],
        graph: SkillGraphSnapshot,
        *,
        dense_embedder: Embedder | None = None,
        dense_model_path: str | None = None,
        dense_model_id: str | None = None,
        query_prompt: str = "query: ",
        document_prompt: str = "passage: ",
    ) -> None:
        if dense_embedder is not None and dense_model_path is not None:
            raise ValueError("provide either dense_embedder or dense_model_path")
        self.documents = tuple(documents)
        self.graph = graph
        self._node_ids = {
            document.version.skill_id: graph_node_id(
                "skill", document.version.skill_id
            )
            for document in self.documents
        }
        route = academic_bm25_benchmark_route()
        route.retriever.index(self.documents)
        self._bm25 = route.retriever
        self._dense_embedder = dense_embedder
        self._dense_model_id = dense_model_id or "injected-dense-model"
        self._dense_version = "injected"
        self._model_validation: dict[str, Any] = {
            "configured": dense_embedder is not None,
            "valid": dense_embedder is not None,
        }
        if dense_model_path is not None:
            try:
                validated = load_validated_local_model(
                    dense_model_path,
                    model_id=dense_model_id,
                    query_prompt=query_prompt,
                    document_prompt=document_prompt,
                )
                self._dense_embedder = validated.embedder
                self._dense_model_id = validated.validation.model_id
                self._dense_version = validated.validation.revision
                self._model_validation = {
                    "configured": True,
                    "valid": True,
                    **validated.validation.as_dict(),
                }
            except LocalModelValidationError as error:
                self._model_validation = {
                    "configured": True,
                    "valid": False,
                    "error": str(error),
                }
        self._dense: EmbeddingRetriever | None = None
        self._dense_lock = Lock()
        self._projection_cache: dict[int, KnowledgeGraphProjection] = {}

    def manifests(self) -> dict[str, Any]:
        projections = []
        if self._dense_embedder is not None:
            projections.append(
                {
                    "projection_source_id": DENSE_PROVIDER_ID,
                    "label": f"PCA · {self._dense_model_id}",
                    "method": f"pca:{self._dense_model_id}",
                    "dimensions": [2, 3],
                    "provider_id": DENSE_PROVIDER_ID,
                    "provider_version": self._dense_version,
                }
            )
        return {
            "providers": [manifest.as_dict() for manifest in self._manifests()],
            "default_provider_id": BM25_PROVIDER_ID,
            "fallback_provider_id": BM25_PROVIDER_ID,
            "model_validation": self._model_validation,
            "projections": projections,
            "confidence_semantics": "query-relative min-max score",
        }

    def query(
        self,
        query: str,
        provider_id: str,
        *,
        limit: int | None = None,
    ) -> KnowledgeGraphSelection:
        query = query.strip()
        if not query:
            raise ValueError("query is required")
        if provider_id not in {BM25_PROVIDER_ID, DENSE_PROVIDER_ID, HYBRID_PROVIDER_ID}:
            raise LookupError(f"unknown graph provider: {provider_id}")
        result_limit = min(max(1, limit or len(self.documents)), len(self.documents))
        route_hits: dict[str, Sequence[SearchHit]] = {}
        if provider_id in {BM25_PROVIDER_ID, HYBRID_PROVIDER_ID}:
            route_hits[BM25_PROVIDER_ID] = self._bm25.search(query, result_limit)
        if provider_id in {DENSE_PROVIDER_ID, HYBRID_PROVIDER_ID}:
            try:
                route_hits[DENSE_PROVIDER_ID] = self._dense_retriever().search(
                    query, result_limit
                )
            except Exception:
                return self._fallback_selection(query, provider_id, result_limit)

        if provider_id == HYBRID_PROVIDER_ID:
            fused = reciprocal_rank_fusion(route_hits, limit=result_limit)
            ranked = [
                (
                    hit.skill_version.skill_id,
                    hit.score,
                    hit.rank,
                    hit.contributing_routes,
                )
                for hit in fused
            ]
        else:
            hits = route_hits[provider_id]
            ranked = [
                (
                    hit.skill_version.skill_id,
                    hit.score,
                    hit.rank,
                    (provider_id,),
                )
                for hit in hits
            ]

        confidences = _minmax_confidence([item[1] for item in ranked])
        direct_by_skill = self._direct_confidences(route_hits)
        selected_nodes = tuple(
            SelectedGraphNode(
                node_id=self._node_ids[skill_id],
                score=confidence,
                rank=rank,
                direct_confidence=direct_by_skill.get(skill_id, confidence),
                routed_confidence=confidence,
                path=(self._node_ids[skill_id],),
                contributors=tuple(contributors),
            )
            for (skill_id, _, rank, contributors), confidence in zip(
                ranked, confidences
            )
        )
        derived_links = self._query_links(query, selected_nodes)
        manifest = next(
            item for item in self._manifests() if item.provider_id == provider_id
        )
        return KnowledgeGraphSelection(
            query=query,
            threshold=0.5,
            provider_kind=manifest.kind,
            provider_id=provider_id,
            provider_version=manifest.version,
            selected_nodes=selected_nodes,
            derived_links=derived_links,
        )

    def projection(
        self, projection_source_id: str, dimensions: int
    ) -> KnowledgeGraphProjection:
        if projection_source_id != DENSE_PROVIDER_ID:
            raise LookupError(
                f"unknown projection source: {projection_source_id}"
            )
        if dimensions not in {2, 3}:
            raise ValueError("projection dimensions must be 2 or 3")
        with self._dense_lock:
            cached = self._projection_cache.get(dimensions)
            if cached is not None:
                return cached
            dense = self._dense_retriever_locked()
            projection = _pca_projection(
                tuple(self._node_ids[document.version.skill_id] for document in self.documents),
                dense.document_vectors,
                dimensions,
                method=f"pca:{self._dense_model_id}",
            )
            self._projection_cache[dimensions] = projection
            return projection

    def _manifests(self) -> tuple[ProviderManifest, ...]:
        manifests = [
            ProviderManifest(
                BM25_PROVIDER_ID,
                "Frozen BM25",
                "lexical",
                ACADEMIC_BM25_PROFILE,
            )
        ]
        if self._dense_embedder is None:
            return tuple(manifests)
        manifests.extend(
            (
            ProviderManifest(
                DENSE_PROVIDER_ID,
                f"Local dense · {self._dense_model_id}",
                "embedding",
                self._dense_version,
                DENSE_PROVIDER_ID,
            ),
            ProviderManifest(
                HYBRID_PROVIDER_ID,
                f"BM25 + {self._dense_model_id} · RRF",
                "hybrid",
                f"{ACADEMIC_BM25_PROFILE}+{self._dense_version}",
                DENSE_PROVIDER_ID,
            ),
            )
        )
        return tuple(manifests)

    def _dense_retriever(self) -> EmbeddingRetriever:
        with self._dense_lock:
            return self._dense_retriever_locked()

    def _dense_retriever_locked(self) -> EmbeddingRetriever:
        if self._dense is not None:
            return self._dense
        if self._dense_embedder is None:
            raise RuntimeError("no validated local dense model is available")
        embedder = self._dense_embedder
        perspective = RetrievalPerspective(
            name="knowledge-graph-document-v1",
            field_repetitions={"title": 3, "description": 2, "body": 1},
            metadata_keys=("category", "tags"),
        )
        identity = ExpertIdentity(
            name="pkm-dense",
            perspective=perspective.name,
            revision=self._dense_version,
        )
        dense = EmbeddingRetriever(identity, perspective, embedder)
        dense.index(self.documents)
        self._dense = dense
        return dense

    def _fallback_selection(
        self, query: str, requested_provider_id: str, limit: int
    ) -> KnowledgeGraphSelection:
        fallback = self.query(query, BM25_PROVIDER_ID, limit=limit)
        return KnowledgeGraphSelection(
            query=fallback.query,
            threshold=fallback.threshold,
            provider_kind=fallback.provider_kind,
            provider_id=fallback.provider_id,
            provider_version=fallback.provider_version,
            selected_nodes=fallback.selected_nodes,
            derived_links=fallback.derived_links,
            requested_provider_id=requested_provider_id,
            fallback_reason="dense_provider_unavailable",
        )

    def _direct_confidences(
        self, route_hits: dict[str, Sequence[SearchHit]]
    ) -> dict[str, float]:
        direct: dict[str, float] = {}
        for hits in route_hits.values():
            confidences = _minmax_confidence([hit.score for hit in hits])
            for hit, confidence in zip(hits, confidences):
                skill_id = hit.skill_version.skill_id
                direct[skill_id] = max(direct.get(skill_id, 0.0), confidence)
        return direct

    @staticmethod
    def _query_links(
        query: str, selected_nodes: Sequence[SelectedGraphNode]
    ) -> tuple[SelectedGraphLink, ...]:
        if len(selected_nodes) < 2:
            return ()
        anchor = selected_nodes[0]
        return tuple(
            SelectedGraphLink(
                source_id=anchor.node_id,
                target_id=node.node_id,
                confidence=min(anchor.routed_confidence or 0, node.routed_confidence or 0),
                topic=query,
                contributors=node.contributors,
            )
            for node in selected_nodes[1:]
        )


def _minmax_confidence(scores: Sequence[float]) -> list[float]:
    if not scores:
        return []
    low, high = min(scores), max(scores)
    if high == low:
        return [1.0 for _ in scores]
    return [(score - low) / (high - low) for score in scores]


def _pca_projection(
    node_ids: Sequence[str],
    vectors: Sequence[Sequence[float]],
    dimensions: int,
    method: str = "pca:dense-local",
) -> KnowledgeGraphProjection:
    import numpy as np

    matrix = np.asarray(vectors, dtype=float)
    centered = matrix - matrix.mean(axis=0, keepdims=True)
    _, _, right = np.linalg.svd(centered, full_matrices=False)
    coordinates = centered @ right[:dimensions].T
    if coordinates.shape[1] < dimensions:
        coordinates = np.pad(
            coordinates, ((0, 0), (0, dimensions - coordinates.shape[1]))
        )
    return KnowledgeGraphProjection(
        method=method,
        dimensions=dimensions,
        nodes=tuple(
            ProjectedGraphNode(
                node_id=node_id,
                coordinates=tuple(float(value) for value in row),
            )
            for node_id, row in zip(node_ids, coordinates)
        ),
    )