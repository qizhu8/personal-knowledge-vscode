from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .skill_graph import SkillGraphSnapshot


EDGE_CONFIDENCE = {
    "EXPLICIT_REFERENCE": 0.97,
    "DERIVED_FROM": 0.95,
    "OWNED_BY": 0.90,
    "CHILD_OF": 0.86,
    "HAS_FACET": 0.82,
}
DIRECTED_EDGE_TYPES = frozenset({"EXPLICIT_REFERENCE", "DERIVED_FROM"})


@dataclass(frozen=True, slots=True)
class SelectedGraphNode:
    node_id: str
    score: float
    rank: int | None = None
    direct_confidence: float | None = None
    routed_confidence: float | None = None
    path: tuple[str, ...] = ()
    contributors: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for value in (self.score, self.direct_confidence, self.routed_confidence):
            if value is not None and not 0 <= value <= 1:
                raise ValueError("scores and confidence must be between 0 and 1")


@dataclass(frozen=True, slots=True)
class ProjectedGraphNode:
    node_id: str
    coordinates: tuple[float, ...]

    def __post_init__(self) -> None:
        if len(self.coordinates) not in {2, 3}:
            raise ValueError("projection coordinates must have 2 or 3 dimensions")


@dataclass(frozen=True, slots=True)
class KnowledgeGraphProjection:
    method: str
    dimensions: int
    nodes: tuple[ProjectedGraphNode, ...]

    def __post_init__(self) -> None:
        if not self.method.strip() or self.dimensions not in {2, 3}:
            raise ValueError("projection method and 2 or 3 dimensions are required")
        if any(len(node.coordinates) != self.dimensions for node in self.nodes):
            raise ValueError("all projection coordinates must match dimensions")


@dataclass(frozen=True, slots=True)
class SelectedGraphLink:
    source_id: str
    target_id: str
    confidence: float
    topic: str = ""
    directed: bool = False
    contributors: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.source_id.strip() or not self.target_id.strip():
            raise ValueError("derived link endpoints are required")
        if not 0 <= self.confidence <= 1:
            raise ValueError("derived link confidence must be between 0 and 1")


@dataclass(frozen=True, slots=True)
class KnowledgeGraphSelection:
    query: str
    threshold: float
    provider_kind: str
    provider_id: str
    provider_version: str
    selected_nodes: tuple[SelectedGraphNode, ...]
    derived_links: tuple[SelectedGraphLink, ...] = ()
    projection: KnowledgeGraphProjection | None = None
    requested_provider_id: str | None = None
    fallback_reason: str | None = None

    def __post_init__(self) -> None:
        if not self.query.strip():
            raise ValueError("query is required")
        if not 0 <= self.threshold <= 1:
            raise ValueError("threshold must be between 0 and 1")
        if not all(
            value.strip()
            for value in (self.provider_kind, self.provider_id, self.provider_version)
        ):
            raise ValueError("selection provider identity and version are required")

    def as_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "threshold": self.threshold,
            "provider_kind": self.provider_kind,
            "provider_id": self.provider_id,
            "provider_version": self.provider_version,
            "requested_provider_id": self.requested_provider_id,
            "fallback_reason": self.fallback_reason,
            "selected_nodes": [asdict(node) for node in self.selected_nodes],
            "derived_links": [asdict(link) for link in self.derived_links],
            "projection": asdict(self.projection) if self.projection else None,
        }


def knowledge_graph_payload(
    snapshot: SkillGraphSnapshot,
    *,
    selection_provider: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    node_counts: dict[str, int] = {}
    labels = {node.node_id: node.label for node in snapshot.nodes}
    for node in snapshot.nodes:
        node_counts[node.node_type] = node_counts.get(node.node_type, 0) + 1

    links = []
    for edge in snapshot.edges:
        confidence = EDGE_CONFIDENCE.get(edge.edge_type, edge.confidence)
        topic = " / ".join(
            label
            for label in (labels.get(edge.source_id), labels.get(edge.target_id))
            if label
        )
        links.append(
            {
                "id": edge.edge_id,
                "source": edge.source_id,
                "target": edge.target_id,
                "type": edge.edge_type,
                "confidence": confidence,
                "confidence_loss": 1.0 - confidence,
                "directed": edge.edge_type in DIRECTED_EDGE_TYPES,
                "topic": topic,
                "provenance": edge.provenance,
            }
        )

    return {
        "schema_version": 1,
        "graph_hash": snapshot.graph_hash,
        "identity_strategy": snapshot.identity_strategy,
        "node_counts": node_counts,
        "nodes": [
            {
                "id": node.node_id,
                "label": node.label,
                "type": node.node_type,
                "properties": dict(node.properties),
            }
            for node in snapshot.nodes
        ],
        "links": links,
        "selection_provider": (
            dict(selection_provider) if selection_provider is not None else None
        ),
    }
