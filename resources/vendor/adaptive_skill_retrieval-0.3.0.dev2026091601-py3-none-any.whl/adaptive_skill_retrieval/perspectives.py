from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Mapping

from .models import FeatureSelectorVersion, SkillDocument


@dataclass(frozen=True, slots=True)
class RetrievalPerspective:
    name: str
    revision: str = "1"
    field_repetitions: Mapping[str, int] = field(
        default_factory=lambda: {"title": 3, "description": 2, "body": 1}
    )
    metadata_keys: tuple[str, ...] = ()
    query_prefix: str = ""

    @property
    def version(self) -> FeatureSelectorVersion:
        configuration = json.dumps(
            {
                "field_repetitions": dict(self.field_repetitions),
                "metadata_keys": self.metadata_keys,
                "query_prefix": self.query_prefix,
            },
            ensure_ascii=True,
            sort_keys=True,
        )
        return FeatureSelectorVersion(
            name=self.name,
            revision=self.revision,
            configuration_hash=sha256(configuration.encode("utf-8")).hexdigest(),
        )

    def prepare_query(self, query: str) -> str:
        return f"{self.query_prefix} {query}".strip()

    def prepare_document(self, document: SkillDocument) -> str:
        fields = {
            "title": document.title,
            "description": document.description,
            "body": document.body,
        }
        parts: list[str] = []
        for field_name, repetitions in self.field_repetitions.items():
            value = fields.get(field_name, "")
            parts.extend([value] * max(0, repetitions))
        parts.extend(
            document.metadata[key]
            for key in self.metadata_keys
            if key in document.metadata
        )
        return "\n".join(parts)
