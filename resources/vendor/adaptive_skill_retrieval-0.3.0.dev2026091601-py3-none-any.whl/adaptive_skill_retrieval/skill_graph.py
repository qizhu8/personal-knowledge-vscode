from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import UUID, uuid5

from .benchmark import load_pkm_skills
from .models import SkillDocument


GRAPH_SCHEMA_VERSION = 1
_GRAPH_NAMESPACE = UUID("2f46fc68-97d7-4f0d-b05d-fc95bf3e747d")
_FACET_SLUG = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True, slots=True)
class GraphNode:
    node_id: str
    node_type: str
    label: str
    properties: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class GraphEdge:
    edge_id: str
    edge_type: str
    source_id: str
    target_id: str
    confidence: float
    provenance: str


@dataclass(frozen=True, slots=True)
class SkillGraphSnapshot:
    schema_version: int
    identity_strategy: str
    corpus_hash: str
    graph_hash: str
    nodes: tuple[GraphNode, ...]
    edges: tuple[GraphEdge, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "identity_strategy": self.identity_strategy,
            "corpus_hash": self.corpus_hash,
            "graph_hash": self.graph_hash,
            "nodes": [asdict(node) for node in self.nodes],
            "edges": [asdict(edge) for edge in self.edges],
        }


def build_skill_graph(
    documents: Sequence[SkillDocument],
    *,
    source_paths: Mapping[str, Path] | None = None,
    source_root: Path | None = None,
) -> SkillGraphSnapshot:
    nodes: dict[str, GraphNode] = {}
    edges: dict[str, GraphEdge] = {}
    root_id = graph_node_id("taxonomy", "root")
    nodes[root_id] = GraphNode(root_id, "taxonomy", "Skills", {"path": ""})

    for document in sorted(documents, key=lambda item: item.version.skill_id):
        skill_id = document.version.skill_id
        category = skill_id.rpartition("/")[0]
        parent_id = root_id
        category_path = ""
        for segment in filter(None, category.split("/")):
            category_path = f"{category_path}/{segment}".strip("/")
            category_id = graph_node_id("taxonomy", category_path)
            nodes.setdefault(
                category_id,
                GraphNode(
                    category_id,
                    "taxonomy",
                    segment,
                    {"path": category_path},
                ),
            )
            _add_edge(
                edges,
                "CHILD_OF",
                category_id,
                parent_id,
                provenance="filesystem_path",
            )
            parent_id = category_id

        skill_node_id = graph_node_id("skill", skill_id)
        nodes[skill_node_id] = GraphNode(
            skill_node_id,
            "skill",
            document.title,
            {
                "skill_id": skill_id,
                "description": document.description,
                "content_hash": document.version.content_hash,
            },
        )
        _add_edge(
            edges,
            "OWNED_BY",
            skill_node_id,
            parent_id,
            provenance="filesystem_path",
        )

        tags = str(document.metadata.get("tags") or "").split()
        for tag in sorted(set(filter(None, tags))):
            facet_key = _FACET_SLUG.sub("-", tag.casefold()).strip("-")
            if not facet_key:
                continue
            facet_id = graph_node_id("facet", f"tag:{facet_key}")
            nodes.setdefault(
                facet_id,
                GraphNode(
                    facet_id,
                    "facet",
                    tag,
                    {"dimension": "tag", "value": facet_key},
                ),
            )
            _add_edge(
                edges,
                "HAS_FACET",
                skill_node_id,
                facet_id,
                provenance="frontmatter_tag",
            )

        source_path = (source_paths or {}).get(skill_id)
        if source_path is not None:
            relative_path = (
                source_path.relative_to(source_root).as_posix()
                if source_root is not None
                else source_path.name
            )
            source_id = graph_node_id("source", relative_path)
            nodes[source_id] = GraphNode(
                source_id,
                "source",
                source_path.name,
                {"relative_path": relative_path},
            )
            _add_edge(
                edges,
                "DERIVED_FROM",
                skill_node_id,
                source_id,
                provenance="pkm_loader",
            )

    ordered_nodes = tuple(sorted(nodes.values(), key=lambda item: item.node_id))
    ordered_edges = tuple(sorted(edges.values(), key=lambda item: item.edge_id))
    corpus_payload = [
        (document.version.skill_id, document.version.content_hash)
        for document in sorted(documents, key=lambda item: item.version.skill_id)
    ]
    corpus_hash = _canonical_hash(corpus_payload)
    graph_hash = _canonical_hash(
        {
            "schema_version": GRAPH_SCHEMA_VERSION,
            "identity_strategy": "path-derived-v0",
            "corpus_hash": corpus_hash,
            "nodes": [asdict(node) for node in ordered_nodes],
            "edges": [asdict(edge) for edge in ordered_edges],
        }
    )
    return SkillGraphSnapshot(
        schema_version=GRAPH_SCHEMA_VERSION,
        identity_strategy="path-derived-v0",
        corpus_hash=corpus_hash,
        graph_hash=graph_hash,
        nodes=ordered_nodes,
        edges=ordered_edges,
    )


def write_skill_graph(snapshot: SkillGraphSnapshot, output: str | Path) -> Path:
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(snapshot.as_dict(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return output_path


def graph_node_id(node_type: str, identity: str) -> str:
    return f"{node_type}:{uuid5(_GRAPH_NAMESPACE, f'{node_type}:{identity}') }"


def _add_edge(
    edges: dict[str, GraphEdge],
    edge_type: str,
    source_id: str,
    target_id: str,
    *,
    provenance: str,
) -> None:
    identity = f"{edge_type}:{source_id}:{target_id}"
    edge_id = f"edge:{uuid5(_GRAPH_NAMESPACE, identity)}"
    edges.setdefault(
        edge_id,
        GraphEdge(
            edge_id=edge_id,
            edge_type=edge_type,
            source_id=source_id,
            target_id=target_id,
            confidence=1.0,
            provenance=provenance,
        ),
    )


def _canonical_hash(value: object) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return sha256(payload.encode("utf-8")).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a read-only graph projection of a PKM Skill corpus"
    )
    parser.add_argument("--pkm-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.pkm_root).resolve()
    documents, paths = load_pkm_skills(root)
    snapshot = build_skill_graph(
        documents,
        source_paths=paths,
        source_root=root,
    )
    output = write_skill_graph(snapshot, args.output)
    print(
        json.dumps(
            {
                "output": str(output),
                "nodes": len(snapshot.nodes),
                "edges": len(snapshot.edges),
                "corpus_hash": snapshot.corpus_hash,
                "graph_hash": snapshot.graph_hash,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()