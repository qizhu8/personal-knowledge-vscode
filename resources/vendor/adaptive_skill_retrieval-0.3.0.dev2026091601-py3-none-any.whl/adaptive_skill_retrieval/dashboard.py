from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .benchmark import load_pkm_skills
from .collector import CollectorStore, replay_collected
from .graph_providers import KnowledgeGraphProviderRegistry
from .knowledge_graph import knowledge_graph_payload
from .skill_graph import SkillGraphSnapshot, build_skill_graph
from .skill_paths import SkillPathRecommender
from .summary import build_dashboard_summary
from .telemetry import JsonlTelemetryStore


PATH_RECOMMENDER_VERSION = "ownership-signals-v1"


def _first(values: dict[str, list[str]], key: str) -> str | None:
    items = values.get(key)
    return items[0] if items else None


def _is_same_origin(origin: str | None, hosts: set[str]) -> bool:
    if not origin:
        return False
    parsed = urlparse(origin)
    return parsed.scheme in {"http", "https"} and parsed.netloc.casefold() in {
        host.casefold() for host in hosts if host
    }


def _handler_for(
    store: JsonlTelemetryStore,
    benchmark_report: Path | None,
    default_view: str,
    collector: CollectorStore | None,
    collector_token: str | None,
    path_recommender: SkillPathRecommender | None,
    knowledge_graph: SkillGraphSnapshot | None,
    graph_providers: KnowledgeGraphProviderRegistry | None,
) -> type[BaseHTTPRequestHandler]:
    dashboard_path = Path(__file__).with_name("dashboard.html")
    benchmark_path = Path(__file__).with_name("benchmark_dashboard.html")

    class DashboardHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            path = parsed.path
            if path == "/api/summary":
                self._send_json(build_dashboard_summary(store.read_events()))
                return
            if path == "/api/benchmark":
                if benchmark_report is None or not benchmark_report.exists():
                    self.send_error(404, "Benchmark report not configured")
                    return
                self._send_json(json.loads(benchmark_report.read_text(encoding="utf-8")))
                return
            if path == "/api/knowledge-graph":
                if knowledge_graph is None:
                    self.send_error(404, "PKM root not configured")
                    return
                self._send_json(knowledge_graph_payload(knowledge_graph))
                return
            if path == "/api/knowledge-graph/providers":
                if graph_providers is None:
                    self.send_error(404, "PKM root not configured")
                    return
                self._send_json(graph_providers.manifests())
                return
            if path == "/api/knowledge-graph/projection":
                if graph_providers is None:
                    self.send_error(404, "PKM root not configured")
                    return
                query = parse_qs(parsed.query)
                try:
                    projection = graph_providers.projection(
                        _first(query, "source") or "",
                        int(_first(query, "dimensions") or 2),
                    )
                    self._send_json(asdict(projection))
                except LookupError as error:
                    self._send_json({"ok": False, "error": str(error)}, status=404)
                except (ValueError, TypeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=400)
                except (ImportError, OSError, RuntimeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=503)
                return
            if path == "/api/health":
                self._send_json(
                    {
                        "status": "ok",
                        "benchmark_available": bool(
                            benchmark_report is not None and benchmark_report.exists()
                        ),
                        "collector_available": collector is not None,
                    }
                )
                return
            if path == "/api/collector/summary":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                self._send_json(collector.summary())
                return
            if path == "/api/collector/events":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                query = parse_qs(parsed.query)
                self._send_json(
                    {
                        "events": collector.events(
                            event_type=_first(query, "event_type"),
                            interaction_id=_first(query, "interaction_id"),
                            limit=int(_first(query, "limit") or 1000),
                        )
                    }
                )
                return
            if path == "/api/collector/training-data":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                examples = collector.training_examples()
                self._send_json({"count": len(examples), "examples": examples})
                return
            if path == "/api/collector/trash":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                examples = collector.trash_examples()
                self._send_json({"count": len(examples), "examples": examples})
                return
            if path == "/api/collector/export.jsonl":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                self._send(
                    collector.export_jsonl().encode("utf-8"),
                    "application/x-ndjson; charset=utf-8",
                )
                return
            if path == "/api/collector/replay":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                self._send_json(replay_collected(collector))
                return
            if path == "/api/skill-path/decisions":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                query = parse_qs(parsed.query)
                decisions = collector.path_decisions(
                    limit=int(_first(query, "limit") or 1000)
                )
                self._send_json({"count": len(decisions), "decisions": decisions})
                return
            if path in {"/", "/index.html"}:
                self._send(
                    (
                        benchmark_path.read_bytes()
                        if default_view == "performance"
                        else dashboard_path.read_bytes()
                    ),
                    "text/html; charset=utf-8",
                )
                return
            if path in {"/telemetry", "/telemetry.html"}:
                self._send(
                    dashboard_path.read_bytes(),
                    "text/html; charset=utf-8",
                )
                return
            if path in {"/performance", "/performance.html"}:
                self._send(
                    benchmark_path.read_bytes(),
                    "text/html; charset=utf-8",
                )
                return
            self.send_error(404)

        def do_POST(self) -> None:
            path = urlparse(self.path).path
            if path == "/api/knowledge-graph/query":
                if graph_providers is None:
                    self.send_error(404, "PKM root not configured")
                    return
                if not self._dashboard_authorized():
                    self.send_error(403, "Dashboard writes require a same-origin request")
                    return
                try:
                    payload = self._read_json_object()
                    selection = graph_providers.query(
                        str(payload.get("query") or ""),
                        str(payload.get("provider_id") or ""),
                        limit=(
                            int(payload["limit"])
                            if payload.get("limit") is not None
                            else None
                        ),
                    )
                    self._send_json(selection.as_dict())
                except LookupError as error:
                    self._send_json({"ok": False, "error": str(error)}, status=404)
                except (ValueError, TypeError, json.JSONDecodeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=400)
                except (ImportError, OSError, RuntimeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=503)
                return
            if path == "/api/skill-path/recommend":
                if path_recommender is None:
                    self.send_error(404, "PKM root not configured")
                    return
                if not self._dashboard_authorized():
                    self.send_error(403, "Dashboard writes require a same-origin request")
                    return
                try:
                    payload = self._read_json_object()
                    suggestion = path_recommender.recommend(
                        name=str(payload.get("name") or ""),
                        description=str(payload.get("description") or ""),
                        content=str(payload.get("content") or ""),
                        tags=tuple(str(tag) for tag in payload.get("tags") or ()),
                        source_project=str(payload.get("source_project") or ""),
                    )
                    result = suggestion.as_dict()
                    if collector is not None:
                        taxonomy_ids = sorted(
                            document.version.skill_id
                            for document in path_recommender.documents
                        )
                        taxonomy_version = sha256(
                            "\n".join(taxonomy_ids).encode("utf-8")
                        ).hexdigest()
                        recommendation = collector.record_path_recommendation(
                            draft=payload,
                            suggestion=result,
                            taxonomy_version=taxonomy_version,
                            corpus_snapshot_id=collector.snapshot_corpus(),
                            model_version=PATH_RECOMMENDER_VERSION,
                        )
                        result.update(
                            {
                                "recommendation_id": recommendation[
                                    "recommendation_id"
                                ],
                                "skill_draft_hash": recommendation[
                                    "skill_draft_hash"
                                ],
                                "taxonomy_version": taxonomy_version,
                                "corpus_snapshot_id": recommendation[
                                    "corpus_snapshot_id"
                                ],
                                "model_version": PATH_RECOMMENDER_VERSION,
                            }
                        )
                    self._send_json(result)
                except (ValueError, json.JSONDecodeError, TypeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=400)
                return
            if path == "/api/skill-path/decisions":
                if collector is None:
                    self.send_error(404, "Collector not configured")
                    return
                if not self._dashboard_authorized():
                    self.send_error(403, "Dashboard writes require a same-origin request")
                    return
                try:
                    payload = self._read_json_object()
                    decision = collector.record_path_decision(
                        recommendation_id=str(
                            payload.get("recommendation_id") or ""
                        ),
                        decision=str(payload.get("decision") or ""),
                        accepted_category=str(
                            payload.get("accepted_category") or ""
                        ),
                        existing_skill_id=str(
                            payload.get("existing_skill_id") or ""
                        ),
                        new_child_name=str(payload.get("new_child_name") or ""),
                    )
                    self._send_json({"ok": True, "decision": decision}, status=201)
                except LookupError as error:
                    self._send_json({"ok": False, "error": str(error)}, status=404)
                except (ValueError, json.JSONDecodeError, TypeError) as error:
                    self._send_json({"ok": False, "error": str(error)}, status=400)
                return
            if collector is None or path not in {
                "/api/collector/events",
                "/api/collector/trash",
                "/api/collector/trash/restore",
                "/api/collector/trash/purge",
            }:
                self.send_error(404)
                return
            is_event_ingestion = path == "/api/collector/events"
            if is_event_ingestion and not self._collector_authorized():
                self.send_error(403, "Collector writes require loopback or token")
                return
            if not is_event_ingestion and not self._dashboard_authorized():
                self.send_error(403, "Dashboard writes require a same-origin request")
                return
            try:
                payload = self._read_json()
                if path != "/api/collector/events":
                    if not isinstance(payload, dict):
                        raise ValueError("request must be an object")
                    interaction_id = str(payload.get("interaction_id") or "")
                    operation = {
                        "/api/collector/trash": collector.trash_interaction,
                        "/api/collector/trash/restore": collector.restore_interaction,
                        "/api/collector/trash/purge": collector.purge_interaction,
                    }[path]
                    changed = operation(interaction_id)
                    self._send_json({"ok": changed, "interaction_id": interaction_id}, status=200 if changed else 404)
                    return
                events = payload if isinstance(payload, list) else [payload]
                if not all(isinstance(event, dict) for event in events):
                    raise ValueError("request must be an event object or event array")
                self._send_json(collector.append_many(events), status=202)
            except (ValueError, json.JSONDecodeError) as error:
                self._send_json({"ok": False, "error": str(error)}, status=400)

        def _read_json(self) -> object:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > 16 * 1024 * 1024:
                raise ValueError("request body must be between 1 byte and 16 MiB")
            return json.loads(self.rfile.read(length))

        def _read_json_object(self) -> dict[str, object]:
            payload = self._read_json()
            if not isinstance(payload, dict):
                raise ValueError("request must be an object")
            return payload

        def _collector_authorized(self) -> bool:
            if collector_token:
                return self.headers.get("Authorization") == f"Bearer {collector_token}"
            return self.client_address[0] in {"127.0.0.1", "::1"}

        def _dashboard_authorized(self) -> bool:
            if self.client_address[0] in {"127.0.0.1", "::1"}:
                return True
            hosts = {
                self.headers.get("Host", ""),
                self.headers.get("X-Forwarded-Host", ""),
            }
            return _is_same_origin(self.headers.get("Origin"), hosts)

        def _send_json(self, value: object, *, status: int = 200) -> None:
            self._send(
                json.dumps(value, ensure_ascii=True).encode("utf-8"),
                "application/json; charset=utf-8",
                status=status,
            )

        def _send(self, payload: bytes, content_type: str, *, status: int = 200) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, format: str, *args: object) -> None:
            return

    return DashboardHandler


def create_dashboard_server(
    store: JsonlTelemetryStore,
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    benchmark_report: str | Path | None = None,
    default_view: str = "telemetry",
    collector_database: str | Path | None = None,
    pkm_root: str | Path | None = None,
    collector_token: str | None = None,
    dense_model_path: str | None = None,
    dense_model_id: str | None = None,
    dense_query_prompt: str = "query: ",
    dense_document_prompt: str = "passage: ",
    graph_provider_registry: KnowledgeGraphProviderRegistry | None = None,
) -> ThreadingHTTPServer:
    if default_view not in {"telemetry", "performance"}:
        raise ValueError("default_view must be 'telemetry' or 'performance'")
    report_path = Path(benchmark_report) if benchmark_report is not None else None
    collector = (
        CollectorStore(collector_database, pkm_root=pkm_root)
        if collector_database is not None
        else None
    )
    path_recommender = None
    knowledge_graph = None
    graph_providers = graph_provider_registry
    if pkm_root is not None:
        root = Path(pkm_root).resolve()
        documents, paths = load_pkm_skills(root)
        path_recommender = SkillPathRecommender(documents)
        knowledge_graph = build_skill_graph(
            documents,
            source_paths=paths,
            source_root=root,
        )
        if graph_providers is None:
            graph_providers = KnowledgeGraphProviderRegistry(
                documents,
                knowledge_graph,
                dense_model_path=dense_model_path,
                dense_model_id=dense_model_id,
                query_prompt=dense_query_prompt,
                document_prompt=dense_document_prompt,
            )
    return ThreadingHTTPServer(
        (host, port),
        _handler_for(
            store,
            report_path,
            default_view,
            collector,
            collector_token,
            path_recommender,
            knowledge_graph,
            graph_providers,
        ),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve route performance telemetry")
    parser.add_argument("--events", default="telemetry/events.jsonl")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8765, type=int)
    parser.add_argument("--benchmark-report")
    parser.add_argument("--collector-database")
    parser.add_argument("--pkm-root")
    parser.add_argument("--collector-token")
    parser.add_argument("--dense-model-path")
    parser.add_argument("--dense-model-id")
    parser.add_argument("--dense-query-prompt", default="query: ")
    parser.add_argument("--dense-document-prompt", default="passage: ")
    parser.add_argument(
        "--default-view",
        choices=("telemetry", "performance"),
        default="telemetry",
    )
    args = parser.parse_args()
    server = create_dashboard_server(
        JsonlTelemetryStore(args.events),
        host=args.host,
        port=args.port,
        benchmark_report=args.benchmark_report,
        default_view=args.default_view,
        collector_database=args.collector_database,
        pkm_root=args.pkm_root,
        collector_token=args.collector_token,
        dense_model_path=args.dense_model_path,
        dense_model_id=args.dense_model_id,
        dense_query_prompt=args.dense_query_prompt,
        dense_document_prompt=args.dense_document_prompt,
    )
    print(f"Dashboard: http://{args.host}:{server.server_port}")
    if args.benchmark_report:
        print(f"Performance: http://{args.host}:{server.server_port}/performance")
    server.serve_forever()


if __name__ == "__main__":
    main()