from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum


class QueryIntent(StrEnum):
    EXACT = "exact"
    SEMANTIC = "semantic"
    HYBRID = "hybrid"


@dataclass(frozen=True, slots=True)
class QueryIntentDecision:
    intent: QueryIntent
    exact_terms: tuple[str, ...] = ()
    lexical_anchors: tuple[str, ...] = ()
    fuzzy_terms: tuple[str, ...] = ()
    fuzzy_query: str = ""
    relevance_query: str = ""
    signals: tuple[str, ...] = ()


_CLAUSE_PATTERN = re.compile(
    r'\$([^$]+)\$|~"([^"]+)"|~`([^`]+)`|"([^"]+)"|`([^`]+)`|~(\S+)'
)
_IDENTIFIER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_$])(?:[A-Za-z_$][\w$]*(?:[._/#:][\w$]+)+|"
    r"[A-Za-z]+\d+[A-Za-z0-9]*|[A-Za-z_$]*[a-z][A-Z][A-Za-z0-9$]*)"
    r"(?![A-Za-z0-9_$])"
)
_FUZZY_TERM_PATTERN = re.compile(r"[\w.+#/-]+", re.UNICODE)


def classify_query_intent(query: str) -> QueryIntentDecision:
    stripped = query.strip()
    hard_exact: list[str] = []
    soft_anchors: list[str] = []
    forced_fuzzy: list[str] = []
    residual_parts: list[str] = []
    signals: list[str] = []
    cursor = 0
    for match in _CLAUSE_PATTERN.finditer(stripped):
        residual_parts.append(stripped[cursor:match.start()])
        hard, fuzzy_quote, fuzzy_code, phrase, code, fuzzy_token = match.groups()
        if hard and hard.strip():
            hard_exact.append(hard.strip())
            signals.append("hard_exact")
        elif phrase and phrase.strip():
            soft_anchors.append(phrase.strip())
            signals.append("quoted_anchor")
        elif code and code.strip():
            soft_anchors.append(code.strip())
            signals.append("code_anchor")
        else:
            forced = fuzzy_quote or fuzzy_code or fuzzy_token
            if forced and forced.strip():
                forced_fuzzy.append(forced.strip())
                signals.append("forced_fuzzy")
        cursor = match.end()
    residual_parts.append(stripped[cursor:])
    residual = " ".join(residual_parts)
    identifiers = _IDENTIFIER_PATTERN.findall(residual)
    if identifiers:
        soft_anchors.extend(identifiers)
        signals.append("identifier_anchor")
    residual = _IDENTIFIER_PATTERN.sub(" ", residual)

    exact_terms = tuple(dict.fromkeys(hard_exact))
    lexical_anchors = tuple(dict.fromkeys(soft_anchors))
    fuzzy_query = " ".join((*forced_fuzzy, residual)).strip()
    fuzzy_terms = tuple(_FUZZY_TERM_PATTERN.findall(fuzzy_query))
    relevance_query = " ".join((*lexical_anchors, fuzzy_query)).strip()
    has_lexical = bool(exact_terms or lexical_anchors)
    intent = (
        QueryIntent.HYBRID
        if has_lexical and fuzzy_terms
        else QueryIntent.EXACT
        if has_lexical
        else QueryIntent.SEMANTIC
    )
    return QueryIntentDecision(
        intent=intent,
        exact_terms=exact_terms,
        lexical_anchors=lexical_anchors,
        fuzzy_terms=fuzzy_terms,
        fuzzy_query=fuzzy_query or (stripped if not has_lexical else ""),
        relevance_query=relevance_query or stripped,
        signals=tuple(dict.fromkeys(signals)),
    )