from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Mapping, Sequence
from uuid import uuid4

from .content_types import infer_content_types, normalize_content_types
from .fusion import FusedHit, reciprocal_rank_fusion
from .models import ContentType, ExpertIdentity, RouteState, SkillDocument, SkillVersion
from .query_intent import QueryIntent, classify_query_intent
from .retrievers import Retriever, SearchHit


@dataclass(slots=True)
class Route:
    identity: ExpertIdentity
    retriever: Retriever
    state: RouteState
    estimated_cost: float = 0.0
    index_version: str = ""
    intents: frozenset[QueryIntent] = field(
        default_factory=lambda: frozenset(
            {QueryIntent.SEMANTIC, QueryIntent.HYBRID}
        )
    )


@dataclass(frozen=True, slots=True)
class RetrievalResult:
    query_id: str
    query: str
    hits: tuple[FusedHit, ...]
    route_hits: Mapping[str, tuple[SearchHit, ...]]
    route_states: Mapping[str, RouteState]
    route_index_versions: Mapping[str, str]
    serving_routes: tuple[str, ...]
    observed_routes: tuple[str, ...]
    query_intent: QueryIntent = QueryIntent.SEMANTIC
    intent_signals: tuple[str, ...] = ()
    exact_terms: tuple[str, ...] = ()
    lexical_anchors: tuple[str, ...] = ()
    fuzzy_terms: tuple[str, ...] = ()
    fuzzy_query: str = ""
    requested_content_types: tuple[ContentType, ...] = ()
    content_type_routing: str = "none"
    engine_index_version: str = ""
    document_content_types: Mapping[SkillVersion, ContentType] = field(
        default_factory=dict
    )

    route_strengths: Mapping[str, float] = field(default_factory=dict)

class RetrievalEngine:
    def __init__(self, routes: Sequence[Route]) -> None:
        route_keys = [route.identity.key for route in routes]
        if len(set(route_keys)) != len(route_keys):
            raise ValueError("route identities must be unique")
        self.routes = list(routes)
        self._documents: dict[SkillVersion, SkillDocument] = {}
        self.index_version = ""

    def index(self, documents: Sequence[SkillDocument]) -> str:
        self._documents = {document.version: document for document in documents}
        snapshot_manifest = "\n".join(
            sorted(
                ":".join(
                    (
                        document.version.skill_id,
                        document.version.content_hash,
                        document.content_type.value,
                        document.source_uri,
                        str(document.read_only),
                    )
                )
                for document in documents
            )
        )
        self.index_version = sha256(snapshot_manifest.encode("utf-8")).hexdigest()
        active_routes = [
            route
            for route in self.routes
            if route.state not in {RouteState.TRAINING, RouteState.DEMOTED}
        ]
        with ThreadPoolExecutor(max_workers=max(1, len(active_routes))) as executor:
            futures = {
                route.identity.key: executor.submit(route.retriever.index, documents)
                for route in active_routes
            }
            for route in active_routes:
                futures[route.identity.key].result()
                manifest = "\n".join(
                    [route.identity.key]
                    + sorted(
                        f"{document.version.skill_id}:{document.version.content_hash}"
                        f":{document.content_type.value}"
                        for document in documents
                    )
                )
                route.index_version = sha256(manifest.encode("utf-8")).hexdigest()
            return self.index_version

    def search(
        self,
        query: str,
        *,
        limit: int = 5,
        per_route_limit: int = 20,
        content_type_filter: Sequence[ContentType | str] | None = None,
    ) -> RetrievalResult:
        intent = classify_query_intent(query)
        explicit_types = (
            normalize_content_types(content_type_filter)
            if content_type_filter is not None
            else ()
        )
        requested_types = explicit_types or infer_content_types(query)
        content_type_routing = (
            "filter" if content_type_filter is not None else "prefer" if requested_types else "none"
        )
        observed = [
            route
            for route in self.routes
            if route.state in {
                RouteState.SERVING,
                RouteState.SHADOW,
                RouteState.CANDIDATE,
            }
            and intent.intent in route.intents
        ]
        fallback_routes = [
            route
            for route in self.routes
            if route.state in {
                RouteState.SERVING,
                RouteState.SHADOW,
                RouteState.CANDIDATE,
            }
            and QueryIntent.SEMANTIC in route.intents
        ]
        if not observed:
            observed = fallback_routes
        route_hits: dict[str, tuple[SearchHit, ...]] = {}
        with ThreadPoolExecutor(max_workers=max(1, len(observed))) as executor:
            futures = {
                route.identity.key: executor.submit(
                    route.retriever.search,
                    _route_query(route, intent, query),
                    per_route_limit,
                )
                for route in observed
            }
            for route_key, future in futures.items():
                route_hits[route_key] = tuple(future.result())
        route_hits = {
            route_key: _route_by_content_type(
                hits,
                self._documents,
                requested_types,
                strict=content_type_filter is not None,
            )
            for route_key, hits in route_hits.items()
        }

        serving_keys = tuple(
            route.identity.key
            for route in observed
            if route.state == RouteState.SERVING
        )
        serving_hits = {key: route_hits[key] for key in serving_keys}
        fused = reciprocal_rank_fusion(serving_hits, limit=limit)
        if intent.intent in {QueryIntent.EXACT, QueryIntent.HYBRID}:
            exact_keys = {
                route.identity.key
                for route in observed
                if QueryIntent.EXACT in route.intents
                and route.state == RouteState.SERVING
            }
            exact_hits = {
                key: route_hits[key] for key in exact_keys if route_hits[key]
            }
            if exact_hits:
                fused = _promote_exact_hits(
                    exact_hits,
                    serving_hits,
                    limit,
                    restrict_to_exact=bool(intent.exact_terms),
                )
            elif intent.exact_terms:
                fused = []
            elif intent.intent == QueryIntent.EXACT and fallback_routes != observed:
                return self._search_with_routes(
                    query,
                    intent,
                    fallback_routes,
                    limit=limit,
                    per_route_limit=per_route_limit,
                    requested_types=requested_types,
                    content_type_routing=content_type_routing,
                )
        return RetrievalResult(
            query_id=str(uuid4()),
            query=query,
            hits=tuple(fused),
            route_hits=route_hits,
            route_states={route.identity.key: route.state for route in observed},
            route_index_versions={
                route.identity.key: route.index_version for route in observed
            },
            serving_routes=serving_keys,
            observed_routes=tuple(route_hits),
            query_intent=intent.intent,
            intent_signals=intent.signals,
            exact_terms=intent.exact_terms,
            lexical_anchors=intent.lexical_anchors,
            fuzzy_terms=intent.fuzzy_terms,
            fuzzy_query=intent.fuzzy_query,
            requested_content_types=requested_types,
            content_type_routing=content_type_routing,
            engine_index_version=self.index_version,
            document_content_types={
                version: document.content_type
                for version, document in self._documents.items()
            },
            route_strengths={
                route.identity.key: 1.0 if route.identity.key in serving_keys else 0.0
                for route in observed
            },
        )

    def _search_with_routes(
        self,
        query: str,
        intent,
        routes: Sequence[Route],
        *,
        limit: int,
        per_route_limit: int,
        requested_types: tuple[ContentType, ...] = (),
        content_type_routing: str = "none",
    ) -> RetrievalResult:
        route_hits = {
            route.identity.key: tuple(
                route.retriever.search(
                    _route_query(route, intent, query), per_route_limit
                )
            )
            for route in routes
        }
        route_hits = {
            route_key: _route_by_content_type(
                hits,
                self._documents,
                requested_types,
                strict=content_type_routing == "filter",
            )
            for route_key, hits in route_hits.items()
        }
        serving_keys = tuple(
            route.identity.key for route in routes if route.state == RouteState.SERVING
        )
        fused = reciprocal_rank_fusion(
            {key: route_hits[key] for key in serving_keys}, limit=limit
        )
        return RetrievalResult(
            query_id=str(uuid4()),
            query=query,
            hits=tuple(fused),
            route_hits=route_hits,
            route_states={route.identity.key: route.state for route in routes},
            route_index_versions={
                route.identity.key: route.index_version for route in routes
            },
            serving_routes=serving_keys,
            observed_routes=tuple(route_hits),
            query_intent=intent.intent,
            intent_signals=intent.signals,
            exact_terms=intent.exact_terms,
            lexical_anchors=intent.lexical_anchors,
            fuzzy_terms=intent.fuzzy_terms,
            fuzzy_query=intent.fuzzy_query,
            requested_content_types=requested_types,
            content_type_routing=content_type_routing,
            engine_index_version=self.index_version,
            document_content_types={
                version: document.content_type
                for version, document in self._documents.items()
            },
            route_strengths={
                route.identity.key: 1.0
                if route.identity.key in serving_keys
                else 0.0
                for route in routes
            },
        )


def _route_query(route: Route, intent, original_query: str) -> str:
    is_exact_route = (
        QueryIntent.EXACT in route.intents
        and QueryIntent.SEMANTIC not in route.intents
    )
    if is_exact_route or intent.intent != QueryIntent.HYBRID:
        return original_query
    return intent.relevance_query or original_query


def _route_by_content_type(
    hits: Sequence[SearchHit],
    documents: Mapping[SkillVersion, SkillDocument],
    requested_types: Sequence[ContentType],
    *,
    strict: bool,
) -> tuple[SearchHit, ...]:
    if not requested_types and not strict:
        return tuple(hits)
    requested = frozenset(requested_types)
    eligible = [
        hit
        for hit in hits
        if documents[hit.skill_version].content_type in requested
    ]
    if not strict:
        eligible_versions = {hit.skill_version for hit in eligible}
        eligible.extend(hit for hit in hits if hit.skill_version not in eligible_versions)
    return tuple(
        SearchHit(
            skill_version=hit.skill_version,
            score=hit.score,
            rank=rank,
            route_key=hit.route_key,
        )
        for rank, hit in enumerate(eligible, start=1)
    )


def _promote_exact_hits(
    exact_hits: Mapping[str, Sequence[SearchHit]],
    serving_hits: Mapping[str, Sequence[SearchHit]],
    limit: int,
    *,
    restrict_to_exact: bool = False,
) -> list[FusedHit]:
    exact_fused = reciprocal_rank_fusion(exact_hits, limit=limit)
    regular_fused = reciprocal_rank_fusion(serving_hits, limit=limit)
    exact_versions = {hit.skill_version for hit in exact_fused}
    ordered = list(exact_fused)
    if not restrict_to_exact:
        ordered.extend(
            hit for hit in regular_fused if hit.skill_version not in exact_versions
        )
    regular_by_version = {hit.skill_version: hit for hit in regular_fused}
    return [
        FusedHit(
            skill_version=hit.skill_version,
            score=hit.score,
            rank=rank,
            contributing_routes=tuple(
                sorted(
                    set(hit.contributing_routes)
                    | set(
                        regular_by_version.get(
                            hit.skill_version, hit
                        ).contributing_routes
                    )
                )
            ),
        )
        for rank, hit in enumerate(ordered[:limit], start=1)
    ]


