from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from torch import Tensor


def _torch() -> Any:
    try:
        import torch
    except ImportError as error:
        raise RuntimeError(
            "SoftRank training requires PyTorch; install the 'training' extra"
        ) from error
    return torch


def soft_rank(
    scores: Tensor,
    *,
    temperature: float = 0.1,
    availability_mask: Tensor | None = None,
) -> Tensor:
    """Approximate descending ranks with pairwise logistic comparisons."""
    torch = _torch()
    if scores.ndim < 1:
        raise ValueError("scores must have at least one dimension")
    if not scores.is_floating_point():
        raise ValueError("scores must be floating point")
    if temperature <= 0:
        raise ValueError("temperature must be positive")

    available = (
        torch.ones_like(scores, dtype=torch.bool)
        if availability_mask is None
        else availability_mask.to(device=scores.device, dtype=torch.bool)
    )
    if available.shape != scores.shape:
        raise ValueError("availability_mask must have the same shape as scores")

    finite_scores = torch.where(available, scores, torch.zeros_like(scores))
    pairwise = torch.sigmoid(
        (finite_scores.unsqueeze(-2) - finite_scores.unsqueeze(-1)) / temperature
    )
    candidate_count = scores.shape[-1]
    competitors = available.unsqueeze(-2).expand_as(pairwise)
    off_diagonal = ~torch.eye(
        candidate_count, dtype=torch.bool, device=scores.device
    )
    ranks = 1.0 + (pairwise * competitors * off_diagonal).sum(dim=-1)
    return torch.where(available, ranks, torch.zeros_like(ranks))


def soft_reciprocal_rank_fusion(
    route_scores: Tensor,
    *,
    availability_mask: Tensor | None = None,
    temperature: float = 0.1,
    rank_constant: float = 60.0,
) -> Tensor:
    """Fuse route scores through differentiable ranks without route weights."""
    torch = _torch()
    if route_scores.ndim != 2:
        raise ValueError("route_scores must have shape [routes, candidates]")
    if rank_constant <= 0:
        raise ValueError("rank_constant must be positive")

    available = (
        torch.ones_like(route_scores, dtype=torch.bool)
        if availability_mask is None
        else availability_mask.to(device=route_scores.device, dtype=torch.bool)
    )
    ranks = soft_rank(
        route_scores,
        temperature=temperature,
        availability_mask=available,
    )
    contributions = torch.where(
        available,
        1.0 / (rank_constant + ranks),
        torch.zeros_like(route_scores),
    )
    return contributions.sum(dim=0)


def soft_rrf_listwise_loss(
    fused_scores: Tensor,
    relevant_mask: Tensor,
    *,
    temperature: float = 0.01,
) -> Tensor:
    """Maximize the probability mass assigned to one or more relevant Skills."""
    torch = _torch()
    if fused_scores.ndim != 1:
        raise ValueError("fused_scores must have shape [candidates]")
    relevant = relevant_mask.to(device=fused_scores.device, dtype=torch.bool)
    if relevant.shape != fused_scores.shape:
        raise ValueError("relevant_mask must have the same shape as fused_scores")
    if not bool(relevant.any()):
        raise ValueError("at least one candidate must be relevant")
    if temperature <= 0:
        raise ValueError("temperature must be positive")

    logits = fused_scores / temperature
    return torch.logsumexp(logits, dim=0) - torch.logsumexp(logits[relevant], dim=0)