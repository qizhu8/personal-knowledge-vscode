from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from .fusion import FusedHit, reciprocal_rank_fusion
from .models import ContentType, SkillDocument
from .perspectives import RetrievalPerspective
from .retrievers import SearchHit


@dataclass(frozen=True, slots=True)
class BenchmarkCase:
    case_id: str
    domain: str
    language: str
    query: str
    relevant_skill_ids: frozenset[str]
    split: str = "test"


@dataclass(frozen=True, slots=True)
class RankingMetrics:
    cases: int
    hit_rate_at_k: float
    top1_accuracy: float
    precision_at_k: float
    recall_at_k: float
    mrr: float
    map_at_k: float
    ndcg_at_k: float
    latency_ms: float | None = None


def load_pkm_skills(root: str | Path) -> tuple[list[SkillDocument], dict[str, Path]]:
    root = Path(root)
    documents: list[SkillDocument] = []
    paths: dict[str, Path] = {}
    for path in sorted(root.rglob("*.md")):
        relative = path.relative_to(root)
        if any(part.startswith((".", "_")) for part in relative.parts):
            continue
        metadata, body = _parse_frontmatter(path.read_text(encoding="utf-8"))
        tags = metadata.get("tags") or []
        if isinstance(tags, str):
            tags = [tags]
        skill_id = relative.with_suffix("").as_posix()
        documents.append(
            SkillDocument.create(
                skill_id=skill_id,
                title=str(metadata.get("name") or path.stem),
                description=str(metadata.get("description") or ""),
                body=body,
                metadata={
                    "category": relative.parent.as_posix(),
                    "tags": " ".join(str(tag) for tag in tags),
                },
                provenance={"provider": "pkm", "collection": "skills"},
                content_type=ContentType.SKILL,
                source_uri=f"pkm://skills/{skill_id}",
                read_only=True,
            )
        )
        paths[skill_id] = path
    return documents, paths


def benchmark_feature_selectors() -> dict[str, RetrievalPerspective]:
    return {
        "coding": RetrievalPerspective(
            name="coding-v1",
            field_repetitions={"title": 4, "description": 2, "body": 1},
            metadata_keys=("category", "tags"),
        ),
        "summary": RetrievalPerspective(
            name="summary-v1",
            field_repetitions={"title": 2, "description": 4, "body": 1},
            metadata_keys=("category", "tags"),
        ),
        "writing": RetrievalPerspective(
            name="writing-v1",
            field_repetitions={"title": 2, "description": 2, "body": 2},
            metadata_keys=("category", "tags"),
        ),
    }


def evaluate_rankings(
    cases: Sequence[BenchmarkCase],
    rankings: Mapping[str, Sequence[str]],
    *,
    k: int,
    latency_ms: float | None = None,
) -> RankingMetrics:
    if not cases:
        raise ValueError("at least one benchmark case is required")
    hits = top1 = precisions = recalls = reciprocal_ranks = average_precisions = ndcgs = 0.0
    for case in cases:
        ranked = list(rankings.get(case.case_id, ()))[:k]
        relevant_positions = [
            index
            for index, skill_id in enumerate(ranked, start=1)
            if skill_id in case.relevant_skill_ids
        ]
        hits += bool(relevant_positions)
        top1 += bool(ranked and ranked[0] in case.relevant_skill_ids)
        precisions += len(relevant_positions) / k
        recalls += len(relevant_positions) / len(case.relevant_skill_ids)
        reciprocal_ranks += 1 / relevant_positions[0] if relevant_positions else 0.0
        average_precisions += sum(
            sum(
                ranked[index - 1] in case.relevant_skill_ids
                for index in range(1, position + 1)
            )
            / position
            for position in relevant_positions
        ) / min(k, len(case.relevant_skill_ids))
        dcg = sum(1 / math.log2(position + 1) for position in relevant_positions)
        ideal_count = min(k, len(case.relevant_skill_ids))
        ideal_dcg = sum(
            1 / math.log2(position + 1)
            for position in range(1, ideal_count + 1)
        )
        ndcgs += dcg / ideal_dcg
    count = len(cases)
    return RankingMetrics(
        cases=count,
        hit_rate_at_k=hits / count,
        top1_accuracy=top1 / count,
        precision_at_k=precisions / count,
        recall_at_k=recalls / count,
        mrr=reciprocal_ranks / count,
        map_at_k=average_precisions / count,
        ndcg_at_k=ndcgs / count,
        latency_ms=latency_ms,
    )


def fuse_rankings(
    route_rankings: Mapping[str, Mapping[str, Sequence[SearchHit]]],
    cases: Sequence[BenchmarkCase],
    *,
    limit: int,
) -> dict[str, list[str]]:
    rankings: dict[str, list[str]] = {}
    for case in cases:
        fused = reciprocal_rank_fusion(
            {
                route_key: hits_by_case.get(case.case_id, ())
                for route_key, hits_by_case in route_rankings.items()
            },
            limit=limit,
        )
        rankings[case.case_id] = [hit.skill_version.skill_id for hit in fused]
    return rankings


def domain_routed_fusion(
    cases: Sequence[BenchmarkCase],
    baseline_hits: Mapping[str, Sequence[SearchHit]],
    model_selector_hits: Mapping[tuple[str, str], Mapping[str, Sequence[SearchHit]]],
    *,
    limit: int,
    include_baseline: bool = True,
) -> dict[str, list[str]]:
    fused_hits = domain_routed_fused_hits(
        cases,
        baseline_hits,
        model_selector_hits,
        limit=limit,
        include_baseline=include_baseline,
    )
    return {
        case_id: [hit.skill_version.skill_id for hit in hits]
        for case_id, hits in fused_hits.items()
    }


def domain_routed_fused_hits(
    cases: Sequence[BenchmarkCase],
    baseline_hits: Mapping[str, Sequence[SearchHit]],
    model_selector_hits: Mapping[tuple[str, str], Mapping[str, Sequence[SearchHit]]],
    *,
    limit: int,
    include_baseline: bool = True,
) -> dict[str, list[FusedHit]]:
    rankings: dict[str, list[FusedHit]] = {}
    models = sorted({model for model, _ in model_selector_hits})
    for case in cases:
        participating: dict[str, Sequence[SearchHit]] = {}
        if include_baseline:
            participating["bm25"] = baseline_hits.get(case.case_id, ())
        for model in models:
            participating[model] = model_selector_hits[(model, case.domain)].get(
                case.case_id, ()
            )
        fused = reciprocal_rank_fusion(participating, limit=limit)
        rankings[case.case_id] = fused
    return rankings


def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        return {}, text
    frontmatter, separator, body = text[4:].partition("\n---\n")
    if not separator:
        return {}, text
    metadata = yaml.safe_load(frontmatter) or {}
    if not isinstance(metadata, dict):
        raise ValueError("Skill frontmatter must be a mapping")
    return metadata, body