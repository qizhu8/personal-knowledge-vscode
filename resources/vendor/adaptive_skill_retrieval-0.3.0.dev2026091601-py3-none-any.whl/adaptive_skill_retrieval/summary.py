from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Sequence


@dataclass(slots=True)
class _RouteAccumulator:
    route_key: str
    state: str | None = None
    index_versions: set[str] = field(default_factory=set)
    current_index_version: str | None = None
    impressions: int = 0
    selected_impressions: int = 0
    strength_total: float = 0.0
    strength_samples: int = 0
    labeled_successes: int = 0
    successful_outcomes: int = 0
    retrieved_labels: int = 0
    relevant_labels: int = 0
    true_positives: int = 0
    training_runs: set[str] = field(default_factory=set)
    training_iterations: set[tuple[str, int]] = field(default_factory=set)
    latest_iteration: int | None = None
    learning_rate: float | None = None
    loss: float | None = None
    training_metrics: dict[str, float] = field(default_factory=dict)
    training_history: list[dict[str, Any]] = field(default_factory=list)


def _ratio(numerator: int | float, denominator: int | float) -> float | None:
    return numerator / denominator if denominator else None


def _versions(values: Sequence[dict[str, Any]]) -> set[tuple[str, str]]:
    return {(value["skill_id"], value["content_hash"]) for value in values}


def build_dashboard_summary(events: Sequence[dict[str, Any]]) -> dict[str, Any]:
    outcomes = {
        event["query_id"]: event
        for event in events
        if event.get("event_type") == "outcome"
    }
    accumulators: dict[str, _RouteAccumulator] = {}
    impression_count = 0

    for event in events:
        if event.get("event_type") == "training_iteration":
            route_key = event["route_key"]
            route = accumulators.setdefault(route_key, _RouteAccumulator(route_key))
            run_id = event["training_run_id"]
            iteration = int(event["iteration"])
            route.training_runs.add(run_id)
            route.training_iterations.add((run_id, iteration))
            route.latest_iteration = iteration
            route.learning_rate = float(event["learning_rate"])
            route.loss = float(event["loss"])
            route.training_metrics = {
                key: float(value) for key, value in event.get("metrics", {}).items()
            }
            route.training_history.append(
                {
                    "training_run_id": run_id,
                    "iteration": iteration,
                    "learning_rate": route.learning_rate,
                    "loss": route.loss,
                    "metrics": route.training_metrics,
                }
            )
            continue
        if event.get("event_type") != "impression":
            continue

        impression_count += 1
        outcome = outcomes.get(event["query_id"])
        relevant: set[tuple[str, str]] = set()
        if outcome is not None:
            labels = outcome.get("used_skills") or outcome.get("selected_skills") or []
            relevant = _versions(labels)

        serving_routes = set(event.get("serving_routes", ()))
        for route_event in event.get("routes", ()):
            route_key = route_event["route_key"]
            route = accumulators.setdefault(route_key, _RouteAccumulator(route_key))
            route.state = route_event.get("state")
            index_version = route_event.get("index_version")
            if index_version:
                route.index_versions.add(index_version)
                route.current_index_version = index_version
            route.impressions += 1
            selected = route_event.get("selected", route_key in serving_routes)
            if selected:
                route.selected_impressions += 1
                if outcome is not None and outcome.get("success") is not None:
                    route.labeled_successes += 1
                    route.successful_outcomes += int(bool(outcome["success"]))
            strength = route_event.get("strength")
            if strength is not None:
                route.strength_total += float(strength)
                route.strength_samples += 1
            if relevant:
                retrieved = _versions(route_event.get("hits", ()))
                route.retrieved_labels += len(retrieved)
                route.relevant_labels += len(relevant)
                route.true_positives += len(retrieved & relevant)

    routes = []
    for route in sorted(accumulators.values(), key=lambda value: value.route_key):
        routes.append(
            {
                "route_key": route.route_key,
                "state": route.state,
                "current_index_version": route.current_index_version,
                "index_version_count": len(route.index_versions),
                "impressions": route.impressions,
                "selected_impressions": route.selected_impressions,
                "selection_rate": _ratio(
                    route.selected_impressions, route.impressions
                ),
                "routing_strength": _ratio(
                    route.strength_total, route.strength_samples
                ),
                "labeled_successes": route.labeled_successes,
                "success_rate": _ratio(
                    route.successful_outcomes, route.labeled_successes
                ),
                "precision": _ratio(route.true_positives, route.retrieved_labels),
                "recall": _ratio(route.true_positives, route.relevant_labels),
                "training": {
                    "run_count": len(route.training_runs),
                    "iteration_count": len(route.training_iterations),
                    "latest_iteration": route.latest_iteration,
                    "learning_rate": route.learning_rate,
                    "loss": route.loss,
                    "metrics": route.training_metrics,
                    "history": route.training_history,
                },
            }
        )

    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "totals": {
            "impressions": impression_count,
            "outcomes": len(outcomes),
            "routes": len(routes),
        },
        "routes": routes,
    }