from __future__ import annotations

import re
from collections import Counter
from dataclasses import asdict, dataclass
from typing import Sequence

from .models import SkillDocument
from .retrievers import tokenize


_SLUG_PATTERN = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True, slots=True)
class SkillPathCandidate:
    category: str
    skill_id: str
    score: float


@dataclass(frozen=True, slots=True)
class SkillPathSuggestion:
    category: str
    skill_id: str
    confidence: float
    alternatives: tuple[str, ...]
    neighboring_skills: tuple[str, ...]
    reasons: tuple[str, ...]
    reason_codes: tuple[str, ...]
    candidate_paths: tuple[SkillPathCandidate, ...]

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


_TOP_LEVEL_SIGNALS = {
    "Ads": (
        "advertising", "advertiser", "ads", "campaign", "creative", "monetization",
        "singularity", "广告", "广告主", "投放",
    ),
    "Coding": (
        "code", "coding", "implementation", "library", "parser", "api", "algorithm",
        "python", "typescript", "c#", "scope", "编程", "代码", "实现", "算法",
    ),
    "Design": (
        "design system", "visual design", "interaction design", "typography", "ux",
        "设计系统", "视觉设计", "交互设计",
    ),
    "DevOps": (
        "deploy", "deployment", "release", "docker", "container", "ci/cd", "pipeline",
        "service operation", "infrastructure", "发布", "部署", "容器", "运维",
    ),
    "Presentation": (
        "presentation", "slide", "deck", "storytelling", "visualization artifact",
        "演示文稿", "幻灯片", "汇报",
    ),
    "Research": (
        "research", "experiment", "hypothesis", "evaluation", "literature", "retrieval",
        "ranking", "研究", "实验", "假设", "评估", "检索", "排序",
    ),
    "System": (
        "pkm schema", "skill registry", "mcp protocol", "system internals",
        "系统内部", "注册表", "协议",
    ),
    "User": (
        "my machine", "my account", "personal preference", "private convention",
        "我的机器", "我的账号", "个人偏好", "个人约定",
    ),
}


class SkillPathRecommender:
    def __init__(self, documents: Sequence[SkillDocument]) -> None:
        self.documents = tuple(documents)

    def recommend(
        self,
        *,
        name: str,
        description: str,
        content: str = "",
        tags: Sequence[str] = (),
        source_project: str = "",
        limit: int = 5,
    ) -> SkillPathSuggestion:
        if not name.strip() or not description.strip():
            raise ValueError("name and description are required")
        requested_slug = _slugify(name)
        existing = next(
            (
                document
                for document in self.documents
                if _slugify(document.title) == requested_slug
                or _slugify(document.version.skill_id.rsplit("/", 1)[-1])
                == requested_slug
            ),
            None,
        )
        if existing is not None:
            category = str(existing.metadata.get("category") or "General")
            return SkillPathSuggestion(
                category=category,
                skill_id=existing.version.skill_id,
                confidence=1.0,
                alternatives=(),
                neighboring_skills=(existing.version.skill_id,),
                reasons=("An existing Skill already owns this name; update it instead of creating a duplicate.",),
                reason_codes=("existing_name_owner",),
                candidate_paths=(
                    SkillPathCandidate(
                        category=category,
                        skill_id=existing.version.skill_id,
                        score=1.0,
                    ),
                ),
            )
        text = " ".join((name, description, content, " ".join(tags))).casefold()
        top_scores = Counter(
            {
                category: sum(1 for signal in signals if signal in text)
                for category, signals in _TOP_LEVEL_SIGNALS.items()
            }
        )
        reasons: list[str] = []
        reason_codes: list[str] = []
        if source_project.strip():
            top_scores["Project"] += 4
            reasons.append(f"Bound to source project '{source_project.strip()}'.")
            reason_codes.append("source_project_owner")

        neighbor_pool = self._neighbors(text, limit=max(20, limit * 4))
        neighbors = neighbor_pool[: max(1, limit)]
        neighbor_votes: Counter[str] = Counter()
        for document, score in neighbor_pool:
            category = str(document.metadata.get("category") or "General")
            top_level = category.split("/", 1)[0]
            neighbor_votes[top_level] += score
        for category, score in neighbor_votes.items():
            top_scores[category] += min(2.0, score / 4.0)

        if not top_scores or max(top_scores.values(), default=0) <= 0:
            top_level = "General"
            reasons.append("No strong ownership signal; use the cross-project fallback.")
            reason_codes.append("general_fallback")
        else:
            top_level = sorted(top_scores, key=lambda key: (-top_scores[key], key))[0]
            reasons.append(f"Strongest taxonomy ownership signal is {top_level}.")
            reason_codes.append("taxonomy_ownership_signal")

        category = self._choose_category(
            top_level, neighbor_pool, source_project, text
        )
        if neighbors:
            reasons.append(f"Nearest existing Skill directories support '{category}'.")
            reason_codes.append("neighbor_directory_support")
        alternatives = tuple(
            candidate
            for candidate in self._rank_categories(
                top_scores, neighbor_pool, source_project, text
            )
            if candidate != category
        )[:3]
        strongest = float(top_scores.get(top_level, 0))
        confidence = min(0.95, 0.45 + 0.1 * strongest + (0.1 if neighbors else 0.0))
        candidate_categories = (category, *alternatives)
        return SkillPathSuggestion(
            category=category,
            skill_id=f"{category}/{requested_slug}",
            confidence=round(confidence, 3),
            alternatives=alternatives,
            neighboring_skills=tuple(
                document.version.skill_id for document, _ in neighbors
            ),
            reasons=tuple(reasons),
            reason_codes=tuple(reason_codes),
            candidate_paths=tuple(
                SkillPathCandidate(
                    category=candidate,
                    skill_id=f"{candidate}/{requested_slug}",
                    score=round(max(0.0, confidence - index * 0.1), 3),
                )
                for index, candidate in enumerate(candidate_categories)
            ),
        )

    def _neighbors(
        self, query: str, *, limit: int
    ) -> list[tuple[SkillDocument, float]]:
        query_terms = set(tokenize(query))
        scored: list[tuple[SkillDocument, float]] = []
        for document in self.documents:
            candidate = " ".join(
                (
                    document.title,
                    document.description,
                    str(document.metadata.get("category") or ""),
                    str(document.metadata.get("tags") or ""),
                )
            )
            candidate_terms = set(tokenize(candidate))
            overlap = len(query_terms & candidate_terms)
            if overlap:
                scored.append((document, overlap / max(1, len(query_terms))))
        scored.sort(key=lambda item: (-item[1], item[0].version.skill_id))
        return scored[:limit]

    @staticmethod
    def _choose_category(
        top_level: str,
        neighbors: Sequence[tuple[SkillDocument, float]],
        source_project: str,
        query: str,
    ) -> str:
        votes: Counter[str] = Counter()
        query_terms = set(tokenize(query))
        for document, score in neighbors:
            category = str(document.metadata.get("category") or "General")
            if category.split("/", 1)[0] == top_level:
                votes[category] += score
                category_terms = set(tokenize(category.replace("/", " ")))
                votes[category] += len(query_terms & category_terms)
        if votes:
            return sorted(votes, key=lambda key: (-votes[key], key))[0]
        if top_level == "Project" and source_project.strip():
            return f"Project/{_display_segment(source_project)}"
        return top_level

    def _rank_categories(
        self,
        top_scores: Counter[str],
        neighbors: Sequence[tuple[SkillDocument, float]],
        source_project: str,
        query: str,
    ) -> list[str]:
        ranked_top = sorted(top_scores, key=lambda key: (-top_scores[key], key))
        categories = [
            self._choose_category(top_level, neighbors, source_project, query)
            for top_level in ranked_top
            if top_scores[top_level] > 0
        ]
        categories.append("General")
        return list(dict.fromkeys(categories))


def _slugify(value: str) -> str:
    slug = _SLUG_PATTERN.sub("-", value.casefold()).strip("-")
    if not slug:
        raise ValueError("name must contain an ASCII letter or number")
    return slug


def _display_segment(value: str) -> str:
    words = [word for word in _SLUG_PATTERN.split(value.casefold()) if word]
    return " ".join(word.capitalize() for word in words) or "Uncategorized"