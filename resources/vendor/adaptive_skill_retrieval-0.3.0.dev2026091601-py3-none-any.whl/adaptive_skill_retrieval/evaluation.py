from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .engine import RetrievalResult


@dataclass(frozen=True, slots=True)
class EvaluationCase:
    result: RetrievalResult
    relevant_skill_ids: frozenset[str]


@dataclass(frozen=True, slots=True)
class RouteContribution:
    route_key: str
    cases: int
    standalone_success_rate: float
    incremental_success_rate: float
    conditional_residual_coverage: float
    unique_success_rate: float
    estimated_cost_per_incremental_success: float | None


def _route_succeeds(case: EvaluationCase, route_key: str) -> bool:
    return any(
        hit.skill_version.skill_id in case.relevant_skill_ids
        for hit in case.result.route_hits.get(route_key, ())
    )


def evaluate_route_contributions(
    cases: Sequence[EvaluationCase],
    *,
    baseline_routes: frozenset[str],
    route_costs: Mapping[str, float] | None = None,
) -> dict[str, RouteContribution]:
    if not cases:
        return {}
    route_costs = route_costs or {}
    all_routes = sorted(
        {
            route_key
            for case in cases
            for route_key in case.result.route_hits
        }
    )
    baseline_successes = [
        any(_route_succeeds(case, route_key) for route_key in baseline_routes)
        for case in cases
    ]
    residual_count = sum(not success for success in baseline_successes)
    contributions: dict[str, RouteContribution] = {}
    for route_key in all_routes:
        route_successes = [_route_succeeds(case, route_key) for case in cases]
        incremental = sum(
            route_success and not baseline_success
            for route_success, baseline_success in zip(
                route_successes, baseline_successes
            )
        )
        unique = sum(
            route_success
            and not any(
                _route_succeeds(case, other_route)
                for other_route in all_routes
                if other_route != route_key
            )
            for case, route_success in zip(cases, route_successes)
        )
        cost = route_costs.get(route_key, 0.0)
        cost_per_incremental = None if incremental == 0 else cost * len(cases) / incremental
        contributions[route_key] = RouteContribution(
            route_key=route_key,
            cases=len(cases),
            standalone_success_rate=sum(route_successes) / len(cases),
            incremental_success_rate=incremental / len(cases),
            conditional_residual_coverage=(
                incremental / residual_count if residual_count else 0.0
            ),
            unique_success_rate=unique / len(cases),
            estimated_cost_per_incremental_success=cost_per_incremental,
        )
    return contributions
