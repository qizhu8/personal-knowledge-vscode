from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Sequence

import torch
from torch import Tensor, nn
from torch.nn import functional as F


@dataclass(frozen=True, slots=True)
class MultiPerspectiveOutput:
    route_scores: Tensor
    perspective_weights: Tensor
    fused_scores: Tensor


class MultiPerspectiveEmbeddingModel(nn.Module):
    def __init__(
        self,
        *,
        input_dimensions: int,
        projection_dimensions: int,
        perspectives: Sequence[str],
    ) -> None:
        super().__init__()
        if input_dimensions <= 0 or projection_dimensions <= 0:
            raise ValueError("embedding dimensions must be positive")
        if not perspectives or len(set(perspectives)) != len(perspectives):
            raise ValueError("perspectives must be non-empty and unique")
        self.input_dimensions = input_dimensions
        self.projection_dimensions = projection_dimensions
        self.perspectives = tuple(perspectives)
        self.query_projections = nn.ModuleList(
            nn.Linear(input_dimensions, projection_dimensions, bias=False)
            for _ in self.perspectives
        )
        self.document_projections = nn.ModuleList(
            nn.Linear(input_dimensions, projection_dimensions, bias=False)
            for _ in self.perspectives
        )
        self.query_gate = nn.Linear(input_dimensions, len(self.perspectives))

    @property
    def configuration_hash(self) -> str:
        configuration = ":".join(
            (
                str(self.input_dimensions),
                str(self.projection_dimensions),
                *self.perspectives,
            )
        )
        return sha256(configuration.encode("utf-8")).hexdigest()

    def forward(
        self,
        query_embeddings: Tensor,
        document_embeddings: Tensor,
    ) -> MultiPerspectiveOutput:
        if query_embeddings.ndim != 2:
            raise ValueError("query_embeddings must have shape [batch, dimensions]")
        if document_embeddings.ndim != 3:
            raise ValueError(
                "document_embeddings must have shape [batch, candidates, dimensions]"
            )
        if query_embeddings.shape[0] != document_embeddings.shape[0]:
            raise ValueError("query and document batch dimensions must match")
        if (
            query_embeddings.shape[-1] != self.input_dimensions
            or document_embeddings.shape[-1] != self.input_dimensions
        ):
            raise ValueError("input embedding dimensions do not match the model")

        query_views = torch.stack(
            [
                F.normalize(projector(query_embeddings), dim=-1)
                for projector in self.query_projections
            ],
            dim=1,
        )
        document_views = torch.stack(
            [
                F.normalize(projector(document_embeddings), dim=-1)
                for projector in self.document_projections
            ],
            dim=1,
        )
        route_scores = torch.einsum("bpd,bpcd->bpc", query_views, document_views)
        perspective_weights = torch.softmax(self.query_gate(query_embeddings), dim=-1)
        fused_scores = torch.einsum(
            "bp,bpc->bc", perspective_weights, route_scores
        )
        return MultiPerspectiveOutput(
            route_scores=route_scores,
            perspective_weights=perspective_weights,
            fused_scores=fused_scores,
        )

    def conditional_document_similarity(
        self,
        query_embeddings: Tensor,
        left_document_embeddings: Tensor,
        right_document_embeddings: Tensor,
    ) -> Tensor:
        if query_embeddings.ndim != 2:
            raise ValueError("query_embeddings must have shape [batch, dimensions]")
        if (
            left_document_embeddings.shape != query_embeddings.shape
            or right_document_embeddings.shape != query_embeddings.shape
        ):
            raise ValueError(
                "query and paired document embeddings must have matching shapes"
            )
        if query_embeddings.shape[-1] != self.input_dimensions:
            raise ValueError("input embedding dimensions do not match the model")

        perspective_weights = torch.softmax(self.query_gate(query_embeddings), dim=-1)
        left_views = torch.stack(
            [
                F.normalize(projector(left_document_embeddings), dim=-1)
                for projector in self.document_projections
            ],
            dim=1,
        )
        right_views = torch.stack(
            [
                F.normalize(projector(right_document_embeddings), dim=-1)
                for projector in self.document_projections
            ],
            dim=1,
        )
        perspective_similarities = torch.einsum(
            "bpd,bpd->bp", left_views, right_views
        )
        return torch.einsum(
            "bp,bp->b", perspective_weights, perspective_similarities
        )


def explicit_multi_positive_loss(
    scores: Tensor,
    positive_mask: Tensor,
    negative_mask: Tensor,
    *,
    temperature: float = 0.05,
) -> Tensor:
    if scores.ndim != 2:
        raise ValueError("scores must have shape [batch, candidates]")
    positives = positive_mask.to(device=scores.device, dtype=torch.bool)
    negatives = negative_mask.to(device=scores.device, dtype=torch.bool)
    if positives.shape != scores.shape or negatives.shape != scores.shape:
        raise ValueError("label masks must have the same shape as scores")
    if bool((positives & negatives).any()):
        raise ValueError("a candidate cannot be both positive and negative")
    if not bool(positives.any(dim=-1).all()):
        raise ValueError("every query must have at least one explicit positive")
    if temperature <= 0:
        raise ValueError("temperature must be positive")

    labeled = positives | negatives
    logits = scores / temperature
    denominator = torch.logsumexp(
        logits.masked_fill(~labeled, float("-inf")), dim=-1
    )
    numerator = torch.logsumexp(
        logits.masked_fill(~positives, float("-inf")), dim=-1
    )
    return (denominator - numerator).mean()


def perspective_gate_loss(
    perspective_weights: Tensor,
    target_mask: Tensor,
) -> Tensor:
    if perspective_weights.ndim != 2:
        raise ValueError("perspective_weights must have shape [batch, perspectives]")
    targets = target_mask.to(
        device=perspective_weights.device,
        dtype=perspective_weights.dtype,
    )
    if targets.shape != perspective_weights.shape:
        raise ValueError("target_mask must match perspective_weights")
    target_mass = targets.sum(dim=-1, keepdim=True)
    if bool((target_mass <= 0).any()):
        raise ValueError("every query must select at least one perspective")
    targets = targets / target_mass
    return -(targets * perspective_weights.clamp_min(1e-12).log()).sum(dim=-1).mean()


def conditional_shortcut_loss(
    similarities: Tensor,
    similar_targets: Tensor,
    observed_mask: Tensor,
    *,
    temperature: float = 0.1,
) -> Tensor:
    if similarities.ndim != 1:
        raise ValueError("similarities must have shape [pairs]")
    targets = similar_targets.to(device=similarities.device, dtype=similarities.dtype)
    observed = observed_mask.to(device=similarities.device, dtype=torch.bool)
    if targets.shape != similarities.shape or observed.shape != similarities.shape:
        raise ValueError("shortcut labels and observed_mask must match similarities")
    if not bool(observed.any()):
        raise ValueError("at least one shortcut label must be observed")
    if bool(((targets < 0) | (targets > 1)).any()):
        raise ValueError("similarity targets must be between 0 and 1")
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    losses = F.binary_cross_entropy_with_logits(
        similarities / temperature,
        targets,
        reduction="none",
    )
    return losses[observed].mean()