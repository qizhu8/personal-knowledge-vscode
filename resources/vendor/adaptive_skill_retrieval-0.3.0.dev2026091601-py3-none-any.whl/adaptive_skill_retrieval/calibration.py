from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol, Sequence


class Calibrator(Protocol):
    def fit(self, scores: Sequence[float], labels: Sequence[int]) -> None: ...
    def predict(self, scores: Sequence[float]) -> list[float]: ...


@dataclass(frozen=True, slots=True)
class ReliabilityBin:
    lower: float
    upper: float
    count: int
    mean_confidence: float | None
    empirical_accuracy: float | None


@dataclass(frozen=True, slots=True)
class CalibrationMetrics:
    samples: int
    positives: int
    brier_score: float
    log_loss: float
    expected_calibration_error: float
    bins: tuple[ReliabilityBin, ...]


class PlattCalibrator:
    def __init__(self, *, learning_rate: float = 0.05, iterations: int = 2000) -> None:
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.slope = 1.0
        self.intercept = 0.0
        self.mean = 0.0
        self.scale = 1.0

    def fit(self, scores: Sequence[float], labels: Sequence[int]) -> None:
        _validate(scores, labels)
        self.mean = sum(scores) / len(scores)
        variance = sum((score - self.mean) ** 2 for score in scores) / len(scores)
        self.scale = math.sqrt(variance) or 1.0
        normalized = [(score - self.mean) / self.scale for score in scores]
        positive_rate = min(1 - 1e-6, max(1e-6, sum(labels) / len(labels)))
        self.slope = 1.0
        self.intercept = math.log(positive_rate / (1 - positive_rate))
        for _ in range(self.iterations):
            probabilities = [
                _sigmoid(self.slope * score + self.intercept)
                for score in normalized
            ]
            slope_gradient = sum(
                (probability - label) * score
                for probability, label, score in zip(
                    probabilities, labels, normalized
                )
            ) / len(labels)
            intercept_gradient = sum(
                probability - label
                for probability, label in zip(probabilities, labels)
            ) / len(labels)
            self.slope = max(0.0, self.slope - self.learning_rate * slope_gradient)
            self.intercept -= self.learning_rate * intercept_gradient

    def predict(self, scores: Sequence[float]) -> list[float]:
        return [
            _sigmoid(self.slope * ((score - self.mean) / self.scale) + self.intercept)
            for score in scores
        ]


class IsotonicCalibrator:
    def __init__(self) -> None:
        self._upper_bounds: list[float] = []
        self._values: list[float] = []

    def fit(self, scores: Sequence[float], labels: Sequence[int]) -> None:
        _validate(scores, labels)
        blocks = [[score, score, float(label), 1] for score, label in sorted(zip(scores, labels))]
        index = 0
        while index < len(blocks) - 1:
            if blocks[index][2] / blocks[index][3] <= blocks[index + 1][2] / blocks[index + 1][3]:
                index += 1
                continue
            blocks[index : index + 2] = [[
                blocks[index][0],
                blocks[index + 1][1],
                blocks[index][2] + blocks[index + 1][2],
                blocks[index][3] + blocks[index + 1][3],
            ]]
            index = max(0, index - 1)
        self._upper_bounds = [float(block[1]) for block in blocks]
        self._values = [float(block[2]) / int(block[3]) for block in blocks]

    def predict(self, scores: Sequence[float]) -> list[float]:
        if not self._upper_bounds:
            raise RuntimeError("calibrator must be fitted before prediction")
        return [
            self._values[next((index for index, upper in enumerate(self._upper_bounds) if score <= upper), len(self._values) - 1)]
            for score in scores
        ]


def evaluate_calibration(probabilities: Sequence[float], labels: Sequence[int], *, bin_count: int = 10) -> CalibrationMetrics:
    _validate(probabilities, labels)
    clipped = [min(1 - 1e-12, max(1e-12, value)) for value in probabilities]
    brier = sum((probability - label) ** 2 for probability, label in zip(clipped, labels)) / len(labels)
    log_loss = -sum(label * math.log(probability) + (1 - label) * math.log(1 - probability) for probability, label in zip(clipped, labels)) / len(labels)
    bins = []
    ece = 0.0
    for index in range(bin_count):
        lower, upper = index / bin_count, (index + 1) / bin_count
        members = [(probability, label) for probability, label in zip(clipped, labels) if lower <= probability < upper or (index == bin_count - 1 and probability == 1)]
        confidence = sum(item[0] for item in members) / len(members) if members else None
        accuracy = sum(item[1] for item in members) / len(members) if members else None
        if members:
            ece += len(members) / len(labels) * abs(confidence - accuracy)
        bins.append(ReliabilityBin(lower, upper, len(members), confidence, accuracy))
    return CalibrationMetrics(len(labels), sum(labels), brier, log_loss, ece, tuple(bins))


def threshold_metrics(top_probabilities: Sequence[float], top_labels: Sequence[int], thresholds: Sequence[float]) -> list[dict[str, float | int | None]]:
    _validate(top_probabilities, top_labels)
    rows = []
    for threshold in thresholds:
        accepted = [label for probability, label in zip(top_probabilities, top_labels) if probability >= threshold]
        rows.append({
            "threshold": threshold,
            "accepted": len(accepted),
            "coverage": len(accepted) / len(top_labels),
            "precision": sum(accepted) / len(accepted) if accepted else None,
        })
    return rows


def _validate(values: Sequence[float], labels: Sequence[int]) -> None:
    if len(values) != len(labels) or not labels:
        raise ValueError("values and labels must be non-empty and aligned")
    if any(label not in {0, 1} for label in labels):
        raise ValueError("calibration labels must be binary")


def _sigmoid(value: float) -> float:
    if value >= 0:
        return 1 / (1 + math.exp(-value))
    exponential = math.exp(value)
    return exponential / (1 + exponential)