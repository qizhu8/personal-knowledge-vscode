from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Mapping, Sequence

from .models import SkillVersion
from .retrievers import SearchHit


@dataclass(frozen=True, slots=True)
class FusedHit:
    skill_version: SkillVersion
    score: float
    rank: int
    contributing_routes: tuple[str, ...]


def reciprocal_rank_fusion(
    route_hits: Mapping[str, Sequence[SearchHit]],
    *,
    limit: int,
    rank_constant: int = 60,
) -> list[FusedHit]:
    scores: defaultdict[SkillVersion, float] = defaultdict(float)
    routes: defaultdict[SkillVersion, set[str]] = defaultdict(set)
    for route_key, hits in route_hits.items():
        for hit in hits:
            scores[hit.skill_version] += 1.0 / (rank_constant + hit.rank)
            routes[hit.skill_version].add(route_key)
    ordered = sorted(
        scores,
        key=lambda version: (-scores[version], version.skill_id, version.content_hash),
    )
    return [
        FusedHit(
            skill_version=version,
            score=scores[version],
            rank=rank,
            contributing_routes=tuple(sorted(routes[version])),
        )
        for rank, version in enumerate(ordered[:limit], start=1)
    ]
