from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any, Mapping

from .engine import RetrievalResult
from .models import SkillVersion


@dataclass(frozen=True, slots=True)
class OutcomeEvent:
    query_id: str
    agent_id: str | None = None
    session_id: str | None = None
    selected_skills: tuple[SkillVersion, ...] = ()
    used_skills: tuple[SkillVersion, ...] = ()
    success: bool | None = None
    reward: float | None = None
    correction: str | None = None


@dataclass(frozen=True, slots=True)
class TrainingIterationEvent:
    route_key: str
    training_run_id: str
    iteration: int
    learning_rate: float
    loss: float
    metrics: Mapping[str, float] = field(default_factory=dict)


class JsonlTelemetryStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()

    def record_impression(
        self,
        result: RetrievalResult,
        *,
        agent_id: str | None = None,
        session_id: str | None = None,
    ) -> None:
        routes = []
        for route_key, hits in result.route_hits.items():
            routes.append(
                {
                    "route_key": route_key,
                    "state": result.route_states[route_key].value,
                    "index_version": result.route_index_versions[route_key],
                    "selected": route_key in result.serving_routes,
                    "strength": result.route_strengths.get(route_key),
                    "hits": [
                        {
                            "skill_id": hit.skill_version.skill_id,
                            "content_hash": hit.skill_version.content_hash,
                            "content_type": result.document_content_types.get(
                                hit.skill_version
                            ).value
                            if hit.skill_version in result.document_content_types
                            else None,
                            "rank": hit.rank,
                            "score": hit.score,
                        }
                        for hit in hits
                    ],
                }
            )
        self._append(
            {
                "event_type": "impression",
                "timestamp": datetime.now(UTC).isoformat(),
                "query_id": result.query_id,
                "query": result.query,
                "agent_id": agent_id,
                "session_id": session_id,
                "requested_content_types": [
                    content_type.value
                    for content_type in result.requested_content_types
                ],
                "content_type_routing": result.content_type_routing,
                "engine_index_version": result.engine_index_version,
                "serving_routes": list(result.serving_routes),
                "routes": routes,
            }
        )

    def record_outcome(self, event: OutcomeEvent) -> None:
        self._append(
            {
                "event_type": "outcome",
                "timestamp": datetime.now(UTC).isoformat(),
                "query_id": event.query_id,
                "agent_id": event.agent_id,
                "session_id": event.session_id,
                "selected_skills": [self._version(value) for value in event.selected_skills],
                "used_skills": [self._version(value) for value in event.used_skills],
                "success": event.success,
                "reward": event.reward,
                "correction": event.correction,
            }
        )

    def record_training_iteration(self, event: TrainingIterationEvent) -> None:
        self._append(
            {
                "event_type": "training_iteration",
                "timestamp": datetime.now(UTC).isoformat(),
                "route_key": event.route_key,
                "training_run_id": event.training_run_id,
                "iteration": event.iteration,
                "learning_rate": event.learning_rate,
                "loss": event.loss,
                "metrics": dict(event.metrics),
            }
        )

    def read_events(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as stream:
            return [json.loads(line) for line in stream if line.strip()]

    def _append(self, event: dict[str, Any]) -> None:
        payload = json.dumps(event, ensure_ascii=True, sort_keys=True)
        with self._lock, self.path.open("a", encoding="utf-8") as stream:
            stream.write(payload + "\n")

    @staticmethod
    def _version(version: SkillVersion) -> dict[str, str]:
        return {
            "skill_id": version.skill_id,
            "content_hash": version.content_hash,
        }
