from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from hashlib import blake2b
from typing import Any, Protocol, Sequence

from .models import ExpertIdentity, SkillDocument, SkillVersion
from .perspectives import RetrievalPerspective
from .query_intent import classify_query_intent

_TOKEN_PATTERN = re.compile(r"[\w.+#/-]+", re.UNICODE)


@dataclass(frozen=True, slots=True)
class SearchHit:
    skill_version: SkillVersion
    score: float
    rank: int
    route_key: str


class Retriever(Protocol):
    identity: ExpertIdentity

    def index(self, documents: Sequence[SkillDocument]) -> None: ...

    def search(self, query: str, limit: int) -> list[SearchHit]: ...


def tokenize(text: str) -> list[str]:
    return [token.casefold() for token in _TOKEN_PATTERN.findall(text)]


class BM25Retriever:
    def __init__(
        self,
        identity: ExpertIdentity,
        perspective: RetrievalPerspective,
        *,
        k1: float = 1.2,
        b: float = 0.75,
    ) -> None:
        self.identity = identity
        self.perspective = perspective
        self.k1 = k1
        self.b = b
        self._documents: list[SkillDocument] = []
        self._term_frequencies: list[Counter[str]] = []
        self._document_frequencies: Counter[str] = Counter()
        self._lengths: list[int] = []
        self._average_length = 0.0

    def index(self, documents: Sequence[SkillDocument]) -> None:
        self._documents = list(documents)
        self._term_frequencies = []
        self._document_frequencies = Counter()
        self._lengths = []
        for document in self._documents:
            terms = tokenize(self.perspective.prepare_document(document))
            frequencies = Counter(terms)
            self._term_frequencies.append(frequencies)
            self._document_frequencies.update(frequencies.keys())
            self._lengths.append(len(terms))
        self._average_length = (
            sum(self._lengths) / len(self._lengths) if self._lengths else 0.0
        )

    def search(self, query: str, limit: int) -> list[SearchHit]:
        if not self._documents or limit <= 0:
            return []
        query_terms = tokenize(self.perspective.prepare_query(query))
        scores: list[tuple[int, float]] = []
        document_count = len(self._documents)
        for index, frequencies in enumerate(self._term_frequencies):
            score = 0.0
            for term in query_terms:
                term_frequency = frequencies[term]
                if term_frequency == 0:
                    continue
                document_frequency = self._document_frequencies[term]
                inverse_document_frequency = math.log(
                    1 + (document_count - document_frequency + 0.5)
                    / (document_frequency + 0.5)
                )
                length_ratio = self._lengths[index] / self._average_length
                denominator = term_frequency + self.k1 * (
                    1 - self.b + self.b * length_ratio
                )
                score += inverse_document_frequency * (
                    term_frequency * (self.k1 + 1) / denominator
                )
            if score > 0:
                scores.append((index, score))
        scores.sort(key=lambda item: (-item[1], self._documents[item[0]].version.skill_id))
        return [
            SearchHit(
                skill_version=self._documents[index].version,
                score=score,
                rank=rank,
                route_key=self.identity.key,
            )
            for rank, (index, score) in enumerate(scores[:limit], start=1)
        ]


class ExactMatchRetriever:
    def __init__(self, identity: ExpertIdentity) -> None:
        self.identity = identity
        self._documents: list[SkillDocument] = []
        self._fields: list[tuple[tuple[str, float], ...]] = []

    def index(self, documents: Sequence[SkillDocument]) -> None:
        self._documents = list(documents)
        self._fields = [
            (
                (document.title.casefold(), 4.0),
                (document.version.skill_id.casefold(), 3.0),
                (document.description.casefold(), 2.0),
                (document.body.casefold(), 1.0),
                *tuple((value.casefold(), 1.0) for value in document.metadata.values()),
            )
            for document in self._documents
        ]

    def search(self, query: str, limit: int) -> list[SearchHit]:
        if limit <= 0:
            return []
        decision = classify_query_intent(query)
        if not decision.exact_terms and not decision.lexical_anchors:
            return []
        scored: list[tuple[int, float]] = []
        for index, fields in enumerate(self._fields):
            exact_scores = [
                sum(weight for value, weight in fields if term.casefold() in value)
                for term in decision.exact_terms
            ]
            if exact_scores and not all(exact_scores):
                continue
            anchor_score = sum(
                weight
                for term in decision.lexical_anchors
                for value, weight in fields
                if term.casefold() in value
            )
            if not exact_scores and not anchor_score:
                continue
            scored.append((index, sum(exact_scores) + anchor_score))
        scored.sort(
            key=lambda item: (
                -item[1],
                self._documents[item[0]].version.skill_id,
            )
        )
        return [
            SearchHit(
                skill_version=self._documents[index].version,
                score=score,
                rank=rank,
                route_key=self.identity.key,
            )
            for rank, (index, score) in enumerate(scored[:limit], start=1)
        ]


class Embedder(Protocol):
    dimensions: int

    def encode(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...


class AsymmetricEmbedder(Protocol):
    dimensions: int

    def encode_queries(
        self, texts: Sequence[str]
    ) -> list[tuple[float, ...]]: ...

    def encode_documents(
        self, texts: Sequence[str]
    ) -> list[tuple[float, ...]]: ...


class HashingEmbedder:
    """Small deterministic baseline used to exercise the embedding route contract."""

    def __init__(self, dimensions: int = 128, salt: str = "default") -> None:
        self.dimensions = dimensions
        self.salt = salt

    def encode(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return [self._encode_one(text) for text in texts]

    def encode_queries(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self.encode(texts)

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self.encode(texts)

    def _encode_one(self, text: str) -> tuple[float, ...]:
        vector = [0.0] * self.dimensions
        for token in tokenize(text):
            digest = blake2b(
                f"{self.salt}:{token}".encode("utf-8"), digest_size=16
            ).digest()
            index = int.from_bytes(digest[:8], "big") % self.dimensions
            sign = 1.0 if digest[8] & 1 else -1.0
            vector[index] += sign
        norm = math.sqrt(sum(value * value for value in vector))
        if norm:
            vector = [value / norm for value in vector]
        return tuple(vector)


class SentenceTransformerEmbedder:
    """Lazy adapter for real SentenceTransformers embedding models."""

    def __init__(
        self,
        model_name: str,
        *,
        query_prompt: str = "",
        document_prompt: str = "",
        revision: str | None = None,
        device: str | None = None,
        normalize_embeddings: bool = True,
        local_files_only: bool = False,
        backend: Any | None = None,
    ) -> None:
        if backend is None:
            from sentence_transformers import SentenceTransformer

            backend = SentenceTransformer(
                model_name,
                revision=revision,
                device=device,
                local_files_only=local_files_only,
            )
        get_dimensions = getattr(backend, "get_embedding_dimension", None)
        if get_dimensions is None:
            get_dimensions = backend.get_sentence_embedding_dimension
        dimensions = get_dimensions()
        if dimensions is None:
            raise ValueError("embedding model must report its dimensions")
        self.dimensions = int(dimensions)
        self.model_name = model_name
        self.query_prompt = query_prompt
        self.document_prompt = document_prompt
        self.normalize_embeddings = normalize_embeddings
        self._backend = backend

    def encode(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._encode(texts, "")

    def encode_queries(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._encode(texts, self.query_prompt)

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._encode(texts, self.document_prompt)

    def _encode(
        self, texts: Sequence[str], prompt: str
    ) -> list[tuple[float, ...]]:
        prepared = [f"{prompt}{text}" for text in texts]
        vectors = self._backend.encode(
            prepared,
            normalize_embeddings=self.normalize_embeddings,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [tuple(float(value) for value in vector) for vector in vectors]


class EmbeddingRetriever:
    def __init__(
        self,
        identity: ExpertIdentity,
        perspective: RetrievalPerspective,
        embedder: Embedder,
    ) -> None:
        self.identity = identity
        self.perspective = perspective
        self.embedder = embedder
        self._documents: list[SkillDocument] = []
        self._vectors: list[tuple[float, ...]] = []

    def _encode_queries(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        encoder = getattr(self.embedder, "encode_queries", self.embedder.encode)
        return encoder(texts)

    def _encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        encoder = getattr(self.embedder, "encode_documents", self.embedder.encode)
        return encoder(texts)

    def index(self, documents: Sequence[SkillDocument]) -> None:
        self._documents = list(documents)
        texts = [self.perspective.prepare_document(item) for item in self._documents]
        self._vectors = self._encode_documents(texts)

    @property
    def document_vectors(self) -> tuple[tuple[float, ...], ...]:
        return tuple(self._vectors)

    def search(self, query: str, limit: int) -> list[SearchHit]:
        if not self._documents or limit <= 0:
            return []
        query_vector = self._encode_queries(
            [self.perspective.prepare_query(query)]
        )[0]
        scores = [
            (index, sum(left * right for left, right in zip(query_vector, vector)))
            for index, vector in enumerate(self._vectors)
        ]
        scores.sort(key=lambda item: (-item[1], self._documents[item[0]].version.skill_id))
        return [
            SearchHit(
                skill_version=self._documents[index].version,
                score=score,
                rank=rank,
                route_key=self.identity.key,
            )
            for rank, (index, score) in enumerate(scores[:limit], start=1)
        ]
