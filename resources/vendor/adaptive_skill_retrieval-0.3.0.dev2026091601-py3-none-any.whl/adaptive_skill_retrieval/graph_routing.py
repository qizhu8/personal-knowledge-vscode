from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Mapping, Protocol, Sequence

from .models import SkillDocument
from .shortcuts import ConditionalShortcut, active_shortcut_neighbors
from .skill_graph import SkillGraphSnapshot, graph_node_id


TREE_SHORTCUT_EDGE_TYPES = frozenset({"CHILD_OF", "OWNED_BY"})


class DocumentEmbedder(Protocol):
    def encode(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...


@dataclass(frozen=True, slots=True)
class SphereHit:
    node_id: str
    cosine_similarity: float
    cosine_distance: float


@dataclass(frozen=True, slots=True)
class RoutingCandidate:
    node_id: str
    channels: tuple[str, ...]
    semantic_similarity: float | None
    hop_cost: float


class EmbeddingSphereIndex:
    def __init__(
        self,
        vectors: Mapping[str, Sequence[float]],
        *,
        embedding_version: str,
    ) -> None:
        if not embedding_version.strip():
            raise ValueError("embedding_version is required")
        dimensions = {len(vector) for vector in vectors.values()}
        if len(dimensions) > 1:
            raise ValueError("all embedding vectors must have the same dimensions")
        self.embedding_version = embedding_version
        self.dimensions = next(iter(dimensions), 0)
        self._vectors = {
            node_id: _normalize(vector)
            for node_id, vector in sorted(vectors.items())
        }

    def search(
        self,
        query_vector: Sequence[float],
        *,
        radius: float | None = None,
        limit: int = 20,
        exclude: Iterable[str] = (),
    ) -> list[SphereHit]:
        if limit <= 0:
            return []
        if self.dimensions and len(query_vector) != self.dimensions:
            raise ValueError("query vector dimensions do not match the index")
        if radius is not None and not 0 <= radius <= 2:
            raise ValueError("cosine radius must be between 0 and 2")
        query = _normalize(query_vector)
        excluded = set(exclude)
        hits = []
        for node_id, vector in self._vectors.items():
            if node_id in excluded:
                continue
            similarity = sum(left * right for left, right in zip(query, vector))
            similarity = max(-1.0, min(1.0, similarity))
            distance = 1.0 - similarity
            if radius is None or distance <= radius:
                hits.append(
                    SphereHit(
                        node_id=node_id,
                        cosine_similarity=similarity,
                        cosine_distance=distance,
                    )
                )
        hits.sort(key=lambda hit: (hit.cosine_distance, hit.node_id))
        return hits[:limit]


def build_skill_sphere_index(
    documents: Sequence[SkillDocument],
    embedder: DocumentEmbedder,
    *,
    embedding_version: str,
) -> EmbeddingSphereIndex:
    ordered = sorted(documents, key=lambda document: document.version.skill_id)
    texts = [
        "\n".join(
            (
                document.title,
                document.description,
                document.body,
                str(document.metadata.get("category") or ""),
                str(document.metadata.get("tags") or ""),
            )
        )
        for document in ordered
    ]
    encoder = getattr(embedder, "encode_documents", embedder.encode)
    vectors = encoder(texts)
    if len(vectors) != len(ordered):
        raise ValueError("embedder returned an unexpected number of vectors")
    return EmbeddingSphereIndex(
        {
            graph_node_id("skill", document.version.skill_id): vector
            for document, vector in zip(ordered, vectors)
        },
        embedding_version=embedding_version,
    )


def routing_candidates(
    snapshot: SkillGraphSnapshot,
    sphere_index: EmbeddingSphereIndex,
    *,
    from_node_id: str,
    query_vector: Sequence[float],
    radius: float | None,
    sphere_limit: int = 20,
    tree_hop_cost: float = 0.25,
    shortcuts: Iterable[ConditionalShortcut] = (),
    active_topics: Iterable[str] = (),
) -> list[RoutingCandidate]:
    candidates: dict[str, dict[str, object]] = {}
    for edge in snapshot.edges:
        if edge.edge_type not in TREE_SHORTCUT_EDGE_TYPES:
            continue
        if edge.source_id == from_node_id:
            neighbor_id = edge.target_id
        elif edge.target_id == from_node_id:
            neighbor_id = edge.source_id
        else:
            continue
        candidates[neighbor_id] = {
            "channels": {"tree_shortcut"},
            "semantic_similarity": None,
            "hop_cost": tree_hop_cost,
        }

    for neighbor_id, confidence in active_shortcut_neighbors(
        shortcuts,
        node_id=from_node_id,
        active_topics=active_topics,
    ):
        candidate = candidates.setdefault(
            neighbor_id,
            {
                "channels": set(),
                "semantic_similarity": None,
                "hop_cost": 1.0 - confidence,
            },
        )
        channels = candidate["channels"]
        assert isinstance(channels, set)
        channels.add("conditional_shortcut")
        candidate["hop_cost"] = min(
            float(candidate["hop_cost"]), 1.0 - confidence
        )

    for hit in sphere_index.search(
        query_vector,
        radius=radius,
        limit=sphere_limit,
        exclude=(from_node_id,),
    ):
        candidate = candidates.setdefault(
            hit.node_id,
            {
                "channels": set(),
                "semantic_similarity": None,
                "hop_cost": hit.cosine_distance,
            },
        )
        channels = candidate["channels"]
        assert isinstance(channels, set)
        channels.add("embedding_sphere")
        candidate["semantic_similarity"] = hit.cosine_similarity
        candidate["hop_cost"] = min(
            float(candidate["hop_cost"]), hit.cosine_distance
        )

    routed = [
        RoutingCandidate(
            node_id=node_id,
            channels=tuple(sorted(value["channels"])),
            semantic_similarity=(
                float(value["semantic_similarity"])
                if value["semantic_similarity"] is not None
                else None
            ),
            hop_cost=float(value["hop_cost"]),
        )
        for node_id, value in candidates.items()
    ]
    routed.sort(key=lambda candidate: (candidate.hop_cost, candidate.node_id))
    return routed


def _normalize(vector: Sequence[float]) -> tuple[float, ...]:
    values = tuple(float(value) for value in vector)
    if any(not math.isfinite(value) for value in values):
        raise ValueError("embedding vectors must contain only finite values")
    norm = math.sqrt(sum(value * value for value in values))
    if norm == 0:
        raise ValueError("embedding vectors must be non-zero")
    return tuple(value / norm for value in values)