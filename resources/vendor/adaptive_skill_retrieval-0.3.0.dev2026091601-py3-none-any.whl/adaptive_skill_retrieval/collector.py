from __future__ import annotations

import argparse
import gzip
import json
import sqlite3
import uuid
from dataclasses import asdict
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping

from .benchmark import BenchmarkCase, evaluate_rankings, load_pkm_skills
from .routes import academic_bm25_benchmark_route

COLLECTOR_SCHEMA_VERSION = 1
EVENT_TYPES = {"retrieval", "skill_load", "outcome"}
PLACEMENT_DECISIONS = {"accepted", "corrected", "create_child", "duplicate"}


class CollectorStore:
    def __init__(
        self,
        database_path: str | Path,
        *,
        pkm_root: str | Path | None = None,
        snapshots_dir: str | Path | None = None,
    ) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.pkm_root = Path(pkm_root) if pkm_root is not None else None
        self.snapshots_dir = Path(
            snapshots_dir or self.database_path.parent / "snapshots"
        )
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def append(self, event: Mapping[str, Any]) -> tuple[str, bool]:
        normalized = self._normalize(event)
        snapshot_id = None
        if normalized["event_type"] == "retrieval" and self.pkm_root is not None:
            snapshot_id = self.snapshot_corpus()
            normalized["payload"].setdefault("corpus_snapshot_id", snapshot_id)
        with self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO events (
                    event_id, interaction_id, event_type, occurred_at, received_at,
                    source_node_id, observation_source, schema_version,
                    corpus_snapshot_id, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    normalized["event_id"],
                    normalized["interaction_id"],
                    normalized["event_type"],
                    normalized["occurred_at"],
                    datetime.now(UTC).isoformat(),
                    normalized["source_node_id"],
                    normalized["observation_source"],
                    normalized["schema_version"],
                    snapshot_id or normalized["payload"].get("corpus_snapshot_id"),
                    json.dumps(
                        normalized["payload"], ensure_ascii=False, sort_keys=True
                    ),
                ),
            )
        return normalized["event_id"], cursor.rowcount == 1

    def append_many(
        self, events: Iterable[Mapping[str, Any]]
    ) -> dict[str, Any]:
        accepted = duplicates = 0
        event_ids = []
        for event in events:
            event_id, inserted = self.append(event)
            event_ids.append(event_id)
            accepted += int(inserted)
            duplicates += int(not inserted)
        return {
            "accepted": accepted,
            "duplicates": duplicates,
            "event_ids": event_ids,
        }

    def events(
        self,
        *,
        event_type: str | None = None,
        interaction_id: str | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        clauses = []
        parameters: list[Any] = []
        if event_type:
            clauses.append("event_type = ?")
            parameters.append(event_type)
        if interaction_id:
            clauses.append("interaction_id = ?")
            parameters.append(interaction_id)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        parameters.append(max(1, min(int(limit), 100_000)))
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT event_id, interaction_id, event_type, occurred_at,
                       received_at, source_node_id, observation_source,
                       schema_version, corpus_snapshot_id, payload_json
                  FROM events
                """
                + where
                + " ORDER BY rowid ASC LIMIT ?",
                parameters,
            ).fetchall()
        return [self._event_from_row(row) for row in rows]

    def summary(self) -> dict[str, Any]:
        with self._connect() as connection:
            total = connection.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            interactions = connection.execute(
                "SELECT COUNT(DISTINCT interaction_id) FROM events"
            ).fetchone()[0]
            by_type = dict(
                connection.execute(
                    "SELECT event_type, COUNT(*) FROM events GROUP BY event_type"
                ).fetchall()
            )
            nodes = connection.execute(
                "SELECT COUNT(DISTINCT source_node_id) FROM events"
            ).fetchone()[0]
            snapshots = connection.execute(
                "SELECT COUNT(DISTINCT corpus_snapshot_id) FROM events "
                "WHERE corpus_snapshot_id IS NOT NULL"
            ).fetchone()[0]
        return {
            "events": total,
            "interactions": interactions,
            "source_nodes": nodes,
            "corpus_snapshots": snapshots,
            "by_type": by_type,
        }

    def record_path_recommendation(
        self,
        *,
        draft: Mapping[str, Any],
        suggestion: Mapping[str, Any],
        taxonomy_version: str,
        corpus_snapshot_id: str,
        model_version: str,
    ) -> dict[str, Any]:
        recommendation_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        draft_json = json.dumps(dict(draft), ensure_ascii=False, sort_keys=True)
        draft_hash = sha256(draft_json.encode("utf-8")).hexdigest()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO path_recommendations (
                    recommendation_id, created_at, skill_draft_hash, draft_json,
                    suggestion_json, taxonomy_version, corpus_snapshot_id,
                    model_version
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    recommendation_id,
                    created_at,
                    draft_hash,
                    draft_json,
                    json.dumps(dict(suggestion), ensure_ascii=False, sort_keys=True),
                    taxonomy_version,
                    corpus_snapshot_id,
                    model_version,
                ),
            )
        return self.path_recommendation(recommendation_id) or {}

    def path_recommendation(self, recommendation_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT recommendation_id, created_at, skill_draft_hash, draft_json,
                       suggestion_json, taxonomy_version, corpus_snapshot_id,
                       model_version
                  FROM path_recommendations
                 WHERE recommendation_id = ?
                """,
                (recommendation_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "recommendation_id": row[0],
            "created_at": row[1],
            "skill_draft_hash": row[2],
            "draft": json.loads(row[3]),
            "suggestion": json.loads(row[4]),
            "taxonomy_version": row[5],
            "corpus_snapshot_id": row[6],
            "model_version": row[7],
        }

    def record_path_decision(
        self,
        *,
        recommendation_id: str,
        decision: str,
        accepted_category: str = "",
        existing_skill_id: str = "",
        new_child_name: str = "",
    ) -> dict[str, Any]:
        decision = decision.strip().casefold()
        if decision not in PLACEMENT_DECISIONS:
            raise ValueError(f"unsupported placement decision: {decision}")
        recommendation = self.path_recommendation(recommendation_id)
        if recommendation is None:
            raise LookupError("path recommendation not found")
        suggested_category = str(recommendation["suggestion"]["category"])
        if decision == "accepted":
            accepted_category = suggested_category
        elif decision == "corrected" and not accepted_category.strip():
            raise ValueError("accepted_category is required for corrected decisions")
        elif decision == "create_child":
            if not accepted_category.strip() or not new_child_name.strip():
                raise ValueError(
                    "accepted_category and new_child_name are required for create_child decisions"
                )
            accepted_category = (
                f"{accepted_category.strip().rstrip('/')}/{new_child_name.strip()}"
            )
        elif decision == "duplicate" and not existing_skill_id.strip():
            raise ValueError("existing_skill_id is required for duplicate decisions")
        decision_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO path_decisions (
                    decision_id, recommendation_id, created_at, decision,
                    accepted_category, existing_skill_id, new_child_name
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision_id,
                    recommendation_id,
                    created_at,
                    decision,
                    accepted_category.strip(),
                    existing_skill_id.strip(),
                    new_child_name.strip(),
                ),
            )
        return {
            "decision_id": decision_id,
            "recommendation_id": recommendation_id,
            "created_at": created_at,
            "decision": decision,
            "accepted_category": accepted_category.strip(),
            "existing_skill_id": existing_skill_id.strip(),
            "new_child_name": new_child_name.strip(),
            "taxonomy_version": recommendation["taxonomy_version"],
            "corpus_snapshot_id": recommendation["corpus_snapshot_id"],
        }

    def path_decisions(self, *, limit: int = 1000) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT d.decision_id, d.recommendation_id, d.created_at,
                       d.decision, d.accepted_category, d.existing_skill_id,
                       d.new_child_name, r.skill_draft_hash, r.draft_json,
                       r.suggestion_json, r.taxonomy_version,
                       r.corpus_snapshot_id, r.model_version
                  FROM path_decisions d
                  JOIN path_recommendations r USING (recommendation_id)
                 ORDER BY d.rowid DESC LIMIT ?
                """,
                (max(1, min(int(limit), 100_000)),),
            ).fetchall()
        return [
            {
                "decision_id": row[0],
                "recommendation_id": row[1],
                "created_at": row[2],
                "decision": row[3],
                "accepted_category": row[4],
                "existing_skill_id": row[5],
                "new_child_name": row[6],
                "skill_draft_hash": row[7],
                "draft": json.loads(row[8]),
                "suggestion": json.loads(row[9]),
                "taxonomy_version": row[10],
                "corpus_snapshot_id": row[11],
                "model_version": row[12],
            }
            for row in rows
        ]

    def training_examples(self, *, include_trashed: bool = False) -> list[dict[str, Any]]:
        with self._connect() as connection:
            trashed = dict(
                connection.execute(
                    "SELECT interaction_id, deleted_at FROM trashed_interactions"
                ).fetchall()
            )
        interactions: dict[str, dict[str, Any]] = {}
        for event in self.events(limit=100_000):
            interaction = interactions.setdefault(
                event["interaction_id"],
                {"retrieval": None, "loads": [], "outcome": None},
            )
            if event["event_type"] == "retrieval":
                interaction["retrieval"] = event
            elif event["event_type"] == "skill_load":
                interaction["loads"].append(event)
            elif event["event_type"] == "outcome":
                interaction["outcome"] = event

        examples = []
        for interaction_id, interaction in interactions.items():
            if interaction_id in trashed and not include_trashed:
                continue
            retrieval = interaction["retrieval"]
            if retrieval is None:
                continue
            payload = retrieval["payload"]
            candidates = payload.get("candidates") or []
            final_ranking = []
            for fallback_rank, candidate in enumerate(candidates, start=1):
                final_ranking.append(
                    {
                        "skill_id": candidate.get("skill_id"),
                        "content_hash": candidate.get("content_hash", ""),
                        "rank": candidate.get("rank", fallback_rank),
                        "score": candidate.get("score", 0.0),
                        "calibrated_probabilities": {},
                        "contributors": [
                            {
                                "route_key": payload.get("retriever", {}).get(
                                    "name", "pkm-skill-context"
                                ),
                                "source_rank": candidate.get("rank", fallback_rank),
                                "source_score": candidate.get("score", 0.0),
                            }
                        ],
                    }
                )
            loaded_skill_ids = [
                event["payload"].get("skill", {}).get("skill_id")
                for event in interaction["loads"]
            ]
            loaded_skill_ids = [skill_id for skill_id in loaded_skill_ids if skill_id]
            outcome_payload = (
                interaction["outcome"]["payload"].get("feedback", {})
                if interaction["outcome"]
                else {}
            )
            used_skill_ids = outcome_payload.get("used_skills") or []
            outcome = str(outcome_payload.get("outcome") or "").casefold()
            lifecycle = (
                "complete"
                if interaction["outcome"]
                else "loaded"
                if loaded_skill_ids
                else "no_match"
                if not candidates
                else "pending"
            )
            relevant_skill_ids = list(dict.fromkeys(used_skill_ids or loaded_skill_ids))
            examples.append(
                {
                    "query_id": interaction_id,
                    "interaction_id": interaction_id,
                    "query": payload.get("query", ""),
                    "domain": payload.get("domain", "live"),
                    "language": payload.get("language", "unknown"),
                    "split": "live",
                    "dataset_kind": "live",
                    "lifecycle": lifecycle,
                    "occurred_at": retrieval["occurred_at"],
                    "collected_at": retrieval["received_at"],
                    "session_id": payload.get("collector_session_id", "legacy-unknown"),
                    "source_node_id": retrieval["source_node_id"],
                    "observation_source": retrieval["observation_source"],
                    "corpus_snapshot_id": retrieval["corpus_snapshot_id"],
                    "retrieved": [
                        {
                            "route_key": payload.get("retriever", {}).get(
                                "name", "pkm-skill-context"
                            ),
                            "candidates": candidates,
                        }
                    ],
                    "final_ranking": final_ranking,
                    "selected_skill_id": loaded_skill_ids[0]
                    if loaded_skill_ids
                    else None,
                    "used_skill_id": used_skill_ids[0] if used_skill_ids else None,
                    "relevant_skill_ids": relevant_skill_ids,
                    "success": outcome in {"success", "succeeded", "completed"}
                    if interaction["outcome"]
                    else None,
                    "reward": 1.0
                    if outcome in {"success", "succeeded", "completed"}
                    else 0.0
                    if interaction["outcome"]
                    else None,
                    "deleted_at": trashed.get(interaction_id),
                }
            )
        return sorted(examples, key=lambda item: item["occurred_at"], reverse=True)

    def trash_examples(self) -> list[dict[str, Any]]:
        return [
            example
            for example in self.training_examples(include_trashed=True)
            if example["deleted_at"] is not None
        ]

    def trash_interaction(self, interaction_id: str) -> bool:
        interaction_id = interaction_id.strip()
        if not interaction_id:
            raise ValueError("interaction_id is required")
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM events WHERE interaction_id = ? LIMIT 1",
                (interaction_id,),
            ).fetchone()
            if exists is None:
                return False
            cursor = connection.execute(
                "INSERT OR IGNORE INTO trashed_interactions (interaction_id, deleted_at) VALUES (?, ?)",
                (interaction_id, datetime.now(UTC).isoformat()),
            )
        return cursor.rowcount == 1

    def restore_interaction(self, interaction_id: str) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            )
        return cursor.rowcount == 1

    def purge_interaction(self, interaction_id: str) -> bool:
        with self._connect() as connection:
            trashed = connection.execute(
                "SELECT 1 FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            ).fetchone()
            if trashed is None:
                return False
            connection.execute(
                "DELETE FROM events WHERE interaction_id = ?", (interaction_id,)
            )
            connection.execute(
                "DELETE FROM trashed_interactions WHERE interaction_id = ?",
                (interaction_id,),
            )
        return True

    def export_jsonl(self) -> str:
        return "".join(
            json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n"
            for event in self.events(limit=100_000)
        )

    def snapshot_corpus(self) -> str:
        if self.pkm_root is None:
            raise RuntimeError("pkm_root is required to snapshot the Skillset")
        documents, paths = load_pkm_skills(self.pkm_root)
        by_id = {document.version.skill_id: document for document in documents}
        entries = []
        for skill_id in sorted(paths):
            document = by_id[skill_id]
            raw = paths[skill_id].read_text(encoding="utf-8")
            entries.append(
                {
                    "skill_id": skill_id,
                    "content_hash": document.version.content_hash,
                    "title": document.title,
                    "description": document.description,
                    "body": document.body,
                    "metadata": dict(document.metadata),
                    "source_markdown": raw,
                }
            )
        manifest = [
            (entry["skill_id"], entry["content_hash"]) for entry in entries
        ]
        snapshot_id = sha256(
            json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).encode(
                "utf-8"
            )
        ).hexdigest()
        target = self.snapshots_dir / f"{snapshot_id}.json.gz"
        if not target.exists():
            temporary = target.with_suffix(".tmp")
            with gzip.open(temporary, "wt", encoding="utf-8") as stream:
                json.dump(
                    {
                        "schema_version": 1,
                        "snapshot_id": snapshot_id,
                        "created_at": datetime.now(UTC).isoformat(),
                        "skills": entries,
                    },
                    stream,
                    ensure_ascii=False,
                    sort_keys=True,
                )
            temporary.replace(target)
        return snapshot_id

    def load_snapshot(self, snapshot_id: str) -> dict[str, Any]:
        path = self.snapshots_dir / f"{snapshot_id}.json.gz"
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            return json.load(stream)

    def _normalize(self, event: Mapping[str, Any]) -> dict[str, Any]:
        event_type = str(event.get("event_type") or "")
        if event_type not in EVENT_TYPES:
            raise ValueError(f"unsupported event_type: {event_type}")
        interaction_id = str(event.get("interaction_id") or "").strip()
        if not interaction_id:
            raise ValueError("interaction_id is required")
        payload = event.get("payload") or {}
        if not isinstance(payload, dict):
            raise ValueError("payload must be an object")
        return {
            "event_id": str(event.get("event_id") or uuid.uuid4()),
            "interaction_id": interaction_id,
            "event_type": event_type,
            "occurred_at": str(
                event.get("occurred_at") or datetime.now(UTC).isoformat()
            ),
            "source_node_id": str(event.get("source_node_id") or "unknown"),
            "observation_source": str(
                event.get("observation_source") or "live_agent"
            ),
            "schema_version": int(
                event.get("schema_version") or COLLECTOR_SCHEMA_VERSION
            ),
            "payload": dict(payload),
        }

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    interaction_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    source_node_id TEXT NOT NULL,
                    observation_source TEXT NOT NULL,
                    schema_version INTEGER NOT NULL,
                    corpus_snapshot_id TEXT,
                    payload_json TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS events_interaction "
                "ON events(interaction_id, occurred_at)"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS events_type ON events(event_type)"
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS trashed_interactions (
                    interaction_id TEXT PRIMARY KEY,
                    deleted_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS path_recommendations (
                    recommendation_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    skill_draft_hash TEXT NOT NULL,
                    draft_json TEXT NOT NULL,
                    suggestion_json TEXT NOT NULL,
                    taxonomy_version TEXT NOT NULL,
                    corpus_snapshot_id TEXT NOT NULL,
                    model_version TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS path_decisions (
                    decision_id TEXT PRIMARY KEY,
                    recommendation_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    accepted_category TEXT NOT NULL,
                    existing_skill_id TEXT NOT NULL,
                    new_child_name TEXT NOT NULL,
                    FOREIGN KEY (recommendation_id)
                        REFERENCES path_recommendations(recommendation_id)
                )
                """
            )

    @staticmethod
    def _event_from_row(row: tuple[Any, ...]) -> dict[str, Any]:
        return {
            "event_id": row[0],
            "interaction_id": row[1],
            "event_type": row[2],
            "occurred_at": row[3],
            "received_at": row[4],
            "source_node_id": row[5],
            "observation_source": row[6],
            "schema_version": row[7],
            "corpus_snapshot_id": row[8],
            "payload": json.loads(row[9]),
        }


def replay_collected(store: CollectorStore) -> dict[str, Any]:
    events = store.events(limit=100_000)
    retrievals = {
        event["interaction_id"]: event
        for event in events
        if event["event_type"] == "retrieval"
    }
    final_hits: dict[str, str] = {}
    for event in events:
        if event["event_type"] != "skill_load":
            continue
        skill_id = event["payload"].get("skill", {}).get("skill_id")
        if skill_id:
            final_hits[event["interaction_id"]] = skill_id

    cases = []
    rankings: dict[str, list[str]] = {}
    historical_rankings: dict[str, list[str]] = {}
    for interaction_id, retrieval in retrievals.items():
        relevant = final_hits.get(interaction_id)
        snapshot_id = retrieval.get("corpus_snapshot_id")
        if not relevant or not snapshot_id:
            continue
        payload = retrieval["payload"]
        case = BenchmarkCase(
            case_id=interaction_id,
            domain=str(payload.get("domain") or "live"),
            language=str(payload.get("language") or "unknown"),
            query=str(payload.get("query") or ""),
            relevant_skill_ids=frozenset({relevant}),
        )
        snapshot = store.load_snapshot(snapshot_id)
        from .models import SkillDocument

        documents = [
            SkillDocument.create(
                skill_id=item["skill_id"],
                title=item["title"],
                description=item["description"],
                body=item["body"],
                metadata=item.get("metadata") or {},
            )
            for item in snapshot["skills"]
        ]
        route = academic_bm25_benchmark_route()
        route.retriever.index(documents)
        rankings[interaction_id] = [
            hit.skill_version.skill_id
            for hit in route.retriever.search(case.query, 5)
        ]
        historical_rankings[interaction_id] = [
            str(item["skill_id"])
            for item in payload.get("candidates", [])
            if item.get("skill_id")
        ]
        cases.append(case)

    if not cases:
        return {"cases": 0, "reason": "no linked retrieval and skill_load events"}
    return {
        "cases": len(cases),
        "reference": "historical final loaded Skill",
        "historical": asdict(evaluate_rankings(cases, historical_rankings, k=5)),
        "bm25_replay": asdict(evaluate_rankings(cases, rankings, k=5)),
        "case_results": {
            case.case_id: {
                "query": case.query,
                "reference_skill_id": next(iter(case.relevant_skill_ids)),
                "historical": historical_rankings[case.case_id],
                "bm25_replay": rankings[case.case_id],
            }
            for case in cases
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Replay collected PKM Skill interactions locally"
    )
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--snapshots-dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = replay_collected(
        CollectorStore(args.database, snapshots_dir=args.snapshots_dir)
    )
    payload = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    else:
        print(payload)


if __name__ == "__main__":
    main()