from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from hashlib import sha256
import json
from typing import Mapping


class RouteState(StrEnum):
    TRAINING = "training"
    SHADOW = "shadow"
    CANDIDATE = "candidate"
    SERVING = "serving"
    DEMOTED = "demoted"


class ContentType(StrEnum):
    SKILL = "skill"
    NOTE = "note"
    SCRIPT = "script"
    SUBSCRIPTION = "subscription"
    OTHER = "other"


@dataclass(frozen=True, slots=True)
class SkillVersion:
    skill_id: str
    content_hash: str


@dataclass(frozen=True, slots=True)
class SkillDocument:
    version: SkillVersion
    title: str
    description: str
    body: str
    metadata: Mapping[str, str] = field(default_factory=dict)
    provenance: Mapping[str, str] = field(default_factory=dict)
    content_type: ContentType = ContentType.SKILL
    source_uri: str = ""
    read_only: bool = False

    @classmethod
    def create(
        cls,
        *,
        skill_id: str,
        title: str,
        description: str,
        body: str,
        metadata: Mapping[str, str] | None = None,
        provenance: Mapping[str, str] | None = None,
        content_type: ContentType | str = ContentType.SKILL,
        source_uri: str = "",
        read_only: bool = False,
    ) -> SkillDocument:
        resolved_content_type = ContentType(content_type)
        canonical = json.dumps(
            {
                "content_type": resolved_content_type.value,
                "title": title,
                "description": description,
                "body": body,
                "metadata": dict(metadata or {}),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        version = SkillVersion(
            skill_id=skill_id,
            content_hash=sha256(canonical.encode("utf-8")).hexdigest(),
        )
        return cls(
            version=version,
            title=title,
            description=description,
            body=body,
            metadata=dict(metadata or {}),
            provenance=dict(provenance or {}),
            content_type=resolved_content_type,
            source_uri=source_uri,
            read_only=read_only,
        )


@dataclass(frozen=True, slots=True)
class EmbeddingModelVersion:
    provider: str
    model: str
    revision: str
    dimensions: int
    normalization: str = "l2"
    query_prompt: str = ""
    document_prompt: str = ""

    @property
    def key(self) -> str:
        prompt_hash = sha256(
            f"{self.query_prompt}\n{self.document_prompt}".encode("utf-8")
        ).hexdigest()[:12]
        return ":".join(
            (
                self.provider,
                self.model,
                self.revision,
                str(self.dimensions),
                self.normalization,
                prompt_hash,
            )
        )


@dataclass(frozen=True, slots=True)
class FeatureSelectorVersion:
    name: str
    revision: str
    configuration_hash: str

    @property
    def key(self) -> str:
        return f"{self.name}:{self.revision}:{self.configuration_hash[:12]}"


@dataclass(frozen=True, slots=True)
class CalibrationVersion:
    method: str
    revision: str
    training_data_hash: str
    parameters_hash: str

    @property
    def key(self) -> str:
        return ":".join(
            (
                self.method,
                self.revision,
                self.training_data_hash[:12],
                self.parameters_hash[:12],
            )
        )


@dataclass(frozen=True, slots=True)
class ExpertIdentity:
    name: str
    perspective: str
    model: EmbeddingModelVersion | None = None
    revision: str = "1"
    feature_selector: FeatureSelectorVersion | None = None

    @property
    def key(self) -> str:
        if self.feature_selector is None:
            model_key = "lexical"
            if self.model is not None:
                model_key = ":".join(
                    (self.model.provider, self.model.model, self.model.revision)
                )
            return f"{self.name}:{self.perspective}:{model_key}:{self.revision}"

        model_key = "lexical"
        if self.model is not None:
            model_key = self.model.key
        return (
            f"{self.name}:model={model_key}:"
            f"selector={self.feature_selector.key}:{self.revision}"
        )
