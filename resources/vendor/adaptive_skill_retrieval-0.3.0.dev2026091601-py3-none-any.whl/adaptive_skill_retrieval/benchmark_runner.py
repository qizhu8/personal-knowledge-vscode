from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping, Sequence

from .benchmark import (
    BenchmarkCase,
    RankingMetrics,
    benchmark_feature_selectors,
    domain_routed_fusion,
    domain_routed_fused_hits,
    evaluate_rankings,
    load_pkm_skills,
)
from .calibration import (
    IsotonicCalibrator,
    PlattCalibrator,
    evaluate_calibration,
    threshold_metrics,
)
from .engine import RetrievalResult
from .fusion import reciprocal_rank_fusion
from .hooks import AgentSkillHooks
from .models import CalibrationVersion, EmbeddingModelVersion, RouteState, SkillDocument
from .retrievers import SearchHit, SentenceTransformerEmbedder
from .routes import academic_bm25_benchmark_route, embedding_route
from .telemetry import JsonlTelemetryStore

MODEL_SPECS = (
    {
        "name": "intfloat/multilingual-e5-small",
        "revision": "614241f622f53c4eeff9890bdc4f31cfecc418b3",
        "query_prompt": "query: ",
        "document_prompt": "passage: ",
    },
    {
        "name": "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
        "revision": "e8f8c211226b894fcb81acc59f3b34ba3efd5f42",
        "query_prompt": "",
        "document_prompt": "",
    },
)
DEFAULT_CALIBRATION_THRESHOLD = 0.5


def load_cases(path: str | Path) -> list[BenchmarkCase]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return [
        BenchmarkCase(
            case_id=item["case_id"],
            domain=item["domain"],
            language=item["language"],
            query=item["query"],
            relevant_skill_ids=frozenset(item["relevant_skill_ids"]),
            split=item.get("split", "test"),
        )
        for item in payload
    ]


def run_multilingual_benchmark(
    *,
    pkm_root: str | Path,
    cases_path: str | Path,
    output_dir: str | Path,
    limit: int = 5,
    device: str | None = None,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    documents, paths = load_pkm_skills(pkm_root)
    cases = load_cases(cases_path)
    _validate_cases(cases, paths)

    bm25 = academic_bm25_benchmark_route()
    started = perf_counter()
    bm25.retriever.index(documents)
    bm25_index_seconds = perf_counter() - started
    bm25_hits, bm25_latency = _search(bm25.retriever, cases, limit)
    bm25_rankings = _to_skill_ids(bm25_hits)

    route_hits: dict[str, Mapping[str, Sequence[SearchHit]]] = {
        bm25.identity.key: bm25_hits
    }
    routed_hits: dict[tuple[str, str], Mapping[str, Sequence[SearchHit]]] = {}
    routed_keys: dict[tuple[str, str], str] = {}
    route_reports: dict[str, dict[str, Any]] = {
        bm25.identity.key: {
            "kind": "bm25-baseline",
            "metrics": asdict(
                evaluate_rankings(cases, bm25_rankings, k=limit, latency_ms=bm25_latency)
            ),
            "slices": _slice_metrics(cases, bm25_rankings, limit),
            "index_seconds": bm25_index_seconds,
            "rankings": bm25_rankings,
        }
    }
    selectors = benchmark_feature_selectors()

    for spec in MODEL_SPECS:
        embedder = SentenceTransformerEmbedder(
            spec["name"],
            revision=spec["revision"],
            query_prompt=spec["query_prompt"],
            document_prompt=spec["document_prompt"],
            device=device,
        )
        provider, model_name = spec["name"].split("/", 1)
        model = EmbeddingModelVersion(
            provider=provider,
            model=model_name,
            revision=spec["revision"],
            dimensions=embedder.dimensions,
            query_prompt=spec["query_prompt"],
            document_prompt=spec["document_prompt"],
        )
        for selector_name, selector in selectors.items():
            route = embedding_route(
                name="pkm-dense",
                model=model,
                feature_selector=selector,
                embedder=embedder,
                state=RouteState.SHADOW,
            )
            started = perf_counter()
            route.retriever.index(documents)
            index_seconds = perf_counter() - started
            hits, latency = _search(route.retriever, cases, limit)
            rankings = _to_skill_ids(hits)
            route_hits[route.identity.key] = hits
            routed_hits[(spec["name"], selector_name)] = hits
            routed_keys[(spec["name"], selector_name)] = route.identity.key
            route_reports[route.identity.key] = {
                "kind": "dense",
                "model": spec["name"],
                "model_revision": spec["revision"],
                "selector": selector_name,
                "selector_version": selector.version.key,
                "metrics": asdict(
                    evaluate_rankings(cases, rankings, k=limit, latency_ms=latency)
                ),
                "slices": _slice_metrics(cases, rankings, limit),
                "index_seconds": index_seconds,
                "rankings": rankings,
            }

    dense_rankings = domain_routed_fusion(
        cases, bm25_hits, routed_hits, limit=limit, include_baseline=False
    )
    hybrid_fused = domain_routed_fused_hits(
        cases, bm25_hits, routed_hits, limit=limit, include_baseline=True
    )
    analysis_hybrid_fused = domain_routed_fused_hits(
        cases,
        bm25_hits,
        routed_hits,
        limit=len(documents),
        include_baseline=True,
    )
    hybrid_rankings = {
        case_id: [hit.skill_version.skill_id for hit in hits]
        for case_id, hits in hybrid_fused.items()
    }
    baseline_metrics = evaluate_rankings(cases, bm25_rankings, k=limit)
    dense_metrics = evaluate_rankings(cases, dense_rankings, k=limit)
    hybrid_metrics = evaluate_rankings(cases, hybrid_rankings, k=limit)

    telemetry_path = output_dir / "hook-events.jsonl"
    if telemetry_path.exists():
        telemetry_path.unlink()
    hook_case = next(case for case in cases if case.language == "zh")
    hook_summary = _run_hook_probe(
        hook_case,
        hybrid_rankings[hook_case.case_id],
        documents,
        paths,
        {
            bm25.identity.key: route_hits[bm25.identity.key],
            **{
                routed_keys[(spec["name"], hook_case.domain)]: route_hits[
                    routed_keys[(spec["name"], hook_case.domain)]
                ]
                for spec in MODEL_SPECS
            },
        },
        telemetry_path,
        limit,
    )
    calibration_report, calibrated_probabilities = _calibrate(
        cases, hybrid_fused
    )
    training_examples = build_training_examples(
        cases,
        hybrid_fused,
        route_hits,
        routed_keys,
        bm25.identity.key,
        calibrated_probabilities,
        analysis_final_hits=analysis_hybrid_fused,
        hook_case_id=hook_case.case_id,
        hook_used_skill_id=hook_summary["used_skills"][0]["skill_id"],
    )
    training_data_path = output_dir / "training-examples.jsonl"
    training_data_path.write_text(
        "".join(
            json.dumps(example, ensure_ascii=False, sort_keys=True) + "\n"
            for example in training_examples
        ),
        encoding="utf-8",
    )

    report = {
        "benchmark_version": _file_hash(cases_path),
        "corpus_size": len(documents),
        "case_count": len(cases),
        "k": limit,
        "models": list(MODEL_SPECS),
        "selectors": {
            name: selector.version.key for name, selector in selectors.items()
        },
        "routes": route_reports,
        "systems": {
            "bm25": {
                "metrics": asdict(baseline_metrics),
                "slices": _slice_metrics(cases, bm25_rankings, limit),
            },
            "multilingual-dense-rag": {
                "metrics": asdict(dense_metrics),
                "slices": _slice_metrics(cases, dense_rankings, limit),
            },
            "multilingual-hybrid-rag": {
                "metrics": asdict(hybrid_metrics),
                "slices": _slice_metrics(cases, hybrid_rankings, limit),
            },
        },
        "gain_over_bm25": _metric_gain(baseline_metrics, hybrid_metrics),
        "case_results": {
            case.case_id: {
                "domain": case.domain,
                "language": case.language,
                "split": case.split,
                "query": case.query,
                "relevant_skill_ids": sorted(case.relevant_skill_ids),
                "bm25": bm25_rankings[case.case_id],
                "multilingual_dense_rag": dense_rankings[case.case_id],
                "multilingual_hybrid_rag": hybrid_rankings[case.case_id],
            }
            for case in cases
        },
        "calibration": calibration_report,
        "training_data": {
            "path": str(training_data_path),
            "count": len(training_examples),
            "examples": training_examples,
        },
        "hook_probe": hook_summary,
        "caveat": (
            "Exploratory hand-labeled benchmark. The system configuration is fixed "
            "before evaluation, but independent human relevance review is still required."
        ),
    }
    report_path = output_dir / "report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return report


def _validate_cases(cases: Sequence[BenchmarkCase], paths: Mapping[str, Path]) -> None:
    missing = sorted(
        skill_id
        for case in cases
        for skill_id in case.relevant_skill_ids
        if skill_id not in paths
    )
    if missing:
        raise ValueError(f"benchmark labels reference missing Skills: {missing}")
    if {case.domain for case in cases} != {"coding", "summary", "writing"}:
        raise ValueError("benchmark must contain coding, summary, and writing cases")
    if not {"en", "zh"}.issubset({case.language for case in cases}):
        raise ValueError("benchmark must contain English and Chinese queries")
    if {case.split for case in cases} != {"calibration", "test"}:
        raise ValueError("benchmark must contain calibration and test splits")


def _search(retriever: Any, cases: Sequence[BenchmarkCase], limit: int) -> tuple[dict[str, Sequence[SearchHit]], float]:
    started = perf_counter()
    hits = {case.case_id: retriever.search(case.query, limit) for case in cases}
    return hits, (perf_counter() - started) * 1000 / len(cases)


def _to_skill_ids(hits: Mapping[str, Sequence[SearchHit]]) -> dict[str, list[str]]:
    return {
        case_id: [hit.skill_version.skill_id for hit in case_hits]
        for case_id, case_hits in hits.items()
    }


def _slice_metrics(cases: Sequence[BenchmarkCase], rankings: Mapping[str, Sequence[str]], k: int) -> dict[str, dict[str, Any]]:
    slices: dict[str, dict[str, Any]] = {}
    for attribute in ("domain", "language"):
        values = sorted({getattr(case, attribute) for case in cases})
        for value in values:
            selected = [case for case in cases if getattr(case, attribute) == value]
            slices[f"{attribute}={value}"] = asdict(
                evaluate_rankings(selected, rankings, k=k)
            )
    return slices


def _metric_gain(baseline: RankingMetrics, candidate: RankingMetrics) -> dict[str, float]:
    return {
        field: getattr(candidate, field) - getattr(baseline, field)
        for field in (
            "hit_rate_at_k",
            "top1_accuracy",
            "precision_at_k",
            "recall_at_k",
            "mrr",
            "map_at_k",
            "ndcg_at_k",
        )
    }


def _calibrate(
    cases: Sequence[BenchmarkCase],
    fused_hits: Mapping[str, Sequence[Any]],
) -> tuple[dict[str, Any], dict[str, dict[str, dict[str, float]]]]:
    training_scores, training_labels = _calibration_samples(
        cases, fused_hits, "calibration"
    )
    test_scores, test_labels = _calibration_samples(cases, fused_hits, "test")
    training_hash = sha256(
        json.dumps(
            list(zip(training_scores, training_labels)), separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()
    methods = {
        "platt": PlattCalibrator(),
        "isotonic": IsotonicCalibrator(),
    }
    report: dict[str, Any] = {
        "training_query_count": sum(case.split == "calibration" for case in cases),
        "test_query_count": sum(case.split == "test" for case in cases),
        "training_candidate_count": len(training_labels),
        "test_candidate_count": len(test_labels),
        "methods": {},
    }
    probabilities_by_method: dict[str, dict[str, dict[str, float]]] = {}
    for name, calibrator in methods.items():
        calibrator.fit(training_scores, training_labels)
        test_probabilities = calibrator.predict(test_scores)
        metrics = evaluate_calibration(test_probabilities, test_labels)
        parameters = _calibrator_parameters(calibrator)
        parameters_hash = sha256(
            json.dumps(parameters, sort_keys=True).encode("utf-8")
        ).hexdigest()
        version = CalibrationVersion(name, "1", training_hash, parameters_hash)
        top_scores = [fused_hits[case.case_id][0].score for case in cases if case.split == "test"]
        top_labels = [
            int(fused_hits[case.case_id][0].skill_version.skill_id in case.relevant_skill_ids)
            for case in cases
            if case.split == "test"
        ]
        report["methods"][name] = {
            "version": version.key,
            "parameters": parameters,
            "test_metrics": asdict(metrics),
            "threshold_curve": threshold_metrics(
                calibrator.predict(top_scores),
                top_labels,
                (0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9),
            ),
        }
        probabilities_by_method[name] = {
            case.case_id: {
                hit.skill_version.skill_id: probability
                for hit, probability in zip(
                    fused_hits[case.case_id],
                    calibrator.predict([item.score for item in fused_hits[case.case_id]]),
                )
            }
            for case in cases
        }
    return report, probabilities_by_method


def _calibration_samples(
    cases: Sequence[BenchmarkCase],
    fused_hits: Mapping[str, Sequence[Any]],
    split: str,
) -> tuple[list[float], list[int]]:
    scores: list[float] = []
    labels: list[int] = []
    for case in cases:
        if case.split != split:
            continue
        for hit in fused_hits[case.case_id]:
            scores.append(hit.score)
            labels.append(int(hit.skill_version.skill_id in case.relevant_skill_ids))
    return scores, labels


def _calibrator_parameters(calibrator: Any) -> dict[str, Any]:
    if isinstance(calibrator, PlattCalibrator):
        return {
            "slope": calibrator.slope,
            "intercept": calibrator.intercept,
            "mean": calibrator.mean,
            "scale": calibrator.scale,
        }
    return {
        "upper_bounds": calibrator._upper_bounds,
        "values": calibrator._values,
    }


def build_training_examples(
    cases: Sequence[BenchmarkCase],
    final_hits: Mapping[str, Sequence[Any]],
    route_hits: Mapping[str, Mapping[str, Sequence[SearchHit]]],
    routed_keys: Mapping[tuple[str, str], str],
    baseline_route_key: str,
    calibrated_probabilities: Mapping[str, Mapping[str, Mapping[str, float]]],
    *,
    analysis_final_hits: Mapping[str, Sequence[Any]] | None = None,
    hook_case_id: str | None = None,
    hook_used_skill_id: str | None = None,
) -> list[dict[str, Any]]:
    examples = []
    for case in cases:
        route_keys = [baseline_route_key] + [
            routed_keys[(spec["name"], case.domain)] for spec in MODEL_SPECS
        ]
        retrieved = []
        contribution_by_skill: dict[str, list[dict[str, Any]]] = {}
        for route_key in route_keys:
            candidates = []
            for hit in route_hits[route_key][case.case_id]:
                candidate = {
                    "skill_id": hit.skill_version.skill_id,
                    "content_hash": hit.skill_version.content_hash,
                    "rank": hit.rank,
                    "score": hit.score,
                }
                candidates.append(candidate)
                contribution_by_skill.setdefault(hit.skill_version.skill_id, []).append(
                    {"route_key": route_key, "source_rank": hit.rank, "source_score": hit.score}
                )
            retrieved.append({"route_key": route_key, "candidates": candidates})
        final_ranking = [
            {
                "skill_id": hit.skill_version.skill_id,
                "content_hash": hit.skill_version.content_hash,
                "rank": hit.rank,
                "score": hit.score,
                "outside_top_k": False,
                "score_scope": "production_rrf",
                "contributors": contribution_by_skill.get(hit.skill_version.skill_id, []),
                "calibrated_probabilities": {
                    method: by_case[case.case_id][hit.skill_version.skill_id]
                    for method, by_case in calibrated_probabilities.items()
                },
            }
            for hit in final_hits[case.case_id]
        ]
        top_skill_ids = {candidate["skill_id"] for candidate in final_ranking}
        analysis_by_skill = {
            hit.skill_version.skill_id: hit
            for hit in (analysis_final_hits or {}).get(case.case_id, ())
        }
        for skill_id in sorted(case.relevant_skill_ids - top_skill_ids):
            hit = analysis_by_skill.get(skill_id)
            if hit is None:
                continue
            final_ranking.append(
                {
                    "skill_id": skill_id,
                    "content_hash": hit.skill_version.content_hash,
                    "rank": hit.rank,
                    "score": hit.score,
                    "outside_top_k": True,
                    "score_scope": "production_rrf",
                    "contributors": [],
                    "calibrated_probabilities": {},
                }
            )
        selected_skill_id = final_ranking[0]["skill_id"] if final_ranking else None
        success = selected_skill_id in case.relevant_skill_ids
        is_hook_case = case.case_id == hook_case_id
        threshold_decisions = {
            method: {
                "threshold": DEFAULT_CALIBRATION_THRESHOLD,
                "confidence": probabilities[case.case_id].get(
                    selected_skill_id, 0.0
                ),
                "decision": (
                    "accept"
                    if selected_skill_id is not None
                    and probabilities[case.case_id].get(selected_skill_id, 0.0)
                    >= DEFAULT_CALIBRATION_THRESHOLD
                    else "abstain"
                ),
            }
            for method, probabilities in calibrated_probabilities.items()
        }
        examples.append({
            "schema_version": 1,
            "query_id": case.case_id,
            "query": case.query,
            "domain": case.domain,
            "language": case.language,
            "split": case.split,
            "retrieved": retrieved,
            "final_ranking": final_ranking,
            "selected_skill_id": selected_skill_id,
            "threshold_decisions": threshold_decisions,
            "used_skill_id": hook_used_skill_id if is_hook_case else None,
            "relevant_skill_ids": sorted(case.relevant_skill_ids),
            "success": success,
            "reward": float(success),
            "observation_source": "runtime_hook_probe" if is_hook_case else "offline_benchmark",
        })
    return examples


def _run_hook_probe(
    case: BenchmarkCase,
    ranking: Sequence[str],
    documents: Sequence[SkillDocument],
    paths: Mapping[str, Path],
    route_hits: Mapping[str, Mapping[str, Sequence[SearchHit]]],
    telemetry_path: Path,
    limit: int,
) -> dict[str, Any]:
    by_id = {document.version.skill_id: document for document in documents}
    participating_hits = {
        route_key: tuple(hits.get(case.case_id, ()))
        for route_key, hits in route_hits.items()
    }
    fused = reciprocal_rank_fusion(participating_hits, limit=limit)
    result = RetrievalResult(
        query_id=f"benchmark-{case.case_id}",
        query=case.query,
        hits=tuple(fused),
        route_hits=participating_hits,
        route_states={key: RouteState.SERVING for key in participating_hits},
        route_index_versions={key: "offline-pkm-corpus" for key in participating_hits},
        serving_routes=tuple(participating_hits),
        observed_routes=tuple(participating_hits),
        route_strengths={key: 1.0 for key in participating_hits},
    )
    store = JsonlTelemetryStore(telemetry_path)
    hooks = AgentSkillHooks(store)
    select = hooks.wrap_selector(lambda: [by_id[ranking[0]].version])
    version_paths = {
        document.version: paths[document.version.skill_id] for document in documents
    }
    load = hooks.wrap_skill_loader(
        lambda version: version_paths[version].read_text(encoding="utf-8")
    )
    with hooks.trace(
        result, agent_id="offline-benchmark-agent", session_id="pkm-hook-probe"
    ) as interaction:
        selected = select()
        loaded = load(selected[0])
        success = selected[0].skill_id in case.relevant_skill_ids
        interaction.finish(success=success, reward=float(success))
    outcome = store.read_events()[-1]
    return {
        "access_mode": "local-pkm-source-of-truth",
        "query": case.query,
        "retrieved_by_route": {
            key: [hit.skill_version.skill_id for hit in hits]
            for key, hits in participating_hits.items()
        },
        "selected_skills": outcome["selected_skills"],
        "used_skills": outcome["used_skills"],
        "loaded_characters": len(loaded),
        "success": success,
        "telemetry_path": str(telemetry_path),
    }


def _file_hash(path: str | Path) -> str:
    return sha256(Path(path).read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the multilingual retrieval benchmark against real PKM Skills"
    )
    parser.add_argument(
        "--pkm-root",
        type=Path,
        default=Path.home() / "uone-knowledge" / "skills",
    )
    parser.add_argument(
        "--cases",
        type=Path,
        default=Path("experiments/pkm_multilingual_cases.json"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/pkm-multilingual-benchmark"),
    )
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()
    report = run_multilingual_benchmark(
        pkm_root=args.pkm_root,
        cases_path=args.cases,
        output_dir=args.output_dir,
        limit=args.limit,
        device=args.device,
    )
    print(json.dumps(report["systems"], ensure_ascii=False, indent=2))
    print(json.dumps({"gain_over_bm25": report["gain_over_bm25"]}, indent=2))